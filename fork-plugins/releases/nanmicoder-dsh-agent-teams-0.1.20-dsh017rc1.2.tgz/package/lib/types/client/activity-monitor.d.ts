/** Shared, demand-driven state for the AgentTeams browser monitor. */
/** One member row of a host snapshot. */
export interface ActivityMember {
    readonly id: string;
    readonly name: string;
    readonly role: string;
    readonly provider?: string;
    readonly model?: string;
    readonly reasoningEffort?: string;
    readonly executionPrompt?: string;
    readonly status?: 'idle' | 'working' | 'removed';
    readonly activity: 'working' | 'idle' | 'unknown';
    readonly progress: number;
    readonly done: number;
    readonly total: number;
    readonly currentTask: string;
    readonly unread: number;
}
/** One task row of a host snapshot. */
export interface ActivityTask {
    readonly id: string;
    readonly subject: string;
    readonly description?: string;
    readonly status: string;
    readonly state: 'blocked' | 'open' | 'running' | 'completed' | 'failed' | 'cancelled';
    readonly assignee: string;
    readonly model?: string;
    readonly dependencies: readonly string[];
    readonly depth: number;
    readonly kind?: string;
    readonly round?: number;
    readonly verdict?: string;
}
/** One team snapshot (mirrors the host TeamActivitySnapshot). */
export interface ActivityTeam {
    readonly workspace: string;
    readonly teamId: string;
    readonly name: string;
    readonly description?: string;
    readonly captainSessionId: string;
    readonly phase: 'staged' | 'running';
    readonly planReviewState?: 'awaiting_review' | 'awaiting_feedback';
    readonly halted?: boolean;
    readonly detail?: 'summary' | 'full';
    readonly detailRevision?: string;
    readonly members: readonly ActivityMember[];
    readonly tasks: readonly ActivityTask[];
    readonly messageCount: number;
    readonly captainInbox?: readonly {
        readonly from: string;
        readonly content: string;
    }[];
}
/** A successfully-created conversation card that currently needs updates. */
export interface ActivityMonitorTarget {
    readonly key: string;
    readonly sessionId: string;
    readonly teamId: string;
    /** Whether this mounted card still requires live/archive lookup. */
    readonly active: boolean;
}
/** Latest shared response data for both the floater and conversation cards. */
export interface ActivitySnapshots {
    readonly teams: readonly ActivityTeam[];
    readonly archivedTeams: readonly ActivityTeam[];
}
/** Subscribe to the mounted monitor-target list (React external-store shape). */
export declare function subscribeActivityMonitorTargets(listener: () => void): () => void;
/** Read mounted targets, including settled targets retained by visible cards. */
export declare function getActivityMonitorTargetsSnapshot(): readonly ActivityMonitorTarget[];
/**
 * Register one successful AgentTeams card as a monitoring demand.
 *
 * The returned cleanup is reference-counted so multiple cards and React
 * StrictMode remounts cannot stop another card's monitor.
 */
export declare function monitorAgentTeam(sessionId: string, teamId: string): () => void;
/** Stop polling targets whose final archived snapshot has been captured. */
export declare function settleActivityMonitorTargets(keys: ReadonlySet<string>): void;
/** Subscribe to the shared live/archive snapshot. */
export declare function subscribeActivitySnapshots(listener: () => void): () => void;
/** Read the stable shared live/archive snapshot. */
export declare function getActivitySnapshotsSnapshot(): ActivitySnapshots;
/** Publish one or both successful state-route responses. */
export declare function updateActivitySnapshots(update: Partial<ActivitySnapshots>): void;
/** Poll cadence for the live host snapshot route. */
export declare const ACTIVITY_POLL_MS = 1000;
/**
 * Low-frequency probe cadence while a cardless discovery session still owns
 * no team. The probe keeps the panel able to pick up a team created later in
 * that session (e.g. a run_code-wrapped agent_teams_create) without turning
 * every ordinary session into a one-second filesystem scan.
 */
export declare const ACTIVITY_PROBE_MS = 5000;
/** Host route serving live and archived team snapshots. */
export declare const ACTIVITY_STATE_URL = "/plugins/dsh-agent-teams/state";
export declare const ACTIVITY_HALT_URL = "/plugins/dsh-agent-teams/halt";
interface ActivityFetchResponse {
    readonly ok: boolean;
    json(): Promise<unknown>;
}
/** Injectable browser primitives used by the poll controller and its tests. */
export interface ActivityPollingRuntime {
    /** Current captain used for cold discovery and Host-side response filtering. */
    readonly discoverySessionId?: string;
    /** Captain whose staged plan may load long editor detail. Defaults to discoverySessionId. */
    readonly detailCaptainSessionId?: string;
    readonly fetchState?: (url: string, init: {
        readonly cache: 'no-store';
        readonly signal: AbortSignal;
    }) => Promise<ActivityFetchResponse>;
    readonly schedule?: (callback: () => void, intervalMs: number) => unknown;
    readonly cancel?: (timer: unknown) => void;
    readonly publishSnapshots?: (update: Partial<ActivitySnapshots>) => void;
    /** Read the latest snapshots when scoped responses must be merged. */
    readonly readSnapshots?: () => ActivitySnapshots;
    readonly settleTargets?: (keys: ReadonlySet<string>) => void;
    /** Browser visibility; hidden pages perform no activity request. */
    readonly visible?: () => boolean;
    /** Subscribe to browser visibility changes. */
    readonly subscribeVisibility?: (listener: () => void) => () => void;
}
/** Handle returned by one current-session polling loop. */
export interface ActivityPollingController {
    /** The first visible pass, exposed so offline verification can await it. */
    readonly firstTick: Promise<void>;
    /** Idempotently stop the timer and abort the current request. */
    stop(): void;
}
/**
 * Mark one staged plan's authoring fields for explicit refresh after a mutation.
 * @param captainSessionId - owning captain session id.
 * @param teamId - durable team id.
 */
export declare function invalidateActivityTeamDetail(captainSessionId: string, teamId: string): void;
/**
 * Start the single polling loop for the current session's requested targets.
 *
 * The Host receives the current captain and explicit team ids, so it filters
 * before mailbox/activity assembly. Hidden browser pages abort active work and
 * resume with an immediate pass. Staged-plan authoring fields use a separate
 * explicit detail request and remain cached until a successful plan mutation
 * invalidates them.
 */
export declare function startActivityPolling(monitorTargets: readonly ActivityMonitorTarget[], runtime?: ActivityPollingRuntime): ActivityPollingController;
export {};
