/**
 * The `subscriptions-auth` host RPC endpoints the web Settings page drives.
 * They are mounted as exact POST Fetch routes on the shared `/api` channel
 * (`/api/subscriptions-auth.<endpoint>`) and registered only when a host
 * `connection` service exists (the web profile); headless compositions load
 * the plugin without it. All business outcomes are returned as RpcResult
 * values; handlers never throw.
 */
import type { Context } from '@deepseek-ai/cordis';
import type { ImageAttachmentRef } from '@deepseek-ai/dsh-attachment';
import { type ProviderId } from './store.js';
import type { SpeedTier } from '../model-defaults.js';
import type { ProviderUsage, ResetCreditConsumeResult, ResetCreditList } from '../providers/common.js';
import type { ProxyConfigView, ProxyDraft, ProxyInput, ProxyTestResult } from '../http.js';
/**
 * Endpoint-name prefix under the shared `/api` channel: endpoint `status`
 * is served at `/api/subscriptions-auth.status`. The browser half calls
 * `rpc.call('/api', 'subscriptions-auth.status', payload)`.
 */
export declare const SUBSCRIPTIONS_AUTH_PREFIX = "subscriptions-auth.";
/** Decoded image bytes returned by the `image` endpoint. */
export interface ImageBytesResult {
    mediaType: string;
    dataBase64: string;
}
/** Decoded video bytes returned by the `video` endpoint. */
export interface VideoBytesResult {
    mediaType: string;
    dataBase64: string;
}
/** One model's speed choice: standard routing or the fast (priority) tier. */
export type { SpeedTier };
/** `speed` endpoint value: one model's stored tier plus the visibility list. */
export interface SpeedState {
    /** The stored tier for the requested model (default `standard`). */
    tier: SpeedTier;
    /** Fast-capable ids for the requested provider; Codex includes its independent account rows. */
    fastModels: string[];
}
/** Speed state the RPC handler delegates to (the durable per-model store). */
export interface SpeedController {
    /** Current speed state for one provider's model: its stored tier and the fast-capable models. */
    speed(provider: ProviderId, model: string): Promise<SpeedState>;
    /** Store one provider's model tier; `standard` clears the stored entry. */
    setSpeed(provider: ProviderId, model: string, tier: SpeedTier): Promise<void>;
}
/** One logged-in account, as rendered by the Settings page. */
export interface AccountStatus {
    /** Stable account key (store identity). */
    key: string;
    /** Display identity (email / login), when known. */
    account?: string;
    /** Epoch milliseconds at which the stored access token expires. */
    expiresAt?: number;
    /** Plan name the session carries (codex planType / claude subscriptionType), when known. */
    plan?: string;
    /** Whether direct (non-pool) routes serve this account. */
    isDefault: boolean;
}
/** Login state of one provider, as rendered by the Settings page. */
export interface ProviderStatus {
    /** Whether a login attempt is currently waiting for its code. */
    busy: boolean;
    /** Logged-in accounts, default first. */
    accounts: AccountStatus[];
    /** The last login error, shown until the next success. */
    detail?: string;
}
/** How a Claude login should acquire credentials (other providers ignore it). */
export type LoginMethod = 'oauth' | 'keychain' | 'manual';
/** Proxy config operations behind the `proxyGet/proxySet/proxyTest` endpoints. */
interface ProxyConfigController {
    /** Current proxy configuration (secrets omitted). */
    get(): Promise<ProxyConfigView>;
    /** Validate, persist, and apply one config. */
    set(input: ProxyInput): Promise<ProxyConfigView>;
    /** Probe one destination through the draft (unsaved) or stored proxy. */
    test(payload: {
        url?: string;
        proxy?: ProxyDraft;
    }): Promise<ProxyTestResult>;
}
/** Provider and account preference operations behind providerSettings/setProviderSettings. */
interface ProviderSettingsController {
    get(provider: ProviderId, force: boolean, refresh?: boolean): Promise<unknown>;
    set(provider: ProviderId, settings: unknown): Promise<void>;
}
export interface ModelDefaultsController {
    /** Set one model's configured default effort; undefined clears the override. */
    set(provider: ProviderId, model: string, effort: string | undefined): Promise<void>;
}
/** Provider-agnostic auth operations the RPC handler delegates to. */
export interface AuthController {
    /** Current status of one provider. */
    status(provider: ProviderId): Promise<ProviderStatus>;
    /**
     * Start a background login attempt.
     * @param provider - the provider route.
     * @param method - Claude only: force the OAuth browser flow or the Claude
     *   Code credential import; omitted keeps the auto behavior (import when
     *   available, else OAuth).
     * @returns the authorize URL for the user's browser; device-flow providers
     *   (copilot) also return the `userCode` the user types at that URL.
     * @throws when an attempt is already running for this provider.
     */
    login(provider: ProviderId, method?: LoginMethod): Promise<{
        authorizeUrl: string;
        userCode?: string;
    }>;
    /**
     * Feed a pasted callback URL or bare code into the pending attempt.
     * @throws when no attempt is pending or the input is unusable.
     */
    manual(provider: ProviderId, input: string): Promise<void>;
    /** Abort the pending attempt; a no-op when none is pending. */
    cancel(provider: ProviderId): Promise<void>;
    /** Delete one account's stored session. */
    logout(provider: ProviderId, account: string): Promise<void>;
    /** Pin the account direct (non-pool) routes serve. */
    setDefault(provider: ProviderId, account: string): Promise<void>;
    /**
     * Local subscription usage snapshot for one account. Plain reads never query
     * the provider; missing data is reported through cache metadata, not as zero usage.
     * @param signal - caller cancellation from the RPC transport.
     * @param force - explicitly refresh even a fresh success; failure cooldown still applies.
     * @param refresh - allow a scoped refresh only if the cached data needs one.
     * @returns the retained usage and freshness metadata, or `{ supported: false }`.
     * @throws on caller cancellation or a credential failure during an explicit refresh.
     */
    usage(provider: ProviderId, account: string, signal: AbortSignal, force?: boolean, refresh?: boolean): Promise<ProviderUsage>;
    /**
     * Banked ChatGPT reset credits for one account. Other providers answer
     * `{ supported: false }` and make no network call.
     * @param force - bypass a fresh cached list. A live failure cooldown still applies.
     */
    listResetCredits(provider: ProviderId, account: string, signal: AbortSignal, force?: boolean): Promise<ResetCreditList>;
    /**
     * Spend one ChatGPT reset credit. The request id is the caller's idempotency
     * key and is forwarded unchanged.
     */
    consumeResetCredit(provider: ProviderId, account: string, creditId: string, redeemRequestId: string, signal: AbortSignal): Promise<ResetCreditConsumeResult>;
    /**
     * Read one image attachment's bytes for inline display.
     * @param ref - the full durable reference (`readImage` verifies against it).
     * @param signal - caller cancellation from the RPC transport.
     * @returns the media type and base64-encoded bytes.
     * @throws when no attachment service is mounted or the read fails.
     */
    readImage(ref: ImageAttachmentRef, signal: AbortSignal): Promise<ImageBytesResult>;
    /**
     * Read one generated video's bytes for inline playback.
     * @param name - bare MP4 file name inside the plugin's videos directory
     *   (validated against {@link VIDEO_NAME_PATTERN}; never a path).
     * @param signal - caller cancellation from the RPC transport.
     * @returns the media type and base64-encoded bytes.
     * @throws when the file does not exist or cannot be read.
     */
    readVideo(name: string, signal: AbortSignal): Promise<VideoBytesResult>;
}
/** Payload carried no usable provider id — an RPC client bug, not a server failure. */
export declare class BadRequest extends Error {
}
/**
 * Register the `/subscriptions-auth` RPC channel when a host connection exists.
 * @param ctx - the plugin context (headless profiles have no `connection`).
 * @param controller - the auth operations backing the endpoints.
 * @param speed - the durable per-model speed-tier state backing the Speed toggle.
 * @param proxy - optional proxy-config controller backing `proxyGet`/`proxySet`/`proxyTest`.
 * @param modelDefaults - optional per-model effort writer; catalogue reads belong to `providerSettings`.
 */
export declare function registerAuthRpc(ctx: Context, controller: AuthController, speed: SpeedController, proxy?: ProxyConfigController | undefined, modelDefaults?: ModelDefaultsController | undefined, providerSettings?: ProviderSettingsController | undefined): void;
