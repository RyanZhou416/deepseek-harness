/**
 * Multi-account token plumbing: one {@link AccountTokenManager} per provider
 * owns a lazily-built {@link TokenManager} per account, so refresh coalescing
 * (`inflight`) and permanent-failure removal stay scoped to ONE account —
 * a revoked account deletes itself without touching its siblings.
 *
 * {@link AccountAwareAdapter} is the internal interface the pool uses to
 * stream through a specific account. A catalog model listed by several
 * accounts failovers; one listed by a single account is pinned to it.
 */
import { LlmAdapter } from '@deepseek-ai/dsh-llm';
import type { GenerateOptions, LlmModelInfo, LlmResolvedModelInfo, StreamChunk } from '@deepseek-ai/dsh-llm';
import { TokenManager } from './common.js';
import type { CatalogRefreshReport, TokenManagerOptions } from './common.js';
import type { AccountEntry, ProviderId } from '../auth/store.js';
export { DISCOVERY_TIMEOUT_MS } from './common.js';
/** Minimal session shape the token managers need (mirrors common.ts). */
interface TimedSession {
    accessToken: string;
    refreshToken: string;
    expiresAt: number;
}
/** An adapter that can stream through a named account (the pool's seam). */
export interface AccountAwareAdapter extends LlmAdapter {
    /** Stream using the given account's credentials instead of the default. */
    streamAccount(options: GenerateOptions, account: string): AsyncIterable<StreamChunk>;
    /**
     * The provider's own catalog: one account when `account` is set, otherwise
     * the union of every logged-in account (default first; later duplicates
     * dropped). The picker uses the union; pool assembly lists each account.
     * A read: it answers from the local cache or the built-in rows and never
     * starts a provider request. Use {@link refreshOwnCatalog} for that.
     */
    listOwnModels(provider: string, account?: string, signal?: AbortSignal): Promise<readonly LlmModelInfo[]>;
    /**
     * The provider's own catalog for one account for an advisory read: the
     * last-known catalogue, or the built-in rows while nothing is known, without
     * ever starting a provider request, so `undefined` reports caller cancellation
     * alone — the caller sits that account out instead of starting a second
     * attempt. Absent on an adapter with no catalog of its own, where callers fall
     * back to {@link listOwnModels}, which stays the read for an explicit enumeration.
     */
    resolveOwnCatalog?(provider: string, account: string, signal?: AbortSignal): Promise<readonly LlmModelInfo[] | undefined>;
    /**
     * The ONE path that asks the provider for a catalogue. Every catalogue-owning
     * adapter implements it; it is optional here only because an adapter without a
     * catalogue of its own has nothing to refresh.
     *
     * `account` names the account to refresh and defaults to the provider's default
     * account — never every peer. Without `force` it is an ensure: it requests the
     * catalogue only when the entry is missing, older than the route's configured
     * maximum age, and no failure cooldown is running; otherwise it reports the
     * account as skipped. `force` re-requests a fresh successful entry (an explicit
     * user refresh) and still honours a live failure cooldown, so a broken provider
     * is not re-queried on every click. `signal` detaches this caller alone; a
     * request other callers still await keeps running.
     * @param provider - the provider route whose catalogue is refreshed.
     * @param account - the account to refresh; the provider's default when omitted.
     * @param options - `force` for an explicit refresh, `signal` for caller cancellation.
     * @returns which account was requested, skipped, cancelled or failed.
     */
    refreshOwnCatalog?(provider: string, account?: string, options?: {
        force?: boolean;
        signal?: AbortSignal;
    }): Promise<CatalogRefreshReport>;
    /**
     * Await every catalogue request this route still has in flight, without
     * starting new work, so disposal leaves no write behind. Never rejects.
     */
    drainOwnCatalogs?(): Promise<void>;
    /**
     * Capability resolution of the provider's OWN models, bypassing the pool
     * delegation. The pool resolves its members through this — an account pool
     * reuses the catalog wire id (e.g. `gpt-5.4`), so resolveModel would
     * otherwise bounce straight back into the pool forever. The optional account
     * lets adapters with account-specific limits resolve that member conservatively.
     * A read: it answers from cache and never starts a provider request.
     */
    resolveOwnModel(provider: string, model: string, account?: string): Promise<LlmResolvedModelInfo>;
    /**
     * Drop the cached catalogue of one account, or every account when omitted: the
     * stored entry goes too, and an in-flight request that loses the race cannot
     * write back. Login/logout, account removal, or a changed catalogue identity.
     */
    clearAccountCatalog(account?: string): void;
    /**
     * Move one account's cached catalogue to the canonical key the store renamed
     * it to, keeping the snapshot, its freshness instant and its failure cooldown
     * under the new key. Called from the account manager's rename hook, which runs
     * inside the save that proved the rename: it must not wait on an in-flight
     * catalogue request.
     * @param from - the key the account's catalogue was stored under.
     * @param to - the canonical key the account now resolves to.
     */
    renameAccountCatalog?(from: string, to: string): Promise<void>;
    /**
     * Whether this route's catalog advertises the model's fast tier; absent on
     * routes whose requests carry none. The account scopes which catalog entry
     * answers (Codex and Cursor discover per account); omitted asks the
     * default-first account that lists the model. A read: never starts a request.
     */
    supportsFastTier?(model: string, account?: string): boolean | Promise<boolean>;
}
/** Options for {@link unionAccountCatalogs}. */
interface UnionAccountCatalogsOptions {
    /** Per-account bound; a hang sits that account out instead of blocking the picker. */
    timeoutMs?: number;
    /** Caller cancellation; aborting drops the whole union. */
    signal?: AbortSignal;
}
/**
 * Merge per-account catalogs, keeping the first occurrence of each model id.
 * Rows that carry a numeric `priority` (Codex discovery) are then ordered by
 * it so a model only the second account lists — e.g. `gpt-5.6-sol` — still
 * sits with its generation instead of being appended after the default
 * account's older ids.
 */
export declare function unionAccountCatalogs(accounts: readonly string[], listOne: (account: string, signal?: AbortSignal) => Promise<readonly LlmModelInfo[]>, options?: UnionAccountCatalogsOptions): Promise<LlmModelInfo[]>;
/** Store I/O behind {@link AccountTokenManager} (injectable for tests). */
interface AccountStoreIo<S> {
    list(): Promise<AccountEntry<S>[]>;
    get(account?: string): Promise<S | undefined>;
    save(account: string, session: S, expectedPrior?: S): Promise<void>;
    remove(account: string): Promise<void>;
    /** Resolve a legacy alias to the canonical account key. */
    resolve?(account: string): Promise<string>;
}
interface AccountTokenManagerOptions<S extends TimedSession> {
    provider: ProviderId;
    /** Human-readable provider name for error messages. */
    displayName: string;
    /** Provider hooks shared by every account (load/save/remove are bound per account). */
    makeOptions: (account: string) => Omit<TokenManagerOptions<S>, 'load' | 'save' | 'remove' | 'onRemoved' | 'displayName'>;
    /** Called after a permanent refresh failure deleted one account's session. */
    onAccountRemoved?: (account: string) => void;
    /**
     * Called when a successful save proves the store renamed one account's
     * canonical key — a Codex identity that gained its stable user id, for
     * instance. Awaited before the manager re-binds, so an owner of
     * account-keyed state can move that account's own metadata to the new key
     * before anything reads it.
     *
     * A rejection is contained by the caller: the renamed session is already
     * stored and the store still resolves the old key through the alias it
     * recorded, so a move that could not complete must not surface as a refresh
     * failure for a usable account. The failure is reported through {@link onWarn}.
     * @param from - the key the account was stored under until this save.
     * @param to - the canonical key the store now resolves that account to.
     */
    onAccountRenamed?: (from: string, to: string) => Promise<void>;
    /** Warning sink for a rename move that could not complete; absent stays quiet. */
    onWarn?: (message: string) => void;
    /** Store backend; defaults to the durable auth store. */
    io?: AccountStoreIo<S>;
}
export declare class AccountTokenManager<S extends TimedSession> {
    private readonly options;
    private readonly managers;
    private readonly io;
    constructor(options: AccountTokenManagerOptions<S>);
    /** The provider's accounts, default first (straight from the store). */
    list(): Promise<AccountEntry<S>[]>;
    /** The default account's key, or undefined when logged out. */
    defaultAccount(): Promise<string | undefined>;
    /**
     * Resolve a usable session for one account (default when omitted),
     * refreshing proactively or on demand.
     * @param account - the account key; the default account when undefined.
     * @param forceRefresh - refresh regardless of expiry (used after a 401).
     * @returns the persisted session to send.
     * @throws LlmError MISSING_CREDENTIAL when the account is not logged in.
     */
    session(account?: string, forceRefresh?: boolean): Promise<S>;
    /** Resolve a legacy alias before it reaches any per-account manager or cache. */
    resolveAccount(account: string): Promise<string>;
    /** Read an account's stored session without any refresh side effect. */
    peek(account?: string): Promise<S | undefined>;
    /**
     * Persist a caller-updated session for one account (default when omitted).
     * Identity backfill uses this; the next {@link session} read returns the
     * updated copy.
     * @param account - the account key; the default account when undefined.
     * @param session - the updated session to store.
     */
    persist(account: string | undefined, session: S): Promise<void>;
    /** Whether a session is stored for the account (cheap; never refreshes). */
    hasSession(account?: string): Promise<boolean>;
    /** The TokenManager bound to one account (created lazily, then cached). */
    tokensFor(account: string): TokenManager<S>;
    /** The logged-out error, mirroring TokenManager's own message. */
    private missingCredential;
}
