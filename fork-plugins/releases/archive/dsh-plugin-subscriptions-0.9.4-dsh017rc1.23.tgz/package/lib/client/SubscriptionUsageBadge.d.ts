import type { InjectFace, PropsLocale } from '@deepseek-ai/dsh-client-ui-slots';
import type { ConnectionHandle } from '@deepseek-ai/dsh-api-remotes/client';
import type { SubscriptionProvider, UsageWindow } from './SubscriptionsSection.js';
import type { ModelRef } from './SpeedSelect.js';
import type { CachedUsage, ObservableSnapshot, StatusRead, SubscriptionsCacheState, UsageReadMode } from './subscriptions-cache.js';
import type { SubscriptionsKey } from './locales.js';
/** Injected dependencies (slot `inject`, session-bound). */
export interface SubscriptionUsageBadgeInjected {
    /** Connection RPC caller to reach the `subscriptions-auth` endpoints. */
    rpc: ConnectionHandle['rpc'];
    /**
     * Read the shared cache's roster; newly listed accounts seed a local read.
     * @returns the roster, or the message the caller discards (the badge shows cached state only).
     */
    readStatus: () => Promise<StatusRead>;
    /**
     * Read one account's usage.
     * @param provider - the account's provider.
     * @param account - the account key.
     * @param mode - local snapshot (default), if-needed refresh, or forced refresh.
     * @returns nothing once the read has started.
     */
    readUsage: (provider: SubscriptionProvider, account: string, mode?: UsageReadMode) => Promise<void>;
    /**
     * Read every listed account of one provider.
     * @param provider - the provider whose accounts are read.
     * @param mode - read strength.
     * @returns nothing once every read has started.
     */
    readProvider: (provider: SubscriptionProvider, mode?: UsageReadMode) => Promise<void>;
    /**
     * Read every listed account.
     * @param mode - read strength.
     * @returns nothing once every read has started.
     */
    readAll: (mode?: UsageReadMode) => Promise<void>;
    /** Registrant hooks compartment: the shared cache and the session's model selection. */
    hooks: {
        usage: ObservableSnapshot<SubscriptionsCacheState>;
        model: ObservableSnapshot<ModelRef | null>;
    };
}
/** Props delivered by the slot outlet + inject + the locale seat. */
export type SubscriptionUsageBadgeProps = InjectFace<SubscriptionUsageBadgeInjected> & Partial<PropsLocale<'settings.subscriptions'>>;
/** One logged-in account's usage windows, as listed in the expanded dialog. */
interface AccountUsageDisplay {
    /** Account key (the `usage` endpoint's `account` argument). */
    key: string;
    /** Display handle (email / login), when the provider reports one. */
    account?: string;
    plan?: string;
    /** The account direct routes serve; the collapsed pill reads this one. */
    isDefault: boolean;
    windows: UsageWindow[];
    /** ChatGPT banked reset credits, when the usage payload disclosed a count. */
    resetCredits?: number;
    /** The account's cache entry, for the freshness line the dialog states. */
    entry?: CachedUsage;
}
/** One provider's usage snapshot: every logged-in account that reports windows. */
export interface ProviderUsageDisplay {
    provider: SubscriptionProvider;
    name: string;
    /** Default account first, then the rest in the `status` endpoint's order. */
    accounts: AccountUsageDisplay[];
}
/**
 * Fold the shared cache into the badge's provider list: every logged-in
 * account the cache holds an entry for — default account first, providers in
 * the roster's order.
 *
 * An entry with no windows is still listed: the node half's `missing` state
 * means "nothing read yet", not "no quota", and dropping the row would take
 * the pill (and with it the panel's refresh control) off screen exactly when
 * the user needs it. A retained payload survives a failed or stale
 * revalidation, so a provider whose quota read is failing keeps the windows it
 * last reported.
 * @param state - the shared cache snapshot.
 * @returns one entry per provider the cache holds usage state for.
 */
export declare function displaysOf(state: SubscriptionsCacheState): ProviderUsageDisplay[];
/**
 * Compact time-remaining label derived from the window's `resetsAt` timestamp:
 * "6d18h" (days+hours), "1h58m" (hours+minutes), or "42m" (minutes only), shaped
 * by the dictionary's own unit templates. Falls back to the scope, or to the
 * localized scope/kind abbreviation when no reset time is known.
 * @param w - the reported window.
 * @param t - Subscriptions dictionary translator.
 * @returns the compact remaining-time or window-kind label.
 */
export declare function windowLabel(w: UsageWindow, t?: Translate): string;
export declare function previewWindows(windows: readonly UsageWindow[], model?: string): {
    shown: UsageWindow[];
    hidden: UsageWindow[];
};
/** Bounded readout; Antigravity quotas belong to individual models, not the account. */
export declare function compactSegment(d: ProviderUsageDisplay, model?: string, t?: Translate): string;
/**
 * Pick what the collapsed pill shows: the current model's provider when its
 * usage is known, otherwise every provider (unknown model, a provider this
 * plugin does not serve, or a current provider with no usage to report).
 */
export declare function collapsedDisplays(displays: readonly ProviderUsageDisplay[], current: string | undefined): readonly ProviderUsageDisplay[];
/** Order for the expanded dialog: the current provider first, the rest in roster order. */
export declare function expandedDisplays(displays: readonly ProviderUsageDisplay[], current: string | undefined): readonly ProviderUsageDisplay[];
type Translate = (key: SubscriptionsKey, params?: Record<string, unknown>) => string;
/**
 * The composer subscription-usage badge: a pill reading e.g.
 * `Codex 6d1h 25%` for the current model's provider, opening a dialog with
 * every provider's accounts and their windows. Returns the bare dock seat when
 * no account reports usage.
 */
export declare function SubscriptionUsageBadge(props: SubscriptionUsageBadgeProps): import("react").JSX.Element;
/** Preview each account independently; all remaining quotas stay accessible. */
export declare function AccountWindows({ windows, model, translate }: {
    windows: readonly UsageWindow[];
    model: string | undefined;
    translate: Translate;
}): import("react").JSX.Element;
export {};
