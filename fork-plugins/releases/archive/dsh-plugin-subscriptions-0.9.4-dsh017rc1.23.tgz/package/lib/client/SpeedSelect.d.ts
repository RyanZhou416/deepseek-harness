import type { InjectFace, PropsLocale } from '@deepseek-ai/dsh-client-ui-slots';
import type { ConnectionHandle } from '@deepseek-ai/dsh-api-remotes/client';
import type { ObservableSnapshot } from './subscriptions-cache.js';
import type { SubscriptionsKey } from './locales.js';
/** One model's speed choice: standard routing or the fast (priority) tier. */
export type SpeedTier = 'standard' | 'fast';
/** A session's resolved model selection, as the model directory publishes it. */
export interface ModelRef {
    provider: string;
    model: string;
}
/** `speed` endpoint value, mirrored from the node half. */
export interface SpeedState {
    tier: SpeedTier;
    fastModels: string[];
}
/** What {@link SpeedSelect} renders from: visibility plus the current tier. */
export interface SpeedSelectState {
    visible: boolean;
    tier: SpeedTier;
}
/**
 * The speed state this control watches, and the choice generation its reads belong to.
 *
 * The read and the user's choice are both asynchronous, and the read is the slower of the
 * two (it asks the node half to enumerate the fast-capable models). A read that started before a
 * choice can therefore settle after it, and publishing that result would put the tier the user
 * just replaced back on screen. A read also names the model it addressed, because a model
 * switch moves the row onto a model whose tier that read never asked for.
 */
export interface SpeedView {
    /** Choices this control has settled; a read carries the value it started under. */
    generation: number;
    /** The last state this control published, or null until the first read settles. */
    state: SpeedSelectState | null;
}
/** One read in flight: the model it addresses and the choice generation it started under. */
export interface SpeedRead {
    /** The model this read answers for. */
    model: ModelRef | null;
    /** The generation this read started under. */
    generation: number;
}
/**
 * Fold one settled host read into the view, unless a choice or a model switch superseded it.
 *
 * Dropping a superseded read is what keeps the row honest: a read stamped with an older
 * generation carries the tier the user's choice replaced, and a read of another model answers a
 * question the row is no longer asking — publishing either would show a tier that belongs to no
 * model on screen.
 * @param view - the view the read settles into.
 * @param read - the model and generation the read was started under.
 * @param state - the state the read returned.
 * @param current - the model the row shows now.
 * @returns the updated view, or the same view when the read is stale.
 */
export declare function settleRead(view: SpeedView, read: SpeedRead, state: SpeedSelectState, current: ModelRef | null): SpeedView;
/**
 * Fold one settled choice into the view, superseding every read started before it.
 *
 * The choice is stated directly rather than re-read: a successful write is the authoritative
 * answer, and a fresh read would take another round trip to say the same thing.
 * @param view - the view the choice settles into.
 * @param tier - the tier the write accepted.
 * @returns the updated view at the next generation.
 */
export declare function settleChoice(view: SpeedView, tier: SpeedTier): SpeedView;
/**
 * Minimal structural face of one session's model directory (ui-model-selection's
 * `ctx.modelDirectories` service — the sanctioned cross-plugin channel: cordis
 * services, not value imports, same mirroring discipline as ToolCallOwnerProps).
 * `store` is the framework's own shared snapshot source for this session; the
 * resolved `current` already includes the Host's default when the Session
 * carries no selection of its own.
 */
export interface ModelDirectoryLike {
    /** The shared directory store; `current` is the session's resolved selection. */
    readonly store: ObservableSnapshot<{
        current: ModelRef | null;
    }>;
    /** Explicit one-shot read, for entry points with no slot hook (the /fast command). */
    load(): Promise<{
        current: ModelRef | null;
    }>;
}
/** Structural face of ui-model-selection's `ctx.modelDirectories` service. */
export interface ModelDirectoriesLike {
    /**
     * Resolve one session's shared model directory (throws for unknown sessions).
     * @param sessionId - the owning session.
     * @returns the resident directory both selection entries share.
     */
    directoryFor(sessionId: string): ModelDirectoryLike;
}
/**
 * The session's resolved model selection as a bare observable source, for the
 * inject `hooks` compartment. Snapshot identity follows the directory store's
 * own `current` object, so a subscriber re-renders only when the selection moves.
 * @param directory - the session's shared directory.
 * @returns the observable selection source.
 */
export declare function modelSelectionSource(directory: ModelDirectoryLike): ObservableSnapshot<ModelRef | null>;
/**
 * Resolve a session's model selection once, through the directory's explicit
 * read. Entry points that receive no slot hook (the /fast command) use this;
 * slot components read the observable source instead.
 * @param models - the lazy service lookup.
 * @param sessionId - the owning session.
 * @returns the resolved selection, or null when nothing is selected.
 */
export declare function resolveCurrentModel(models: () => ModelDirectoriesLike | undefined, sessionId: string): Promise<ModelRef | null>;
/** Injected dependencies of {@link SpeedSelect} (slot `inject`, session-bound). */
export interface SpeedSelectInjected {
    /**
     * Load one model's speed state; `visible` false keeps the control hidden.
     * @param current - the model the row is showing, or null when none is selected.
     * @returns the model's speed state.
     */
    loadSpeed: (current: ModelRef | null) => Promise<SpeedSelectState>;
    /**
     * Store one model's speed tier.
     * @param current - the addressed model.
     * @param tier - the tier to store.
     * @returns false when the write failed.
     */
    setSpeed: (current: ModelRef, tier: SpeedTier) => Promise<boolean>;
    /** Registrant hooks compartment: the session's resolved model selection. */
    hooks: {
        model: ObservableSnapshot<ModelRef | null>;
    };
}
/**
 * Props delivered by the slot outlet: the injected callbacks and the model
 * hook the framework binds from the inject hooks compartment. The framework's
 * own standard shares are ignored — everything arrives session-bound here.
 */
export type SpeedSelectProps = InjectFace<SpeedSelectInjected> & Partial<PropsLocale<'settings.subscriptions'>>;
/**
 * Whether the Speed control belongs on screen for the session's current model.
 *
 * The gate has two halves: the model's route must be one whose requests carry a fast tier, and
 * the node half must list that exact model id as fast-capable. A session with no model selection
 * has nothing to switch.
 * @param current - the session's effective model selection, or null when it has none.
 * @param fastModels - the node half's fast-capable model ids.
 * @returns true when the control should render.
 */
export declare function speedControlVisible(current: ModelRef | null, fastModels: readonly string[]): boolean;
/**
 * The `loadSpeed` half of the inject face: the addressed model's stored tier plus
 * the node half's fast-capable listing (the visibility gate). A model-RPC
 * failure throws rather than answering "hidden" — the caller keeps its last
 * known state, so a transient failure never locks the toggle away.
 * @param rpc - Connection RPC caller.
 * @returns the loader the inject face binds.
 */
export declare function createSpeedLoader(rpc: ConnectionHandle['rpc']): SpeedSelectInjected['loadSpeed'];
/**
 * The `setSpeed` half of the inject face: boolean outcome for the component's busy state.
 * @param rpc - Connection RPC caller.
 * @returns the setter the inject face binds.
 */
export declare function createSpeedSetter(rpc: ConnectionHandle['rpc']): SpeedSelectInjected['setSpeed'];
/**
 * Settle one picked tier against a model. A false answer fails the call with
 * the dictionary's failure copy, which is how an entry point that owns no
 * notice surface of its own states the failure: the `/fast` popup renders
 * through the shell's error strip, while the composer control shows the same
 * copy in place.
 * @param setSpeed - the setter.
 * @param current - the model the pick addresses.
 * @param tier - the picked tier.
 * @param t - Subscriptions dictionary translator.
 * @returns nothing once the write takes effect.
 * @throws Error carrying `speedSaveFailed` when the write fails.
 */
export declare function settleSpeedTier(setSpeed: SpeedSelectInjected['setSpeed'], current: ModelRef, tier: SpeedTier, t: (key: SubscriptionsKey) => string): Promise<void>;
/**
 * The model menu's Speed row: a cell reading `速度` and the current tier, opening
 * the two tiers in place (standard/fast with descriptions, a check on the current
 * one). The cell keeps the shape of the seat's own root cells — label, current
 * value, chevron — so the row reads as one of them.
 *
 * The row re-reads when the session's model moves and when the menu opens, never
 * on a timer; a failed read keeps the last known state, so a transient RPC
 * failure can never lock the choice away. Every read is stamped with the choice
 * generation it started under and names the model it addresses, so a read a
 * later choice superseded is dropped and no read or write can land on a model
 * the menu no longer shows.
 */
export declare function SpeedSelect(props: SpeedSelectProps): import("react").JSX.Element | null;
