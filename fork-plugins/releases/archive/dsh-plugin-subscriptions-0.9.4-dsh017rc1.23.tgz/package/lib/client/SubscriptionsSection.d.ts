import type { ConnectionHandle } from '@deepseek-ai/dsh-api-remotes/client';
import type { InjectFace } from '@deepseek-ai/dsh-client-ui-slots';
import type { SubscriptionsKey } from './locales.js';
export { callSubscriptionsAuth } from './subscriptions-rpc.js';
import type { CachedUsage, ObservableSnapshot, StatusRead, SubscriptionsCacheState, UsageReadMode } from './subscriptions-cache.js';
/** Subscription provider ids, fixed by the node half's OAuth adapters. */
export type SubscriptionProvider = 'codex' | 'claude' | 'grok' | 'copilot' | 'antigravity' | 'cursor';
/** One logged-in account as answered by the `status` endpoint. */
export interface AccountStatus {
    key: string;
    account?: string;
    expiresAt?: number;
    plan?: string;
    isDefault: boolean;
}
/** One provider's login state as answered by the `status` endpoint. */
export interface ProviderStatus {
    busy: boolean;
    accounts: AccountStatus[];
    detail?: string;
}
/** One rate-limit window as answered by the `usage` endpoint. */
export interface UsageWindow {
    kind: 'session' | 'weekly' | 'other';
    scope?: string;
    usedPercent: number;
    resetsAt?: number;
}
/** One unified rate-limit window as reported by the `usage` endpoint. */
interface RateLimitWindow {
    window: string;
    utilization?: number;
    resetsAt?: number;
    surpassedThreshold?: number;
}
/** The account's captured `anthropic-ratelimit-unified-*` report. */
export interface RateLimitReport {
    status: 'allowed' | 'allowed_warning' | 'rejected' | 'other';
    resetsAt?: number;
    claim?: string;
    fallbackAvailable?: boolean;
    overageStatus?: 'allowed' | 'allowed_warning' | 'rejected' | 'other';
    overageResetsAt?: number;
    overageDisabledReason?: string;
    overageInUse?: boolean;
    overageScope?: string;
    windows: RateLimitWindow[];
    observedAt: number;
}
/** The account pool's view of one account, present only while the pool is enabled. */
export interface PoolReport {
    coolingReason?: 'auth' | 'quota';
    coolingUntil?: number;
    peerAvailable: boolean;
}
/**
 * Cache state the node half reports beside a usage snapshot.
 *
 * `missing` is not zero percent and not "unsupported": nothing has been read
 * for this account yet. `stale` and `error` carry the last known windows, and
 * `retryAt` is the instant the node half's cooldown lets a forced read run.
 */
export interface UsageCacheMetadata {
    state: 'fresh' | 'stale' | 'missing' | 'error' | 'refreshing';
    /** Instant the reported values were observed, on the node half's clock. */
    observedAt?: number;
    /** Earliest instant a forced read is accepted again. */
    retryAt?: number;
    /** Coded reason of an `error` state (never raw provider text). */
    error?: string;
}
/** `usage` endpoint value: the node half owns this shape. */
export interface ProviderUsage {
    supported: boolean;
    windows?: UsageWindow[];
    plan?: string;
    /** Present only when the usage payload disclosed a reset-credit count. */
    resetCredits?: {
        availableCount: number;
    };
    /** The account's last answered request's unified rate-limit report, when captured. */
    rateLimit?: RateLimitReport;
    /** The account pool's view of this account, when the pool is enabled. */
    pool?: PoolReport;
    /** Freshness of this snapshot, when the node half reports one. */
    cache?: UsageCacheMetadata;
}
/** `proxyGet` endpoint value: the node half owns this shape (no secrets). */
export interface ProxyConfigView {
    enabled: boolean;
    url: string;
    username?: string;
    passwordSet: boolean;
    bypass: string[];
    error?: string;
}
/** `proxyTest` endpoint value. */
export interface ProxyTestResult {
    ok: boolean;
    viaProxy: boolean;
    status?: number;
    latencyMs?: number;
    error?: string;
}
/** Injected dependencies of {@link SubscriptionsSection} (slot `inject`). */
export interface SubscriptionsSectionInjected {
    /** Generic logical-RPC caller over the Connection transport. */
    rpc: ConnectionHandle['rpc'];
    /** Section copy: translate a 'settings.subscriptions' key with `{name}` template params. */
    t: (key: SubscriptionsKey, params?: Record<string, unknown>) => string;
    /**
     * Read the shared cache's roster.
     * @param options - `fresh` starts an independent read instead of folding into one already running.
     * @returns the roster, or the message the caller renders.
     */
    readStatus: (options?: {
        fresh?: boolean;
    }) => Promise<StatusRead>;
    /**
     * Read one account's usage from the shared cache.
     * @param provider - the account's provider.
     * @param account - the account key.
     * @param mode - local snapshot (default), if-needed refresh, or forced refresh.
     * @returns nothing once the read has started.
     */
    readUsage: (provider: SubscriptionProvider, account: string, mode?: UsageReadMode) => Promise<void>;
    /** Registrant hooks compartment: the shared cache source, bound to `useUsage`. */
    hooks: {
        usage: ObservableSnapshot<SubscriptionsCacheState>;
    };
}
/**
 * Props delivered by the slot outlet: the inject face with its hooks
 * compartment bound (`useUsage` is the framework's own seat and is always
 * present), and the optional members standalone renders may omit.
 */
export type SubscriptionsSectionProps = Partial<Pick<SubscriptionsSectionInjected, 'rpc' | 't'>> & Required<Pick<SubscriptionsSectionInjected, 'readStatus' | 'readUsage'>> & Pick<InjectFace<SubscriptionsSectionInjected>, 'useUsage'>;
/** Bar fill color: success normally, warn from 80%, error from 95%. Shared with the composer badge. */
export declare function usageBarColor(usedPercent: number): string;
/**
 * Localized freshness line of one cached usage entry: when the values were
 * observed, whether the node half kept a stale value, has none yet, failed its
 * last revalidation, or is refreshing now, plus the instant a forced read may
 * be tried again.
 *
 * The line states the cache's own state, so a `missing` account never reads as
 * "zero percent" and a failed revalidation never hides the quotas that are
 * still on screen.
 * @param entry - the account's cache entry, or undefined before any read.
 * @param t - section translate.
 * @returns the line, or undefined when the entry carries nothing to state.
 */
export declare function usageCacheNote(entry: CachedUsage | undefined, t: SubscriptionsSectionInjected['t']): string | undefined;
/**
 * The fact one account's red usage line states.
 *
 * `limit` and `near` come from the reported window percentages, `rejected` and
 * `warning` from the provider's unified rate-limit status, `relogin` from a
 * stored login the pool found dead, and `cooldown` and `overage` from the
 * account pool working around this account.
 */
type UsageAlertKind = 'limit' | 'near' | 'rejected' | 'warning' | 'relogin' | 'cooldown' | 'overage';
/** What one account's card states about its usage. */
interface UsageAlert {
    /** The fact the line states. */
    kind: UsageAlertKind;
    /**
     * `account` when the fact is about this account alone; `pool` when this
     * account is out and another pool member is serving in its place. The
     * distinction is the difference between "you are blocked" and "we routed
     * around a cooling account".
     */
    attribution: 'account' | 'pool';
    /** Latest disclosed instant still ahead of the clock at which the state clears. */
    resetsAt?: number;
}
/**
 * Whether an account's reported usage puts it out of service.
 *
 * Contract: the header state outranks the percentage state, because the
 * provider's own `rejected` verdict is more specific than a window percentage
 * that may have been read minutes earlier. A dead login is always attributed
 * to the account: no routing decision clears it. A near-limit `allowed_warning`
 * status is an account fact too — it proves only that this account is close to
 * its limit, which routing around it does not change. Overage is always
 * attributed to the pool and only reported when a peer can serve, because the
 * account itself is still answering.
 *
 * The percentage rule is unchanged from the reported windows: a window counts
 * as full at `usedPercent >= 100` for Codex and Claude, which spend a window
 * all the way down, and at `usedPercent >= 95` for every other provider — the
 * per-provider rule the pool's availability check applies
 * (`CONSUMABLE_QUOTA_FULL_PERCENT` / `QUOTA_FULL_PERCENT`). Absent or empty
 * windows, and every window below its threshold, report no alert.
 * @param provider - the provider that reported the windows.
 * @param windows - the account's reported windows, or undefined while unknown.
 * @param rateLimit - the account's captured unified rate-limit report, when any.
 * @param pool - the pool's view of this account, when the pool is enabled.
 * @returns the out-of-service state, or undefined while the account can serve.
 */
export declare function usageAlert(provider: SubscriptionProvider, windows: readonly UsageWindow[] | undefined, rateLimit?: RateLimitReport, pool?: PoolReport): UsageAlert | undefined;
/**
 * The locale key stating one alert. Account-level facts name what is wrong with
 * this account; pool-level facts name that another account is serving instead.
 * @param alert - the alert derived by {@link usageAlert}.
 * @returns the key of the line to render.
 */
export declare function usageAlertKey(alert: UsageAlert): SubscriptionsKey;
/**
 * The Subscriptions settings page component.
 * @param props - the slot inject face ({@link SubscriptionsSectionInjected}).
 * @returns the section body, or a notice while the RPC face is absent.
 */
export declare function SubscriptionsSection(props: SubscriptionsSectionProps): import("react").JSX.Element;
