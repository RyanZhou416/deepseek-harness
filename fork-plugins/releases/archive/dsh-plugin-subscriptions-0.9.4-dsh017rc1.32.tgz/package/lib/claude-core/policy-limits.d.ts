/**
 * The `policy_limits` document: its pinned envelope schema, the canonical validator hashed
 * over the raw body, and the bounded in-memory cache the reader adopts into.
 *
 * Everything here is a pure function over inputs the caller supplies. Nothing in this
 * module performs I/O, reads a credential, chooses an account or keeps a raw document on
 * disk: the caller injects the raw body, and the only thing retained is the derived
 * document plus its validator.
 */
import type { CoreFailure } from './failures.js';
/** One key's server verdict. */
export interface PolicyRestriction {
    readonly allowed: boolean;
}
/** The document the pinned envelope describes. */
export interface PolicyLimitsDocument {
    /** Per-key verdicts; the envelope requires this member. */
    readonly restrictions: Readonly<Record<string, PolicyRestriction>>;
    /** Compliance taints, normalized and deduplicated. */
    readonly complianceTaints: readonly string[];
    /** Monitoring notice, or `null` when the server stated none. */
    readonly monitoringNotice: {
        readonly text: string;
        readonly url: string | null;
    } | null;
    /** Default values; a non-empty map makes every verdict unsettled. */
    readonly defaults: Readonly<Record<string, unknown>>;
    /** Bundled core skill names. */
    readonly coreSkills: readonly string[];
    /** Whether normalization dropped at least one taint the server sent. */
    readonly lossyComplianceTaints: boolean;
}
/** What one parse produced. */
export type PolicyDocumentParse = {
    readonly ok: true;
    readonly document: PolicyLimitsDocument;
} | {
    readonly ok: false;
    readonly failure: CoreFailure;
};
/**
 * Parse and normalize one `policy_limits` response body.
 *
 * The envelope follows the pinned schema: `restrictions` and every `restrictions[k].allowed`
 * are required, while taints, the monitoring notice, defaults and core skills each have a
 * declared default. An unknown top-level key is stripped, not rejected. A taint list that
 * carried something but normalized to nothing is a parse failure; a list that lost some
 * entries keeps the legal ones and marks the document lossy.
 * @param raw - the parsed JSON body, exactly as the transport delivered it.
 * @returns the normalized document, or why the body was refused.
 */
export declare function parsePolicyLimitsDocument(raw: unknown): PolicyDocumentParse;
/**
 * The canonical form of one JSON value, as the pinned validator computes it.
 *
 * Arrays keep their order; objects are rebuilt with their keys sorted, recursively, so two
 * bodies that differ only in member order hash the same. Anything else is serialized as
 * JSON leaves it.
 * @param value - the value to canonicalize.
 * @returns the canonical JSON text.
 */
export declare function canonicalPolicyJson(value: unknown): string;
/**
 * Hash one canonical text with sha256.
 *
 * WebCrypto is used when the runtime exposes it; otherwise the Node crypto module hashes
 * the same bytes. Both produce the same lowercase hex.
 * @param text - the canonical text.
 * @returns the lowercase hex digest.
 */
export declare function sha256Hex(text: string): Promise<string>;
/**
 * The validator of one raw policy body: `sha256:<hex>` over its canonical form.
 *
 * The pinned client hashes the RAW body it received, never the parsed projection, so a body
 * whose unknown members were stripped still validates as the server sent it.
 * @param raw - the parsed JSON body.
 * @returns the validator string.
 */
export declare function policyValidator(raw: unknown): Promise<string>;
/** One adopted policy snapshot. */
export interface PolicySnapshot {
    /** The normalized document. */
    readonly document: PolicyLimitsDocument;
    /** The validator of the raw body this document came from. */
    readonly validator: string;
    /** When the caller received the body, in epoch milliseconds. */
    readonly receivedAt: number;
    /**
     * The `signature` response header, when one was sent. It is kept for diagnostics only and
     * never participates in adoption.
     */
    readonly signature?: string;
}
/**
 * The bounded in-memory adoption cache.
 *
 * It holds at most one snapshot, replaces it only through {@link adopt}, and never writes
 * anything to disk. The caller owns its lifetime; clearing it drops the live policy while
 * leaving the caller's own state untouched.
 */
export declare class PolicyLimitsCache {
    private snapshot;
    /**
     * Adopt one parsed response body.
     * @param raw - the parsed JSON body.
     * @param options - when it was received and the signature header, when one was sent.
     * @returns the adopted snapshot, or why the body was refused.
     */
    adopt(raw: unknown, options: {
        receivedAt: number;
        signature?: string;
    }): Promise<{
        ok: true;
        snapshot: PolicySnapshot;
    } | {
        ok: false;
        failure: CoreFailure;
    }>;
    /**
     * The adopted snapshot, without any read or refresh.
     * @returns the snapshot, or `undefined` when nothing was adopted.
     */
    current(): PolicySnapshot | undefined;
    /**
     * The live policy document the verdict evaluator reads (`cb()`).
     * @returns the document, or `null` when no policy is live.
     */
    live(): PolicyLimitsDocument | null;
    /**
     * The conditional-request validator for the session policy (`s`).
     * @returns the validator, or `undefined` when no policy is live.
     */
    validator(): string | undefined;
    /** Drop the adopted snapshot. */
    clear(): void;
}
