/**
 * One reading of a subscription account's quota, from a single raw source.
 *
 * The raw sources are kept apart because their units are established per source and per
 * field: the `anthropic-ratelimit-unified-*` response headers carry a utilization fraction
 * and an epoch-seconds reset, while the OAuth usage document's windows carry a percent
 * utilization and an ISO reset. A value is normalized once, after its unit is known, and the
 * source, the window kind and the reset encoding ride along so a consumer never infers
 * either.
 *
 * Every entry point here is a pure function of its arguments: no clock is read (callers
 * pass `now`), no state survives a call, and the module imports nothing from the harness,
 * Cordis, the adapters or Node. Reading the header family one member at a time belongs to
 * {@link parseRawFacts}, which is its only reader; the projectors below consume the facts it
 * produced and never touch the response again.
 *
 * @module dsh-plugin-subscriptions/claude-core/quota-observation
 */
/**
 * The read-only header source the raw header parse reads: the one operation a response
 * header object has to offer. `Headers` satisfies it directly, and a caller can hand in any
 * object with the same method. A missing member reads `undefined`.
 */
export interface QuotaHeaderSource {
    /** One response header's value, or `undefined` when the response carried none. */
    get(name: string): string | undefined;
}
/** Prefix every member of the unified rate-limit family shares. */
export declare const CLAUDE_UNIFIED_HEADER_PREFIX = "anthropic-ratelimit-unified-";
/** Standalone members of the unified family, outside the per-window readings. */
export declare const CLAUDE_UNIFIED_MEMBER_SUFFIXES: readonly ["status", "reset", "representative-claim", "fallback", "overage-status", "overage-reset", "overage-disabled-reason", "overage-in-use", "overage-scope"];
/**
 * A window's identity. The provider's own window token is preserved rather than folded into
 * a coarser bucket, so a per-model or overage window is never reported as a whole-account
 * weekly one.
 */
export type ClaudeQuotaWindowKind = '5h' | '7d' | '7d_oi' | 'overage' | 'unknown';
/** Window prefixes the provider meters separately, each with its own readings. */
export declare const CLAUDE_UNIFIED_WINDOW_PREFIXES: readonly ClaudeQuotaWindowKind[];
/** The three readings every window prefix carries. */
export declare const CLAUDE_UNIFIED_WINDOW_SUFFIXES: readonly ["utilization", "reset", "surpassed-threshold"];
/**
 * The status member's accepted values. An unrecognized token and a missing status member
 * both read `other`, so a standing the response did not state is never presented as
 * `allowed`.
 */
export type ClaudeQuotaStatus = 'allowed' | 'allowed_warning' | 'rejected' | 'other';
/** Which raw source an observation was read from. */
export type ClaudeQuotaSource = 'ratelimit-headers' | 'usage-json';
/**
 * The reset encodings this application validates. `epoch-seconds` is the header family's
 * documented encoding; `iso` is the encoding the usage document's `resets_at` declares.
 * `unknown` means the raw value matched neither, so no instant is reported for it.
 */
export type ClaudeQuotaResetFormat = 'epoch-seconds' | 'iso' | 'unknown';
/**
 * What one strict reading covers, kept apart from the window token because the two answer
 * different questions: two model-scoped weekly windows and the whole-account weekly window
 * can share the token `7d`, and a consumer that decides on `kind` alone would treat a model
 * window as the account's own.
 *
 * `model-family` is the one model dimension this application has evidence for, and only for the
 * flat Sonnet/Opus windows: the source client classifies those by model family, not by a stable
 * model id. `unknown-scope` covers every reading whose applicability is not established — a
 * model window this application cannot name, the overage-included week, and the overage route.
 * It is never equivalent to an account window, so an absent `family` never means `account`.
 */
export type ClaudeQuotaScopeKind = 'account' | 'model-family' | 'unknown-scope';
/**
 * The model family a reading is scoped to, when the source states one.
 *
 * Only the flat `seven_day_opus` / `seven_day_sonnet` windows produce it, and it is a family,
 * never a model id: it says which family window this reading is, not which model a request uses.
 */
export type ClaudeQuotaFamily = 'opus' | 'sonnet';
/**
 * The one shape a strict reading takes. It carries the validated value, the unit the
 * normalization used, what the window covers, and the observation time the caller injected; a
 * field the source did not state, or stated unusably, stays absent rather than defaulting to
 * zero.
 */
export interface ClaudeQuotaObservation {
    /** Raw source this reading came from. */
    source: ClaudeQuotaSource;
    /** Window token the source stated. */
    kind: ClaudeQuotaWindowKind;
    /** What this reading covers, always stated so a model window is never read as the account's. */
    scopeKind: ClaudeQuotaScopeKind;
    /**
     * Model family, and only from a window the source itself classifies by family. No stable model
     * id is reported here, and a display name never becomes one.
     */
    family?: ClaudeQuotaFamily;
    /** Percent of the window consumed, normalized exactly once from {@link unit}. */
    normalizedPct: number;
    /** Unit {@link normalizedPct} was normalized from, as the source declared it. */
    unit: 'ratio' | 'percent';
    /** Raw encoding of the reset this observation was built from. */
    resetFormat: ClaudeQuotaResetFormat;
    /** Epoch milliseconds the window reopens, when the raw value validated. */
    resetsAtMs?: number;
    /** Epoch milliseconds this reading was observed, injected by the caller. */
    observedAtMs: number;
}
/** One member's read: what the response carried, and the number it parsed to when it was one. */
export interface RawFactMember {
    /**
     * Present when the response answered with a non-blank value. A missing member and a blank
     * one are both `absent`, which is what keeps them distinguishable from a stated zero: a
     * stated zero is present with `parsedNumber: 0`. A stated value that is not a finite number
     * is `invalid`: it exists, and no consumer may read it as a value.
     */
    presence: 'absent' | 'present' | 'present-zero' | 'invalid';
    /** The trimmed value the response answered with, present exactly when the member is present. */
    rawText?: string;
    /**
     * The finite number `rawText` parsed to. It is present exactly for `present` and
     * `present-zero`, and its presence is the only validity judgement a consumer needs: an
     * `invalid` member may still carry text, and carries no number.
     */
    parsedNumber?: number;
}
/** One window's three raw member readings from the unified header family. */
export interface RawFactWindow {
    /** Window token the readings belong to. */
    window: ClaudeQuotaWindowKind;
    /** The `-utilization` member. */
    utilization: RawFactMember;
    /** The `-reset` member; its encoding is left to the injected legacy resolver. */
    reset: RawFactMember;
    /** The `-surpassed-threshold` member. */
    surpassedThreshold: RawFactMember;
}
/** The unified header family read once, with every member this module consumes classified. */
export interface RawFacts {
    /**
     * Standalone members by suffix, keyed exactly as the family names them. `fallback` is the
     * one member whose raw text a projector reads beyond its presence.
     */
    members: Readonly<Record<string, RawFactMember>>;
    /** Per-window readings, in `5h`, `7d`, `7d_oi`, `overage` order. */
    windows: readonly RawFactWindow[];
}
/**
 * The reset resolver the legacy projector delegates to. It is a caller-supplied port on
 * purpose: it interprets every encoding the subscription routes' shared reader accepts (a
 * delay, epoch seconds, epoch milliseconds, a Go duration such as `6m0s`, and an
 * HTTP-date), and it lives with the providers' retry readers rather than here.
 * @param rawText - the member's raw text, or `undefined` when the response carried none.
 * @param now - the current epoch milliseconds, for a value that states a delay.
 * @returns epoch milliseconds of the reset, or `undefined` when the value disclosed none.
 */
export type LegacyResetResolver = (rawText: string | undefined, now: number) => number | undefined;
/** One window's reading in a legacy report. */
export interface QuotaLegacyWindowReading {
    /** Window token, as the header family names it. */
    window: string;
    /** Fraction of the window consumed (0–1), as the provider reported it. */
    utilization?: number;
    /** Epoch milliseconds at which the window reopens. */
    resetsAt?: number;
    /** Threshold the utilization passed, when the provider sent it. */
    surpassedThreshold?: number;
}
/**
 * One account's unified rate-limit report, under the field names the plugin's settings
 * surfaces and account pool already read.
 */
export interface QuotaLegacyState {
    /** The account's standing: `rejected` is the provider refusing its requests. */
    status: ClaudeQuotaStatus;
    /** Epoch milliseconds the claiming window reopens. */
    resetsAt?: number;
    /** The window claiming the limit, when named. */
    claim?: string;
    /** Whether the provider advertised a fallback route past the limit. */
    fallbackAvailable?: boolean;
    /** The overage route's own status. */
    overageStatus?: ClaudeQuotaStatus;
    /** Epoch milliseconds the overage cap reopens. */
    overageResetsAt?: number;
    /** Why overage is unavailable, when the provider said so. */
    overageDisabledReason?: string;
    /** Whether this account's requests are currently drawing on paid overage. */
    overageInUse?: boolean;
    /** Which budget the overage draws on. */
    overageScope?: string;
    /** Per-window readings, in window-prefix order. */
    windows: QuotaLegacyWindowReading[];
    /** Epoch milliseconds this report was read off the response. */
    observedAt: number;
}
/**
 * One legacy usage window, under the field names the plugin's usage surfaces and pool
 * consume: a percent (0–100) from the provider's own percent unit, and the window kind its
 * `kind` token maps to.
 */
export interface QuotaWindowSpec {
    /** Window kind: `session` for the short rolling window, `weekly` for the 7-day ones. */
    kind: 'session' | 'weekly' | 'other';
    /** Model display label for a model-specific window, when the response names one. */
    scope?: string;
    /** Percent of the window already consumed (0–100). */
    usedPercent: number;
    /** Epoch milliseconds at which the window resets, when the provider discloses it. */
    resetsAt?: number;
}
/**
 * The top-level window keys the usage document is known to carry. A key outside this set is
 * counted and never named, echoed or copied anywhere: an unrecognized key is the provider's
 * data, not this plugin's to expose.
 */
export declare const CLAUDE_USAGE_WINDOW_KEYS: readonly ["five_hour", "seven_day", "seven_day_oauth_apps", "seven_day_opus", "seven_day_sonnet", "cinder_cove"];
/**
 * The usage document's top-level keys this module recognizes. Recognizing a key is not
 * claiming its values are window readings: `limits` is a nested array, and `extra_usage`'s
 * period unit (monthly or per channel) is not established, so no window is produced from it.
 */
export declare const CLAUDE_USAGE_TOP_LEVEL_KEYS: readonly ["five_hour", "seven_day", "seven_day_oauth_apps", "seven_day_opus", "seven_day_sonnet", "cinder_cove", "extra_usage", "limits", "seven_day_overage_included"];
/**
 * A fixed code for a wire member this module could not use. These codes are the complete
 * vocabulary reported to callers; a raw key name, a display name or a raw value never appears
 * in one. Each rejected value increments exactly one code, so the counts are a partition of
 * the rejections and never a double count of the same fact.
 */
export type QuotaParseIssueCode = 'window-shape-invalid' | 'percent-missing' | 'percent-out-of-range' | 'reset-shape-invalid' | 'limit-kind-unknown' | 'window-key-unsupported';
/** Counts for the wire members an application check rejected, keyed by fixed code. */
export type QuotaParseIssues = Readonly<Partial<Record<QuotaParseIssueCode, number>>>;
/** The usage document parsed into legacy windows, plus the strict reading of the same body. */
export interface ClaudeQuotaDocument {
    /** The legacy-compatible window list the usage surfaces render. */
    windows: QuotaWindowSpec[];
    /**
     * Strict per-window observations, present exactly when the caller asked for them. The
     * nested `limits` array wins whenever it carries any entry — the precedence the legacy
     * mapping already used — so one body never yields both a flat and a nested reading.
     */
    strictObservations?: ClaudeQuotaObservation[];
    /**
     * Count of recognized top-level window keys this application could not read: the key held
     * something other than a window object, or held a window object whose `utilization` was
     * missing or not a finite number. A key that is absent or explicitly `null` is not counted,
     * because no window was observed there rather than a window that could not be read.
     */
    rejectedWindowKeys?: number;
    /**
     * Count of top-level keys outside {@link CLAUDE_USAGE_TOP_LEVEL_KEYS}. This counter is the
     * only representation of that fact — no `issues` code duplicates it — so `unknownTopLevelKeys`
     * and the counts in {@link issues} are separate totals over different facts.
     */
    unknownTopLevelKeys?: number;
    /** Fixed-code counts for values an application check rejected, each counted once. */
    issues?: QuotaParseIssues;
}
/**
 * Read one answered response's unified rate-limit headers, once.
 *
 * Every member this module consumes is read here exactly once, and the read-only source is
 * never consulted again by the projectors below: a caller that projects one set of facts
 * into both the legacy report and the strict observations reads the response a single time.
 * The family's member and window names are closed, so a fact set this function did not
 * produce is a programming error rather than wire input.
 * @param get - the read-only header source; `Headers` satisfies it directly.
 * @returns the classified members and windows.
 * @throws Error when the source does not offer the one read this parse depends on.
 */
export declare function parseRawFacts(get: QuotaHeaderSource): RawFacts;
/**
 * Project one read of the unified headers into the plugin's existing report.
 *
 * The reset instant is the injected resolver's answer, not this module's: the legacy
 * surfaces keep every encoding the providers' shared reader accepts (a delay, epoch
 * seconds, epoch milliseconds, a duration, an HTTP-date), and that reader is the one the
 * other subscription routes already use.
 * @param facts - the fact set {@link parseRawFacts} produced.
 * @param deps - the reset resolver, and the observation time for this report.
 * @returns the report, with the fields and values the headers previously produced.
 * @throws Error when the resolver or the observation time is missing or unusable.
 */
export declare function projectLegacy(facts: RawFacts, deps: {
    resolveReset: LegacyResetResolver;
    now: number;
}): QuotaLegacyState;
/**
 * The largest epoch-seconds value this application reads as a header reset.
 *
 * `253402300799` is `9999-12-31T23:59:59Z`, the last second of the last four-digit UTC year
 * RFC 3339 spells without extra digits. The bound exists so the strict path never guesses a
 * unit: a value beyond it is not a four-digit-year instant, and a thirteen-digit value is epoch
 * milliseconds rather than seconds, which this path refuses instead of re-interpreting. It is
 * this build's own reading rule — not a deployment setting and not a limit the service states.
 */
export declare const CLAUDE_QUOTA_MAX_EPOCH_SECONDS = 253402300799;
/**
 * Read the unified headers as strict per-window observations.
 *
 * Only the encoding the header family documents is converted: an `epoch-seconds` reset in the
 * range {@link CLAUDE_QUOTA_MAX_EPOCH_SECONDS} describes becomes epoch milliseconds, once, and
 * nothing else is guessed. A window whose utilization is absent, blank or not a finite number is
 * left out entirely rather than reported as a zero-percent window, and the utilization is
 * normalized exactly once from the fraction the header states.
 *
 * The windows keep their own tokens and observation times: the overage-included week is stored
 * under its own key and gated on a model display list, so it is not the account week and is not
 * merged with it; the overage route states no scope this application established either.
 * @param facts - the fact set {@link parseRawFacts} produced.
 * @param deps - the observation time for this read.
 * @returns one observation per window the response stated usable readings for.
 * @throws Error when the observation time is missing or not finite.
 */
export declare function projectStrict(facts: RawFacts, deps: {
    now: number;
}): ClaudeQuotaObservation[];
/**
 * Parse an OAuth usage document into the plugin's legacy windows, and optionally into strict
 * observations of the same body.
 *
 * The nested `limits` array wins whenever it carries any entry; the flat
 * `five_hour`/`seven_day*` buckets are read only when it does not, so one body never
 * produces two sets of windows for the same quota. Every check here is the application's
 * own: the source client declares but does not enforce a 0–100 percent or an ISO reset, so a
 * value outside those is what the application rejects for a strict reading — the legacy list
 * keeps the window a finite number produced, exactly as it did before this check existed — and
 * a member the document did not state leaves its field absent rather than defaulting to zero.
 *
 * A key this module does not recognize is counted, never named: the returned record carries
 * only fixed codes and counts, so no provider key or display name reaches a log or an
 * observation through it. Every strict reading is projected from its own source element, so two
 * model windows that share a label, a reset or an unknown scope stay two readings.
 * @param body - the parsed usage document, or any other JSON value.
 * @param now - the current epoch milliseconds, for each observation's `observedAtMs`.
 * @param options - set `strictObservations` to also project the strict reading.
 * @returns the legacy windows, and the strict observations when they were requested.
 */
export declare function parseUsageJson(body: unknown, now: number, options?: {
    strictObservations?: boolean;
}): ClaudeQuotaDocument;
