/**
 * The bounded `policy_limits` request reader.
 *
 * It performs one logical request (transport, status classification, the pinned retry
 * budget, cancellation) and returns a decision for its owner to schedule. It never selects
 * an account, never refreshes a credential and never starts a timer: the caller injects the
 * transport, the clock, the sleep, the access token and the one bounded reauthorization, and
 * owns every recovery step this reader only reports.
 */
import type { CoreFailure } from './failures.js';
import type { PolicyLimitsDocument, PolicySnapshot } from './policy-limits.js';
/** A response as this core needs to read it; `fetch`'s `Response` satisfies it. */
export interface CoreHttpResponse {
    readonly status: number;
    readonly headers: {
        get(name: string): string | null;
    };
    /**
     * The unread body. The core pulls it itself under its byte bound, so a transport must NOT
     * pre-read it into a string: a stream is cancelled and its reader released the moment the
     * bound is reached. `fetch`'s `Response.body` satisfies this.
     */
    readonly body: ReadableStream<Uint8Array> | AsyncIterable<Uint8Array> | null;
}
/** One outbound request, with every header the caller decided for this role. */
export interface CoreHttpRequest {
    readonly url: string;
    readonly method: 'GET' | 'POST';
    readonly headers: Readonly<Record<string, string>>;
    /** Request body, or `null` for the bodyless POST the organization validation sends. */
    readonly body: string | null;
    readonly signal: AbortSignal;
    /** Bound on the transport's own wait, in milliseconds. */
    readonly timeoutMs: number;
}
/** The injected transport. It must not read a credential or choose an account. */
export type CoreTransport = (request: CoreHttpRequest) => Promise<CoreHttpResponse>;
/** The injected clock. */
export interface CoreClock {
    /** Current epoch milliseconds. */
    now(): number;
}
/** The injected sleep; it resolves early when the signal aborts. */
export type CoreSleep = (ms: number, signal: AbortSignal) => Promise<void>;
/** The pinned request bound. */
export declare const POLICY_LIMITS_TIMEOUT_MS = 10000;
/** The pinned retry budget: attempts after the first one. */
export declare const POLICY_LIMITS_RETRIES = 5;
/**
 * The authentication replay budget: one extra request after a rejected credential.
 *
 * It is its own explicit budget, outside the retry loop, because a replay answers an
 * authentication result rather than a retryable failure — and it is the credential owner's
 * injected callback that decides what that replay is, not this reader.
 */
export declare const AUTH_REPLAY_BUDGET = 1;
/** The pinned backoff base, ceiling and jitter share. */
export declare const POLICY_LIMITS_BACKOFF_BASE_MS = 500;
export declare const POLICY_LIMITS_BACKOFF_CAP_MS = 32000;
export declare const POLICY_LIMITS_BACKOFF_JITTER = 0.25;
/**
 * The cap on the response body this reader consumes, in bytes.
 *
 * This bound is this build's own product guard, not a pinned constant of the analyzed client:
 * the client reads its body through its own transport with no such fixed byte cap, so a
 * deployment that needs a different bound changes this one deliberately. A body over it is a
 * terminal `unsupported` outcome (`skipRetry`), never a parse failure to retry: re-pulling the
 * same oversized document five more times cannot make it fit.
 */
export declare const POLICY_LIMITS_BODY_LIMIT = 65536;
/**
 * The context a read may lean on, stated by the caller that owns it.
 *
 * It is the same three states its own status projection carries (`PolicyLimitsStatus.fallback`):
 * `live` when an accepted document is in force, `stale` when one is kept through an earlier
 * failed read, and `none` when the caller holds nothing at all. The fail-open answer is for
 * `none` only; under `live` or `stale` the read fails and the caller keeps what it has.
 */
export type PolicyPriorContext = 'live' | 'stale' | 'none';
/**
 * Consume one response body under a hard bound.
 *
 * The body must be read on every outcome, not only when a 200 is parsed: an unread body
 * keeps the connection pinned, and the deadline is only meaningful once the bytes are
 * actually covered. A body over the cap is truncated for classification purposes and
 * reported as truncated, never accumulated further.
 * @param response - the response whose body to consume.
 * @param limit - the byte bound.
 * @returns the consumed text and whether the bound was reached.
 */
export declare function readBoundedBody(response: CoreHttpResponse, limit?: number): Promise<{
    text: string;
    truncated: boolean;
}>;
/**
 * The pinned backoff for one attempt, honouring a `Retry-After` the response stated.
 * @param attempt - zero-based attempt index.
 * @param retryAfterMs - the delay the response asked for, in milliseconds.
 * @param random - injected randomness, so the jitter is deterministic under test.
 * @returns the delay in milliseconds.
 */
export declare function policyBackoffMs(attempt: number, retryAfterMs: number | undefined, random: () => number): number;
/** One `policy_limits` read operation. */
export interface PolicyLimitsReadOperation {
    /** The endpoint, built by the caller from its own base URL. */
    readonly url: string;
    /** The access token for this account; the caller selected and refreshed it. */
    readonly accessToken: string;
    /** The user agent for this role. */
    readonly userAgent: string;
    /** The live session policy's validator (`s`), when one is loaded. */
    readonly validator?: string;
    /** Whether any 2xx is accepted instead of only 200 (`acceptAny2xx`). */
    readonly acceptAny2xx?: boolean;
    /** The injected transport. */
    readonly transport: CoreTransport;
    /** The injected clock. */
    readonly clock: CoreClock;
    /** The injected sleep. */
    readonly sleep: CoreSleep;
    /** Injected randomness for the backoff jitter; defaults to `Math.random`. */
    readonly random?: () => number;
    /** Caller cancellation. */
    readonly signal?: AbortSignal;
    /**
     * The unified classifier for a non-success response, handed the body this reader already
     * consumed exactly once. The version and permission refusals live there, and its
     * `skipRetry` is what makes a refusal terminal for both ends; the classifier owns no side
     * effect (a shared protocol-block record stays the caller's).
     */
    readonly classifyFailure?: (input: {
        readonly status: number;
        readonly headers: {
            get(name: string): string | null;
        };
        readonly body: string;
        readonly truncated: boolean;
    }) => Promise<CoreFailure | undefined>;
    /**
     * One bounded reauthorization, performed by the credential owner. The reader calls it at
     * most once and never refreshes anything itself.
     * @returns the replacement access token.
     */
    readonly reauthorize?: () => Promise<string>;
    /** When true, a parse failure is terminal instead of retryable. */
    readonly parseFailureIsTerminal?: boolean;
    /**
     * When true, a 404 or an unsolicited 304 that finds no prior policy in force (`none`) is
     * answered as a fail-open empty policy; the caller states this from its own
     * `rustlingOrbit` input. With a `live` or `stale` prior it changes nothing: that answer is
     * for a route this caller has never read, never for replacing a rule already in force.
     */
    readonly failOpenOnMissingRoute?: boolean;
    /**
     * What the caller already holds for this account; see {@link PolicyPriorContext}.
     *
     * A caller that omits it is read as `live` when it sent a validator and `none` otherwise,
     * which is the safe inference: no prior context is ever assumed to be a usable `stale`
     * document, so a 404/304 can only fail open for a caller that holds nothing.
     */
    readonly priorContext?: PolicyPriorContext;
}
/** What one logical request resolved to. */
export type PolicyLimitsOutcome = {
    /** A 200 was parsed, or a 304 revalidated the session policy. */
    readonly kind: 'success';
    /** The parsed document, or `null` for a 304 revalidation. */
    readonly response: PolicyLimitsDocument | null;
    /** The validator of the body, absent for a 304. */
    readonly validator?: string;
    /** The `signature` header, when the response carried one. */
    readonly signature?: string;
    readonly attempts: number;
} | {
    /**
     * The pinned fail-open answer for a missing route, produced only for a caller whose
     * `priorContext` is `none`; see the current-state note in the README.
     */
    readonly kind: 'fail_open_empty';
    readonly reason: 'route_missing_fail_open' | 'unsolicited_304_fail_open';
    readonly attempts: number;
} | {
    /**
     * The request failed; the caller owns every recovery decision and keeps its own adopted
     * document, which this reader neither reads nor clears.
     */
    readonly kind: 'failure';
    readonly failure: CoreFailure;
    readonly attempts: number;
    /** Always `caller`: this reader schedules nothing. It sends at most the injected replay. */
    readonly recoveryOwner: 'caller';
} | {
    readonly kind: 'cancelled';
    readonly attempts: number;
};
/**
 * Read the policy document once, with the pinned retry budget.
 *
 * The fail-open answer is produced only for a caller whose prior context is `none`; every other
 * failed read is returned as a failure, and the caller keeps the document it already holds.
 * @param operation - the endpoint, credential, injected transport and classification hooks.
 * @returns the outcome, with the attempt count and the recovery owner on failure.
 */
export declare function readPolicyLimits(operation: PolicyLimitsReadOperation): Promise<PolicyLimitsOutcome>;
/** The snapshot one successful read produces, for a caller that adopts it. */
export declare function snapshotFromOutcome(outcome: PolicyLimitsOutcome, document: PolicyLimitsDocument, validator: string, receivedAt: number): PolicySnapshot;
