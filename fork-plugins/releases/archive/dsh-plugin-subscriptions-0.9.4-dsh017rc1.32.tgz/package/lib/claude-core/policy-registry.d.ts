/**
 * The frozen policy-key registry: the 34 keys the pinned client registers, with the
 * per-key inputs its no-live-policy verdict reads.
 *
 * Generated from the verified evidence package
 * `phase34/business-followup/policy-limits-implementation/evidence.json` (revision 3,
 * `derived.policyRegistry`, anchored at `chunk-d8h3bh4f.js` [33782,38690)). The fields are
 * the pinned artifact own fields: `onCacheMiss`, `onFailOpenVerdict`, `deniedUnder`,
 * `hardBlockUnder`, `serverPopulated`, `transcriptScan`, plus the requirement id and label
 * the registry states. They are protocol constants, not deployment configuration.
 */
/** Verdict a key produces when no live policy is loaded. */
export type PolicyCacheMiss = 'allow' | 'deny' | 'hold';
/** One registered policy key. */
export interface PolicyKeyRegistration {
    /** Verdict a missing live policy produces for this key. */
    readonly onCacheMiss: PolicyCacheMiss;
    /** Verdict a failed-open cache produces, when the key declares one. */
    readonly onFailOpenVerdict: 'deny' | null;
    /** Compliance taints under which the key is denied. */
    readonly deniedUnder: readonly string[];
    /** Compliance taints that block the key outright, ahead of every other input. */
    readonly hardBlockUnder: readonly string[];
    /** Whether the server populates this key in a policy document. */
    readonly serverPopulated: boolean;
    /** Whether the key reads the transcript and is refreshed by that scan. */
    readonly transcriptScan: boolean;
    /** Requirement identifier the pinned registry states. */
    readonly requirementId: string;
    /** Human label the pinned registry states. */
    readonly label: string;
}
/** The registry, keyed by policy key. */
export declare const POLICY_KEY_REGISTRY: Readonly<{
    readonly allow_product_feedback: Readonly<{
        onCacheMiss: "deny";
        onFailOpenVerdict: null;
        deniedUnder: readonly string[];
        hardBlockUnder: readonly never[];
        serverPopulated: true;
        transcriptScan: false;
        requirementId: "HIPAA-R1";
        label: "Feedback";
    }>;
    readonly allow_web_fetch: Readonly<{
        onCacheMiss: "allow";
        onFailOpenVerdict: null;
        deniedUnder: readonly string[];
        hardBlockUnder: readonly never[];
        serverPopulated: true;
        transcriptScan: false;
        requirementId: "HIPAA-R3";
        label: "Web fetch";
    }>;
    readonly allow_memory_sync: Readonly<{
        onCacheMiss: "allow";
        onFailOpenVerdict: null;
        deniedUnder: readonly string[];
        hardBlockUnder: readonly string[];
        serverPopulated: false;
        transcriptScan: false;
        requirementId: "HIPAA-R5";
        label: "Memory sync";
    }>;
    readonly allow_design_sync: Readonly<{
        onCacheMiss: "allow";
        onFailOpenVerdict: null;
        deniedUnder: readonly string[];
        hardBlockUnder: readonly never[];
        serverPopulated: false;
        transcriptScan: false;
        requirementId: "HIPAA-R9";
        label: "Design sync";
    }>;
    readonly allow_projects_tool: Readonly<{
        onCacheMiss: "hold";
        onFailOpenVerdict: null;
        deniedUnder: readonly string[];
        hardBlockUnder: readonly string[];
        serverPopulated: false;
        transcriptScan: false;
        requirementId: "HIPAA-R17";
        label: "Projects";
    }>;
    readonly allow_claude_browser_extension: Readonly<{
        onCacheMiss: "allow";
        onFailOpenVerdict: null;
        deniedUnder: readonly string[];
        hardBlockUnder: readonly never[];
        serverPopulated: true;
        transcriptScan: false;
        requirementId: "HIPAA-R34";
        label: "Claude in Chrome";
    }>;
    readonly allow_remote_sessions: Readonly<{
        onCacheMiss: "deny";
        onFailOpenVerdict: null;
        deniedUnder: readonly string[];
        hardBlockUnder: readonly never[];
        serverPopulated: true;
        transcriptScan: false;
        requirementId: "HIPAA-R6";
        label: "Cloud sessions";
    }>;
    readonly allow_remote_control: Readonly<{
        onCacheMiss: "deny";
        onFailOpenVerdict: null;
        deniedUnder: readonly string[];
        hardBlockUnder: readonly never[];
        serverPopulated: true;
        transcriptScan: false;
        requirementId: "HIPAA-R6";
        label: "Remote Control";
    }>;
    readonly allow_cobalt_plinth: Readonly<{
        onCacheMiss: "deny";
        onFailOpenVerdict: null;
        deniedUnder: readonly string[];
        hardBlockUnder: readonly never[];
        serverPopulated: true;
        transcriptScan: false;
        requirementId: "HIPAA-R16";
        label: "Artifacts";
    }>;
    readonly allow_team_onboarding: Readonly<{
        onCacheMiss: "hold";
        onFailOpenVerdict: null;
        deniedUnder: readonly string[];
        hardBlockUnder: readonly string[];
        serverPopulated: false;
        transcriptScan: false;
        requirementId: "HIPAA-R13";
        label: "Team onboarding";
    }>;
    readonly allow_error_reporting: Readonly<{
        onCacheMiss: "deny";
        onFailOpenVerdict: null;
        deniedUnder: readonly string[];
        hardBlockUnder: readonly never[];
        serverPopulated: false;
        transcriptScan: false;
        requirementId: "HIPAA-R19";
        label: "Error reporting";
    }>;
    readonly allow_auto_mode_sibling_docs: Readonly<{
        onCacheMiss: "deny";
        onFailOpenVerdict: null;
        deniedUnder: readonly string[];
        hardBlockUnder: readonly never[];
        serverPopulated: false;
        transcriptScan: false;
        requirementId: "HIPAA-R36";
        label: "Repository lookups";
    }>;
    readonly allow_repo_visibility_probe: Readonly<{
        onCacheMiss: "hold";
        onFailOpenVerdict: null;
        deniedUnder: readonly string[];
        hardBlockUnder: readonly never[];
        serverPopulated: false;
        transcriptScan: false;
        requirementId: "HIPAA-R36";
        label: "Repository visibility checks";
    }>;
    readonly allow_send_file: Readonly<{
        onCacheMiss: "deny";
        onFailOpenVerdict: null;
        deniedUnder: readonly string[];
        hardBlockUnder: readonly never[];
        serverPopulated: false;
        transcriptScan: false;
        requirementId: "HIPAA-R37";
        label: "File upload";
    }>;
    readonly allow_heap_dump: Readonly<{
        onCacheMiss: "deny";
        onFailOpenVerdict: null;
        deniedUnder: readonly string[];
        hardBlockUnder: readonly never[];
        serverPopulated: false;
        transcriptScan: false;
        requirementId: "HIPAA-R38";
        label: "Heap dumps";
    }>;
    readonly allow_local_checkpoint_commit: Readonly<{
        onCacheMiss: "deny";
        onFailOpenVerdict: null;
        deniedUnder: readonly string[];
        hardBlockUnder: readonly never[];
        serverPopulated: false;
        transcriptScan: false;
        requirementId: "HIPAA-R39";
        label: "Usage-limit checkpoints";
    }>;
    readonly allow_plugin_skill_search: Readonly<{
        onCacheMiss: "deny";
        onFailOpenVerdict: null;
        deniedUnder: readonly string[];
        hardBlockUnder: readonly never[];
        serverPopulated: false;
        transcriptScan: false;
        requirementId: "HIPAA-R26";
        label: "Plugin and skill search";
    }>;
    readonly allow_plugin_directory_search: Readonly<{
        onCacheMiss: "deny";
        onFailOpenVerdict: "deny";
        deniedUnder: readonly string[];
        hardBlockUnder: readonly never[];
        serverPopulated: false;
        transcriptScan: false;
        requirementId: "HIPAA-R35";
        label: "The plugin directory";
    }>;
    readonly allow_connector_suggest: Readonly<{
        onCacheMiss: "deny";
        onFailOpenVerdict: "deny";
        deniedUnder: readonly string[];
        hardBlockUnder: readonly never[];
        serverPopulated: false;
        transcriptScan: false;
        requirementId: "HIPAA-R43";
        label: "Connector suggestions";
    }>;
    readonly allow_mcp_task_worker_wake: Readonly<{
        onCacheMiss: "deny";
        onFailOpenVerdict: null;
        deniedUnder: readonly string[];
        hardBlockUnder: readonly never[];
        serverPopulated: false;
        transcriptScan: false;
        requirementId: "HIPAA-R57";
        label: "Restarting a worker for a background task";
    }>;
    readonly allow_account_skills_sync: Readonly<{
        onCacheMiss: "deny";
        onFailOpenVerdict: null;
        deniedUnder: readonly string[];
        hardBlockUnder: readonly never[];
        serverPopulated: true;
        transcriptScan: false;
        requirementId: "HIPAA-R29";
        label: "Account skills sync";
    }>;
    readonly allow_account_plugins_sync: Readonly<{
        onCacheMiss: "deny";
        onFailOpenVerdict: null;
        deniedUnder: readonly string[];
        hardBlockUnder: readonly never[];
        serverPopulated: true;
        transcriptScan: false;
        requirementId: "HIPAA-R30";
        label: "Account plugins sync";
    }>;
    readonly allow_bundled_skills: Readonly<{
        onCacheMiss: "allow";
        onFailOpenVerdict: null;
        deniedUnder: readonly string[];
        hardBlockUnder: readonly never[];
        serverPopulated: false;
        transcriptScan: false;
        requirementId: "HIPAA-R56";
        label: "Bundled skills";
    }>;
    readonly allow_mycelium: Readonly<{
        onCacheMiss: "deny";
        onFailOpenVerdict: null;
        deniedUnder: readonly string[];
        hardBlockUnder: readonly string[];
        serverPopulated: false;
        transcriptScan: false;
        requirementId: "HIPAA-R25";
        label: "Peer messaging";
    }>;
    readonly allow_usage_transcript_scan: Readonly<{
        onCacheMiss: "deny";
        onFailOpenVerdict: null;
        deniedUnder: readonly string[];
        hardBlockUnder: readonly never[];
        serverPopulated: false;
        transcriptScan: true;
        requirementId: "HIPAA-R31";
        label: "Usage patterns";
    }>;
    readonly allow_skill_doctor_transcript_scan: Readonly<{
        onCacheMiss: "deny";
        onFailOpenVerdict: null;
        deniedUnder: readonly string[];
        hardBlockUnder: readonly never[];
        serverPopulated: false;
        transcriptScan: true;
        requirementId: "HIPAA-R32";
        label: "Skill token counts";
    }>;
    readonly allow_insights: Readonly<{
        onCacheMiss: "deny";
        onFailOpenVerdict: null;
        deniedUnder: readonly string[];
        hardBlockUnder: readonly never[];
        serverPopulated: false;
        transcriptScan: true;
        requirementId: "HIPAA-R40";
        label: "Insights";
    }>;
    readonly allow_stats_transcript_scan: Readonly<{
        onCacheMiss: "deny";
        onFailOpenVerdict: null;
        deniedUnder: readonly string[];
        hardBlockUnder: readonly never[];
        serverPopulated: false;
        transcriptScan: true;
        requirementId: "HIPAA-R42";
        label: "Usage stats";
    }>;
    readonly allow_model_catalog: Readonly<{
        onCacheMiss: "allow";
        onFailOpenVerdict: null;
        deniedUnder: readonly string[];
        hardBlockUnder: readonly never[];
        serverPopulated: false;
        transcriptScan: false;
        requirementId: "HIPAA-R33";
        label: "The model catalog";
    }>;
    readonly allow_container_result_files: Readonly<{
        onCacheMiss: "deny";
        onFailOpenVerdict: null;
        deniedUnder: readonly string[];
        hardBlockUnder: readonly never[];
        serverPopulated: false;
        transcriptScan: false;
        requirementId: "HIPAA-R53";
        label: "Saving large tool results in the tool container";
    }>;
    readonly allow_promo_offers: Readonly<{
        onCacheMiss: "deny";
        onFailOpenVerdict: null;
        deniedUnder: readonly string[];
        hardBlockUnder: readonly never[];
        serverPopulated: false;
        transcriptScan: false;
        requirementId: "HIPAA-R54";
        label: "Promotional offers";
    }>;
    readonly allow_previous_conversation_pointer: Readonly<{
        onCacheMiss: "deny";
        onFailOpenVerdict: null;
        deniedUnder: readonly string[];
        hardBlockUnder: readonly never[];
        serverPopulated: false;
        transcriptScan: false;
        requirementId: "HIPAA-R58";
        label: "Linking a new conversation to the one it replaces";
    }>;
    readonly allow_api_auth_warm: Readonly<{
        onCacheMiss: "deny";
        onFailOpenVerdict: null;
        deniedUnder: readonly string[];
        hardBlockUnder: readonly never[];
        serverPopulated: false;
        transcriptScan: false;
        requirementId: "HIPAA-R59";
        label: "Warming the API credential cache";
    }>;
    readonly allow_cache_keepalive: Readonly<{
        onCacheMiss: "deny";
        onFailOpenVerdict: null;
        deniedUnder: readonly string[];
        hardBlockUnder: readonly never[];
        serverPopulated: false;
        transcriptScan: false;
        requirementId: "HIPAA-R65";
        label: "Renewing the prompt cache lifetime";
    }>;
}>;
/** The literal union of every registered policy key. */
export type PolicyKey = keyof typeof POLICY_KEY_REGISTRY;
/** Every registered policy key, in registry order. */
export declare const POLICY_KEYS: readonly PolicyKey[];
/** The taint the pinned client treats as the HIPAA evidence scope. */
export declare const HIPAA_TAINT = "hipaa";
/**
 * Look one key up.
 * @param key - the policy key.
 * @returns its registration, or `undefined` when this build does not know the key.
 */
export declare function policyRegistration(key: string): PolicyKeyRegistration | undefined;
