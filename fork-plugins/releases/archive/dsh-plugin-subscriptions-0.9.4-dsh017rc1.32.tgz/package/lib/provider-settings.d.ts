import { type ProviderId } from './auth/store.js';
export declare const PROVIDER_TOOLS: {
    readonly codex: readonly ["image_generate", "web_search"];
    readonly claude: readonly [];
    readonly grok: readonly ["image_generate", "video_generate", "x_search"];
    readonly copilot: readonly [];
    readonly antigravity: readonly [];
    readonly cursor: readonly [];
};
export type SubscriptionTool = 'image_generate' | 'video_generate' | 'x_search' | 'web_search';
export interface AccountPreferences {
    alias?: string;
    /** Absent means included. */
    poolEnabled?: boolean;
    /** Absent means no separate picker entries. */
    independentEntry?: boolean;
    /** Absent allows every model; [] allows none. */
    poolModels?: string[];
}
export interface ProviderPreferences {
    /** ChatGPT only; absent disables automatic spending of the globally earliest-expiring credit. */
    autoResetCredits?: boolean;
    accounts?: Record<string, AccountPreferences>;
    /** Absent follows discovery; an explicit selection hides newly discovered models. */
    visibleModels?: string[];
    contextWindows?: Record<string, number>;
    tools?: Partial<Record<SubscriptionTool, boolean>>;
}
export declare function validatePreferences(provider: ProviderId, input: unknown): ProviderPreferences;
/** Durable user preferences, independent of expiring discovery caches. */
export declare class ProviderSettingsStore {
    private current;
    private writes;
    /**
     * Retired account key -> canonical key, per provider, for a rename whose
     * durable move may not have landed. It projects the SAME stored policy onto
     * the canonical key for every reader, so a failed migration write cannot
     * silently restore the permissive defaults the user turned off.
     */
    private readonly renames;
    readonly path: string;
    constructor(path?: string);
    /**
     * The provider's stored preferences, with any pending account rename projected
     * onto the canonical key; callers must treat the result as read-only.
     * @param provider - provider whose preferences are read.
     * @returns the stored preferences, or an empty object when the provider has none.
     */
    get(provider: ProviderId): ProviderPreferences;
    visible(provider: ProviderId, model: string): boolean;
    contextWindow(provider: ProviderId, model: string): number | undefined;
    /** Creation-time policy survives restarts and never changes an existing session. */
    toolEnabled(provider: ProviderId, tool: SubscriptionTool, createdAt?: number): boolean;
    set(provider: ProviderId, input: unknown): Promise<void>;
    /** Apply one validated preference set on the write queue, in call order. */
    private enqueue;
    /**
     * Move one account's stored preferences onto the canonical key the token store
     * renamed it to.
     *
     * This is user policy, not a cache: the account's pool membership, its model
     * allowlist, its independent-picker flag and its alias decide whether the
     * account may serve at all. Losing them at a rename would silently restore the
     * permissive defaults the user turned off, so the entry moves whole. When the
     * canonical key already carries an entry — the user edited it after the rename
     * — that entry's own fields win and the moved entry fills the rest, so neither
     * edit is discarded.
     *
     * The rename is projected in memory FIRST and independently of the write, so
     * every reader of the canonical key sees the same policy even if this write
     * fails; the durable move only makes that projection unnecessary. The edit
     * itself runs on the write queue after any save already queued, so it cannot
     * overwrite that save with a snapshot taken before it landed.
     * @param provider - the provider route.
     * @param from - the key the account's preferences were stored under.
     * @param to - the canonical key the account now resolves to.
     * @returns nothing once the moved preferences are durable.
     */
    renameAccount(provider: ProviderId, from: string, to: string): Promise<void>;
    /** One validated provider preference set, written to disk and adopted. */
    private write;
}
