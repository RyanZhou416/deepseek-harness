/**
 * dsh-plugin-subscriptions: register OAuth-subscription LLM providers
 * (ChatGPT/Codex, Claude, Grok, GitHub Copilot, Google Antigravity, Cursor) on `ctx.llm`, and expose the `/subscriptions-auth`
 * RPC channel the web Settings page uses to run the logins. The token store
 * lives at `~/.dsh/plugins/subscriptions/auth.json`; the channel registers only when
 * a host `connection` service exists, so headless compositions load fine.
 * @module dsh-plugin-subscriptions
 */
import type { Context } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
import type { AttachmentStore, ImageAttachmentRef } from '@deepseek-ai/dsh-attachment';
import type { SubscriptionCachePolicy } from './cache-policy.js';
import { OAuthFlowManager } from './auth/oauth-flow.js';
import { DeviceFlowManager } from './auth/device-flow.js';
import type { ClaudeSourceCredential } from './auth/claude-code-creds.js';
import type { ClaudeCredentialMode } from './auth/claude-credential-ownership.js';
import type { AuthController, ImageBytesResult, LoginMethod, ProviderStatus, VideoBytesResult } from './auth/rpc.js';
import type { ClaudeSession, ProviderId } from './auth/store.js';
import type { FetchFn, ModelEntry, ProviderUsage, ResetCreditConsumeResult, ResetCreditList, UsagePoolState } from './providers/common.js';
import type { RateLimitConfig } from './providers/rate-limit.js';
import type { PoolSchedulingPolicy } from './providers/pool-scheduling.js';
export type { AccountPreferences, ProviderPreferences } from './provider-settings.js';
import type { PoolMemberRef } from './providers/pool-family.js';
import { PoolUsageTracker } from './providers/pool-usage.js';
import type { CoreTransport } from './claude-core/index.js';
import type { AntigravityRuntimeConfig } from './providers/antigravity.js';
export type { ModelEntry, ProviderUsage, UsageWindow } from './providers/common.js';
export type { RateLimitConfig, RateLimitWait } from './providers/rate-limit.js';
export type { AccountStatus, AvailabilityCode, AvailabilityStatus, CredentialCode, CredentialStatus, PolicyCode, PolicyScope, PolicyStatus, ProfileStatus, ProtocolCode, ProtocolStatus, ProviderFailureCode, ProviderOperation, ProviderOperationFailure, ProviderStatus, ProviderUnavailableCode, } from './auth/rpc.js';
export type { AntigravitySession, ClaudeSession, CodexSession, CopilotSession, CursorSession, GrokSession, ProviderId } from './auth/store.js';
export declare const name = "dsh-plugin-subscriptions";
export declare const inject: string[];
export { withTimeout } from './providers/common.js';
/** Plugin config, validated by the same-named schemastery schema. */
export interface Config {
    /** Codex /models client_version override; does not change account entitlements. */
    codexClientVersion?: string;
    /** Provider routes to register; defaults to every supported provider. */
    providers?: ProviderId[];
    /** Maximum provider idle time while one stream read is outstanding (default five minutes). */
    streamIdleTimeoutMs?: number;
    /** Maximum unread bytes per Claude transport response; consumed bytes do not count (default 32 MiB). */
    claudeTransportMaxQueuedBytes?: number;
    /**
     * What a Claude request tells the model about its own environment, in place of the harness
     * identity section. Clamped to this route: the harness identity stays in force everywhere
     * else. Empty omits the identity entirely.
     */
    claudeIdentityLine?: string;
    /**
     * Whether a refresh of a keychain-imported Claude account is written back into Claude
     * Code's own credential store. Off by default: that store belongs to another application,
     * and a browser-authorized account never touches it. Turning it on keeps an installed
     * `claude` CLI in sync with a rotation this plugin performs.
     */
    syncClaudeCodeCredentials?: boolean;
    /** Demand-driven metadata freshness; no duration starts a polling timer. */
    cache?: Partial<SubscriptionCachePolicy>;
    /**
     * Claude account-maintenance bounds. Every value is validated at load: a zero
     * or negative bound is a misconfiguration, because none of them switches a
     * maintenance capability off. The credential lead defaults to the provider's
     * own `CLAUDE_PREEMPT_MS` baseline rather than a second copy of the constant.
     */
    claudeMaintenance?: {
        /** Lead time before credential expiry at which the renewal timer runs. */
        refreshLeadMs?: number;
        /** How long an accepted account profile stays fresh. */
        profileMaxAgeMs?: number;
        /** Period between managed-settings polls while an account is bound. */
        policyPollMs?: number;
        /** Bound on one profile or settings read. */
        readTimeoutMs?: number;
        /** First retry delay after a failed maintenance cycle. */
        failureBackoffMs?: number;
        /** Ceiling the failure backoff doubles up to. */
        maxFailureBackoffMs?: number;
        /**
         * Floor between two credential checks, so a server that keeps answering with a
         * short-lived or unchanged expiry cannot turn a successful cycle into a zero-delay loop.
         */
        minRefreshDelayMs?: number;
    };
    /** Whether and how long a route waits out a closed rate-limit window. */
    rateLimit?: RateLimitConfig;
    /** Advisory model catalogs overriding the built-in defaults, per provider. */
    models?: {
        codex?: ModelEntry[];
        claude?: ModelEntry[];
        grok?: ModelEntry[];
        copilot?: ModelEntry[];
        antigravity?: ModelEntry[];
        cursor?: ModelEntry[];
    };
    /** Antigravity-specific OAuth and endpoint configuration. */
    antigravity?: AntigravityRuntimeConfig & {
        /** Google OAuth client id. May instead be supplied as ANTIGRAVITY_CLIENT_ID. */
        clientId?: string;
        /** Google OAuth client secret, when required by the client registration. */
        clientSecret?: string;
    };
    /** Same-subscription account pools (and optional extra tier models). */
    pool?: {
        /** Enable account pooling (default true; needs ≥2 accounts of one provider). */
        enabled?: boolean;
        /** Member selection: plain priority failover, or quota-aware urgency scheduling. */
        strategy?: 'priority' | 'quota_aware';
        /** A challenger must out-score the sticky member by this factor to take over (default 2). */
        switchMargin?: number;
        /** Bounded reset/finishing preferences and per-account concurrency penalty. */
        scheduling?: Partial<PoolSchedulingPolicy>;
        /** Auto-pool every catalog model across a provider's logged-in accounts (default true). */
        autoAccounts?: boolean;
        /** Explicit account lists for one catalog model (same provider); replaces the auto pool. */
        families?: Record<string, PoolMemberRef[]>;
        /** Extra picker entries with heterogeneous fallbacks, listed under the first member's provider. */
        tiers?: Record<string, PoolMemberRef[]>;
    };
    /**
     * How long one Claude continuation-state operation may wait before the request is refused
     * (default 1000). The bound belongs to this plugin rather than to the client: it is what stops a
     * request from waiting on a document another process is writing, and a caller that reaches it
     * sends nothing.
     */
    continuationStateDeadlineMs?: number;
    /**
     * How long one continuation-state operation may wait for its own lock (default 2000). It is the
     * same owner as the plugin's existing lock budget and never a UI switch: a lock that cannot be
     * owned refuses the operation instead of running it unowned.
     */
    continuationStateLockTimeoutMs?: number;
}
/** The request-state budget in force when the configuration states none. */
export declare const DEFAULT_CONTINUATION_STATE_DEADLINE_MS = 1000;
/** The lock budget in force when the configuration states none. */
export declare const DEFAULT_CONTINUATION_STATE_LOCK_TIMEOUT_MS = 2000;
/**
 * The validated request-state budget this installation runs with.
 *
 * The schema validates and defaults this field, so a configuration that reached `apply` states a
 * number; this is the one place that reads it, rather than defaulting it again at a call site.
 * @param config - the resolved plugin configuration.
 * @returns the budget in milliseconds.
 */
export declare function resolveContinuationStateDeadlineMs(config: Config): number;
/**
 * The validated lock budget this installation runs with.
 * @param config - the resolved plugin configuration.
 * @returns the budget in milliseconds.
 */
export declare function resolveContinuationStateLockTimeoutMs(config: Config): number;
export declare const Config: z<Config>;
/** Per-provider per-account usage lookup; providers without a usage endpoint are absent. */
type UsageFetchers = Partial<Record<ProviderId, (account: string, signal: AbortSignal) => Promise<ProviderUsage>>>;
/** Fixed log code for a Host that does not declare the required contract. */
export declare const CLAUDE_HOST_INCOMPATIBLE = "CLAUDE_HOST_INCOMPATIBLE";
/** One account's decision about one tool operation. */
interface ToolPolicyDecision {
    readonly decision: 'allow' | 'deny';
    /** Stable code naming what refused the call, when it was refused. */
    readonly code?: string;
    /** The registered policy key behind a `policy_limits` refusal, for the model-facing reason. */
    readonly key?: string;
    /** The answer's own fixed reason code, for the model-facing reason. */
    readonly reason?: string;
}
/** The fixed code a key the live document refuses reports when it stops an operation. */
export declare const POLICY_LIMITS_DENIED = "POLICY_LIMITS_DENIED";
/** The fixed code a key this build cannot map exactly reports when it stops an operation. */
export declare const POLICY_LIMITS_UNSUPPORTED = "POLICY_LIMITS_UNSUPPORTED";
/** The fixed code a request refused because its `policy_limits` read failed reports. */
export declare const POLICY_LIMITS_UNAVAILABLE = "POLICY_LIMITS_UNAVAILABLE";
/**
 * The placeholder an unknown policy key is reported as.
 *
 * A key the provider stated is remote text: it may echo a credential, a prompt fragment or an
 * instruction, and this refusal reaches the model, the client's error projection and the
 * session log. Only the pinned registry's own key names may travel, so an unknown key is
 * reported as this fixed placeholder and its value never crosses the boundary — the core still
 * evaluates the original key internally, and the denial it produces is unchanged.
 */
export declare const UNSUPPORTED_POLICY_KEY = "unsupported_policy_key";
/**
 * The fixed code a request refused by the organization pin its accepted policy stated reports.
 *
 * The owner's own finer code (`org_pin_mismatch`, `org_verify_failed`, `invalid_input`) stays
 * inside the message: the client and the pool route read this one, which is the same for every
 * way a pin refuses an account.
 */
export declare const POLICY_ORG_PIN_REFUSED = "POLICY_ORG_PIN_REFUSED";
/**
 * Non-serializable hooks that make an otherwise network-bound decision deterministic in
 * tests. The Loader never supplies them; every decision they replace is still enforced at
 * the same place.
 */
export interface SubscriptionInternals {
    /**
     * Replace the per-account tool-policy decision a guard asks for. Absent reads the live
     * accepted policy from the account-maintenance owner.
     */
    readonly toolPolicyDecision?: (account: string, tool: string) => ToolPolicyDecision;
    /**
     * Replace the transport the independent `policy_limits` read uses. Absent performs the
     * request with this plugin's own fetch, exactly as a deployment does.
     */
    readonly policyLimitsTransport?: CoreTransport;
    /**
     * Replace the transport the organization validation uses. Absent performs the request with
     * this plugin's own fetch, exactly as a deployment does.
     */
    readonly orgPinTransport?: CoreTransport;
    /**
     * Replace the reader of Claude Code's own credential store. Absent reads the real store — the
     * credentials file, or the macOS Keychain on darwin. A test supplies a synthetic reader so no
     * case runs a real `security` command, reads the user's own credential file, or writes one.
     * The returned value keeps the scopes the source itself declared separate from the session
     * shape this plugin records.
     */
    readonly claudeCredentialSource?: () => ClaudeSourceCredential | undefined;
    /**
     * Replace the transport one Claude Messages request is issued through. Absent uses this
     * plugin's own Bun transport, exactly as a deployment does. A test supplies a synthetic
     * transport so a successful request can be observed without a real runtime, the same way the
     * `policy_limits` and organization transports are injected.
     */
    readonly claudeMessagesFetch?: FetchFn;
}
/** ChatGPT reset-credit reads and spends. Absent when the Codex provider is not registered. */
interface CodexResetCreditOps {
    list(account: string, signal: AbortSignal): Promise<ResetCreditList>;
    consume(account: string, creditId: string, redeemRequestId: string, signal: AbortSignal): Promise<ResetCreditConsumeResult>;
}
/**
 * Read one account's locally recorded state without any provider request. The
 * plugin supplies this over its own state owners (pool health, protocol-block
 * store, account maintenance); absent means the account is reported from the
 * credential store alone.
 */
type AccountStateReader = (provider: ProviderId, account: string) => AccountStateReport | undefined | Promise<AccountStateReport | undefined>;
/**
 * Route one credential refresh to the path its ownership mode allows.
 *
 * The manager's refresh selector usually sees only credentials this plugin owns, but that is not
 * a guarantee: a mode change landing between the manager's own load and its refresh hands this
 * selector a record whose ownership has moved. Every mode is therefore routed explicitly, and the
 * read-only one never falls through to this plugin's own grant — it is served from its external
 * source, checked against the reference the manager already holds, or the refresh stops. The
 * plugin's store is deliberately not read again here: this runs while the manager holds its own
 * durable lock on that account, and a second read through the same lock would deadlock.
 * @param session - the credential the refresh cycle is about to spend.
 * @param deps - the sync opt-in and the one credential-source reader.
 * @returns the credential to store.
 */
export declare function refreshForClaudeOwnership(session: ClaudeSession, deps: {
    readonly syncClaudeCodeCredentials: boolean;
    readonly readSource: () => ClaudeSourceCredential | undefined;
}): Promise<ClaudeSession>;
export declare class SubscriptionsAuthController implements AuthController {
    private readonly flows;
    /** Device-flow attempts (copilot); polled in the background like the loopback flows. */
    private readonly deviceFlows;
    /** Announces an auth-state change so catalog readers re-query (fires `llm/adapters-updated`). */
    private readonly onAuthChanged;
    /** Lazy attachment-store lookup for the `image` endpoint. */
    private readonly resolveAttachments;
    /** Usage lookups for providers that expose a usage endpoint. */
    private readonly usageFetchers;
    /**
     * Reads the Claude Code session from its own store. Constructor-injected so
     * tests can drive both login paths without a real credential store; the
     * plugin itself always uses the default.
     */
    private readonly readClaudeCreds;
    /** Antigravity OAuth/runtime configuration. */
    private readonly antigravityConfig;
    /** ChatGPT reset-credit operations. Other providers never call them. */
    private readonly resetCreditOps;
    /**
     * Carries an account's frozen device identity onto a session a fresh authorization
     * produced. Injected so both login paths can be driven without a token store; the
     * plugin itself reads the stored session for that account, because re-authorizing
     * must not change the device the account presents.
     */
    private readonly preserveClaudeIdentity;
    /**
     * The account pool's view of one account, for the `usage` endpoint's
     * attribution line. Undefined while the pool is disabled, which is also
     * when nothing routes around a parked account.
     */
    private readonly poolState;
    /** Local identity reconciliation, shared with the registered model routes. */
    private readonly beforeRead;
    /**
     * Locally recorded per-account dimensions beyond the credential store — pool
     * cooldowns, protocol blocks, account maintenance. Read without any provider
     * request, and absent in compositions that own none of that state.
     */
    private readonly accountState;
    /**
     * Provider routes this plugin refused to register for this Host, so the
     * status projection states the reason instead of an unexplained logout.
     */
    private readonly refusedRoutes;
    /**
     * The identity gate Claude's credential mutations run behind; absent keeps an isolated
     * composition's previous behaviour, and the real composition always supplies one.
     */
    private readonly claudeIdentity;
    /** Last failed provider operation, reported as a fixed code until the next success. */
    private lastError;
    /**
     * Device-flow logins whose poll already settled but whose token exchange +
     * persist is still running. Between those two moments the attempt is gone
     * from the flow manager (busy=false) while no session exists yet
     * (loggedIn=false) — counting this window as busy keeps the Settings page
     * polling until the card can show the real outcome.
     */
    private finalizing;
    /** In-flight OAuth completions, one per provider at most. */
    private completions;
    /** Cursor browser logins, keyed by the claim that started them. */
    private cursorLogins;
    /**
     * Per-provider claim counter. Everything that takes ownership of a
     * provider's session — starting a login, importing Claude Code credentials,
     * cancelling, logging out — bumps it, and a session write carrying an older
     * number has been superseded and is dropped.
     *
     * The counter is what makes a late OAuth completion safe: an attempt leaves
     * `OAuthFlowManager`'s pending map the moment its callback delivers the
     * code, while the token exchange that follows can still run for seconds. For
     * that whole window `pending(provider)?.cancel()` is a no-op, so ownership
     * cannot be read off the flow manager.
     */
    private claims;
    /**
     * Commit one Claude credential behind the identity gate.
     *
     * The account's owner is established first, the change closes the request gate synchronously,
     * and the caller's write is the change's own operation. A refused or failed write therefore
     * publishes nothing and leaves the account closed, rather than reporting a login that did not
     * happen.
     * @param account - the canonical account key.
     * @param change - which identity change this is.
     * @param commit - the credential mutation itself.
     * @throws Error when the account's identity could not be established or the change did not settle.
     */
    private commitClaudeIdentity;
    /** Shared local usage snapshots even when account pooling is disabled. */
    private readonly usageCache;
    /** Cached reset-credit lists, keyed `provider/account`. Not consulted by pool selection. */
    private readonly creditCache;
    /** One in-flight list per account generation, so a spend cannot join a stale read. */
    private readonly creditInflight;
    /** Bumped when a list must not be written back (logout, or a successful spend). */
    private readonly creditEpoch;
    constructor(flows: OAuthFlowManager, 
    /** Device-flow attempts (copilot); polled in the background like the loopback flows. */
    deviceFlows: DeviceFlowManager, 
    /** Announces an auth-state change so catalog readers re-query (fires `llm/adapters-updated`). */
    onAuthChanged: (provider: ProviderId, account?: string, reason?: 'login' | 'logout' | 'default' | 'ownership') => void, 
    /** Lazy attachment-store lookup for the `image` endpoint. */
    resolveAttachments: () => AttachmentStore | undefined, 
    /** Usage lookups for providers that expose a usage endpoint. */
    usageFetchers?: UsageFetchers, 
    /**
     * Reads the Claude Code session from its own store. Constructor-injected so
     * tests can drive both login paths without a real credential store; the
     * plugin itself always uses the default.
     */
    readClaudeCreds?: () => ClaudeSession | undefined, 
    /** Usage snapshots shared with routing; absent only in isolated controller compositions. */
    poolUsage?: PoolUsageTracker | undefined, 
    /** Antigravity OAuth/runtime configuration. */
    antigravityConfig?: Config['antigravity'], 
    /** ChatGPT reset-credit operations. Other providers never call them. */
    resetCreditOps?: CodexResetCreditOps | undefined, 
    /**
     * Carries an account's frozen device identity onto a session a fresh authorization
     * produced. Injected so both login paths can be driven without a token store; the
     * plugin itself reads the stored session for that account, because re-authorizing
     * must not change the device the account presents.
     */
    preserveClaudeIdentity?: (session: ClaudeSession) => Promise<ClaudeSession>, 
    /**
     * The account pool's view of one account, for the `usage` endpoint's
     * attribution line. Undefined while the pool is disabled, which is also
     * when nothing routes around a parked account.
     */
    poolState?: (provider: ProviderId, account: string) => Promise<UsagePoolState | undefined>, 
    /** Local identity reconciliation, shared with the registered model routes. */
    beforeRead?: () => Promise<void>, 
    /**
     * Locally recorded per-account dimensions beyond the credential store — pool
     * cooldowns, protocol blocks, account maintenance. Read without any provider
     * request, and absent in compositions that own none of that state.
     */
    accountState?: AccountStateReader | undefined, 
    /**
     * Provider routes this plugin refused to register for this Host, so the
     * status projection states the reason instead of an unexplained logout.
     */
    refusedRoutes?: readonly ProviderId[], 
    /**
     * The identity gate Claude's credential mutations run behind; absent keeps an isolated
     * composition's previous behaviour, and the real composition always supplies one.
     */
    claudeIdentity?: ClaudeAuthIdentityPort | undefined);
    usage(provider: ProviderId, account: string, signal: AbortSignal, force?: boolean, refresh?: boolean): Promise<ProviderUsage>;
    listResetCredits(provider: ProviderId, account: string, signal: AbortSignal, force?: boolean): Promise<ResetCreditList>;
    consumeResetCredit(provider: ProviderId, account: string, creditId: string, redeemRequestId: string, signal: AbortSignal): Promise<ResetCreditConsumeResult>;
    /** Drop cached credit lists for one account, or every account of a provider. */
    forgetResetCredits(provider: ProviderId, account?: string): void;
    /** Join the in-flight list for this generation, or start one. Failures cool down like usage. */
    private fetchCreditList;
    readImage(ref: ImageAttachmentRef, signal: AbortSignal): Promise<ImageBytesResult>;
    readVideo(name: string, signal: AbortSignal): Promise<VideoBytesResult>;
    status(provider: ProviderId): Promise<ProviderStatus>;
    login(provider: ProviderId, method?: LoginMethod): Promise<{
        authorizeUrl: string;
        userCode?: string;
    }>;
    /**
     * Take ownership of a provider's session, superseding every older claim.
     * @param provider - the provider route.
     * @returns the claim number a later write checks itself against.
     */
    private claim;
    /**
     * Drive one attempt to a stored session; records failures for the status
     * endpoint. The exchange runs unsupervised — the attempt is gone from the
     * flow manager as soon as its code arrives — so the result is stored only
     * while `claim` still owns the provider's session.
     */
    private complete;
    /** Drive one device-flow attempt to a stored session (the copilot path of {@link complete}). */
    private completeDevice;
    private exchange;
    /** Store one Cursor login if this claim still owns the provider. */
    private finishCursorLogin;
    /** Abort every Cursor login this controller started. */
    private cancelCursorLogins;
    private persist;
    manual(provider: ProviderId, input: string): Promise<void>;
    cancel(provider: ProviderId): Promise<void>;
    logout(provider: ProviderId, account: string): Promise<void>;
    setDefault(provider: ProviderId, account: string): Promise<void>;
    /**
     * Persist one Claude account's credential-ownership mode.
     *
     * The change is a setting, not an authorization: this plugin's own OAuth flow is the only
     * thing that can produce an independently authorized credential, and an account this plugin
     * authorized itself has no external store to move to, so both directions are refused by
     * {@link planClaudeCredentialConversion}. Nothing else about the account changes — no token is
     * deleted, rewritten or re-authorized, the account keeps its key, and no background pass
     * touches any other account's mode.
     *
     * Moving onto `legacy-writeback` is the one conversion that may spend the same refresh grant
     * an external holder spends, so it needs the caller's explicit acknowledgement that the risk
     * was shown and accepted. That rule belongs to this server: a client's dialog is not what
     * makes the mode safe, and any other caller of the channel is held to the same statement. A
     * request that already names the account's current mode is an exact no-op — nothing is
     * written, so it needs no acknowledgement.
     * @param provider - the provider route; only `claude` owns an ownership mode.
     * @param account - the account key, canonical or a recorded alias.
     * @param mode - the mode to persist.
     * @param riskAcknowledged - whether the caller states the legacy-writeback risk was accepted.
     * @throws BadRequest when the account is unknown, the requested conversion is refused, or a
     *   real conversion onto legacy-writeback arrives unacknowledged.
     */
    setCredentialOwnership(provider: ProviderId, account: string, mode: ClaudeCredentialMode, riskAcknowledged: boolean): Promise<void>;
}
export declare function apply(ctx: Context, config: Config, internals?: SubscriptionInternals): void;
