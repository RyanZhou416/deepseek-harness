/**
 * The OAuth token client: the authorize URL, the code exchange and the refresh grant.
 *
 * One call is one POST. This module never replays a grant — the service may already have spent
 * it — never persists a token, never reads an environment variable, a keychain or a home
 * directory, and never starts a browser. The authorization code and its `state` are the caller's
 * one-time values: this module echoes them and does not pretend to implement exactly-once, so
 * the host that owns them is what decides the attempt happened once.
 *
 * @module dsh-plugin-subscriptions/claude-account-client/token
 */
import type { ClaudeAccountFailure } from './failure.js';
import type { ClaudeAccountClientProfile } from './protocol.js';
import type { ClaudeAccountTimers, ClaudeAccountTransport } from './wire.js';
/**
 * The pinned bound on one token exchange, in milliseconds.
 *
 * It covers the POST and the read of its answer: a body that never finishes would otherwise hold
 * the refresh — and the credential it is rotating — open after the response headers had arrived.
 */
export declare const CLAUDE_TOKEN_TIMEOUT_MS = 30000;
/**
 * The bound on a token response body this client consumes, in bytes.
 *
 * Like the core readers' caps, this is this build's own product guard rather than a pinned
 * constant of the analyzed client, whose transport applies no fixed byte cap of its own. A body
 * over it is refused outright and never re-pulled; no part of it reaches the failure.
 */
export declare const CLAUDE_TOKEN_BODY_LIMIT = 65536;
/**
 * The S256 PKCE challenge for one verifier (RFC 7636).
 *
 * The verifier itself never leaves the caller: it is minted, kept and presented at the token
 * endpoint by whoever owns the one authorization attempt.
 * @param codeVerifier - the high-entropy verifier for this attempt.
 * @returns the base64url-encoded SHA-256 digest.
 */
export declare function pkceCodeChallenge(codeVerifier: string): string;
/** The inputs one authorize URL is built from. */
export interface ClaudeAuthorizationInput {
    /** The explicit pinned profile the origin and client id come from. */
    readonly profile: ClaudeAccountClientProfile;
    /** The redirect URI this attempt registered. */
    readonly redirectUri: string;
    /** The S256 challenge for this attempt's verifier; see {@link pkceCodeChallenge}. */
    readonly codeChallenge: string;
    /** The caller's own one-time state value; this builder mints nothing. */
    readonly state: string;
    /** Scopes to ask for; defaults to the profile's own set. */
    readonly scopes?: string;
}
/** The authorize URL one attempt opens. */
export interface ClaudeAuthorization {
    /** The URL the browser is sent to. */
    readonly url: string;
    /** The state the URL carries, echoed for the caller's comparison at the callback. */
    readonly state: string;
    /** The scope string the request asked for. */
    readonly scopes: string;
}
/**
 * Build the authorize URL for one attempt.
 *
 * The parameter set and order are the analyzed client's own. The state and the PKCE challenge are
 * caller-provided; this builder neither mints nor remembers them.
 * @param input - the profile, the redirect URI, the challenge, the state and the scopes.
 * @returns the URL and the values it carried.
 * @throws Error when the profile is not the pinned one or a one-time input is empty; a
 * misconfiguration fails loud here rather than opening a page that cannot finish.
 */
export declare function buildOAuthAuthorization(input: ClaudeAuthorizationInput): ClaudeAuthorization;
/** Account metadata a token response stated about itself, when it stated any. */
export interface ClaudeTokenAccountMetadata {
    /** The account uuid the response named. */
    readonly accountUuid?: string;
    /** The organization uuid the response named. */
    readonly organizationUuid?: string;
    /** The address the response named. */
    readonly email?: string;
}
/**
 * One validated token grant.
 *
 * Every field was read from the parsed document and type-checked; nothing here is an unchecked
 * cast of the response. An absent optional field stays absent rather than being invented.
 */
export interface ClaudeTokenGrant {
    /** The access token to carry. */
    readonly accessToken: string;
    /** The rotated refresh token; absent means the caller keeps the one it presented. */
    readonly refreshToken?: string;
    /** The lifetime the endpoint stated, in seconds. */
    readonly expiresInSeconds?: number;
    /** The scopes the endpoint stated, or the scopes this call asked for when it stated none. */
    readonly scopes: readonly string[];
    /** Account metadata the grant carried, when it carried any. */
    readonly account?: ClaudeTokenAccountMetadata;
}
/** What one token call resolved to. */
export type ClaudeTokenOutcome = 
/** A grant was validated. The caller owns committing it; this module committed nothing. */
{
    readonly kind: 'grant';
    readonly grant: ClaudeTokenGrant;
}
/** The caller's own `required` hook said no request was needed; nothing was sent. */
 | {
    readonly kind: 'not-required';
}
/** The caller cancelled. */
 | {
    readonly kind: 'cancelled';
    readonly failure: ClaudeAccountFailure;
}
/** This module's deadline fired; the credential is untouched and must not be deleted for it. */
 | {
    readonly kind: 'timeout';
    readonly failure: ClaudeAccountFailure;
}
/** The grant is permanently gone; only a new authorization can fix the account. */
 | {
    readonly kind: 'invalid_grant';
    readonly failure: ClaudeAccountFailure;
}
/** The service refused the call; no retry and no switch to another account. */
 | {
    readonly kind: 'refused';
    readonly failure: ClaudeAccountFailure;
}
/** Nothing answered, or a 5xx, 429 or 408 did. */
 | {
    readonly kind: 'unreachable';
    readonly failure: ClaudeAccountFailure;
}
/** The answer could not be validated, or the request could not be built. */
 | {
    readonly kind: 'invalid';
    readonly failure: ClaudeAccountFailure;
};
/** The seams every token call shares. */
interface ClaudeTokenRequestBase {
    /** The explicit pinned profile; its token URL and client id are the CC child's own. */
    readonly profile: ClaudeAccountClientProfile;
    /** The injected transport, which carries the account's egress. */
    readonly transport: ClaudeAccountTransport;
    /** The injected deadline scheduler; defaults to the process timer. */
    readonly timers?: ClaudeAccountTimers;
    /** Bound on the whole exchange; defaults to {@link CLAUDE_TOKEN_TIMEOUT_MS}. */
    readonly timeoutMs?: number;
    /** Caller cancellation. */
    readonly signal?: AbortSignal;
    /**
     * The caller's zero-I/O predicate for whether this call is needed at all.
     *
     * It is evaluated before any request is built. `false` means nothing is sent — not even a
     * transport call — which is what lets a caller gate a refresh on state it alone holds.
     */
    readonly required?: () => boolean;
}
/** One authorization-code exchange. */
export interface ClaudeAuthorizationCodeExchange extends ClaudeTokenRequestBase {
    /** The one-time code from the callback; the host owns its single use. */
    readonly code: string;
    /** The verifier whose S256 challenge the authorize URL carried. */
    readonly codeVerifier: string;
    /** The redirect URI this attempt registered. */
    readonly redirectUri: string;
    /** The state the authorize URL carried and the callback echoed. */
    readonly state: string;
}
/** One refresh grant. */
export interface ClaudeRefreshGrantRequest extends ClaudeTokenRequestBase {
    /** The refresh token to present. */
    readonly refreshToken: string;
    /** The scopes the account was granted; `org:create_api_key` is dropped from the request. */
    readonly scopes: string;
}
/**
 * Exchange one authorization code for a grant.
 *
 * The code and its verifier are the caller's one-time values. This sends one POST and reports the
 * outcome; a caller that calls it twice has sent two, and no exactly-once guarantee is claimed.
 * @param input - the code, the verifier, the redirect URI, the state and the shared seams.
 * @returns the validated grant or the typed reason there is none.
 */
export declare function exchangeAuthorizationCode(input: ClaudeAuthorizationCodeExchange): Promise<ClaudeTokenOutcome>;
/**
 * Refresh one account's grant.
 *
 * The client id and the token endpoint are the CC child's own, not the parent keeper's. A timeout
 * is reported as a timeout: this module never deletes, overwrites or commits a credential, and a
 * caller that replaced its stored one on this outcome would be acting on nothing this call said.
 * @param input - the refresh token, the granted scopes and the shared seams.
 * @returns the rotated grant or the typed reason there is none.
 */
export declare function refreshTokenGrant(input: ClaudeRefreshGrantRequest): Promise<ClaudeTokenOutcome>;
export {};
