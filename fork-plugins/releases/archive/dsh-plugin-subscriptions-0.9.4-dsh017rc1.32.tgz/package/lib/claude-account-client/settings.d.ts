/**
 * The managed-settings reader: transfer and envelope validation only.
 *
 * This is the basic reader. It fetches the account's own managed-settings document, validates the
 * `{uuid, checksum, settings}` envelope the endpoint serves, and returns the settings record
 * exactly as the service stated it — unknown keys included. It deliberately projects nothing and
 * declares nothing enforced: which keys a deployment can safely apply, and which unsupported ones
 * must block an operation, is the caller's policy-consumer decision, and this reader cannot claim
 * a rule it did not interpret.
 *
 * The document is kept as a short-lived in-memory value. It is never stored, logged or merged into
 * configuration, an environment or a tool catalog.
 *
 * @module dsh-plugin-subscriptions/claude-account-client/settings
 */
import type { ClaudeAccountFailure } from './failure.js';
import type { ClaudeAccountClientProfile } from './protocol.js';
import type { ClaudeAccountTimers, ClaudeAccountTransport } from './wire.js';
/** The pinned bound on one settings read. */
export declare const CLAUDE_SETTINGS_TIMEOUT_MS = 10000;
/**
 * The bound on a settings body this reader consumes, in bytes.
 *
 * This is this build's own product guard, not a pinned constant of the analyzed client, whose own
 * transport applies no fixed byte cap. A body over it is refused outright and never re-pulled.
 */
export declare const CLAUDE_SETTINGS_BODY_LIMIT = 1048576;
/**
 * Format one server checksum as an `If-None-Match` entity tag.
 *
 * The client sends the cached checksum quoted, and a value that already carries quotes is sent as
 * it arrived rather than double-quoted.
 * @param checksum - the server's checksum.
 * @returns the entity tag to send.
 */
export declare function claudeIfNoneMatch(checksum: string): string;
/**
 * The validated envelope of a 200 response.
 *
 * `uuid` and `checksum` are response-level identifiers and `settings` is the policy object, kept
 * exactly as it arrived. A response missing any of the three is a parse error, never an empty
 * policy.
 */
export interface ClaudeManagedSettingsEnvelope {
    /** The envelope's own revision identifier. */
    readonly uuid: string;
    /** The server's own checksum, sent back as `If-None-Match` on the next conditional read. */
    readonly checksum: string;
    /** The settings record, with every key the service stated and none that it did not. */
    readonly settings: Record<string, unknown>;
}
/**
 * Validate the fixed response envelope `{uuid, checksum, settings}`.
 *
 * The `settings` object is returned verbatim: this parser checks syntax and the three required
 * members only, so a key whose meaning is unknown to this build still reaches the caller that can
 * interpret it.
 * @param text - the bounded response body text.
 * @returns the envelope, or `undefined` when the body is not a valid envelope.
 */
export declare function parseClaudeManagedSettingsEnvelope(text: string): ClaudeManagedSettingsEnvelope | undefined;
/** The snapshot a caller may hold for one identity; a 304 is valid only against it. */
export interface ClaudeManagedSettingsCache {
    /** The revision the cached envelope carried. */
    readonly uuid: string;
    /** The server checksum that made this snapshot conditional. */
    readonly checksum: string;
}
/** Everything one managed-settings read needs. */
export interface ClaudeManagedSettingsRead {
    /** The access token this read carries; the caller selected and may have refreshed it. */
    readonly accessToken: string;
    /** The explicit pinned profile the endpoint comes from. */
    readonly profile: ClaudeAccountClientProfile;
    /** The injected transport, which carries the account's egress. */
    readonly transport: ClaudeAccountTransport;
    /**
     * This identity's cached envelope, when the caller holds one.
     *
     * A 304 is valid only against a checksum this read actually sent, and the cached value is the
     * caller's own snapshot for the same account, organization and protocol profile — a snapshot of
     * another identity never contributes a validator.
     */
    readonly cached?: ClaudeManagedSettingsCache;
    /** The caller's zero-I/O predicate for whether this read is needed; `false` sends nothing. */
    readonly required?: () => boolean;
    /**
     * Re-judged before every attempt.
     *
     * The caller owns what this guard watches; the reader only honours its answer. `false` sends
     * nothing.
     */
    readonly beforeRequest?: (attempt: number) => boolean;
    /** The injected deadline scheduler; defaults to the process timer. */
    readonly timers?: ClaudeAccountTimers;
    /** Bound on the read; defaults to {@link CLAUDE_SETTINGS_TIMEOUT_MS}. */
    readonly timeoutMs?: number;
    /** Caller cancellation. */
    readonly signal?: AbortSignal;
}
/** What one managed-settings read produced. */
export type ClaudeManagedSettingsOutcome = 
/** A 200 envelope was validated. The caller owns adopting, projecting and enforcing it. */
{
    readonly kind: 'accepted';
    readonly envelope: ClaudeManagedSettingsEnvelope;
}
/** The endpoint's own empty-success statuses (204 and 404), accepted as an empty sentinel. */
 | {
    readonly kind: 'empty';
}
/** A 304 revalidated the caller's cached envelope for this identity. */
 | {
    readonly kind: 'unchanged';
    readonly cache: ClaudeManagedSettingsCache;
}
/** The caller's `required` hook said no read was needed; nothing was sent. */
 | {
    readonly kind: 'not-required';
}
/** The caller's `beforeRequest` guard withheld the attempt; nothing was sent. */
 | {
    readonly kind: 'withheld';
}
/** The caller cancelled. */
 | {
    readonly kind: 'cancelled';
    readonly failure: ClaudeAccountFailure;
}
/** The credential was rejected; its owner may refresh and retry exactly once. */
 | {
    readonly kind: 'unauthorized';
    readonly failure: ClaudeAccountFailure;
}
/** The service refused this read; no retry and no switch to another account. */
 | {
    readonly kind: 'refused';
    readonly failure: ClaudeAccountFailure;
}
/** No usable answer arrived, or the endpoint failed transiently; the caller keeps its snapshot. */
 | {
    readonly kind: 'unreachable';
    readonly failure: ClaudeAccountFailure;
}
/** The envelope or the request could not be validated; the caller keeps its snapshot. */
 | {
    readonly kind: 'invalid';
    readonly failure: ClaudeAccountFailure;
};
/**
 * Read the account's managed settings once.
 *
 * The request is the analyzed client's own settings read: a bodyless GET with the settings role's
 * headers — the plain user agent, the OAuth beta, a JSON accept and both cache directives — plus
 * the quoted cached checksum when there is one, authenticated with the account's bearer token and
 * bounded at ten seconds. A redirected response is never read as the pinned endpoint.
 * @param input - the token, the pinned profile, the transport, the optional cache and the hooks.
 * @returns the structured outcome of this read.
 */
export declare function readClaudeManagedSettings(input: ClaudeManagedSettingsRead): Promise<ClaudeManagedSettingsOutcome>;
