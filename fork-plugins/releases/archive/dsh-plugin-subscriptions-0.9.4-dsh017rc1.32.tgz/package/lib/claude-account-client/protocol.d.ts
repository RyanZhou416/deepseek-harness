/**
 * The pinned wire profile one Claude subscription account is read under.
 *
 * Every value here is a fixed protocol constant of the analyzed Claude Code 2.1.288 client, not a
 * deployment setting: the token host receives this account's credentials, so no environment file,
 * page or server answer may choose it. A caller passes the profile explicitly — there is no
 * ambient default — and {@link claudeAccountProfileFailure} rejects a profile whose endpoint
 * origins or paths are not the pinned ones.
 *
 * The user agent is the plain `claude-code/<version>` form. This module derives no operating
 * system or platform field: the plain form is the whole protocol constant, and the platform the
 * Mac engine reports belongs to that engine's own layer.
 *
 * @module dsh-plugin-subscriptions/claude-account-client/protocol
 */
import type { ClaudeAccountFailure } from './failure.js';
/** The OAuth client id the analyzed CC child uses; the parent keeper's id is not this one. */
export declare const CLAUDE_ACCOUNT_CLIENT_ID = "9d1c250a-e61b-44d9-88ed-5944d1962f5e";
/** The plain user agent the profile and settings roles carry. */
export declare const CLAUDE_PLAIN_USER_AGENT = "claude-code/2.1.288";
/** The OAuth beta the account's own endpoints are read under. */
export declare const CLAUDE_OAUTH_BETA = "oauth-2025-04-20";
/** The scopes the authorize request asks for, in the client's own order. */
export declare const CLAUDE_ACCOUNT_SCOPES = "org:create_api_key user:profile user:inference user:sessions:claude_code user:mcp_servers user:file_upload user:plugins";
/** The authorize-only scope a refresh grant never asks for. */
export declare const CLAUDE_REFRESH_EXCLUDED_SCOPE = "org:create_api_key";
/** The authorize page the claude.ai account path uses. */
export declare const CLAUDE_AUTHORIZE_URL = "https://claude.com/cai/oauth/authorize";
/** The token endpoint; it receives this account's tokens. */
export declare const CLAUDE_TOKEN_URL = "https://platform.claude.com/v1/oauth/token";
/** The strict profile endpoint. */
export declare const CLAUDE_PROFILE_URL = "https://api.anthropic.com/api/oauth/profile";
/** The first-party managed-settings endpoint. */
export declare const CLAUDE_SETTINGS_URL = "https://api.anthropic.com/api/claude_code/settings";
/**
 * The endpoints, credential identity and user agent one account client runs under.
 *
 * Every request builder takes this profile as an explicit input. Passing a value whose origins or
 * paths are not the pinned ones is an input failure, reported before any request is sent.
 */
export interface ClaudeAccountClientProfile {
    /** OAuth client id sent by the authorize URL and the token grants. */
    readonly clientId: string;
    /** Authorize page the browser is sent to. */
    readonly authorizeUrl: string;
    /** Token endpoint the grants are POSTed to. */
    readonly tokenUrl: string;
    /** Strict profile endpoint. */
    readonly profileUrl: string;
    /** Managed-settings endpoint. */
    readonly settingsUrl: string;
    /** Plain user agent the profile and settings roles carry. */
    readonly userAgent: string;
    /** Scopes the authorize request asks for; a refresh drops {@link CLAUDE_REFRESH_EXCLUDED_SCOPE}. */
    readonly scopes: string;
}
/** The single pinned profile this build ships; callers pass it explicitly. */
export declare const CLAUDE_ACCOUNT_CLIENT_PROFILE: ClaudeAccountClientProfile;
/**
 * Whether a profile names an endpoint this client refuses to send to.
 *
 * The check pins the origin and the path, not just the host: a server answer, an environment file
 * or a caller typo can therefore not move a grant, a token or a policy read to another target.
 * @param profile - the profile the caller supplied.
 * @returns the input failure, or `undefined` when the profile is the pinned one.
 */
export declare function claudeAccountProfileFailure(profile: ClaudeAccountClientProfile): ClaudeAccountFailure | undefined;
/**
 * The scope string a refresh grant carries.
 *
 * The client never asks for `org:create_api_key` when refreshing; that scope belongs to the
 * authorize request. Everything else the account was granted is echoed back in order, so a
 * project scope stays intact.
 * @param scopes - the scopes the session was granted.
 * @returns the same set without the authorize-only scope.
 */
export declare function refreshScopeString(scopes: string): string;
