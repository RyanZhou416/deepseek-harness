/**
 * The strict profile reader: one account's own identity as the service states it.
 *
 * The document is validated at the wire shape the endpoint serves — `account` and `organization`
 * are two objects with their own fields — so a document missing either is not adopted: reading it
 * would attach half an identity to an account. The completeness verdict is the analyzed client's
 * own criteria, and a client-version refusal found on this read keeps its own outcome rather than
 * being reported as missing data.
 *
 * This module never refreshes a profile by itself. A caller that wires the optional replay hook
 * gets at most one replay, and the response it produces is validated against the same pinned
 * identity as the first, so an old account cannot be adopted through a replaced credential.
 *
 * @module dsh-plugin-subscriptions/claude-account-client/profile
 */
import type { ClaudeAccountFailure } from './failure.js';
import type { ClaudeAccountClientProfile } from './protocol.js';
import type { ClaudeAccountTimers, ClaudeAccountTransport } from './wire.js';
/** The pinned bound on one profile read. */
export declare const CLAUDE_PROFILE_TIMEOUT_MS = 10000;
/**
 * The bound on a profile body this reader consumes, in bytes.
 *
 * This is this build's own product guard, not a pinned constant of the analyzed client, whose own
 * transport applies no fixed byte cap. A profile document is a fixed small shape, so a body over
 * this bound is one this route refuses rather than reads whole.
 */
export declare const CLAUDE_PROFILE_BODY_LIMIT = 65536;
/** The one replay an authentication rejection may produce, when the caller wired a hook for it. */
export declare const CLAUDE_PROFILE_AUTH_REPLAY_BUDGET = 1;
/**
 * The identity a caller already holds.
 *
 * A field that is present and differs from the document's own is a mismatch, not a refresh: the
 * caller's stored account is what its remaining state belongs to.
 */
export interface ClaudeProfileIdentity {
    /** The account uuid the caller pinned. */
    readonly accountUuid?: string;
    /** The organization uuid the caller pinned. */
    readonly organizationUuid?: string;
}
/**
 * The safe projection of one validated profile document.
 *
 * Only these fields leave the reader. The raw document, its timestamps and its onboarding flag
 * body are not returned: the verdict needs to know whether those fields were stated, and a caller
 * that needs a date reads its own projection from the same source.
 */
export interface ClaudeStrictProfile {
    /** `account.uuid`; required by the endpoint's own schema. */
    readonly accountUuid: string;
    /** `account.email`; required by the endpoint's own schema. */
    readonly email: string;
    /** `organization.uuid`; required by the endpoint's own schema. */
    readonly organizationUuid: string;
    /** `organization.billing_type`, when the organization stated a string. */
    readonly billingType?: string;
    /** The subscription type; `null` is the value the document stated, absence is different. */
    readonly subscriptionType?: string | null;
    /** Whether `account.created_at` was stated with a value. */
    readonly accountCreated: boolean;
    /** Whether `organization.subscription_created_at` was stated with a value. */
    readonly subscriptionCreated: boolean;
    /** Whether `organization.cc_onboarding_flags` was stated with a value. */
    readonly onboardingFlags: boolean;
    /**
     * The analyzed client's own completeness verdict.
     *
     * It needs the organization's stated billing type, the account's creation time and the
     * organization's subscription creation time. The onboarding flags are normalised to `{}` when
     * absent, so they never make a document incomplete, and the subscription type is deliberately
     * outside the test: an unknown plan is a complete answer.
     */
    readonly complete: boolean;
}
/** Everything one strict profile read needs. */
export interface ClaudeStrictProfileRead {
    /** The access token this read carries; the caller selected and may have refreshed it. */
    readonly accessToken: string;
    /** The explicit pinned profile the endpoint comes from. */
    readonly profile: ClaudeAccountClientProfile;
    /** The injected transport, which carries the account's egress. */
    readonly transport: ClaudeAccountTransport;
    /** The identity the caller already holds; a conflicting document is refused. */
    readonly expected?: ClaudeProfileIdentity;
    /** The caller's zero-I/O predicate for whether this read is needed; `false` sends nothing. */
    readonly required?: () => boolean;
    /**
     * Re-judged before every attempt, including the replay.
     *
     * The caller owns what this guard watches; the reader only honours its answer. `false` sends
     * nothing, so a policy that changed between attempts stops the request rather than racing it.
     */
    readonly beforeRequest?: (attempt: number) => boolean;
    /**
     * The credential owner's one replay after a rejection.
     *
     * It is called at most once, only for an authentication rejection that is not a client-version
     * refusal, and this reader refreshes nothing itself.
     * @returns the replacement access token.
     */
    readonly reauthorize?: () => Promise<string>;
    /** The injected deadline scheduler; defaults to the process timer. */
    readonly timers?: ClaudeAccountTimers;
    /** Bound on the read; defaults to {@link CLAUDE_PROFILE_TIMEOUT_MS}. */
    readonly timeoutMs?: number;
    /** Caller cancellation. */
    readonly signal?: AbortSignal;
}
/** What one strict profile read disclosed, or why it disclosed nothing. */
export type ClaudeProfileOutcome = 
/** The document was validated; the caller owns adopting it. */
{
    readonly kind: 'profile';
    readonly profile: ClaudeStrictProfile;
}
/** The caller's `required` hook said no read was needed; nothing was sent. */
 | {
    readonly kind: 'not-required';
}
/** The caller's `beforeRequest` guard withheld the attempt; nothing was sent. */
 | {
    readonly kind: 'withheld';
}
/** The caller cancelled. */
 | {
    readonly kind: 'cancelled';
    readonly failure: ClaudeAccountFailure;
}
/** The credential was rejected; its owner may replay exactly once. */
 | {
    readonly kind: 'unauthorized';
    readonly failure: ClaudeAccountFailure;
}
/** The service refused this read; no retry and no switch to another account. */
 | {
    readonly kind: 'refused';
    readonly failure: ClaudeAccountFailure;
}
/** No usable answer arrived, or the endpoint failed transiently. */
 | {
    readonly kind: 'unreachable';
    readonly failure: ClaudeAccountFailure;
}
/** The document, or the request itself, could not be validated. */
 | {
    readonly kind: 'invalid';
    readonly failure: ClaudeAccountFailure;
};
/** The parse of one validated profile document, or the fixed reason it was refused. */
type ClaudeProfileParse = {
    readonly profile: ClaudeStrictProfile;
} | {
    readonly code: 'invalid' | 'identity_mismatch';
    readonly reason: string;
};
/**
 * Validate one parsed profile document into the safe projection.
 *
 * The three identity fields are required exactly as the endpoint's own schema spells them, the
 * completeness criteria read the billing type from the organization and not from the root, and a
 * pinned identity that the document contradicts is a mismatch rather than a newer answer.
 * @param raw - the parsed response document.
 * @param expected - the identity the caller already holds, when it holds one.
 * @returns the projection, or the fixed reason the document was refused.
 */
export declare function parseClaudeStrictProfile(raw: unknown, expected?: ClaudeProfileIdentity): ClaudeProfileParse;
/**
 * Read one account's profile, preserving why it disclosed nothing.
 *
 * The request is the analyzed client's own profile read: a bodyless GET carrying the plain user
 * agent, a JSON content type and `no-cache`, authenticated with the account's bearer token, under
 * the pinned ten-second bound. A deadline is reported as an unreachable read with a `timeout`
 * failure code, never as a rejection of the credential.
 * @param input - the token, the pinned profile, the transport and the optional hooks.
 * @returns the structured outcome of this read.
 */
export declare function readClaudeStrictProfile(input: ClaudeStrictProfileRead): Promise<ClaudeProfileOutcome>;
export {};
