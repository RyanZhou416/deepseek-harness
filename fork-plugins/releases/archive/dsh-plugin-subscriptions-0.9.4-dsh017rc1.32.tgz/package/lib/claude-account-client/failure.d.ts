/**
 * The account client's own failure vocabulary.
 *
 * A `ClaudeAccountFailure` is a plain value: a fixed code, a fixed message and the status it was
 * observed at. It never carries response bytes, a cause chain or text the endpoint wrote, because
 * a token or profile response is the account's own credential and identity. Callers map the code
 * into their own error type; this module imports none and throws none.
 *
 * @module dsh-plugin-subscriptions/claude-account-client/failure
 */
/** The stable codes this client produces. */
export type ClaudeAccountFailureCode = 
/** The caller cancelled before or during the read. */
'cancelled'
/** This module's own deadline expired; this says nothing about the credential. */
 | 'timeout'
/** No response arrived, or a 5xx, 429 or 408 answered. */
 | 'unreachable'
/** The credential was rejected; its owner may replay exactly once and decides what that is. */
 | 'unauthorized'
/** The service refused this operation; no retry and no switch to another account. */
 | 'refused'
/** The operation's own inputs were unusable before any request was sent. */
 | 'invalid_input'
/** A document this client cannot validate: a malformed envelope or an unreadable body. */
 | 'invalid'
/** The grant is permanently gone (`invalid_grant` / `invalid_token`); re-login is the only fix. */
 | 'invalid_grant'
/** The response body exceeded this build's own product bound. */
 | 'body_over_limit'
/** The transport followed a redirect away from the pinned endpoint. */
 | 'redirected'
/** The disclosed identity is not the account or organization the caller pinned. */
 | 'identity_mismatch'
/** The service named one of the known client-version refusals. */
 | 'client_version_unsupported';
/** One failure, as a value rather than a thrown provider error. */
export interface ClaudeAccountFailure {
    /** Stable machine code. */
    readonly code: ClaudeAccountFailureCode;
    /** Fixed description; never response text. */
    readonly message: string;
    /** HTTP status the failure was observed at, when there was one. */
    readonly status?: number;
    /** A fixed sub-reason the caller may switch on, for example `unexpected_304`. */
    readonly reason?: string;
}
/**
 * Build one failure value.
 * @param code - the stable code.
 * @param options - the observed status and a fixed sub-reason.
 * @returns the failure.
 */
export declare function claudeAccountFailure(code: ClaudeAccountFailureCode, options?: {
    status?: number;
    reason?: string;
}): ClaudeAccountFailure;
/**
 * Whether this failure means the stored credential is permanently unusable.
 *
 * Only an explicit permanent grant rejection says that. An `unauthorized` failure is an
 * authentication rejection whose owner may replay exactly once; a generic 401 is not evidence
 * that the grant is gone, so a caller that deleted its stored credential on one would destroy a
 * working login. A timeout, a cancellation and an unreachable endpoint say nothing about the
 * credential either, and this client never deletes one itself.
 * @param failure - the observed failure.
 * @returns true only when the endpoint named a permanently spent grant.
 */
export declare function claudeFailureDropsCredential(failure: ClaudeAccountFailure): boolean;
/** One refusal's classified meaning. */
export interface ClaudeRefusal {
    /** The failure to report. */
    readonly failure: ClaudeAccountFailure;
    /** Whether the credential itself was rejected; the one case whose owner may replay. */
    readonly unauthorized: boolean;
}
/**
 * Classify one non-success response into this client's vocabulary.
 *
 * The known client-version refusals outrank the authentication branch, so a version refusal
 * carried on a 401 never triggers the credential owner's replay. The body is read only to match
 * those fixed markers; no part of it reaches the returned failure.
 * @param status - the response status.
 * @param body - the bounded body text this client already consumed.
 * @returns the refusal the response named.
 */
export declare function classifyClaudeRefusal(status: number, body: string): ClaudeRefusal;
