/**
 * The transport seam, the module-owned deadline and the owned response body.
 *
 * This module never calls `fetch` and never builds a proxy: the caller injects the transport,
 * which carries whatever egress (a per-account proxy today) that caller owns, and which must
 * honour the request's abort signal. What this module adds on top of `claude-core`'s transport
 * contract is a per-request deadline it schedules itself — with an injectable timer — and an
 * owned response body whose reader this module cancels when that deadline or the caller's
 * cancellation wins.
 *
 * Owning the reader is what makes that release real. Cancelling the stream itself throws while a
 * reader holds its lock, and waiting for the transport to notice the abort would make the release
 * depend on the transport rather than on this module. `claude-core`'s `readBoundedBody` cannot be
 * cancelled from outside once it holds the lock, so this module reads its own bodies; the byte
 * bound, the truncation verdict and the release-on-every-path semantics are the same.
 *
 * @module dsh-plugin-subscriptions/claude-account-client/wire
 */
import type { CoreHttpRequest, CoreHttpResponse } from '../claude-core/policy-limits-client.js';
/** One outbound request: the core's request shape, so an injected `CoreTransport` fits. */
export type ClaudeAccountRequest = CoreHttpRequest;
/**
 * A response as this client reads it, plus the redirect evidence a transport may report.
 *
 * The two extra fields are optional so a plain `CoreTransport` (which returns only the core's
 * three fields) is accepted: a transport that cannot report a redirect simply reports none, and
 * the caller's own transport contract is what forbids following one.
 */
export interface ClaudeAccountResponse extends CoreHttpResponse {
    /** Whether the transport followed a redirect to reach this response. */
    readonly redirected?: boolean;
    /** The URL the transport actually reached, when it reports one. */
    readonly url?: string;
}
/**
 * The injected transport. It must not read a credential, choose an account or pick a proxy, and
 * it must honour `request.signal`: this client aborts it on its own deadline and on the caller's
 * cancellation. That obligation covers the request itself; a response body this client owns is
 * released by this client, not by the transport.
 */
export type ClaudeAccountTransport = (request: ClaudeAccountRequest) => Promise<ClaudeAccountResponse>;
/**
 * The injected one-shot deadline scheduler.
 *
 * `arm` returns the cancel handle for the deadline it armed. A module that could only use the
 * ambient `setTimeout` could not be driven by a caller's own clock, so the timer is a parameter
 * rather than an ambient resource; the default is the process's own.
 */
export interface ClaudeAccountTimers {
    /** Arm one deadline, in milliseconds, and return its cancel handle. */
    arm(delayMs: number, onDeadline: () => void): () => void;
}
/** The process timer this client uses when the caller injects none. */
export declare const CLAUDE_SYSTEM_TIMERS: ClaudeAccountTimers;
/**
 * The body of one response this exchange owns.
 *
 * A handler consumes it through {@link ClaudeResponseBody.read}; the exchange releases it when the
 * deadline or the caller's cancellation wins. At most one read is taken, and it is the only reader
 * this body ever gets.
 */
export interface ClaudeResponseBody {
    /**
     * Consume the body under a bound.
     *
     * The bound is inclusive: a chunk that exactly fills it is complete and only a chunk that
     * exceeds it is truncated, at which point the reader is cancelled rather than accumulated
     * further. A second call is a programming error.
     * @param limit - the byte bound.
     * @returns the consumed text and whether the bound was reached.
     */
    read(limit: number): Promise<{
        text: string;
        truncated: boolean;
    }>;
}
/**
 * Consume one response body under a hard bound.
 *
 * This is the direct form, for a caller that holds a raw response and drives no deadline of its
 * own. A body is read or released exactly once; inside {@link exchangeClaudeRequest} the handler
 * reads the owned body it is given instead, so cancellation stays with the exchange.
 * @param response - the response whose body to consume.
 * @param limit - the byte bound.
 * @returns the consumed text and whether the bound was reached.
 */
export declare function readClaudeBody(response: ClaudeAccountResponse, limit: number): Promise<{
    text: string;
    truncated: boolean;
}>;
/**
 * Release one response body this read will not consume.
 *
 * No read may be in flight against the same response when this is called: the only safe way to
 * release a body whose read is pending is the exchange's own cancellation.
 * @param response - the response whose body to release.
 */
export declare function cancelClaudeBody(response: ClaudeAccountResponse): Promise<void>;
/** One outbound exchange: the request and the seams that carry it. */
export interface ClaudeExchange {
    /** The pinned endpoint for this role. */
    readonly url: string;
    /** The method this role uses; both roles here are bodyless GETs or one JSON POST. */
    readonly method: 'GET' | 'POST';
    /** Every header this role decided. */
    readonly headers: Readonly<Record<string, string>>;
    /** The request body, or `null` for the bodyless GET. */
    readonly body: string | null;
    /** The bound on the whole exchange, this client's own deadline included. */
    readonly timeoutMs: number;
    /** The injected transport that carries the account's egress. */
    readonly transport: ClaudeAccountTransport;
    /** The injected deadline scheduler. */
    readonly timers: ClaudeAccountTimers;
    /** Caller cancellation. */
    readonly signal?: AbortSignal;
}
/** What one exchange resolved to. */
export type ClaudeExchangeOutcome<T> = 
/** The handler read the response; its value is the caller's typed outcome. */
{
    readonly kind: 'handled';
    readonly value: T;
}
/** This module's deadline fired; the transport was aborted and the body released. */
 | {
    readonly kind: 'timeout';
}
/** The caller's signal aborted. */
 | {
    readonly kind: 'cancelled';
}
/** No response arrived. */
 | {
    readonly kind: 'unreachable';
};
/**
 * Send one request and read its answer entirely inside this module's deadline.
 *
 * The deadline covers the transport and the handler's own read of the body, not just the response
 * headers. Whichever side wins — the deadline, the caller's cancellation, or the answer — the body
 * this exchange owns is released before this function returns, including a response that only
 * arrives after the race was already lost. One call is exactly one request; this helper never
 * replays, because the service may already have spent the grant.
 * @param exchange - the request, the transport and the deadline.
 * @param handle - reads the owned body inside the deadline and returns the typed answer.
 * @returns what the exchange produced, with the deadline's own verdict kept separate.
 * @throws Error when the handler itself throws, which is a programming error, not an outcome.
 */
export declare function exchangeClaudeRequest<T>(exchange: ClaudeExchange, handle: (response: ClaudeAccountResponse, body: ClaudeResponseBody) => Promise<T>): Promise<ClaudeExchangeOutcome<T>>;
