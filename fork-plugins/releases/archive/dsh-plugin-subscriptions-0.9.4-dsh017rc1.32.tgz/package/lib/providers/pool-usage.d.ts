/**
 * Quota tracking for pool members: the plugin's own cache of what each account
 * last reported, and the scheduling score derived from it.
 *
 * Reads never poll. A snapshot read answers from what is already known, and
 * only an explicit refresh or a candidate about to serve a request may perform
 * one upstream read. Expiry marks a reading stale; no timer ever fires, and a
 * restart reuses the persisted readings under their own recorded age.
 *
 * The baseline score remains the remaining quota fraction divided by time until
 * reset, with model-scoped live windows accompanying that rate. An elapsed
 * window supplies no score or quota-full assertion until the provider reports a
 * replacement.
 */
import type { ProviderUsage, UsageCacheState, UsageFailureReason, UsageWindow } from './common.js';
import type { UnifiedRateLimitState } from './unified-rate-limit.js';
import type { UsageStore } from './usage-store.js';
import type { ProviderId } from '../auth/store.js';
/** Other providers enter the quota-full fallback band at this reported usage. */
export declare const QUOTA_FULL_PERCENT = 95;
/** Claude and ChatGPT can consume their remaining quota until a window reaches 100%. */
export declare const CONSUMABLE_QUOTA_FULL_PERCENT = 100;
/** How long a usage reading is trusted before it reads as stale and a demand re-reads it. */
export declare const USAGE_TTL_MS: number;
/**
 * How long a failed read with no server `retry-after` suppresses the next one.
 * This is a request-retry policy, deliberately independent of the freshness
 * horizon: a reading may be stale enough to refresh while the endpoint is still
 * refusing reads.
 */
export declare const USAGE_RETRY_DELAY_MS = 60000;
/**
 * One upstream usage read. The optional signal aborts the read when the tracker
 * is disposed; a fetcher that ignores it is still safe, because a completion
 * after disposal is discarded by the tracker's own state.
 */
export type UsageFetcher = (signal?: AbortSignal) => Promise<ProviderUsage>;
/** The scheduling view of one member's quota. */
export interface MemberQuota {
    /** False when a window is effectively full or the login is gone. */
    available: boolean;
    /** Required burn rate (fraction of window per ms); 0 when unknown. */
    urgency: number;
    /** Epoch ms of the newest observation behind this reading; 0 when none. */
    fetchedAt: number;
    /** Applicable windows whose recorded reset has not elapsed; absent when usage is unknown. */
    windows?: readonly UsageWindow[];
    /**
     * Retained on the same terms as {@link windows}: this tracker never drops a
     * last-known reading because a later read failed, so the availability floors
     * keep seeing an allowance that was already spent.
     */
    floorWindows?: readonly UsageWindow[];
    /**
     * ChatGPT: the weekly window opened within the last day and an available
     * reset credit expires within three days. Selection ranks these accounts
     * with a bounded bonus inside its availability band. The pool never
     * spends the credit.
     */
    preferFreshCredit?: boolean;
    /** What stands behind this reading, for callers that rank on it. */
    observation?: 'observed' | 'unread' | 'unavailable';
    /** Freshness of the reading behind this score, for callers that report it. */
    cacheState?: UsageCacheState;
    /** Epoch ms of the newest observation behind this score, when one exists. */
    observedAt?: number;
}
/**
 * One account's quota read. A named model asks for the windows that constrain it;
 * an omitted model asks for the account's own session and weekly windows — the ones
 * every model shares — which is what a model-independent availability floor reads.
 */
export interface QuotaQuery {
    provider: ProviderId;
    account: string;
    model?: string;
}
/** One window carried by a {@link UsageObservation}. */
export interface ObservedUsageWindow {
    /** Window kind: `session` for the short rolling window, `weekly` for the 7-day one. */
    kind: 'session' | 'weekly' | 'other';
    /** Model scope for model-specific windows (e.g. `Opus`), when the provider names one. */
    scope?: string;
    /** Percent of the window consumed (0–100). */
    usedPercent: number;
    /** Epoch milliseconds at which the window resets, when the provider discloses it. */
    resetsAt?: number;
}
/**
 * A partial observation of one account: whatever a single provider response
 * stated. A window the observation omits keeps its own reading and its own age.
 */
export interface UsageObservation {
    /** Windows this observation vouches for. */
    windows?: readonly ObservedUsageWindow[];
    /** Plan name the response disclosed, when it did. */
    plan?: string;
    /** Epoch milliseconds the response was read; defaults to the tracker's clock. */
    observedAt?: number;
}
/** Construction options for {@link PoolUsageTracker}. */
export interface PoolUsageOptions {
    /** Freshness horizon of a served reading, in ms. */
    freshMs?: number;
    /** Negative-cache window for a failed read that carried no server `retry-after`. */
    retryDelayMs?: number;
    /** Optional durable store for observed windows, times and cooldowns. */
    store?: UsageStore;
    /** Clock injection for tests; defaults to `Date.now`. */
    now?: () => number;
}
/**
 * Per-ACCOUNT usage readings with in-flight dedupe. A read never polls: it
 * answers from the retained reading, and only
 * {@link PoolUsageTracker.refreshSnapshot} and
 * {@link PoolUsageTracker.ensureForUse} may perform the one upstream request a
 * caller asked for. Providers without a usage endpoint (copilot) resolve no
 * fetcher and cannot be measured at all, which naturally ranks them behind
 * every measured member. Fetchers are resolved lazily per (provider, account)
 * so accounts added after startup join tracking on their first read.
 */
export declare class PoolUsageTracker {
    private readonly fetcherFor;
    private readonly records;
    /**
     * The outstanding read of one account, with the generation it belongs to. A
     * read that started before the account was forgotten or its reading
     * invalidated is superseded rather than joined, so a new login never waits on
     * — or inherits — the previous session's request.
     */
    private readonly inflight;
    /** Bumped by {@link forget} and {@link invalidate} to supersede outstanding reads. */
    private readonly generations;
    /**
     * Bumped only by {@link forget}. A passive observation taken by a request that
     * started before an invalidation is still new evidence and is applied; one taken
     * before the credentials were removed belongs to a session that no longer exists
     * and must never restore it.
     */
    private readonly forgotten;
    /**
     * Retired key -> canonical key, for an account the token store renamed. The
     * reading lives under the new key; a query, observation or clear that still
     * names the old one is resolved through here, so a rename can neither strand
     * the account's floors nor let a stale key write a second record.
     */
    private readonly renamed;
    private readonly store;
    private readonly freshMs;
    private readonly retryDelayMs;
    private readonly now;
    private readonly lifecycle;
    private disposed;
    /**
     * @param fetcherFor - resolves the upstream reader of one account, or undefined when its provider has no usage endpoint.
     * @param options - freshness, retry policy, durability and clock.
     */
    constructor(fetcherFor: (provider: ProviderId, account: string) => UsageFetcher | undefined, options?: PoolUsageOptions);
    /**
     * The retained reading of one account, for direct display (the Settings page).
     *
     * Wholly pure: it never performs an upstream read, never throws, and never
     * starts background work. A provider without a usage endpoint answers
     * `{ supported: false }`; an account with no reading answers
     * `{ supported: true, cache: { state: 'missing' } }` rather than pretending to
     * be empty. Use {@link refreshSnapshot} when a read is actually wanted.
     * @param provider - the account's provider.
     * @param account - the canonical account key.
     * @returns the retained payload with its freshness metadata.
     */
    snapshotFor(provider: ProviderId, account: string): ProviderUsage;
    /**
     * Refresh one account's reading from upstream when it is missing, incomplete
     * or stale — or, when `force` is set, past a fresh success too (the manual
     * Refresh control).
     *
     * A live failure cooldown is never bypassed, `force` included: retrying
     * through it is exactly what turns a progressively rate-limited endpoint's
     * 429 into a permanent lockout. A credential failure still propagates, because
     * it costs no round trip and must stay live so a fixed login rejoins
     * immediately; every other failure resolves with the retained reading and its
     * `cache.error` classification.
     * @param provider - the account's provider.
     * @param account - the canonical account key.
     * @param force - bypass a fresh success cache for an honest re-check.
     * @returns the payload after the attempted read.
     */
    refreshSnapshot(provider: ProviderId, account: string, force?: boolean): Promise<ProviderUsage>;
    /**
     * The quota view of one member, from what is already known.
     *
     * Wholly pure: it never performs an upstream read and never starts background
     * work, so ranking every candidate of a pool costs nothing. An account with no
     * reading scores neutral and is reported `unread`; it is never assumed to be
     * empty. Callers that are about to commit to one candidate verify it with
     * {@link ensureForUse}.
     * @param query - the account to read, and the model whose lanes apply when one is named.
     * @returns availability plus the urgency score.
     */
    quotaFor(query: QuotaQuery): MemberQuota;
    /**
     * The quota view of one candidate that is about to serve, permitting the one
     * upstream read it needs: missing, incomplete or stale readings are refreshed
     * once (single-flight, so concurrent callers join it), and a live cooldown is
     * answered from cache. Peers are never read, so ranking a pool cannot sweep
     * idle accounts.
     * @param query - the candidate account to verify, and the model whose lanes apply.
     * @returns the quota view after the attempted read.
     */
    ensureForUse(query: QuotaQuery): Promise<MemberQuota>;
    /**
     * Merge a partial observation — a provider response that stated some of this
     * account's windows — into what is already known.
     *
     * Only the windows the observation names are refreshed; every other window
     * keeps its own reading and its own age, so a response that omitted a lane
     * cannot make that lane look current. An observation naming no window changes
     * no reading at all, and cannot clear an invalidation. A reading older than
     * the one on record is discarded window by window, so a slower in-flight fetch
     * cannot overwrite a newer statement with older data. A usage-endpoint
     * cooldown is unrelated to this account answering a request and is left alone.
     * @param provider - the account's provider route.
     * @param account - the canonical account key.
     * @param observation - the readings this response carried.
     */
    observe(provider: ProviderId, account: string, observation: UsageObservation): void;
    /**
     * Merge a captured `anthropic-ratelimit-unified-*` report as an observation.
     *
     * The provider's own account-level report is a better statement than the usage
     * endpoint, so its utilization readings — converted from fractions to
     * percentages — become the account's session and weekly windows. The
     * `7d_oi` lane is a second reading of the same weekly period measured with
     * overage included and is deliberately not merged: reporting both would let
     * one period occupy two windows. A report carrying no reading leaves the
     * windows untouched.
     * @param provider - the account's provider route.
     * @param account - the canonical account key.
     * @param state - the report parsed from that account's response headers.
     */
    observeUnified(provider: ProviderId, account: string, state: UnifiedRateLimitState): void;
    /**
     * Capture an observation sink for one request, bound to the account's cache
     * generation at the moment the request starts.
     *
     * A stream can answer long after it began, and by then the account may have
     * been logged out, or another request may have distrusted its reading.
     *
     * Only the logout case blocks the callback: removing the credentials ends the
     * session the response belongs to, so no authorization state has to be re-read
     * asynchronously to know the response must be discarded. An invalidation is a
     * statement about a reading that is already old, and a response taken after it
     * is new evidence — {@link observe} still refuses any window older than the one
     * on record, so applying the callback cannot restore what was distrusted.
     * @param provider - the account's provider route.
     * @param account - the canonical account key.
     * @returns the callback to hand to that request's response path.
     */
    captureUnifiedObserver(provider: ProviderId, account: string): (state: UnifiedRateLimitState) => void;
    /**
     * Mark retained readings stale without dropping them: one account, or a whole
     * provider when `account` is omitted.
     *
     * The windows stay, so the availability floors keep excluding an account whose
     * allowance was already spent, and the next read on demand refreshes it. Reads
     * already in flight when the reading was distrusted are superseded, so an older
     * response cannot restore what the invalidation replaced.
     * @param provider - the provider route.
     * @param account - the account key; omitted marks the whole provider.
     */
    invalidate(provider: ProviderId, account?: string): void;
    /**
     * Drop everything retained for one account, or a whole provider when
     * `account` is omitted: the in-memory reading and its persisted record.
     *
     * This is the credential-removal path — a logout or a deleted login. It
     * differs from {@link invalidate} in that the last reading is deliberately
     * forgotten, and a read that was in flight when the credentials disappeared
     * cannot resurrect the account by landing afterwards.
     * @param provider - the provider route.
     * @param account - the account key; omitted drops the whole provider.
     */
    forget(provider: ProviderId, account?: string): void;
    /** Resolve once every durable write this tracker scheduled has landed. */
    flush(): Promise<void>;
    /**
     * Move one account's retained readings to the canonical key the token store
     * renamed it to.
     *
     * The reading is the account's own state and is kept whole: its windows with
     * their observation instants, the endpoint check that throttles the next read,
     * the plan and the failure cooldown. The retired key resolves to the new one,
     * so a query that still names it reaches the same reading and the same
     * availability floors. An outstanding read of the retired key is superseded
     * rather than allowed to land, because landing would recreate a record under a
     * key nothing reads; the next demand re-reads if it still needs to. Nothing is
     * awaited — this runs inside the save the outstanding read itself triggered.
     * @param provider - the provider route.
     * @param from - the key the account's readings were held under.
     * @param to - the canonical key the account now resolves to.
     */
    renameAccount(provider: ProviderId, from: string, to: string): void;
    /** The key one account's readings are held under now, following a rename. */
    private keyFor;
    /**
     * Stop the tracker for teardown: refuse further observations, abort owned
     * upstream reads, wait for them to settle, and land the durable writes already
     * scheduled — so nothing of this tracker's is outstanding when it resolves.
     */
    dispose(): Promise<void>;
    /**
     * Every cache key an {@link invalidate}/{@link forget} call covers: the named
     * account, or every key the tracker knows of that provider.
     */
    private keysUnder;
    /**
     * Whether one account's reading is complete and current: it holds windows, and
     * every one of them was observed within the freshness horizon and has not
     * reset. A window the provider stopped naming keeps its reading until an
     * authoritative endpoint read replaces the set, so this can be false for an
     * account whose newest observation is recent.
     */
    private isFresh;
    /**
     * Whether a demand should read this account from upstream.
     *
     * A complete, current reading needs nothing. An unknown or incomplete one is
     * throttled by the last successful check instead, so an endpoint that reports
     * no windows is asked once per horizon rather than once per request — and its
     * reading stays unknown rather than becoming a fabricated zero.
     */
    private needsRead;
    /** Freshness metadata of one account's retained reading. */
    private meta;
    /** Whether an upstream read of this account is outstanding for its current generation. */
    private refreshing;
    /** Score one member from the windows that constrain it. */
    private score;
    /**
     * Run (or join) the single in-flight read for one account key, merging either
     * outcome into the retained record. A missing/invalid credential is
     * deliberately NOT negative-cached with a cooldown: it costs no network round
     * trip (the session lookup fails before the request goes out) and re-checking
     * live means the member rejoins routing the instant its login is fixed.
     */
    private runFetch;
    /**
     * Whether a completed read may still write: the tracker is alive, the account
     * was not forgotten or invalidated since it started, and no newer observation
     * superseded it.
     */
    private landed;
    /**
     * Merge a successful endpoint read.
     *
     * The payload refreshes the lanes it names — per window, a reading the account
     * already superseded is kept, and an omitted `resetsAt` falls back to a reset
     * still ahead. A lane the payload omits keeps its own reading and its own age:
     * an absent lane is not evidence that a known allowance came back, so a floor a
     * spent window established survives both a partial and an empty answer. Such a
     * lane keeps the reading stale, which is what {@link needsRead} throttles
     * through this read's `checkedAt`.
     */
    private merge;
    /** Record a failed read with its cooldown and safe classification. */
    private recordFailure;
    /** Write one account's retained reading through, when it holds anything worth keeping. */
    private persist;
    /** Write one reading through under an explicit account key. */
    private persistAs;
}
/**
 * A safe classification of a failed usage read. It is what gets persisted and
 * shown, so it must never carry a provider message, response body or token.
 * @param error - the failure the read reported.
 * @returns the classification.
 */
export declare function classifyUsageFailure(error: unknown): UsageFailureReason;
