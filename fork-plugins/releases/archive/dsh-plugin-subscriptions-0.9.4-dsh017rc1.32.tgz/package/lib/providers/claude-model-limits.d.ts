/**
 * The context and output capacity this route reports for a Claude model.
 *
 * Two different quantities describe the same model. The pinned client's catalogue carries the
 * window it compacts against — a policy window that may sit below what the API accepts — while
 * the API documentation states the model's own limit. The harness picker wants the capacity the
 * model really has, so a documented limit answers before the catalogue entry does.
 *
 * A caller applies a provider-reported limit first; this module answers when discovery disclosed
 * none, in this order: the documented per-model limit, the pinned profile's catalogue entry, and
 * a conservative pair for a model no source names.
 *
 * One documented figure is withheld from a plain model id. A model whose catalogue entry reaches
 * its 1M window only through the long-context beta — the 200000-window entries carrying the
 * 1M-beta flag rather than native 1M — is reported at the catalogue window instead, because a
 * plain id composes no beta: the documentation states what the model accepts with it, and
 * reporting a window a request cannot use is a capacity the harness would then plan against and
 * the API would refuse. An id carrying the request-time `[1m]` marker composes that beta, so it
 * reports the million the client believes; an id whose entry declares no such flag is clamped
 * back to the plain window. The output ceiling is not beta-gated and is reported as documented.
 *
 * The catalogue key a wire model id resolves to therefore belongs to this module: the marker is a
 * capacity choice, and every entry lookup here reads through it.
 */
import type { ClaudeCodeCatalogueEntry } from '@tormentalabs/claude-code-wire-compat';
/** The context and output capacity one Claude model is reported with. */
export interface ClaudeModelLimits {
    /** Combined request/response capacity in tokens. */
    readonly contextWindow: number;
    /** Per-request output ceiling in tokens. */
    readonly maxOutputTokens: number;
}
/**
 * One model's entry in the pinned catalogue, when it carries one.
 *
 * A request-time marker is not part of the catalogue key, so a marked id reads the same entry as
 * the plain one.
 * @param model - the wire model id.
 * @returns the catalogue entry, or undefined for an id the profile does not carry.
 */
export declare function claudeCatalogueEntry(model: string): ClaudeCodeCatalogueEntry | undefined;
/**
 * The documented capacity for one model, when the documentation names it.
 * @param model - the wire model id; a request-time marker resolves to the id the documentation
 *   names.
 * @returns the documented limits, or undefined for a model the documentation does not name.
 */
export declare function claudeDocumentedLimits(model: string): ClaudeModelLimits | undefined;
/**
 * The pinned profile's catalogue capacity for one model.
 *
 * @param model - the wire model id.
 * @returns the catalogue entry's window and default output ceiling, or undefined for an id the
 *   profile does not carry.
 */
export declare function claudeProfileLimits(model: string): ClaudeModelLimits | undefined;
/**
 * The marked id whose request composes the long-context beta, when the marker buys a window.
 *
 * The marked id is the only channel this route has for a context size, so a model whose marked
 * window equals its plain one — every native-1M entry, and every entry the beta flag does not
 * cover, whose claim the client clamps back — gets no variant rather than a second id that
 * reports the same capacity.
 *
 * @param model - the unmarked wire model id.
 * @returns the marked id, or undefined when it reports no larger window than the plain one.
 */
export declare function claudeOneMillionModelId(model: string): string | undefined;
/**
 * The capacity to report for one model when discovery disclosed none.
 *
 * @param model - the wire model id.
 * @returns the documented limit, the pinned catalogue's entry, or the conservative pair. A
 *   documented window that needs the long-context beta is replaced by the catalogue window
 *   under a plain id, and an id that composes the beta reports the million the client believes.
 */
export declare function claudeModelLimits(model: string): ClaudeModelLimits;
