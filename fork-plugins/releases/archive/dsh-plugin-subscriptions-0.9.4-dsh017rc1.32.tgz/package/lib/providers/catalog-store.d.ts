/**
 * On-disk discovered-catalogue cache at
 * `~/.dsh/plugins/subscriptions/models.json` — the durable half of each
 * provider account's {@link ModelCatalogCache}.
 *
 * One entry per provider ACCOUNT, so a machine with several logins to the same
 * provider caches each account's own plan. The file carries a layout version:
 * rows written before accounts were keyed are DISCARDED rather than assigned to
 * some account, because ownership cannot be proven, and each account re-discovers
 * at its next explicit refresh. No credential, token or other secret is stored
 * here; the entry is only the advertised model metadata.
 *
 * Unlike the auth store, this file is a cache: a missing file reads as absent
 * and is rewritten by the next successful discovery. Loads are validated per
 * entry — a malformed entry passed through `resolveModel` would make the
 * harness's metadata validation throw on every call, which is worse than having
 * no fallback at all — and one unusable entry is dropped and reported without
 * discarding its siblings. Writes are serialized per file and applied by atomic
 * rename, so two accounts saving at once cannot lose each other's entry.
 */
import type { ProviderId } from '../auth/store.js';
import type { CatalogRecord, CatalogSnapshot, CatalogStoreFactory } from './common.js';
/** Options for {@link catalogStore}. */
export interface CatalogStoreOptions {
    /** Store file path; defaults to {@link modelsFilePath}. */
    path?: string;
    /** Warning sink for an unreadable, unparsable, or discarded cache entry. */
    onWarn?: (message: string) => void;
}
/**
 * Validate one persisted snapshot. Strict: any malformed field drops the
 * whole snapshot rather than repairing it — the next successful discovery
 * rewrites the entry anyway. An empty model list is valid and authoritative:
 * it records that the provider answered with no models for this account.
 * @param value - the raw per-account file entry.
 * @returns the validated snapshot, or undefined when unusable.
 */
export declare function sanitizeSnapshot(value: unknown): CatalogSnapshot | undefined;
/**
 * Validate one persisted account entry. The snapshot half keeps the strict
 * rules of {@link sanitizeSnapshot}; the failure half is an optional hint beside
 * it, so an entry may legitimately hold either one or both.
 * @param value - the raw per-account file entry.
 * @returns the validated record, or undefined when the entry holds neither half.
 */
export declare function sanitizeRecord(value: unknown): CatalogRecord | undefined;
/**
 * Build the durable half of a provider's catalogue cache over the shared
 * models.json file. The returned factory keys one {@link CatalogPersistence} per
 * ACCOUNT, so every login keeps its own discovered plan, and carries the
 * provider-wide operations a logout needs when no cache was ever built for the
 * account it drops.
 * @param provider - the provider route keying the file entries.
 * @param options - store path and warning sink.
 * @returns a per-account persistence factory.
 */
export declare function catalogStore(provider: ProviderId, options?: CatalogStoreOptions): CatalogStoreFactory;
