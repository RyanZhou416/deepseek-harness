import { LlmAdapter } from '@deepseek-ai/dsh-llm';
import type { GenerateOptions, LlmModelInfo, LlmResolvedModelInfo, StreamChunk } from '@deepseek-ai/dsh-llm';
import type { ProviderId } from '../auth/store.js';
import type { ProviderSettingsStore, AccountPreferences } from '../provider-settings.js';
import type { AccountAwareAdapter } from './accounts.js';
import type { PoolAdapter } from './pool.js';
export declare function accountModelId(account: string, model: string): string;
export declare function parseAccountModelId(id: string): {
    account: string;
    model: string;
} | undefined;
export declare function accountAllowsPool(preferences: AccountPreferences | undefined, model: string): boolean;
interface Options {
    provider: ProviderId;
    adapter: AccountAwareAdapter;
    settings: ProviderSettingsStore;
    accounts: () => Promise<readonly {
        key: string;
        label: string;
    }[]>;
    pool: () => PoolAdapter | undefined;
    /**
     * Resolve one account reference to the key the store holds it under now — the
     * hook a renamed account needs, so an independent entry a session selected
     * before the rename keeps resolving. Absent leaves the reference unchanged.
     */
    resolveAccount?: (account: string) => Promise<string>;
    /**
     * Readiness gate every public read awaits first, so no policy or catalogue
     * read happens under a key the auth store has already retired (see
     * `reconcileStoredCodexAliases`). Deliberately not consulted by the pool-member
     * seam: that seam is only reached from inside a stream that has already passed
     * the gate, and awaiting it again there would let the one-time reconciliation
     * wait on the very call it is preparing.
     */
    beforeRead?: () => Promise<void>;
    /** Where a pool that owns no entry for a requested model is reported. */
    onWarn: (message: string) => void;
}
/** Keeps the registered route separate from raw adapters and pool member seams. */
export declare class AccountPreferencesAdapter extends LlmAdapter {
    private readonly options;
    /** Models already reported as unowned — a per-request diagnostic is stated once otherwise. */
    private readonly reported;
    constructor(options: Options);
    providerRetryPolicy(provider: string): import("@deepseek-ai/dsh-llm").ResolvedRetryPolicy | undefined;
    /**
     * The wrapped adapter's own display identity.
     *
     * The harness reads this for every registered route and shows the name in the model picker for
     * a route that declares no provider directory, which is how these routes appear; without the
     * delegation each adapter's name would be replaced by the raw route id.
     */
    providerInfo(provider: string): import("@deepseek-ai/dsh-llm").LlmProviderInfo;
    private preference;
    private models;
    /**
     * The rows an availability check reads.
     *
     * A capability question answers from the caches alone. A request about to be
     * sent first ENSURES the one account being validated — a single provider
     * request when that account's catalogue is missing or stale, never one per
     * peer — and then reads it; a failed ensure warns and falls through to the
     * last-known rows and the built-in catalog, so an unreachable provider does
     * not turn a selectable model into a refusal.
     * @param account - the account whose catalog is checked.
     * @param requireFresh - true for the account a request is about to use.
     * @returns that account's rows, empty when the read was cancelled.
     */
    private listed;
    private requireAccount;
    /**
     * Report once, per model, that an enabled pool owns no entry for it. The
     * request still runs, but on one account chosen by the pool's availability
     * rule rather than through pool failover, and that gap is a configuration
     * state the operator can act on instead of a silent difference in routing.
     */
    private reportUnowned;
    /**
     * The account serving a model the pool does not own. The pool's availability
     * rule still applies: an account that is cooling down, or that is past a
     * Claude usage floor, is skipped for the next eligible one — the fallback can
     * never reach an account the pool would have held back.
     *
     * When no account qualifies, the error names why the pool held them back and
     * when the earliest one may serve again. That is the pool-exhausted error's own
     * cause and hint: a spent allowance or a parked account is temporary and
     * retryable, and reporting `NO_ADAPTER` for it would name an unavailable model
     * and discard the recovery instant the provider already disclosed.
     *
     * A candidate's usage floor is judged from what the pool already knows, except
     * on the streaming path: `requireFresh` is this caller's statement that it is
     * about to commit a request, which is what permits the one usage read per
     * candidate considered. Listing or resolving a model reaches no usage endpoint.
     */
    private fallback;
    /** Pool-only facade: explicit families/tiers must obey the same policy as auto pools. */
    poolMember(): AccountAwareAdapter;
    listModels(provider: string): Promise<readonly LlmModelInfo[]>;
    resolveModel(provider: string, id: string): Promise<LlmResolvedModelInfo>;
    stream(options: GenerateOptions): AsyncIterable<StreamChunk>;
    /** Wait for the one-time account-rename reconciliation before reading state. */
    private ready;
    /** One account reference as the store holds it now (the rename hook). */
    private resolved;
}
export {};
