/**
 * The durable owner of the Claude wire identity, the ATIS pin state and the account's capture
 * arbitration.
 *
 * In one process these facts already exist as module-level maps. They are not enough: the wire
 * session id decides both `X-Claude-Code-Session-Id` and the billing `cc_prompt_id` derived from
 * it, so a restart that minted a new id would render different model-visible bytes for the same
 * conversation. This store is therefore the durable owner of that identity, and a request may not
 * be built until the identity for its span is committed.
 *
 * **Every ready identity is already committed.** {@link ClaudeSpanBindingStore.prepare} writes the
 * wire session id in the same locked read-modify-write that decides it, for a new span and for a
 * restored one alike, so a later freeze can never mint a second identity for a request that
 * already declared the first. A restored span whose own record is absent takes the identity a
 * verified durable log fact states, or a fresh one when the caller has no such fact; either way
 * its pin is committed empty, because the conversation continued without a fact saying what it
 * used, and a bootstrap read that lands later must not fill it in. A restored span whose record
 * exists but holds no pin is committed empty on the same terms. Only a new span is left unfrozen,
 * and its first freeze takes the account's own arbitration.
 *
 * The rules the in-memory owner applies are preserved rather than re-decided here. A pin freezes
 * to the capture that was newest when that request was prepared — the token a bootstrap read
 * disclosed, or the empty pin when the read disclosed nothing usable — and what it froze to never
 * changes, so a later read cannot replace what the span sends. The newest capture attempt owns the
 * account, so an older capture that finishes late commits nothing and cannot revive a frozen or
 * evicted pin. Spans are bounded per account, oldest first. A discard bumps the account's
 * capture generation, which revokes in-flight tickets, and drops the account's spans.
 *
 * The store is fail-closed. A document that cannot be read, parsed or verified, and a lock that
 * cannot be owned, report the same fixed refusal, and the caller must send nothing: a temporary
 * random identity would silently change the conversation's model-visible bytes and its ATIS
 * state. A refusal that will pass — a held lock, an elapsed deadline, an operation still settling
 * — is answered again on the next call rather than becoming a permanent verdict.
 *
 * @module dsh-plugin-subscriptions/providers/claude-span-store
 */
import type { ContinuationDeadline, ContinuationFiles, ContinuationUnavailable, ContinuationWaitHost } from './claude-continuation-io.js';
import type { ClaudeAccountRef } from '../claude-core/account-ref.js';
export { LOCAL_CONTINUATION_STATE_UNAVAILABLE } from './claude-continuation-io.js';
/** The document version this build writes and reads. */
export declare const CLAUDE_SPAN_STORE_VERSION = 1;
/** At most this many spans per account; the oldest is evicted first. */
export declare const CLAUDE_SPAN_LIMIT = 256;
/** Constructor options for {@link ClaudeSpanBindingStore}. */
export interface ClaudeSpanBindingStoreOptions {
    /** File holding the state; absent uses the plugin's own home directory. */
    readonly path?: string;
    /** How long one operation may wait before its caller is refused. */
    readonly deadlineMs: number;
    /** How long one operation may wait for the owned lock. */
    readonly lockTimeoutMs: number;
    /** Sink for a diagnostic about the store itself; never used for a credential. */
    readonly onWarn?: (message: string) => void;
    /** The private file operations; a test injects one to hold a write. */
    readonly files?: ContinuationFiles;
    /** The timers and abort listeners one bounded wait uses; a test injects one to observe it. */
    readonly waits?: ContinuationWaitHost;
}
/** The span identity one request belongs to. */
export interface ClaudeSpanIdentity {
    /** The account this installation derives references for. */
    readonly accountRef: ClaudeAccountRef;
    /** The harness session the conversation belongs to. */
    readonly harnessSessionId: string;
    /** The identity generation in force when the span was created. */
    readonly spanEpoch: number;
}
/** The pin a span sends: unfrozen until its first request freezes it to a token or to empty. */
export type ClaudeSpanPin = {
    readonly kind: 'unfrozen';
} | {
    readonly kind: 'empty';
} | {
    readonly kind: 'token';
    readonly token: string;
};
/** Whether a span is created or restored; only a new Session may seed a pin. */
export type ClaudeSpanOrigin = 'initial' | 'resume';
/**
 * The wire identity a restored span's own durable record states, as the caller verified it.
 *
 * The store cannot verify provenance: the caller passes this only when its session log itself
 * states the identity for this span. An unusable value is treated as no fact at all, so the
 * restored span gets a fresh identity and sends no chain rather than adopting a value the store
 * cannot accept.
 */
export interface ClaudeSpanRestoredIdentity {
    /** The wire session id the session log recorded for this span. */
    readonly wireSessionId: string;
}
/** What one {@link ClaudeSpanBindingStore.prepare} call may be told and bounded by. */
export interface ClaudeSpanPrepareOptions {
    /** The wire identity a verified log fact states for this restored span. */
    readonly restored?: ClaudeSpanRestoredIdentity;
    /** The bound and cancellation the caller resolved for its own preparation chain. */
    readonly deadline?: ContinuationDeadline;
}
/** What one prepared span carries. */
export interface ClaudeSpanPrepared {
    /** The stable wire session identity this span commits to. */
    readonly wireSessionId: string;
    /** The pin in force, which is unfrozen until the span's first freeze. */
    readonly pin: ClaudeSpanPin;
    /** Whether this call created the span; false means it already existed. */
    readonly created: boolean;
}
/** A prepared span, or the fixed reason nothing may be sent. */
export type ClaudeSpanPrepareResult = {
    readonly kind: 'ready';
    readonly span: ClaudeSpanPrepared;
} | ContinuationUnavailable;
/** What reading one span's pin produced. */
export type ClaudeSpanPinResult = 
/** No span exists for this identity. */
{
    readonly kind: 'absent';
}
/** The pin in force for this span. */
 | {
    readonly kind: 'pin';
    readonly pin: ClaudeSpanPin;
}
/** The state cannot be read; the caller must not send. */
 | ContinuationUnavailable;
/** What freezing one pin produced. */
export type ClaudeSpanFreezeResult = {
    readonly kind: 'frozen';
    readonly pin: ClaudeSpanPin;
} | ContinuationUnavailable;
/** The right to record what one bootstrap read disclosed for an account. */
export interface ClaudeCaptureTicket {
    /** The account the read belongs to. */
    readonly accountRef: ClaudeAccountRef;
    /** The generation the ticket was issued under; a later discard revokes it. */
    readonly generation: number;
    /** The attempt serial that owns the account while it is the newest. */
    readonly attempt: number;
}
/** What claiming a capture right produced. */
export type ClaudeCaptureBeginResult = {
    readonly kind: 'ticket';
    readonly ticket: ClaudeCaptureTicket;
} | ContinuationUnavailable;
/** What committing a capture produced. */
export type ClaudeCaptureCommitResult = 
/** The capture was the newest attempt and became the account's candidate. */
{
    readonly kind: 'committed';
}
/** An older or revoked capture owns nothing; the caller keeps the state it read. */
 | {
    readonly kind: 'refused';
} | ContinuationUnavailable;
/** What discarding one account's state produced. */
export type ClaudeSpanDiscardResult = {
    readonly kind: 'discarded';
} | ContinuationUnavailable;
/**
 * The durable wire identity, pin and capture owner for Claude account spans.
 *
 * Every operation reads and changes the document inside the plugin's own lock, so two processes
 * cannot interleave a discard with a commit or drop each other's account, and a decision is never
 * made from a document a pending write may still replace.
 */
export declare class ClaudeSpanBindingStore {
    private readonly options;
    private readonly path;
    private readonly io;
    private damaged;
    private warned;
    /**
     * @param options - path override, both configured budgets and the injectable I/O boundary.
     */
    constructor(options: ClaudeSpanBindingStoreOptions);
    /**
     * Prepare the span one request belongs to, committing its wire identity before it is returned.
     *
     * A span that already exists keeps the identity it committed. A new Session creates one. A
     * restored Session whose record is absent takes the caller's verified log identity when it has
     * one and a fresh identity otherwise, and its pin is committed empty either way; a restored span
     * whose record holds no pin is committed empty on the same terms, so a bootstrap read that lands
     * later cannot fill it in.
     * @param identity - the account, session and generation the span is keyed by.
     * @param origin - whether this is a new Session or a restored one.
     * @param options - the restored identity fact and the caller's own bound, when it has them.
     * @returns the committed span, or the fixed reason nothing may be sent.
     */
    prepare(identity: ClaudeSpanIdentity, origin: ClaudeSpanOrigin, options?: ClaudeSpanPrepareOptions): Promise<ClaudeSpanPrepareResult>;
    /**
     * The pin in force for one span, without freezing or creating anything.
     * @param identity - the span to look up.
     * @param deadline - the caller's own bound, when it has one.
     * @returns the pin, that no span exists, or why the state cannot be read.
     */
    pinFor(identity: ClaudeSpanIdentity, deadline?: ContinuationDeadline): Promise<ClaudeSpanPinResult>;
    /**
     * Freeze one span's pin, which is the span's first request.
     *
     * The value comes from this account's own arbitration — the candidate the newest capture
     * committed, or the empty pin when it disclosed nothing usable — so a caller cannot introduce a
     * second candidate by passing a token of its own. A span that already froze keeps its value, so
     * a bootstrap read that lands later cannot change what the span sends. A span whose identity was
     * never committed is refused rather than given an identity the request never declared.
     * @param identity - the span to freeze.
     * @param deadline - the caller's own bound, when it has one.
     * @returns the frozen pin, or the fixed reason nothing may be sent.
     */
    freeze(identity: ClaudeSpanIdentity, deadline?: ContinuationDeadline): Promise<ClaudeSpanFreezeResult>;
    /**
     * Claim the right to record what one bootstrap read discloses.
     *
     * The attempt is the newest, so an older read that finishes later commits nothing. A ticket is
     * issued only when the claim was durably recorded: a store that cannot be written has no ticket,
     * and a caller can never mistake a failed claim for an owned attempt.
     * @param accountRef - the account the read belongs to.
     * @param deadline - the caller's own bound, when it has one.
     * @returns the ticket a commit needs, or the fixed refusal.
     */
    beginCapture(accountRef: ClaudeAccountRef, deadline?: ContinuationDeadline): Promise<ClaudeCaptureBeginResult>;
    /**
     * Record what a successful read disclosed, when the ticket still owns the account.
     * @param ticket - the ticket {@link beginCapture} returned.
     * @param disclosed - the raw value the document carried, if any.
     * @param deadline - the caller's own bound, when it has one.
     * @returns whether the capture became the account's candidate.
     */
    commitCapture(ticket: ClaudeCaptureTicket, disclosed: unknown, deadline?: ContinuationDeadline): Promise<ClaudeCaptureCommitResult>;
    /**
     * Forget everything this installation holds for one account.
     *
     * A generation bump revokes in-flight tickets, and dropping the spans means a later request for
     * the same account starts without the pins and wire identity an older identity froze.
     * @param accountRef - the account whose state is dropped.
     * @param deadline - the caller's own bound, when it has one.
     * @returns that the state was dropped, or the fixed reason it was not.
     */
    discard(accountRef: ClaudeAccountRef, deadline?: ContinuationDeadline): Promise<ClaudeSpanDiscardResult>;
    /** Stop accepting operations and wait for the ones already owned to settle. */
    close(): Promise<void>;
    /**
     * Apply one change under the plugin's own lock.
     * @param change - the pure change, given the current document.
     * @param deadline - the caller's own bound, when it has one.
     * @returns the change's value, or the fixed reason it could not be applied.
     */
    private run;
    /** Remember a document this build cannot trust, and report it once. */
    private distrust;
    private warnOnce;
}
