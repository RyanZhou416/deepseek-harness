/**
 * Claude Pro/Max subscription provider: OAuth against claude.ai /
 * platform.claude.com with the Claude Code client id, and streaming against
 * the Anthropic Messages API through the pinned Claude Code 2.1.288 wire
 * contract built by `@tormentalabs/claude-code-wire-compat`.
 */
import { LlmError } from '@deepseek-ai/dsh-llm';
import type { GenerateOptions, LlmProviderInfo, LlmResolvedModelInfo, StreamChunk } from '@deepseek-ai/dsh-llm';
import type { FlowSpec } from '../auth/oauth-flow.js';
import type { ClaudeSession } from '../auth/store.js';
import type { PoolAdapter } from './pool.js';
import type { AttachmentStore } from '@deepseek-ai/dsh-attachment';
import type { TranslatableMessage } from '../translate/resolved.js';
import { ClaudeRequestRecordPort } from './claude-wire-record.js';
import type { ClaudeEnginePolicy } from '../claude-engine/request-policy.js';
import type { ContinuationUnavailable } from './claude-continuation-io.js';
import type { ClaudeContinuationState } from './claude-continuation-state.js';
import type { ClaudeCaptureTicket } from './claude-span-store.js';
import type { ClaudeWireThinking } from './claude-wire.js';
import { AccountTokenManager } from './accounts.js';
import type { CatalogStoreFactory, DiscoveredModel, FetchFn, ModelEntry, ProviderUsage } from './common.js';
import { ProviderCatalog } from './provider-catalog.js';
import { PoolBackedAdapter } from './pool-delegation.js';
import type { ClaudeFailureDecision } from './claude-failure.js';
import type { ClaudeProtocolProfile } from './claude-protocol.js';
import { ClaudeProtocolBlockStore } from './claude-protocol-state.js';
import type { ClaudeProfileReadResult, ClaudeProfileReader } from './claude-profile.js';
import type { ClaudePolicyFetchFn } from './claude-managed-settings.js';
import type { ClaudeProfileFields } from './claude-account-state.js';
import type { RateLimitResetReader, RateLimitWait } from './rate-limit.js';
import type { UnifiedRateLimitState } from './unified-rate-limit.js';
export declare const CLAUDE_CLIENT_ID = "9d1c250a-e61b-44d9-88ed-5944d1962f5e";
export declare const CLAUDE_AUTHORIZE_URL: string;
export declare const CLAUDE_TOKEN_URL: string;
/**
 * Supplies a fresh access token after the service rejects the current one.
 *
 * The genuine client issues its usage request with refresh-and-replay enabled, so a
 * token that expired between the last refresh and the request costs one retry rather
 * than the whole poll.
 */
type ClaudeReauthorize = () => Promise<string>;
/**
 * The model-options endpoint the client uses on the first-party path.
 *
 * `/v1/models` is not part of that path at all — the client reaches it only under the
 * gateway's own discovery switch — so calling it here would be a request the genuine client
 * never sends. This one supplements a catalogue the client already carries, and a response
 * that fails its shape is discarded rather than treated as a failure. Its path comes from
 * the compatibility profile, so one role cannot quietly reach another role's target.
 */
/**
 * The durable capture a bootstrap catalogue read claims before it asks.
 *
 * The read is the only thing that discloses this account's ATIS candidate, so it claims a right
 * that survives a restart and commits what it read under that same right; a read with no wired
 * state claims nothing, and the spans then freeze empty rather than inheriting a token nobody
 * could attribute to an identity.
 */
export interface ClaudeCatalogueCapture {
    /**
     * Claim the right to record what this read discloses.
     * @param account - the canonical account key the read belongs to.
     * @returns the durable ticket, or the fixed refusal.
     */
    beginCapture(account: string): Promise<{
        readonly kind: 'ticket';
        readonly ticket: ClaudeCaptureTicket;
    } | ContinuationUnavailable>;
    /**
     * Record what a successful read disclosed, when its ticket still owns the account.
     * @param ticket - the ticket {@link beginCapture} returned.
     * @param disclosed - the raw value the read disclosed.
     */
    commitCapture(ticket: ClaudeCaptureTicket, disclosed: unknown): Promise<unknown>;
}
/** The plugin's startup hydration result, read once it settled rather than sampled as a flag. */
export type ClaudeContinuationReadiness = {
    readonly kind: 'ready';
} | {
    readonly kind: 'failed';
    readonly reason: string;
};
export declare const CLAUDE_SCOPE = "org:create_api_key user:profile user:inference user:sessions:claude_code user:mcp_servers user:file_upload user:plugins";
export declare const CLAUDE_CALLBACK_PATH = "/callback";
/** Refresh when the access token has less than this much life left. */
export declare const CLAUDE_PREEMPT_MS: number;
/**
 * Reads the reset instant of the Anthropic window that rejected a request.
 *
 * `anthropic-ratelimit-unified-*` is the subscription-plan family — the one
 * Claude Code renders as "resets 3pm" — and is the only header that names the
 * window which actually rejected this request. The per-bucket
 * `anthropic-ratelimit-{requests,tokens,input-tokens,output-tokens}-reset`
 * headers are deliberately not read: they are rollover snapshots attached to
 * every response, so on a 429 they cannot say which bucket refused, and the
 * earliest of them is typically the bucket that still had room — a wait that
 * lands straight back in the closed window. They reach the operator through
 * `rateLimitDiagnostics` instead.
 */
/**
 * Read the client's millisecond-first retry header, bounded to its timer range.
 * @param response - the failed Claude response.
 * @param now - current epoch milliseconds.
 * @returns the disclosed retry instant, or undefined for absent/invalid delays.
 */
export declare function claudeRetryHeaderReset(response: Response, now: number): number | undefined;
export declare const claudeRateLimitReset: RateLimitResetReader;
/**
 * The subscription endpoint only serves requests presenting as Claude Code,
 * so the usage and models endpoints reuse the pinned wire profile's CLI
 * user-agent; the harness attribution user-agent cannot be sent here.
 */
/**
 * Models the prompt-caching guide allows to take a later `{"role":"system"}`
 * message: Fable 5, Fable 5.1, Mythos 5, Mythos 5.1, Opus 4.8, and Opus 5.
 * Sonnet 5 and Opus 5.5 are not in that list.
 */
export declare function supportsMidConversationSystem(model: string): boolean;
/** Files API upload. Official path from the Files HTTP reference. */
/**
 * Vision: images on the Claude API may be at most 10 MB once base64-encoded.
 * Larger images go through the Files API as `{ type: "file", file_id }`.
 */
export declare const CLAUDE_MAX_BASE64_IMAGE_CHARS = 10000000;
/** Uploaded Files API entries kept before the oldest is evicted. */
export declare const CLAUDE_FILE_ID_LIMIT = 256;
/**
 * The Files API id one account already uploaded for an image content hash.
 * @param account - the canonical account key that would own the upload.
 * @param contentHash - sha256 of the image's base64 payload.
 * @returns the uploaded id, or undefined when this account has not uploaded it.
 */
export declare function uploadedClaudeFileId(account: string, contentHash: string): string | undefined;
/**
 * Remember one account's uploaded Files API id for an image content hash.
 *
 * A file id is served only under the token that uploaded it, and the Claude
 * routes are pooled, so the account key joins the content hash in the key: a
 * failover uploads its own copy instead of handing another account's request a
 * file id Anthropic would reject.
 * @param account - the canonical account key that uploaded the file.
 * @param contentHash - sha256 of the image's base64 payload.
 * @param fileId - the Files API id the upload returned.
 */
export declare function rememberClaudeFileId(account: string, contentHash: string, fileId: string): void;
/**
 * Drop the Files API ids uploaded under one account, or every account when none
 * is named. A login replaces the token those ids were minted with, so the
 * adapter drops them with the account's other cached state.
 * @param account - the canonical account key whose uploads are dropped.
 */
export declare function clearClaudeFileIds(account?: string): void;
/**
 * Replace oversized inline images with a Files API `file_id`; smaller images
 * stay base64. The upload is made with the request's own account token, and the
 * resulting id is cached under that account.
 * @param messages - resolved request messages.
 * @param account - the canonical account key serving this request.
 * @param accessToken - that account's current access token.
 * @param fetchFn - fetch implementation (injectable for tests).
 * @param signal - caller cancellation.
 * @param onDecision - sink for an upload's ordered classification.
 * @returns the messages, with uploaded images bound to a file id.
 */
export declare function bindClaudeFileIds(messages: readonly TranslatableMessage[], account: string, accessToken: string, fetchFn?: FetchFn, signal?: AbortSignal, onDecision?: (decision: ClaudeFailureDecision) => void): Promise<readonly TranslatableMessage[]>;
/**
 * Where claude.com sends a browser that cannot reach this machine.
 *
 * The page displays the authorization code for the user to copy back, which is what makes a
 * login started on one device finish on another.
 */
export declare const CLAUDE_MANUAL_REDIRECT_URL = "https://platform.claude.com/oauth/code/callback";
/** Static claude flow facts for the OAuth flow engine. */
export declare const claudeFlow: FlowSpec;
/**
 * One profile read's inputs.
 *
 * The disclosed fields are the maintenance module's own record type, and the result is its
 * reader result type: this route implements that contract instead of declaring a second
 * version of it.
 */
export interface ClaudeProfileRequest {
    /** The access token the read carries. */
    readonly accessToken: string;
    /** Fetch implementation; injectable so no test reaches the network. */
    readonly fetchFn?: FetchFn;
    /** Caller cancellation. */
    readonly signal?: AbortSignal;
    /** Refresh-and-replay hook: one replay after a rejection, as the client performs. */
    readonly reauthorize?: ClaudeReauthorize;
    /** The frozen compatibility profile this read belongs to; absent uses the pinned one. */
    readonly profile?: ClaudeProtocolProfile;
    /** Identity the caller already holds; a conflicting disclosure reports `invalid`. */
    readonly expectedAccountUuid?: string;
    /** Receives the ordered classification, so a refusal here blocks the profile too. */
    readonly onDecision?: (decision: ClaudeFailureDecision) => void;
    /**
     * Accept the pre-wire flat document the login and identity backfill callers tolerate.
     *
     * Off by default: the maintenance reader validates the wire shape, where `account` and
     * `organization` are two objects with their own uuids. This option exists only for those two
     * legacy callers, which treat the read as decoration and check the fields they receive.
     */
    readonly legacyFlatPayload?: boolean;
}
/**
 * What one profile read disclosed, or why it disclosed nothing.
 *
 * The shape is the maintenance reader's own result extended with the two things this route
 * keeps for itself: the transport cause of an unreachable read, and the classified error a
 * refusal already produced — so a caller that must stop never rebuilds one from the record.
 */
export type ClaudeProfileResult = ClaudeProfileReadResult | {
    readonly outcome: 'unreachable';
    readonly cause?: unknown;
} | {
    readonly outcome: 'ok';
    readonly fields: ClaudeProfileFields;
    /** The client's own completeness verdict for this document. */
    readonly complete: boolean;
} | {
    readonly outcome: 'unauthorized' | 'refused';
    readonly failure: ClaudeFailureDecision;
    readonly error: LlmError;
};
/**
 * Read one account's profile, preserving why it disclosed nothing.
 *
 * The read is replayable exactly as the client performs it: one rejection is answered by a
 * refresh and a second request, and a second rejection is reported as it stands. Failures
 * keep their ordered classification, so a client-version refusal found here is not lost to
 * a generic "no profile" result.
 * @param request - the token, cancellation and optional refresh hook.
 * @returns the structured outcome of this read.
 */
export declare function fetchClaudeProfile(request: ClaudeProfileRequest): Promise<ClaudeProfileResult>;
/** Dependencies one {@link claudeProfileReader} carries. */
export interface ClaudeProfileReaderOptions {
    /** Fetch implementation; injectable so no test reaches the network. */
    readonly fetchFn?: FetchFn;
    /** The frozen compatibility profile this reader belongs to. */
    readonly profile?: ClaudeProtocolProfile;
    /** Receives the ordered classification of a refused read. */
    readonly onDecision?: (decision: ClaudeFailureDecision) => void;
}
/**
 * Build the profile reader the account maintenance module consumes.
 *
 * The account key travels with the call so a consumer can key its cache by identity; the
 * read itself is authorized by the token alone.
 * @param options - fetch injection and the compatibility profile.
 * @returns a reader that never throws for a provider outcome, only for a programming error.
 */
export declare function claudeProfileReader(options?: ClaudeProfileReaderOptions): ClaudeProfileReader;
/** Dependencies one {@link claudeSettingsFetch} carries. */
export interface ClaudeSettingsFetchOptions {
    /** Fetch implementation; injectable so no test reaches the network. */
    readonly fetchFn?: FetchFn;
    /** Bound on one settings read; defaults to the profile read's own bound. */
    readonly timeoutMs?: number;
    /** The frozen compatibility profile this read belongs to. */
    readonly profile?: ClaudeProtocolProfile;
}
/**
 * Build the managed-settings fetch the account maintenance module consumes.
 *
 * The settings role owns its headers: it sends the settings user agent and OAuth beta and
 * does not borrow the Messages plan. Only the transfer is performed here; interpreting the
 * status, the checksum and the cached snapshot belongs to the caller.
 * @param options - fetch injection, bound and compatibility profile.
 * @returns a fetch that returns the provider's own response.
 */
export declare function claudeSettingsFetch(options?: ClaudeSettingsFetchOptions): ClaudePolicyFetchFn;
/**
 * Derive the device id for one account on one OS installation.
 *
 * The device input is a hash of a stable OS machine identifier, independent of DSH caches.
 * Messages use `uuid:<accountUuid>` as the account key. This DSH policy differs from CC's
 * random config-root id; no raw machine identifier is stored or sent.
 * @param accountKey - Stable account key, not a token, display name or cache path.
 * @param fingerprint - Hashed device input; omitted uses this host's stable OS identity.
 * @returns A 64-character lowercase hex id.
 * @throws LlmError when no supported stable local device identity is available.
 */
export declare function deriveClaudeDeviceId(accountKey: string, fingerprint?: string): string;
/**
 * Carry stored identity fields across re-authorization.
 *
 * Credential rotation does not itself rewrite device binding. Before the next Messages
 * request, the adapter recomputes the expected id for the account UUID and local device,
 * and conditionally migrates a legacy value or a cache copied from another machine.
 *
 * @param next - The session the authorization just produced.
 * @param previous - The stored session for the same account, when there is one.
 * @returns The session to store, with the earlier identity preserved.
 */
export declare function carryClaudeIdentity(next: ClaudeSession, previous: ClaudeSession | undefined): ClaudeSession;
/** Options one token-endpoint POST accepts; both default to the client's own behavior. */
export interface ClaudeTokenRequestOptions {
    /** Fetch implementation; injectable so a synthetic test never reaches the network. */
    readonly fetchFn?: FetchFn;
    /** Bound on this POST in milliseconds; defaults to {@link CLAUDE_TOKEN_TIMEOUT_MS}. */
    readonly timeoutMs?: number;
}
export declare function exchangeClaudeCode(code: string, verifier: string, redirectUri: string, state: string, options?: ClaudeTokenRequestOptions): Promise<ClaudeSession>;
/**
 * Refresh a claude session (JSON grant echoing the issued scope).
 * @param session - the stored session.
 * @param options - the fetch implementation and the bound; both default to the client's own.
 * @returns the fresh session to store.
 */
export declare function refreshClaude(session: ClaudeSession, options?: ClaudeTokenRequestOptions): Promise<ClaudeSession>;
/**
 * Whether a claude refresh failure means the login is permanently gone.
 * @param error - the thrown refresh error.
 * @returns true when re-login is the only fix.
 */
export declare function isClaudePermanentRefreshError(error: unknown): boolean;
/**
 * Fetch the claude subscription usage from the OAuth usage endpoint (the
 * source of Claude Code's `/usage` screen). Newer responses carry a
 * structured `limits` array; older ones the flat `five_hour`/`seven_day*`
 * buckets — both shapes are read, the array winning when it has entries.
 * @param session - the stored session (used as-is; never refreshed here).
 * @param fetchFn - fetch implementation (injectable for tests).
 * @param signal - caller cancellation from the RPC transport.
 * @returns the mapped usage snapshot.
 */
export declare function fetchClaudeUsage(session: ClaudeSession, fetchFn?: FetchFn, signal?: AbortSignal, reauthorize?: ClaudeReauthorize, timeoutMs?: number): Promise<ProviderUsage>;
/**
 * The `thinking` object for one request.
 *
 * `display: 'summarized'` is fixed by the wire module on both shapes: adaptive
 * models default to `display: 'omitted'`, which returns thinking blocks with
 * an empty `thinking` field. Without this override the Think panel stays empty.
 * @param model - the requested model id.
 * @param thinkingType - the shape the pinned catalogue gives the model, when it gives one.
 * @param maxTokens - the resolved output cap; the manual budget is derived from it.
 * @returns the wire `thinking` request, or undefined when the model takes none.
 */
export declare function claudeThinkingBody(model: string, thinkingType: 'enabled' | 'adaptive' | undefined, maxTokens: number): ClaudeWireThinking | undefined;
/**
 * Read the account's Claude catalogue: the client's own built-in table with the model
 * options this account adds to it.
 *
 * The endpoint carries additions, not a catalogue — its own field is named
 * `additional_model_options` beside `additional_model_costs` — so the built-in table is
 * what the rows are built from and the response is merged onto it. A response that does
 * not match the document's shape, or one the endpoint refuses, leaves the built-in table
 * standing, which is what the client does with one: the catalogue it already carries
 * stays authoritative, and this call only adds to it. An option the service marks
 * disabled is listed as a disabled row rather than dropped, so the account sees that the
 * model exists and cannot use it.
 *
 * @param session - the account whose token authenticates the read.
 * @param extraHeaders - the desktop client headers, which this request carries like every
 *   other subscription request.
 * @param fetchFn - fetch implementation (injectable for tests).
 * @param signal - caller cancellation.
 * @param model - the model the client would be asking about. The genuine caller always has
 *   one, because it asks while a session is running; a listing has none, so the profile's own
 *   first catalogue entry stands in for it rather than sending a request the client's shape
 *   has no counterpart for.
 * @param capture - the durable capture owner, when the plugin wired one; the read claims its
 *   candidate under that owner's ticket.
 * @returns the catalogue rows for this account.
 */
export declare function fetchClaudeCatalogue(session: ClaudeSession, extraHeaders?: readonly (readonly [string, string])[], fetchFn?: FetchFn, signal?: AbortSignal, account?: string, model?: string, capture?: ClaudeCatalogueCapture): Promise<DiscoveredModel[]>;
/**
 * One account attempt the maintenance seam observes.
 *
 * The signal is the caller's own cancellation, never this adapter's idle watchdog: a
 * consumer binding a live session to a user stop must not be handed a synthetic abort that
 * means something else.
 */
export interface ClaudeAccountAttempt {
    /** Canonical account key this attempt routes to. */
    readonly account: string;
    /**
     * The harness session id this attempt belongs to, when the caller supplied one.
     *
     * Absent means the request carries no session identity at all, so a consumer must not
     * create a permanent binding for it: there is no session a stop could later release.
     */
    readonly sessionId?: string;
    /** The credentials in force when the attempt starts. */
    readonly session: ClaudeSession;
    /**
     * The caller's own cancellation, or absent when the caller supplied none.
     *
     * Absent is a statement, not a missing value: no user stop can be observed for this attempt,
     * so a consumer must not infer one from anything this adapter does.
     */
    readonly signal?: AbortSignal;
}
/** How one account attempt ended, for the maintenance seam's diagnostics. */
export interface ClaudeAccountOutcome extends ClaudeAccountAttempt {
    /** Terminal shape of the attempt: a finished stream, a failure, or the caller's cancel. */
    readonly status: 'completed' | 'failed' | 'cancelled';
    /** Whether any chunk for this logical request reached the Host. */
    readonly delivered: boolean;
    /** The failure the attempt ended on, when it failed. */
    readonly error?: LlmError;
    /** The ordered decision behind {@link error}, when this adapter classified it. */
    readonly failure?: ClaudeFailureDecision;
}
/**
 * The per-account maintenance seam.
 *
 * The maintenance module owns the schedule and the account state; this adapter only reports
 * the points it already passes through. Attempt end is not session release: a stream that
 * finishes normally still leaves its session able to send the next prompt, so nothing here
 * tells the consumer to release a binding. The session owner does that on session stop,
 * account unbind, logout and plugin disposal.
 */
export interface ClaudeMaintenanceHooks {
    /**
     * Runs before the account's first wire request and again before the replayed request that
     * follows an authentication refresh.
     *
     * It is the note-that-this-session-is-live point and the place a policy block is enforced:
     * throwing refuses the request before it is sent and carries the hard stop.
     * @param attempt - the account, its session identity and the credentials in force.
     * @returns replacement credentials for this attempt, or nothing to keep them.
     */
    beforeAccountRequest?(attempt: ClaudeAccountAttempt): ClaudeSession | void | Promise<ClaudeSession | void>;
    /** Runs once when the attempt reaches its terminal shape, before the terminal signal. */
    onAttemptResult?(outcome: ClaudeAccountOutcome): void | Promise<void>;
    /** Runs once after the attempt's resources are released. */
    onAttemptEnd?(outcome: ClaudeAccountOutcome): void | Promise<void>;
}
/** Constructor dependencies for {@link ClaudeAdapter}. */
interface ClaudeAdapterOptions {
    /**
     * Trusted policy for one account and session, projected by the host.
     *
     * Synchronous on purpose: the request path reads it while assembling, so it must answer from
     * state the host already holds. It is the only policy seam — nothing in a request body, message
     * metadata or transport option can withhold a beta.
     * @param input - the canonical account the stream owns, and the session the request belongs to.
     * @returns the policy to apply to this request.
     */
    requestPolicy?: (input: {
        account: string;
        sessionId?: string;
    }) => ClaudeEnginePolicy;
    /** Identity line a Claude request carries in place of the harness identity section. */
    identityLine?: string;
    models: readonly ModelEntry[];
    streamIdleTimeoutMs: number;
    tokens: AccountTokenManager<ClaudeSession>;
    /** Late-bound pool facade (wired after adapter construction); pools list under their first member's provider. */
    pool?: () => PoolAdapter | undefined;
    /** Whether to fetch the live catalog when logged in (false when config `models` overrides). */
    discovery: boolean;
    fetchFn?: FetchFn;
    /** Stable hashed OS identity supplier; defaults to this host, never a request/model input. */
    deviceFingerprint?: () => string;
    onWarn?: (message: string) => void;
    /** How long this route may hold a turn open waiting for a rate-limit window; defaults to waiting on, six-hour ceiling. */
    rateLimit?: RateLimitWait;
    /** Resolve the attachment service per request; absent means image requests fail loudly. */
    resolveAttachments?: () => AttachmentStore | undefined;
    /** Durable per-account catalogue store seeding capability metadata across restarts. */
    catalogStore?: CatalogStoreFactory;
    /** How long a stored catalogue is trusted before an explicit refresh may replace it; defaults to 24 h. */
    catalogMaxAgeMs?: number;
    /** Failure cooldown for a catalogue request that sent no retry-after; defaults to 60 s. */
    cacheRetryDelayMs?: number;
    /** Called once after a refresh stored a catalogue different from the previous one. */
    onCatalogChanged?: (provider: string) => void;
    /**
     * Resolves the sink for the unified rate-limit state an account's own answered
     * response carried, once per stream and before the request is sent, so the sink
     * captures the auth epoch that request starts under. The pool observes pass
     * savings here instead of polling a usage endpoint; absent means nothing is
     * reported.
     */
    usageObserverFor?: (account: string) => (state: UnifiedRateLimitState) => void;
    /**
     * Per-model default reasoning effort override (the Settings page's picker).
     * Returns the user-configured default for one model, or undefined to follow
     * the provider's own default.
     */
    defaultEffortOf?: (model: string) => string | undefined;
    /**
     * Per-model speed lookup (the composer Speed toggle's host half). Returns
     * whether this model's stored configuration selects the fast tier; absent
     * means every request stays on standard routing. This adapter applies the
     * tier only where the pinned catalogue advertises `fast_mode`, so a stored
     * `fast` on a model without it keeps standard routing.
     */
    speedFor?: (model: string) => boolean | Promise<boolean>;
    /** Live-session maintenance seam; absent leaves the adapter's behavior unchanged. */
    maintenance?: ClaudeMaintenanceHooks;
    /**
     * Durable record of a refused compatibility profile; absent uses this plugin's own home
     * directory. Injectable so a test never touches the real one.
     */
    protocolBlocks?: ClaudeProtocolBlockStore;
    /** The compatibility profile this route runs; absent uses the pinned one. */
    protocolProfile?: ClaudeProtocolProfile;
    /**
     * Recording port for prepared Messages requests. Absent refuses every POST with
     * `REQUEST_RECORD_UNAVAILABLE`: a route that cannot publish the request it is about to issue
     * must not issue it. The plugin composition always supplies one.
     */
    requestRecord?: ClaudeRequestRecordPort;
    /**
     * The durable continuation owner: the wire identity, the ATIS pin and the identity generation
     * every request is prepared under. Absent refuses every request with
     * `LOCAL_CONTINUATION_STATE_UNAVAILABLE`: a route that cannot commit the wire identity a
     * conversation declares must not invent one, and the plugin composition always supplies this.
     */
    continuation?: ClaudeContinuationState;
    /**
     * The plugin's startup hydration, read inside each request's state budget after it settled. A
     * registration may run before that hydration finishes, and the first legitimate request must not
     * succeed merely by winning that race; the request also must not wait for it unboundedly.
     */
    continuationReady?: Promise<ClaudeContinuationReadiness>;
}
export declare class ClaudeAdapter extends PoolBackedAdapter {
    private readonly options;
    protected readonly catalogs: ProviderCatalog;
    /** The frozen compatibility profile this route builds every request from. */
    private readonly protocolProfile;
    /** Durable record of a refused compatibility profile. */
    private readonly protocolBlocks;
    constructor(options: ClaudeAdapterOptions);
    private fetchCatalog;
    /**
     * Drop this account's cached catalogue, memory and disk, after login/logout or
     * an identity change — and the account's uploaded Files API ids with them:
     * those ids belong to the token that uploaded them, which a login change replaces.
     *
     * The pins and spans are deliberately not dropped here: the identity transition owns them and
     * drops this account's spans inside the same change that commits the new credential, so clearing
     * them from a post-change notification would be a second owner racing the first.
     * @param account - the account whose cached state is dropped, or every account when omitted.
     */
    clearAccountCatalog(account?: string): void;
    /** The known entry for one model, from the account caches only (never a request). */
    private discovered;
    /**
     * The rows a read falls back to while no account catalogue is known.
     *
     * With discovery on, that fallback is the client's own baked-in catalogue —
     * the same table a refused options read already degrades to — so a cold menu
     * offers every pinned model, its 1M variants included, instead of only the
     * configured shortlist. An explicit configuration (discovery off) is the
     * operator's decision and is listed as given.
     */
    private staticModels;
    /** One discovered entry as a picker row, keeping the display text the account's options added. */
    private listed;
    providerInfo(provider: string): LlmProviderInfo;
    /**
     * Whether the pinned catalogue marks this model fast-capable.
     *
     * `fast_mode` is the capability the client's own fast-mode gate reads, so a model without it
     * never receives the tier however the session's toggle is set.
     * @param model - the requested model id.
     * @returns true when the model's catalogue entry carries `fast_mode`.
     */
    supportsFastTier(model: string): boolean;
    /**
     * Ids of every catalogued model carrying `fast_mode` (the Speed toggle's visibility list).
     *
     * The capability belongs to the pinned catalogue rather than to an account, so the list is the
     * same for every account and needs no discovery read. Logged out, no session can select one of
     * these models and the list is empty, which is how the control hides with the models.
     * @returns the fast-capable model ids.
     */
    fastCapableModels(): Promise<string[]>;
    providerRetryPolicy(provider: string): import("@deepseek-ai/dsh-llm").ResolvedRetryPolicy;
    /** Capability resolution of the provider's own models (the pool resolves members here). */
    resolveOwnModel(provider: string, model: string): Promise<LlmResolvedModelInfo>;
    /** The canonical account key that owns this session's conversation chain. */
    private chainAccount;
    /**
     * Refuse a request whose compatibility profile is already blocked.
     *
     * The check precedes request assembly: a profile the service refused must not send one
     * request per retry click, and the failure names the protocol rather than the account.
     * @param profile - the frozen profile this request would use.
     * @throws LlmError carrying the protocol block's hard stop.
     */
    private assertProfileUsable;
    /**
     * Run the maintenance seam's pre-request hook.
     *
     * A failure to check a precondition stops the request: the hook is where a policy block
     * is enforced, so swallowing its failure as a warning would let an unchecked request onto
     * the wire. The resulting failure always carries the hard stop.
     * @param attempt - the account, session identity and credentials.
     * @returns the credentials the hook wants used, or undefined to keep them.
     */
    private runBeforeAccountRequest;
    /**
     * Run one attempt-level maintenance hook, reporting a failure without replacing the
     * attempt's own terminal outcome.
     * @param hook - the hook to run.
     * @param outcome - the attempt's terminal shape.
     * @param label - the hook's name, for the diagnostic.
     */
    private runAttemptHook;
    protected streamOwn(options: GenerateOptions, account?: string): AsyncIterable<StreamChunk>;
    /**
     * Record a refusal that is evidence about the compatibility profile rather than the
     * account, so every later request on this host stops before the wire.
     *
     * The block is published in memory before the write is attempted, so a failed write still
     * stops this process; the returned promise settles once durability is known, so a caller can
     * wait for it before exposing an outcome a retry would race.
     * @param decision - the ordered decision the failed response produced.
     * @returns completion of the record, whether or not it reached disk.
     */
    private recordProtocolBlock;
    private thinkingParam;
    /**
     * Resolve the account UUID and bind its device id to this OS installation.
     * Missing UUIDs use the OAuth profile. Legacy or copied device ids are replaced
     * by the deterministic account/device value with a conditional store write;
     * credentials remain unchanged. An unavailable identity fails before Messages.
     *
     * The profile read is itself replayed after a rejection, and that replay rotates the
     * credential: the refreshed session is both the one the request continues from and the
     * one the backfill is derived from. The write names it as its expected prior, so a
     * concurrent refresh, re-login or logout wins the race instead of having its rotation
     * rolled back. That winner is re-read and served; a winner that cannot be shown to be
     * the account this profile was read for fails the request rather than receiving another
     * account's identity.
     *
     * A read-only account's served credential comes from Claude Code's own store, so it is not
     * what the record holds and cannot be the conditional write's prior. That account's backfill is
     * conditional on the record instead, while every mode passes the revision read before the
     * profile read whenever the backend reports one: an ownership change, a logout or a
     * same-token re-login leaves the credential fields identical, so only the revision refuses the
     * write. A backend that reports none keeps the legacy and independent compatibility path, which
     * the read-only mode refuses to take rather than downgrade the condition.
     *
     * An ownership mode that moves at any point — before the profile read, after it, or over the
     * write itself — stops this request with a fixed identity-changed refusal: no identity is bound
     * under the new mode and no POST is sent under the mode the request started from.
     */
    private identitySession;
    /**
     * When each session last issued a request, and whether its latest break was acted on.
     *
     * Silence cannot be observed from the request itself: the history carries no timestamps. It
     * does not need to be, because no request is issued during silence — the gap between a
     * session's consecutive requests is the gap between its consecutive transcript messages. A
     * decision is remembered so the same break keeps being acted on, which is what the client
     * does, and the table is bounded the way the client bounds its own.
     */
    private readonly requestClock;
    /**
     * Measures the silence before this request, remembering a break that was already acted on.
     *
     * @param sessionId - the session issuing the request.
     * @returns the silence in milliseconds, or the threshold when this break was already acted on.
     */
    private idleBeforeRequest;
    /**
     * Build and issue one Messages request.
     * @param options - the request being served.
     * @param account - the account the identity read addresses.
     * @param session - the credentials this request carries.
     * @param sessionId - the wire session identity.
     * @param chainAccount - the canonical account key owning the request chain.
     * @param watchdog - the attempt's idle watchdog; its signal bounds the send.
     * @param onSend - called once, immediately before the POST is issued.
     * @returns the provider's response.
     */
    /**
     * The earlier turn's request id the retained history states for this span.
     *
     * The selector is the only authority: it walks the final retained messages this request was built
     * from, gates each row on this prepared span and on the row's own envelope, and returns the id the
     * client would have chained. A row whose id is unusable ends the walk without backtracking, a row
     * from another account, generation or wire session is skipped, and the model a row was served for
     * does not filter the chain.
     * @param messages - the retained history the request was built from.
     * @param prepared - the identity facts this attempt was prepared under.
     * @returns the request id to chain, or undefined when the history states none.
     */
    private previousRequestId;
    private request;
}
export {};
