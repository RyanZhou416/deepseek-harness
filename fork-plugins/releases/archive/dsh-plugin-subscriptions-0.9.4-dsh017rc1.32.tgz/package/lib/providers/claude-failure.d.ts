/**
 * The one ordered failure classification for the Claude route.
 *
 * A rejection reaches this adapter as a failed HTTP status or as an `error` event inside a
 * 200, and the same refusal must produce the same decision either way. So both inputs are
 * classified here, in the order the reliability design fixes: a stated client-version
 * refusal first (it outranks every retry signal, including `retry-after` and
 * `x-should-retry: true`), then a refusal the provider stated is final, then credential
 * expiry, then a releasable quota window, then a request fault, then a recognized
 * transient failure, and last an unclassified error that is never reported as a
 * transient server failure.
 *
 * A decision is a value, not a side effect: callers that own an account, a profile block
 * or a response body act on it. Only the route that holds the response may decide whether
 * an event carried a stated-final refusal, so the in-band form takes the caller's probe.
 *
 * @module dsh-plugin-subscriptions/providers/claude-failure
 */
import { LlmError } from '@deepseek-ai/dsh-llm';
import type { LlmFailure } from '@deepseek-ai/dsh-llm';
import type { RateLimitResetReader } from './rate-limit.js';
import type { ClaudeFailureScope, ClaudeProtocolProfile, RetryDisposition } from './claude-protocol.js';
/**
 * Stable code for a response the service refuses because the claiming client version is
 * below its managed floor. Nothing about the account is wrong, so no recovery path may
 * treat it as a credential or quota failure.
 */
export declare const CLIENT_VERSION_UNSUPPORTED_CODE = "CLIENT_VERSION_UNSUPPORTED";
/**
 * Stable code for a failure this route cannot name. Deliberately not `SERVER`: reporting
 * an unmapped structured error as a transient server failure hands a refusal the provider
 * never described as retryable back to the retry loop.
 */
export declare const UNCLASSIFIED_PROVIDER_ERROR_CODE = "UNCLASSIFIED_PROVIDER_ERROR";
/**
 * Stable code for a permission refusal the provider stated without naming a billing,
 * organisation or seat reason. It is terminal for the operation and says nothing about
 * the stored credential, so it must not clear a token or trigger an authentication
 * refresh.
 */
export declare const PERMISSION_DENIED_CODE = "PERMISSION_DENIED";
/**
 * Stable code for a stream that ended before its business terminal state.
 *
 * The response was accepted, so the request has certainly been sent and its outcome is
 * unknown: replaying it could submit the same turn twice, and no delivery boundary changes
 * that. A transport failure that never produced a response is a different case and keeps its
 * own transient code.
 */
export declare const STREAM_INCOMPLETE_CODE = "STREAM_INCOMPLETE";
/** Which half of the exchange produced a failure. */
export type ClaudeFailureStage = 
/** A non-2xx HTTP status. */
'http'
/** An `error` event inside an HTTP 200. */
 | 'sse'
/** A stream that ended without its terminal state. */
 | 'stream'
/** A thrown transport failure. */
 | 'transport'
/** Local request assembly. */
 | 'request';
/**
 * The serializable record one Claude failure resolves to.
 *
 * Callers route on this instead of on message text: the reason is stable, the scope states
 * what the failure is evidence about, and `retryDisposition` is the hard-stop decision the
 * Host failure record carries.
 */
export interface ClaudeFailureDecision {
    /** Stable plugin reason code. */
    readonly reason: string;
    /** The provider's own code or type, when it sent one. */
    readonly serverCode?: string;
    /** HTTP status, when the failure arrived on a response. */
    readonly status?: number;
    /** Which half of the exchange produced this failure. */
    readonly stage: ClaudeFailureStage;
    /** What the failure is evidence about. */
    readonly scope: ClaudeFailureScope;
    /** Whether automatic recovery may still run. */
    readonly retryDisposition: RetryDisposition;
    /** Whether output for this logical request already reached the Host. */
    readonly outputDelivered: boolean;
    /** The provider-disclosed delay before retrying, when it disclosed one. */
    readonly retryAfterMs?: number;
    /** Normalized provider origin the request targeted. */
    readonly origin: string;
    /** Protocol fingerprint the request was built from. */
    readonly protocolFingerprint: string;
}
/** Cap on the error body this classifier parses; a larger body is classified unclassified. */
export declare const CLAUDE_ERROR_BODY_LIMIT: number;
/** One error body read under a byte cap. */
export interface ClaudeErrorBody {
    /** The decoded body, at most {@link CLAUDE_ERROR_BODY_LIMIT} bytes. */
    readonly text: string;
    /** Whether the response carried more than the cap, so the read stopped early. */
    readonly overflowed: boolean;
}
/**
 * Read an error body without letting one response decide how much memory it spends.
 *
 * The cap is applied to the bytes as they arrive and the reader is cancelled once it is
 * reached, so a body that never ends — or one crafted to exhaust memory — costs one bounded
 * read and one released connection. The cap is a byte count, not a UTF-16 code-unit count:
 * a body of multi-byte characters must not be able to exceed it.
 * @param response - the failed response.
 * @param limit - the maximum number of body bytes to decode.
 * @returns the decoded prefix and whether the body exceeded the cap.
 */
export declare function readClaudeErrorBody(response: Response, limit?: number): Promise<ClaudeErrorBody>;
/** Inputs one HTTP response's ordered Claude classification reads. */
export interface ClaudeHttpFailureInput {
    /** The failed response, for its status, headers and origin. */
    readonly response: Response;
    /** The bounded response body. */
    readonly body: string;
    /** Whether the body read stopped at the byte cap. */
    readonly oversized?: boolean;
    /** The instant the caller resolved for a retry, when one was disclosed. */
    readonly reset: number | undefined;
    /** Current epoch milliseconds. */
    readonly now: number;
    /** Whether the status was 429. */
    readonly rateLimited: boolean;
    /** The compatibility profile the request was built from. */
    readonly profile: ClaudeProtocolProfile;
    /** Whether output for this logical request already reached the Host. */
    readonly outputDelivered?: boolean;
}
/**
 * Classify one failed Claude HTTP response in the design's fixed order.
 *
 * The order is the contract: a stated client-version refusal outranks `retry-after` and
 * every other recoverable signal; a permission refusal is not a credential failure; and a
 * structured type this route does not map is unclassified rather than transient.
 * @param input - the failed response and the facts the order reads.
 * @returns the ordered decision for this response.
 */
export declare function classifyClaudeHttpFailure(input: ClaudeHttpFailureInput): ClaudeFailureDecision;
/** The wire error object one in-band `error` event carries. */
export interface ClaudeSseErrorObject {
    /** The event's own error type. */
    type?: string;
    /** The provider's message. */
    message?: string;
    /** The provider's own code, when it states one beside the type. */
    code?: string;
    /** Nested detail object; `details.error_code` is where the version refusal is named. */
    details?: unknown;
    /** A flat error code, on the shapes that do not nest one. */
    error_code?: string;
}
/** Inputs one in-band `error` event's ordered classification reads. */
export interface ClaudeSseFailureInput {
    /** The error object the event carried, read whole rather than projected to type and message. */
    readonly error: ClaudeSseErrorObject | undefined;
    /** The compatibility profile the request was built from. */
    readonly profile: ClaudeProtocolProfile;
    /** Whether output for this logical request already reached the Host. */
    readonly outputDelivered?: boolean;
    /**
     * The caller's probe for a refusal the response itself states. The event alone cannot
     * say whether the response was refused, so a probe that answers true makes the
     * refusal-bearing types terminal exactly as {@link isEnforcementRefusal} does for a
     * failed status.
     */
    readonly isRefusal?: ClaudeRefusalProbe;
}
/**
 * Reports whether an in-band error event is a refusal the response itself states.
 *
 * The status and headers that make a failure terminal belong to the response, and an
 * `error` event can arrive inside a 200, so only the caller holding that response can
 * answer; the event alone cannot.
 */
export type ClaudeRefusalProbe = (error: ClaudeSseErrorObject | undefined) => boolean;
/**
 * Classify an in-band `error` event with the same order the HTTP form uses.
 *
 * The event carries no status and no headers, so the caller's own classification of the
 * response behind it stands in; without one the event's own fields decide. The whole error
 * object is read under the same bounded envelope walk the HTTP body uses, because a
 * refusal can arrive as `details.error_code` rather than as the event's own type.
 * @param input - the event, the profile and the caller's refusal probe.
 * @returns the ordered decision for this event.
 */
export declare function classifyClaudeSseFailure(input: ClaudeSseFailureInput): ClaudeFailureDecision;
/**
 * The decision one error was built from.
 * @param error - the error to look up.
 * @returns the decision, or undefined for an error this module did not classify.
 */
export declare function claudeFailureDecisionOf(error: LlmError): ClaudeFailureDecision | undefined;
/**
 * Build the error one decision produces.
 * @param decision - the decision being reported.
 * @param message - the human-readable summary.
 * @param extras - response facts the decision does not carry.
 * @returns the error to throw.
 */
export declare function claudeFailureError(decision: ClaudeFailureDecision, message: string, extras?: {
    readonly cause?: unknown;
    readonly status?: number;
    readonly providerRetryAfterMs?: number;
}): LlmError;
/** What a route must supply to classify and report one failed Claude response. */
export interface ClaudeHttpFailureOptions {
    /** Diagnostic prefix naming the API. */
    readonly label: string;
    /** The compatibility profile the request was built from. */
    readonly profile: ClaudeProtocolProfile;
    /** The route's own reader for a disclosed quota window. */
    readonly rateLimitReset?: RateLimitResetReader;
    /** The route's own retry-header reader; absent preserves the shared `retry-after` reader. */
    readonly retryHeaderReset?: (response: Response, now: number) => number | undefined;
    /** Diagnostic sink for a 429 that disclosed no recognized reset. */
    readonly onWarn?: (message: string) => void;
    /** Whether output for this logical request already reached the Host. */
    readonly outputDelivered?: boolean;
    /** Receives the ordered decision, so the caller can act on a profile block. */
    readonly onDecision?: (decision: ClaudeFailureDecision) => void;
    /**
     * A body the caller already read under the byte cap.
     *
     * Used where the decision must be made before the response can be released — a 401 the
     * route inspects before deciding on its one refresh — so the body is consumed exactly once
     * and never re-read.
     */
    readonly body?: ClaudeErrorBody;
}
/**
 * Classify a failed Claude response and build the error to throw.
 *
 * The body is read under a fixed byte cap and cancelled once that cap is reached, so one
 * response cannot decide how much memory this process spends. It is used for classification
 * and then dropped: it is never a cause, never part of the message, and never repeated into a
 * warning, so a body that echoed a prompt, a token or an address cannot become durable session
 * text, a model-visible error or a diagnostic. The message is this route's own template plus
 * the status and, when the code names one, a provider code this route already recognizes.
 * @param response - the failed response.
 * @param options - the route's readers, profile and diagnostics sink.
 * @returns the classified error, already carrying the hard-stop decision when it applies.
 */
export declare function claudeHttpLlmError(response: Response, options: ClaudeHttpFailureOptions): Promise<LlmError>;
/**
 * The message one Claude failure reports.
 *
 * Built from this route's own template plus the facts the design allows a failure to carry —
 * the status, the stable reason and, when the code names one, the provider code this route
 * already recognizes. The response body and the provider's prose never reach it: content
 * parsed for classification is held in memory and dropped, so a body that echoed a prompt, a
 * token or an address cannot become durable session text or a model-visible error.
 * @param label - diagnostic prefix naming the API.
 * @param decision - the ordered decision this failure produced.
 * @returns the message to report.
 */
export declare function claudeFailureMessage(label: string, decision: ClaudeFailureDecision): string;
/**
 * Build the decision a stored protocol block produces.
 *
 * The block is checked before a request is built, so a refused profile produces this
 * decision without a network round trip and without an account being blamed.
 * @param profile - the compatibility profile the request would have used.
 * @param outputDelivered - whether output already reached the Host for this request.
 * @returns the decision for an already-refused profile.
 */
export declare function claudeProtocolBlockDecision(profile: ClaudeProtocolProfile, outputDelivered?: boolean): ClaudeFailureDecision;
/** Inputs {@link claudeStreamFailure} reads. */
export interface ClaudeStreamFailureInput {
    /** The compatibility profile the request was built from. */
    readonly profile: ClaudeProtocolProfile;
    /** Whether any chunk for this logical request already reached the Host. */
    readonly outputDelivered: boolean;
}
/**
 * Project a stream failure onto the hard-stop rule.
 *
 * The first chunk the Host receives commits this attempt: after that boundary no replay,
 * account switch or whole-step retry may run, because the delivered output would be
 * submitted twice. The same rule covers a thrown failure and an `error` finish, which is
 * why both pass through here.
 * @param error - the classified failure the stream produced.
 * @param input - the profile and the delivery boundary.
 * @returns the error to surface, carrying `retryDisposition: 'forbid'` once output was delivered.
 */
export declare function claudeStreamFailure(error: LlmError, input: ClaudeStreamFailureInput): LlmError;
/**
 * Add the hard-stop decision to a finish failure that follows delivered output.
 *
 * A finish chunk is a value, not a throw, so it cannot pass through
 * {@link claudeStreamFailure}; the same boundary decides it.
 * @param failure - the finish failure record.
 * @param outputDelivered - whether output already reached the Host for this request.
 * @returns the failure record to emit.
 */
export declare function claudeFinishFailure(failure: LlmFailure, outputDelivered: boolean): LlmFailure;
/**
 * The ordered decision behind a terminal error finish.
 *
 * A failed turn reported as a finish value is classified by the same table a thrown failure
 * uses, so an attempt that ended this way is reported to the maintenance seam as failed with
 * its decision attached, exactly like one that threw.
 * @param failure - the failure record the finish carried.
 * @param profile - the frozen compatibility profile the request was built from.
 * @param outputDelivered - whether output already reached the Host.
 * @returns the decision for that terminal value.
 */
export declare function claudeFinishDecision(failure: LlmFailure, profile: ClaudeProtocolProfile, outputDelivered: boolean): ClaudeFailureDecision;
/**
 * Whether one error already carries the hard stop.
 * @param error - the failure to read.
 * @returns true when the Host failure record forbids automatic resend.
 */
export declare function claudeForbidsRetry(error: LlmError): boolean;
/**
 * Carry the hard stop onto a failure whose only allowed recovery this request already spent.
 *
 * The controlled authentication replay happens once per logical request. A rejection that
 * arrives after it is not recoverable inside this request, and letting it keep an
 * authentication code with an ordinary disposition would hand the whole cycle — refresh, then
 * the Host's unconditional resend, then refresh again — back to the layers above.
 * @param error - the failure that exhausted its recovery.
 * @returns the same code and message with the stop attached.
 */
export declare function claudeRecoveryExhausted(error: LlmError): LlmError;
/**
 * Classify a Messages POST that failed after it was issued.
 *
 * The request body has already left this process, so the server may have accepted and acted
 * on it before anything failed: the outcome is unknown, and repeating the logical request
 * could submit the same turn twice. This is the conservative disposition the design requires
 * where the send cannot be shown to have been refused — it is not a claim that the service
 * received the request, and it is deliberately not an assertion that the attempt is safe to
 * repeat. A failure raised before the POST is issued — request assembly, image resolution,
 * wire construction — keeps its own specific rule instead.
 *
 * The failure's own code and safe facts are kept; only the disposition changes.
 * @param error - what the issued send threw.
 * @returns the error to surface, always carrying the hard stop.
 */
export declare function claudeAmbiguousSend(error: unknown): LlmError;
/** Stable code for a local precondition that refused a request before it was sent. */
export declare const MAINTENANCE_REFUSED_CODE = "MAINTENANCE_REFUSED";
/**
 * Turn a local precondition's refusal into the error to throw.
 *
 * A precondition that could not be checked is not a warning: it is enforced before the
 * wire, so its failure stops the request and carries the hard stop rather than letting an
 * unchecked request through. An error the precondition already classified keeps its code
 * and message, and only gains the stop.
 * @param error - what the precondition threw.
 * @param message - the local summary used when the throw carried no classification.
 * @returns the error to throw.
 */
export declare function claudeBlockedRequest(error: unknown, message: string): LlmError;
