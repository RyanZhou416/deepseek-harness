/**
 * Device identity for the Claude provider.
 *
 * The wire device id is derived from the caller's stable account key and this machine's own
 * operating-system identifier, so the same account on the same machine rebuilds one id after
 * the harness cache, the credential record, or `DSH_HOME` is lost. That identifier is the
 * operating system's installation identity, not immutable hardware: reinstalling or cloning
 * can change or duplicate it, and a clone presents the same identifier as its source. Nothing
 * here detects that, and no network address, hostname, OS version, or memory size is read.
 *
 * The raw identifier never leaves this module: the exported identity reads return a hash or
 * throw, and no message carries the registry value, the file's contents, or the platform UUID.
 */
import { LlmError } from '@deepseek-ai/dsh-llm';
/**
 * The failure code a caller may key on when no machine identifier can be read. Deliberately
 * not `AUTH`: the credential is sound, no account is at fault, and no route may retry it.
 */
export declare const DEVICE_IDENTITY_UNAVAILABLE = "CLAUDE_DEVICE_IDENTITY_UNAVAILABLE";
/**
 * No usable machine identifier on this host. An {@link LlmError}, so a classifier that
 * re-wraps a thrown fetch failure returns it unchanged instead of reclassifying it as a
 * retryable transport failure.
 */
export declare class DeviceIdentityError extends LlmError {
    /** @param message - what could not be read; never the value or the environment. */
    constructor(message: string);
}
/**
 * The host reads one fingerprint is resolved from. Every access is a seam, so the resolution
 * can be exercised for Windows, Linux and macOS output on one machine and a test never reads
 * this host's real identifier.
 */
export interface DeviceFingerprintSeams {
    /** The host platform, as `process.platform`. */
    readonly platform: NodeJS.Platform;
    /** The environment, read for the Windows directory only. */
    readonly env: Readonly<Record<string, string | undefined>>;
    /** Read one small system file as UTF-8; throws when it cannot be read. */
    readonly readFile: (path: string) => string;
    /** Run one bounded system command and return its stdout; throws on failure or timeout. */
    readonly execFile: (file: string, args: readonly string[]) => string;
}
/**
 * The device id one account presents on one machine.
 *
 * Pure: the same account key and fingerprint always return the same id, in any process, with
 * no cache, store, or credential involved.
 *
 * @param accountKey - the stable account key the caller chose; a caller that has none must
 *   defer the derivation, because this module substitutes no fallback.
 * @param fingerprint - the machine fingerprint from {@link resolveDeviceFingerprint}.
 * @returns a 64-character lowercase hex id, the format the client uses.
 * @throws DeviceIdentityError when either input is empty.
 */
export declare function deriveAccountDeviceId(accountKey: string, fingerprint: string): string;
/**
 * The fingerprint of this host's machine identifier.
 *
 * The hash carries the platform and the normalized identifier, never the source that supplied
 * it: on Linux the same id normally stands in both files, so a fingerprint that changed when
 * the first became readable would move the device id for no change in the machine.
 *
 * @param seams - the host reads to resolve through.
 * @returns a 64-character lowercase hex fingerprint.
 * @throws DeviceIdentityError when no source here yields a usable identifier.
 */
export declare function resolveDeviceFingerprint(seams: DeviceFingerprintSeams): string;
/**
 * A reader that resolves the fingerprint once and returns it for every later call. Only a
 * successful read is remembered, so a host that becomes readable later recovers and a failure
 * never becomes a permanent verdict.
 *
 * @param seams - the host reads to resolve through.
 * @returns the memoized reader.
 */
export declare function createDeviceFingerprintReader(seams: DeviceFingerprintSeams): () => string;
/**
 * This process's machine fingerprint, read once. The first call performs the platform's own
 * read, and later calls return the remembered fingerprint; only the hash is held, in this
 * process's memory, and it is never written to the store or to a log.
 *
 * @returns a 64-character lowercase hex fingerprint.
 * @throws DeviceIdentityError when this host's identifier cannot be read.
 */
export declare function readLocalDeviceFingerprint(): string;
