/**
 * The account identity generation: durable proof that a request belongs to the identity it was
 * prepared for.
 *
 * A generation advances only when the authenticated account itself changes — a login, a logout,
 * an account removal, or a change of credential ownership. A token rotation does not advance it:
 * the account is the same account, and starting a new identity for every refresh would drop a
 * live conversation's continuation and ATIS state for no reason.
 *
 * One file keeps one record per derived account reference, so a change on one account cannot
 * invalidate another account's live span. Every read and every read-modify-write runs inside the
 * plugin's own lock, and the decisions that must not be made from a stale read are made inside
 * that critical section: a baseline is created only when the account has no record, and the one
 * generation a change may publish is fixed together with its own statement, in the same lock that
 * states the change, rather than re-derived from whatever the record holds later.
 *
 * **The producer owns one whole identity change, not one counter write.** The plugin's auth
 * lifecycle notifies only after it has already committed a credential, so a gate that closed at
 * notification time would close after the new credential is visible. The lifecycle therefore
 * hands this producer the complete work of one change — the credential commit, the account's
 * release and the span cleanup — and the gate is closed synchronously, before that work's first
 * await, and reopened only once every part of it has settled.
 *
 * **An unfinished change is durable, not remembered.** Before the operation runs, the record on
 * disk states that this account has a change in flight, and the whole transition — that statement,
 * the operation's real work and the generation's publication — runs under one cooperative lock on
 * this record's document, so another process cannot begin its own change while one is in flight and
 * cannot run its credential work beside it. A request that reads an unfinished statement refuses to
 * be served, and so does a fresh process: a process that died between the credential commit and the
 * publication cannot come back and serve requests under the epoch that preceded them.
 *
 * A statement that is still `active` is never taken over and never replaced by a later change: a
 * stale lock is not evidence that the instance running the change has stopped, so it stays closed
 * until that change is resolved. A change whose publication settled without confirming waits for its
 * own file operation to really settle, reads the record back once, and then either reports the
 * generation that landed or states the failure durably — only such a recorded failure, and a
 * statement of a finished change, is replaced by a later lifecycle action publishing the next
 * generation.
 *
 * **Disposal waits for the whole transition.** Closing the record stops new changes, waits for the
 * transition this instance owns — the operation's work and the publication — to really settle, and
 * only then drains its own file operations. A caller's elapsed wait never shortens that: the wait
 * is the caller's, and the settlement is the account's.
 *
 * **Requests read the durable record; they never establish one.** Establishing a baseline is a
 * separate lifecycle action that does not advance the account: a normal restart finds the
 * baseline already recorded and leaves it alone, and only a real identity change moves the
 * number. A request that finds no baseline is refused, because serving it would invent the
 * identity it is supposed to be gated by.
 *
 * @module dsh-plugin-subscriptions/providers/claude-identity-generation
 */
import type { ClaudeAccountRef } from '../claude-core/account-ref.js';
import type { ContinuationDeadline, ContinuationFiles, ContinuationUnavailable, ContinuationWaitHost } from './claude-continuation-io.js';
/** The document version this build writes and reads. */
export declare const CLAUDE_IDENTITY_GENERATION_VERSION = 1;
/** The identity changes that advance a generation; a rotation is not one of them. */
export type ClaudeIdentityChange = 'login' | 'logout' | 'removal' | 'ownership';
/** What reading the current generation produced. */
export type ClaudeGenerationState = 
/** The generation this account is on; the gate is open. */
{
    readonly kind: 'ready';
    readonly generation: number;
}
/** No baseline exists yet; the lifecycle must establish it. */
 | {
    readonly kind: 'uninitialized';
}
/** No request for this account may be served. */
 | ContinuationUnavailable;
/** What establishing the baseline or running one change produced. */
export type ClaudeGenerationAdvance = 
/** The generation is durable. */
{
    readonly kind: 'advanced';
    readonly generation: number;
}
/** The work did not settle or did not commit; the gate stays closed until one succeeds. */
 | {
    readonly kind: 'failed';
    readonly reason: string;
};
/** What waiting for a transition produced. */
export type ClaudeGenerationWait = 
/** No transition is in flight; the generation is usable. */
{
    readonly kind: 'settled';
    readonly generation: number;
}
/** A transition is in flight and did not settle within the caller's bound. */
 | {
    readonly kind: 'timed-out';
}
/** The caller aborted the wait; no request may be built. */
 | {
    readonly kind: 'aborted';
}
/** A transition failed, or the record cannot be read; this account is refused. */
 | {
    readonly kind: 'failed';
    readonly reason: string;
};
/**
 * The producer's own authority over one identity change.
 *
 * A transition opens with this capability and closes with it. Nothing else can open the gate:
 * the capability is created by the producer, handed only to the operation the producer is
 * running, and settling it is the only path to a reopened gate. It carries no power to declare a
 * request finished and none to publish a generation directly.
 */
export interface ClaudeIdentityCompletion {
    /**
     * The account this change belongs to.
     * @returns the derived reference the change is keyed by.
     */
    accountRef(): ClaudeAccountRef;
    /**
     * Whether the gate is still closed for this change.
     * @returns true while no request may be prepared for this account.
     */
    isGateClosed(): boolean;
}
/** The work of one identity change, run inside the producer's gate. */
export type ClaudeIdentityOperation = (completion: ClaudeIdentityCompletion) => Promise<void>;
/** Constructor options for {@link ClaudeIdentityGeneration}. */
export interface ClaudeIdentityGenerationOptions {
    /** The account this counter belongs to. */
    readonly accountRef: ClaudeAccountRef;
    /** File holding the record; absent uses the plugin's own home directory. */
    readonly path?: string;
    /** How long one operation may wait before its caller is refused. */
    readonly deadlineMs: number;
    /** How long one operation may wait for the owned lock. */
    readonly lockTimeoutMs: number;
    /** Sink for a diagnostic about the record itself; never used for a credential. */
    readonly onWarn?: (message: string) => void;
    /** The private file operations; a test injects one to hold a write. */
    readonly files?: ContinuationFiles;
    /** The timers and abort listeners one bounded wait uses; a test injects one to observe it. */
    readonly waits?: ContinuationWaitHost;
}
/**
 * The durable identity generation of one derived account.
 *
 * Every read and every read-modify-write runs inside the plugin's own lock, so a request sees the
 * same durable row another process wrote and two processes cannot each read the document and then
 * drop the other's account. The record is written atomically at owner-only mode.
 */
export declare class ClaudeIdentityGeneration {
    private readonly options;
    private readonly path;
    private readonly accountRef;
    private readonly io;
    private damaged;
    private pending;
    private running;
    private closing;
    private warned;
    /**
     * @param options - the account this counter belongs to, path, both budgets and the I/O boundary.
     */
    constructor(options: ClaudeIdentityGenerationOptions);
    /**
     * The generation this account's requests carry, read from the durable record.
     *
     * The record is re-read because another process's legitimate change is exactly the case a
     * cached number would get wrong. A missing baseline is `uninitialized` rather than an implicit
     * write, and a record that states an unfinished change refuses, because the epoch it names is
     * the one that change was meant to replace.
     * @param deadline - the bound and cancellation the caller resolved; absent uses the configured
     *   deadline and no signal.
     * @returns the current generation, or why no request may be served.
     */
    current(deadline?: ContinuationDeadline): Promise<ClaudeGenerationState>;
    /**
     * Establish this account's baseline, which the lifecycle calls before any request.
     *
     * The record is created only when the account has none, inside the lock that decides it, so a
     * normal restart establishes nothing, a later initialization cannot overwrite an advanced row
     * with zero, and two initializations that race leave one baseline. Only the lifecycle calls it.
     * @param deadline - the bound and cancellation the caller resolved; absent uses the configured
     *   deadline and no signal.
     * @returns the generation in force, or why it could not be established.
     */
    initialize(deadline?: ContinuationDeadline): Promise<ClaudeGenerationAdvance>;
    /**
     * Run one whole identity change inside the producer's gate.
     *
     * The gate closes synchronously, before this call yields, so no request can be prepared while the
     * change's own commit is in progress, and the whole transition then runs under a cooperative lock
     * on this account that another process's change also has to take. The change's statement is made
     * durable before the operation runs, and the operation is awaited to real settlement; the
     * returned `result` resolves only after the operation and the generation publication have both
     * settled. A second change for the same account while one is in flight is refused, and a change
     * that this record states as still active is refused rather than taken over.
     * @param change - the identity change this operation performs.
     * @param operation - the complete work of the change.
     * @returns the transition handle; its `result` is the one completion signal.
     */
    changed(change: ClaudeIdentityChange, operation: ClaudeIdentityOperation): ClaudeIdentityTransition;
    /**
     * Whether a transition is in flight, so a request must wait before it is served.
     * @returns true while a transition has not settled.
     */
    hasPendingTransition(): boolean;
    /**
     * Wait for the transition this process is running, bounded by the caller's own budget.
     *
     * The wait never starts a transition: a request waits for the auth lifecycle's work, which is the
     * only owner allowed to begin one. A pre-aborted caller is answered before anything else, and a
     * failure is a fixed state a later call reads rather than a wait. The durable read that follows a
     * settled transition is part of the same budget and keeps the same cancellation, so a wait cannot
     * hand the caller a state it read after the caller's bound had ended.
     * @param deadline - the absolute budget and the caller's cancellation.
     * @returns the settled generation, or the fixed reason this account is not served.
     */
    waitSettled(deadline: ContinuationDeadline): Promise<ClaudeGenerationWait>;
    /**
     * Stop accepting new changes and wait for the whole transition this instance owns to settle.
     *
     * The order matters: new changes are refused first, so no operation starts after this call; the
     * running transition — its operation and its publication — is awaited to real settlement; only
     * then are this record's own file operations drained. Disposal reports settlement, not success,
     * and a caller's elapsed wait never shortens it. It must not be awaited from inside the
     * operation, and it awaits no work of its own.
     */
    close(): Promise<void>;
    /** Read the durable state this account is served under. */
    private readState;
    /** Read this account's record once under the plugin's own lock, writing nothing. */
    private readRecord;
    /** Read the durable state a settled wait reports. */
    private settledState;
    /**
     * Run one transition: the durable statement, the operation, then the publication.
     *
     * The whole transition runs under a cooperative lock taken on a resource beside the record, so
     * the record's own read-modify-write locks never nest. That lock belongs to the whole document
     * rather than to one account, which serialises the accounts in one file conservatively: the
     * document's read-modify-write locks are per file anyway, and a per-account resource would add a
     * second naming rule for no correctness this round needs. The lock is what keeps a second instance
     * from running its credential work beside this one, and the durable statement is what keeps it
     * from taking over a change that may still be running: a lock whose lease expired says nothing
     * about the instance that held it.
     */
    private advance;
    /**
     * The lock resource every identity transition of this document takes.
     *
     * It is one resource for the whole document, beside the record so the record's own read-modify-
     * write locks never nest; accounts sharing one file therefore serialise conservatively rather
     * than concurrently.
     */
    private transitionResource;
    /** The capability one transition hands its operation; it can only observe the gate. */
    private completion;
    /**
     * State one change as begun, durably, before the operation it covers runs.
     *
     * A record that names an account with no baseline cannot begin a change: a generation this call
     * invented would not be the one the account is served under. A change this record still states as
     * active is never taken over, because the instance that began it may be running its credential
     * work right now and neither a stale lock nor a fresh process is evidence that it stopped. Only a
     * statement of a settled failure is replaced, and only by this lifecycle action.
     */
    private beginChange;
    /**
     * Publish the generation one change produced, clearing the statement in the same lock.
     *
     * An attempt that does not confirm is not a verdict: the write it started may still be on its way,
     * so the outcome is settled from the durable record rather than from the attempt's own report, and
     * against the generation this change's own statement was made for.
     * @param id - the statement this change wrote.
     * @param change - the identity change being published.
     * @param expected - the one generation this change may publish: its base plus one.
     */
    private publishChange;
    /**
     * Attempt the publication once, reporting what it confirmed.
     *
     * The generation written is the one this change's own statement was made for, fixed before the
     * operation ran, so two changes can never publish the same number and a later attempt cannot be
     * re-derived from whatever the record happens to hold when a wait ends. A record that does not
     * state this change's own active statement at the generation it was made for is not this change's
     * to publish, and a damaged record is refused rather than reconciled against.
     * @param id - the statement this change wrote.
     * @param change - the identity change being published.
     * @param expected - the one generation this change may publish: its base plus one.
     * @returns what the attempt itself confirmed.
     */
    private attemptPublication;
    /**
     * Settle one publication attempt that did not confirm, and read the record back once.
     *
     * The first step waits for this producer's own file operation to really settle: a logical bound or
     * an abort ended the caller's wait, not the write, and a late write must be observed rather than
     * assumed away. Then one read-only pass decides, against the one generation this change's own
     * statement was made for rather than against anything the ended wait happened to observe: that
     * generation standing with this change's reason means the change published and is reported as
     * such, without running the operation again or incrementing twice, while this change's own
     * statement still standing is stated as a failure so that a later explicit lifecycle action can
     * begin. A record that still cannot be read, or a failure that still cannot be stated, keeps the
     * account refused instead of ready, and never takes over a statement this change does not own.
     * @param id - the statement this change wrote.
     * @param change - the identity change being published.
     * @param expected - the one generation this change may publish: its base plus one.
     * @param reason - the attempt's own reason, reported when the record cannot be settled.
     * @returns the settled outcome this change may report.
     */
    private settlePublication;
    /**
     * State durably that one change settled without publishing.
     *
     * Only this transition's own active statement is turned into a failed one. When the state cannot
     * be confirmed — the write refused, or the record no longer states this change — the active
     * statement stands, and the account keeps refusing rather than being reported as ready.
     */
    private recordFailure;
    private begin;
    /** Report a refusal that may pass, and remember a document this build cannot trust. */
    private unavailable;
    /** Remember a document this build cannot trust, and report it once. */
    private distrust;
    private warnOnce;
}
/**
 * One identity transition, as the auth lifecycle starts it and a request observes it.
 *
 * `result` is the single completion signal: it resolves after the operation and the generation
 * publication have both settled, so no caller has to await a second promise to learn whether the
 * account may be served again.
 */
export interface ClaudeIdentityTransition {
    /** Whether the gate closed for this transition (false when another one already owns it). */
    readonly closed: boolean;
    /** The transition's outcome, resolved once all of its work has settled. */
    readonly result: Promise<ClaudeGenerationAdvance>;
}
/**
 * The auth lifecycle's typed producer for one account's identity generation.
 *
 * The producer is the only owner that establishes a baseline or runs an identity change, and it
 * runs a change only for the four that replace the authenticated account. Its synchronous return
 * closes the request gate, and the operation it runs carries the change's real work — the
 * credential commit, the account's release and the span cleanup — so the gate is never reopened
 * around a half-applied change. A credential rotation is explicitly not a change.
 */
export interface ClaudeIdentityLifecycleProducer {
    /**
     * Establish this account's baseline, before any request is served.
     * @returns the generation in force, or why it could not be established.
     */
    initialize(): Promise<ClaudeGenerationAdvance>;
    /**
     * Run one whole identity change inside the producer's gate.
     * @param change - the account identity change that happened.
     * @param operation - the complete work of that change.
     * @returns the transition whose `result` is the one completion signal.
     */
    changed(change: ClaudeIdentityChange, operation: ClaudeIdentityOperation): ClaudeIdentityTransition;
    /**
     * Report that a credential rotation kept the same account.
     * @returns the generation in force, unchanged.
     */
    rotated(): Promise<ClaudeGenerationState>;
}
/**
 * Build the producer over one account's generation record.
 * @param generation - the record to establish and advance.
 * @returns the producer the auth lifecycle calls.
 */
export declare function claudeIdentityLifecycle(generation: ClaudeIdentityGeneration): ClaudeIdentityLifecycleProducer;
