/**
 * Durable per-account usage observations: the windows the pool last saw, when
 * each was seen, and the cooldown of a failed read.
 *
 * The file is a cache, not a source of truth: a restart loads it and serves it
 * as stale, and nothing here ever performs a network read. Writes are coalesced,
 * serialized, and land through a temporary file plus rename, so a reader never
 * observes a partial record.
 *
 * A write is a read-modify-write of the file's current contents under the shared
 * store lock: several harness instances share one cache path, and one instance
 * saving its own account must not erase records another instance owns. Only the
 * keys this store changed are applied, so an untouched account's record is never
 * rewritten from a stale in-memory copy.
 *
 * No credential, token, request id or provider message is stored — only the
 * normalized window readings and a safe failure classification.
 */
import type { ProviderId } from '../auth/store.js';
import type { UsageFailureReason } from './common.js';
/** One window's durable reading, with the instant it was observed. */
export interface PersistedUsageWindow {
    /** Window kind: `session` for the short rolling window, `weekly` for the 7-day one. */
    kind: 'session' | 'weekly' | 'other';
    /** Model scope for model-specific windows (e.g. `Opus`), when the provider named one. */
    scope?: string;
    /** Percent of the window consumed (0–100) as of {@link observedAt}. */
    usedPercent: number;
    /** Epoch milliseconds at which the window resets, when the provider disclosed it. */
    resetsAt?: number;
    /** Epoch milliseconds this reading was observed. */
    observedAt: number;
}
/** A failed read whose retry is suppressed until {@link retryAt}. */
export interface PersistedUsageFailure {
    /** Epoch milliseconds the read failed. */
    at: number;
    /** Epoch milliseconds the failure stops suppressing upstream reads. */
    retryAt: number;
    /** Safe classification; never a provider message or token. */
    reason: UsageFailureReason;
}
/** One account's durable usage state. */
export interface PersistedUsageAccount {
    /** The account's provider route. */
    provider: ProviderId;
    /** The canonical account key the readings belong to. */
    account: string;
    /** Epoch milliseconds of the newest observation of any window, when one exists. */
    observedAt?: number;
    /**
     * Epoch milliseconds the usage endpoint last answered this account, whether or
     * not it reported a window. It throttles the next read of an unknown reading.
     */
    checkedAt?: number;
    /** Plan name the usage endpoint last reported, when it reported one. */
    plan?: string;
    /** Per-window readings, each carrying its own observation time. */
    windows: PersistedUsageWindow[];
    /** The read failure still cooling down, when the last read failed. */
    failure?: PersistedUsageFailure;
}
/**
 * Persistence seam for usage observations. Implementations are optional: a
 * tracker without one keeps the same state in memory for the plugin's lifetime.
 */
export interface UsageStore {
    /** Every record the store was loaded with, read once when it was created. */
    records(): readonly PersistedUsageAccount[];
    /** Replace one account's record, scheduling a coalesced serial write. */
    save(record: PersistedUsageAccount): void;
    /** Drop one account's record, scheduling a coalesced serial write. */
    remove(provider: ProviderId, account: string): void;
    /** Resolve once every scheduled write has been attempted. */
    flush(): Promise<void>;
    /** Flush, then refuse further writes. */
    dispose(): Promise<void>;
}
/** What one decoded store file yielded, including what could not be read. */
export interface UsageFileRead {
    /** The records this build can use. */
    records: PersistedUsageAccount[];
    /** Entries the file listed that this build could not read. */
    dropped: number;
    /** True when the file declared a format version this build does not read. */
    unsupportedVersion: boolean;
}
/**
 * One account's record from an untrusted durable value. A record missing a
 * required reading is dropped whole rather than partially trusted: a window
 * with an invented percentage would steer routing with data no provider sent.
 * @param value - the parsed value to normalize.
 * @returns the record, or undefined when the value is not a complete record.
 */
export declare function normalizeUsageAccount(value: unknown): PersistedUsageAccount | undefined;
/**
 * Every intact record in one decoded store file. Entries this version cannot
 * read are dropped, and only a value that is not an object at all — or that
 * declares another format version — discards the file.
 * @param value - the parsed file contents.
 * @returns the retained records plus what could not be read.
 */
export declare function readUsageRecords(value: unknown): UsageFileRead;
/**
 * Create the plugin's durable usage cache.
 * @param options - the cache file path and its warning sink.
 * @param options.file - absolute path of the usage cache file.
 * @param options.onWarn - receives a safe diagnostic when the file cannot be read or written.
 * @returns the store, loaded from disk when that file holds usable records.
 */
export declare function createFileUsageStore(options: {
    file: string;
    onWarn?: (message: string) => void;
}): UsageStore;
