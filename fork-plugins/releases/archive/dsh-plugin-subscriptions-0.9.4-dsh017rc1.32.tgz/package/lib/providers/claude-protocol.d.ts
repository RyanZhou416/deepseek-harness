/**
 * The one Claude compatibility profile this route runs.
 *
 * The pinned wire contract stays owned by `@tormentalabs/claude-code-wire-compat`; this
 * module composes it with the desktop release the pin is anchored to and states, in one
 * place, the facts every Claude request kind must agree on: the version claims, the
 * endpoint each role calls, the headers that role may carry, and the rejections the
 * service is known to send. Nothing here performs I/O or invents a request the pinned
 * client does not make.
 *
 * Account- and request-scoped state (ATIS pins, request-id chaining, credentials,
 * quota observations) deliberately stays out: those are per identity and per request,
 * not properties of the compatibility profile.
 *
 * @module dsh-plugin-subscriptions/providers/claude-protocol
 */
/**
 * What a provider rejection is evidence about.
 *
 * The scope is what later scheduling may act on, so it is deliberately narrower than
 * “the account is broken”: a protocol rejection is evidence about the compatibility
 * profile, a permission rejection about one request or one organisation, and only a
 * credential rejection about the stored login.
 */
export type ClaudeFailureScope = 
/** This logical operation only. */
'operation'
/** One account's credentials or standing. */
 | 'account'
/** The provider origin plus compatibility-profile fingerprint, across accounts. */
 | 'provider-profile'
/** One model or model family. */
 | 'model'
/** The evidence names no usable scope. */
 | 'unknown';
/**
 * Whether automatic recovery may still run for a decided failure.
 *
 * `forbid` is the hard stop: no refresh, no account switch, no parameter adjustment and
 * no whole-step replay. It is reported to the Host through the failure's
 * `retryDisposition`.
 */
export type RetryDisposition = 'forbid' | 'allow';
/**
 * One request kind whose endpoint, headers and rules differ from every other.
 *
 * The OAuth token exchange is deliberately absent: its host is chosen once at module load
 * by `CLAUDE_CODE_CUSTOM_OAUTH_URL` and receiving this account's tokens, so its endpoint
 * stays owned by the login flow rather than repeated here.
 */
export type ClaudeRequestRole = 'messages' | 'countTokens' | 'profile' | 'usage' | 'bootstrap' | 'files' | 'settings';
/** Absolute endpoint per request role. */
export type ClaudeEndpoints = Readonly<Record<ClaudeRequestRole, string>>;
/** How one request role authenticates and what client identity it presents. */
export interface ClaudeHeaderRole {
    /** How the access token travels; `none` for the OAuth token exchange. */
    readonly authorization: 'bearer' | 'none';
    /**
     * Which pinned user agent the role sends: the transport one carrying the entrypoint
     * clause, or the plain `claude-code/<version>` one.
     */
    readonly userAgent: 'transport' | 'plain';
    /** `anthropic-beta` value the role sends, absent when it sends none. */
    readonly anthropicBeta?: string;
    /** Fixed headers the role adds beyond the user agent and authorization. */
    readonly headers: Readonly<Record<string, string>>;
}
/** The pinned compatibility profile every Claude request on this route is built from. */
export interface ClaudeProtocolProfile {
    /** Wire-profile id, as the pinned package names it. */
    readonly id: string;
    /** Digest over every identity-bearing field; the protocol-block key's revision half. */
    readonly fingerprint: string;
    /** Claude Code version this route claims on the wire. */
    readonly cliVersion: string;
    /** SDK version the pinned profile pairs with {@link cliVersion}. */
    readonly sdkVersion: string;
    /** Desktop application release the pin is anchored to; a separate claim from the CLI version. */
    readonly desktopAppVersion: string;
    /** Normalized origin every endpoint below shares. */
    readonly origin: string;
    /** `CLAUDE_CODE_ENTRYPOINT` value the requests declare. */
    readonly entrypoint: string;
    /** User agent sent on the transport role. */
    readonly userAgent: string;
    /** User agent sent on roles that use the plain form. */
    readonly plainUserAgent: string;
    /** `anthropic-version` header value. */
    readonly anthropicVersion: string;
    /** The provider the pinned billing header names. */
    readonly provider: string;
    /** Endpoint per request role. */
    readonly endpoints: ClaudeEndpoints;
    /** Header policy per request role; roles never borrow another role's set. */
    readonly headerRoles: Readonly<Record<ClaudeRequestRole, ClaudeHeaderRole>>;
}
export { CLAUDE_VERSION_REJECTION_MARKERS, matchesClaudeVersionRejection, anthropicErrorEventRule, } from '../claude-engine/failure-rules.js';
export type { ClaudeErrorEventRule } from '../claude-engine/failure-rules.js';
/**
 * Compute the profile fingerprint a protocol block is keyed by.
 *
 * Derived from the compiled pin, never from configuration or a declaration: a fingerprint
 * therefore changes only when a trusted profile replacement changes the identity the
 * route presents, which is exactly the condition under which an older block stops
 * matching.
 * @param profile - the compatibility profile to digest.
 * @returns a 64-character lowercase hex digest.
 */
export declare function claudeProtocolFingerprint(profile: ClaudeProtocolProfile): string;
/**
 * Build the profile snapshot one logical request freezes.
 *
 * Every request freezes the snapshot at the point its account is chosen, so a
 * configuration change reaches later operations only and an in-flight retry keeps the
 * profile it was decided under.
 * @param endpoints - endpoint overrides; absent uses the pinned endpoints.
 * @returns the frozen compatibility profile.
 */
export declare function resolveClaudeProtocolProfile(endpoints?: Partial<ClaudeEndpoints>): ClaudeProtocolProfile;
/**
 * The profile this route runs.
 *
 * Verified at module load: a pin whose version-bearing fields disagree with each other
 * misrepresents the client in ways the service can see, so the combination fails loudly at
 * startup instead of quietly on the wire.
 */
export declare const CLAUDE_PROTOCOL_PROFILE: ClaudeProtocolProfile;
/**
 * The headers one request role sends, without the authorization value.
 *
 * The caller supplies the token, so this function never handles one. The Messages role's
 * full header plan is composed by the pinned builder; this returns its fixed extras only.
 * @param role - the request role being sent.
 * @returns fixed header name/value pairs for that role.
 */
export declare function claudeRoleHeaders(role: ClaudeRequestRole): Record<string, string>;
