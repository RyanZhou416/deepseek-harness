/**
 * The plugin's `policy_limits` owner: one independent document per Claude account, read on a
 * live binding's own schedule, plus the DSH operation mapping its verdicts are enforced on.
 *
 * Everything protocol-shaped lives in `src/claude-core/` (parse, validator, retry budget,
 * verdict order); this module owns only what is plugin-side: which accounts are eligible,
 * which reads are in flight, what was adopted, when the next read may run, what the status
 * card shows, and which DSH operation a key's verdict reaches.
 *
 * The document is independent of the managed-settings policy: its own cache file, its own
 * validator, its own single-flight. A failure keeps the last adopted document (stale) rather
 * than dropping a known restriction. A stored record is restored as an unverified snapshot
 * that may only narrow the gate, and a store that cannot be trusted refuses the operations it
 * might otherwise have restricted.
 */
import type { PolicyAnswer, PolicyVerdictInputs } from '../claude-core/no-live-policy.js';
import type { ControlRequirements } from '../claude-core/control-requirements.js';
import type { PolicyLimitsEligibility } from '../claude-core/eligibility.js';
import type { CoreFailure } from '../claude-core/failures.js';
import type { OrgPinParse } from '../claude-core/org-pin.js';
import type { PolicyLimitsReadOperation } from '../claude-core/policy-limits-client.js';
import type { CoreClock, CoreHttpRequest, CoreHttpResponse, CoreSleep, CoreTransport } from '../claude-core/policy-limits-client.js';
import type { ClaudePolicyLimitsStateError, ClaudePolicyLimitsStateStore } from './claude-policy-limits-state.js';
/** The pinned first-party origin this build serves. */
export declare const CLAUDE_DEFAULT_POLICY_ORIGIN = "https://api.anthropic.com";
/** The scope a first-party subscription credential must carry for inference. */
export declare const CLAUDE_INFERENCE_SCOPE = "user:inference";
/** The plugin facts the core's eligibility decision is built from. */
export interface PolicyLimitsEligibilityFacts {
    /** Whether this account is served by the plugin's own first-party OAuth path. */
    readonly firstPartyOAuth: boolean;
    /** Whether the endpoint base is the pinned default one, not a configured override. */
    readonly defaultBaseUrl: boolean;
    /** The stored credential's scopes, exactly as stored. */
    readonly scopes: string;
    /** The stored credential's access token, when one is present. */
    readonly accessToken?: string | undefined;
    /** The confirmed subscription type, exactly as the stored credential stated it. */
    readonly subscriptionType?: string | null | undefined;
}
/**
 * Build the core's eligibility decision from one account's stored facts.
 *
 * The rule itself is the core's; this only reads the plugin's own credential shape —
 * presence of a token, the scope list as stored (nothing is trimmed into a match), and the
 * configured endpoint base.
 * @param facts - the stored account facts.
 * @returns the core's decision.
 */
export declare function policyLimitsEligibilityFor(facts: PolicyLimitsEligibilityFacts): PolicyLimitsEligibility;
/**
 * Read the pinned organizations out of an adopted managed-settings document.
 *
 * The three-state rule is the core's, and this wrapper only makes the absence distinction the
 * core's parse input cannot see. The pinned settings preprocessing deletes a null
 * `forceLoginOrgUUID` member before it is adopted, so a null value here is the same fact as an
 * absent one and must never turn a valid session into a refusal. Any other unusable shape — an
 * empty string, an empty array, or a member that is not a string — stays `invalid`, because
 * that is a refusal rather than an absence.
 * @param settings - the adopted settings document, when one was accepted.
 * @returns the pin state.
 */
export declare function orgPinFromSettings(settings: unknown): OrgPinParse;
/**
 * One DSH operation a policy key's verdict can reach.
 *
 * These are the operations this plugin actually performs or serves for a Claude-attributed
 * session. A key is only ever mapped onto one of them; nothing is inferred from a key's name.
 */
export type DshPolicyOperation = 
/** The provider's own model inference request. */
'provider.messages'
/** This plugin's provider catalogue fetch over the network, not a local model listing. */
 | 'provider.catalog_fetch'
/** Any other egress this plugin performs for that session. */
 | 'provider.network'
/** The harness's own web-fetch capability, when one is declared and executed. */
 | 'web_fetch'
/** A file-transfer capability performed for that session. */
 | 'file_transfer'
/** A tool the Host owns, executed on behalf of that session. */
 | 'host.tools';
/** How one key's verdict is enforced. */
export type PolicyKeyMapping = 
/** The key reaches exactly these operations. */
{
    readonly enforcement: 'enforced';
    readonly operations: readonly DshPolicyOperation[];
}
/**
 * This build cannot establish the exact operation the key reaches, and the capability
 * exists here: the attributed session's operations are conservatively refused.
 */
 | {
    readonly enforcement: 'unsupported';
    readonly operations: readonly DshPolicyOperation[];
    readonly reason: string;
}
/** This build has no such capability at all, with the exact reason recorded. */
 | {
    readonly enforcement: 'inapplicable';
    readonly reason: string;
};
/**
 * The enforcement one policy key resolves to.
 *
 * A key this build does not map is not assumed harmless: it reaches the attributed session's
 * operations conservatively, and the reason says so.
 * @param key - the policy key.
 * @returns the mapping, with a recorded reason when it is not an exact one.
 */
export declare function policyKeyMapping(key: string): PolicyKeyMapping;
/** Every registered key, so a build change is visible rather than silent. */
export declare const POLICY_MAPPING_GAPS: readonly string[];
/**
 * A reason this account's policy is not answered from a document this process confirmed.
 *
 * Every code is fixed and is the only thing a refusal carries: a snapshot's blind spot, or a
 * store that could not be trusted, never quotes a remote value.
 */
export type PolicyLimitsBlockerCode = 
/** The durable store exists but cannot be trusted; a restriction may have been lost. */
'policy_limits_state_unavailable'
/** The stored document stated restriction keys this build cannot re-state. */
 | 'policy_limits_unknown_keys'
/** The stored document named core skills, whose names are not retained. */
 | 'policy_limits_core_skills_unstored'
/** The stored document's taints did not all normalize, so its taint set is incomplete. */
 | 'policy_limits_lossy_taints';
/**
 * One capability an accepted document configures that this build does not provide.
 *
 * It is reported, never enforced: a capability default is a per-capability value, so losing
 * one is not evidence that any policy key was restricted, and it must not turn into a
 * whole-request refusal.
 */
export interface PolicyLimitsUnsupportedScope {
    /** The capability the document configures, named when this build knows it. */
    readonly scope: string;
    /** The fixed reason it cannot be applied here. */
    readonly reason: string;
}
/** The monitoring notice an account's accepted document states. */
export interface PolicyLimitsNotice {
    /** The notice text, already normalized and bounded by the core's own parse. */
    readonly text: string;
    /**
     * The notice URL, when the server stated a usable https one, or `null`. It is text for a
     * caller to render; this plugin never follows it.
     */
    readonly url: string | null;
}
/** One account's status projection. */
export interface PolicyLimitsStatus {
    state: 'ineligible' | 'loading' | 'current' | 'stale' | 'unavailable' | 'blocked';
    reason: string;
    fetchedAt?: number;
    /**
     * What the verdicts are being answered from: an accepted document confirmed by this
     * process (`live`), a document kept through a failed read or restored from the store
     * (`stale`), or nothing at all (`none`, where the no-live-policy order answers). It is the
     * same distinction the fallback path uses, so a status card never has to infer it from the
     * reason code.
     */
    fallback: 'live' | 'stale' | 'none';
    /** Keys the live document explicitly refused, for the status card. */
    deniedKeys?: readonly string[];
    /**
     * The pure core failure the last read produced, when it failed. It is the same value the
     * read result carries and holds no response body: the code, the fixed sub-reason, the
     * status and the retry disposition only.
     */
    failure?: CoreFailure;
    /** The blockers in force; while any is present, every verdict is refused. */
    blockers?: readonly PolicyLimitsBlockerCode[];
    /** Whether the documents in this state were confirmed by this process. */
    verified?: boolean;
    /** Whether a monitoring notice is in force; read its text with `monitoringNotice`. */
    notice?: boolean;
    /** The normalized compliance taints in force. */
    taints?: readonly string[];
    /** Capabilities the document configures that this build does not provide. */
    unsupportedScopes?: readonly PolicyLimitsUnsupportedScope[];
    /**
     * The control obligations the document in force states, when it states any.
     *
     * It is the document's own `restrictions` read through the control family's tri-state, and it
     * is reported beside `unsupportedScopes` rather than merged into it: a capability default and
     * a control obligation are different statements. A member of
     * {@link ControlRequirements.unsupportedActiveControls} refuses no operation.
     */
    controlRequirements?: ControlRequirements;
}
/** The identity one account's policy state belongs to. */
export interface PolicyLimitsIdentity {
    /** Canonical account key. */
    readonly account: string;
    /** Organization UUID the credential states, when it states one. */
    readonly accountUuid?: string | undefined;
    /** Confirmed organization, when one is known. */
    readonly organization?: string | undefined;
    /** Endpoint origin this identity's requests target. */
    readonly origin: string;
    /** Protocol-profile fingerprint this identity was read under. */
    readonly profileFingerprint: string;
    /**
     * Credential lease epoch, when the caller has one. A new login keeps the canonical account
     * key, so the epoch is what keeps the earlier lease's state from being reused for it.
     */
    readonly epoch?: string | undefined;
}
/** What one read attempt resolved to, for the caller's scheduling. */
export interface PolicyLimitsReadResult {
    readonly outcome: 'current' | 'stale' | 'unavailable';
    /**
     * The stable outcome code for this attempt, in the vocabulary consumers map onto their own
     * codes. The classifier's specific fixed sub-reason travels in `failure`, never flattened
     * into this value.
     */
    readonly reason: string;
    /**
     * The pure core failure this attempt produced, when it failed. The classifier's fixed
     * sub-reason is preserved here — a refusal such as `CLIENT_VERSION_UNSUPPORTED` is never
     * flattened into the coarse code — and it carries no response body.
     */
    readonly failure?: CoreFailure;
}
/** One failed read, as the caller's own failure handler receives it. */
export interface PolicyLimitsReadFailure {
    /** Canonical account key the read belonged to. */
    readonly account: string;
    /** The identity that produced the failure; a read for another identity never reports here. */
    readonly identity: PolicyLimitsIdentity;
    /**
     * The pure core failure: the stable code, the classifier's fixed sub-reason, the observed
     * status and the retry disposition. It carries no response body.
     */
    readonly failure: CoreFailure;
}
/** What this owner's durable store resolved to. */
export type PolicyLimitsStorageStatus = 
/** No store was injected: nothing is read or written. */
{
    readonly status: 'none';
}
/** A store was injected and hydration has not run yet. */
 | {
    readonly status: 'pending';
}
/** The store was never written. */
 | {
    readonly status: 'cold';
}
/** The restored records, one per account. */
 | {
    readonly status: 'loaded';
    readonly accounts: number;
}
/** A store exists but cannot be trusted; the caller must keep failing closed. */
 | {
    readonly status: 'unavailable';
    readonly error: ClaudePolicyLimitsStateError;
};
/** The owner's injected dependencies. */
export interface ClaudePolicyLimitsOptions {
    /** Absolute endpoint base, without the path. */
    readonly baseUrl: string;
    /** User agent the read carries. */
    readonly userAgent: string;
    /** The transport this plugin performs the read with. */
    readonly transport: CoreTransport;
    /** Resolve one account's access token; the caller owns refresh and its single-flight. */
    readonly accessToken: (account: string) => Promise<string>;
    /** Time source. */
    readonly clock?: CoreClock;
    /** Cancellable sleep used between retries. */
    readonly sleep?: CoreSleep;
    /** Random source for the retry jitter. */
    readonly random?: () => number;
    /** Injected verdict inputs; the defaults are this build's documented configuration. */
    readonly verdictInputs?: PolicyVerdictInputs;
    /** Warning sink for a contained read failure. */
    readonly onWarn?: (message: string) => void;
    /** Refresh interval for a bound account's cadence; defaults to the pinned one. */
    readonly pollMs?: number;
    /** Timer source for the cadence; defaults to the process timers. */
    readonly scheduler?: ClaudePolicyLimitsScheduler;
    /**
     * The forced refresh the reader performs at most once after a 401. It must be the plugin's
     * real forced-refresh path; a cached token read is not a refresh and is not used here.
     */
    readonly refreshOnUnauthorized?: ((account: string) => Promise<string>) | undefined;
    /** The unified failure classifier the reader hands one bounded read to. */
    readonly classifyFailure?: PolicyLimitsReadOperation['classifyFailure'];
    /**
     * The durable store of adopted documents. Absent keeps this owner in memory only.
     *
     * The store is read by {@link ClaudePolicyLimitsOwner.hydrate} and written on adoption; the
     * caller injects it so its path comes from the harness home the plugin already configures.
     */
    readonly persistence?: ClaudePolicyLimitsStateStore;
    /**
     * The caller's one side effect for a failed read, called with the account, the identity the
     * read belonged to and the pure core failure.
     *
     * This is the caller's only opportunity to record a shared protocol block, and the owner
     * awaits it before the read result settles: a caller that observes the terminal result knows
     * the record it asked for is durable, so the request path and a background cadence read
     * cannot both write it. The owner itself records no block.
     *
     * The handler runs inside this owner's own failure path, so it must not await work that
     * waits for this read to settle: it sets its fence and stops cadences synchronously — see
     * {@link ClaudePolicyLimitsOwner.stopCadence} — and schedules anything asynchronous after
     * returning rather than awaiting it here.
     */
    readonly readFailure?: (event: PolicyLimitsReadFailure) => void | Promise<void>;
    /**
     * Called after any observable state change (an adoption, a failure, a restore, a release),
     * so a status projection re-reads. It is a notification only: this owner registers no
     * route and the callback must not re-enter it synchronously.
     */
    readonly onChanged?: (account: string) => void;
}
/** The pinned refresh interval a bound account's policy document is re-read on. */
export declare const POLICY_LIMITS_POLL_MS = 3600000;
/** The timer source the owner's cadence uses. */
export interface ClaudePolicyLimitsScheduler {
    /**
     * Run one callback after the delay.
     * @param delayMs - the delay in milliseconds.
     * @param run - the callback.
     * @returns a canceller for the armed timer.
     */
    after(delayMs: number, run: () => void): () => void;
}
/**
 * The `policy_limits` owner.
 *
 * One document per account, adopted on success and kept on failure. Reads for one account are
 * single-flight: a second caller joins the read already running instead of starting another.
 * Nothing here refreshes a credential — the caller passes an access token resolver, and the
 * core's reader performs its one bounded replay through the same resolver.
 */
export declare class ClaudePolicyLimitsOwner {
    private readonly options;
    private readonly states;
    private readonly inFlight;
    /**
     * A pending identity handover per account: the previous state's cleanup, awaited before the
     * replacement starts its own read so two identities never read for one account at once.
     */
    private readonly handovers;
    private hydration;
    private storage;
    private storeBlocked;
    private disposed;
    constructor(options: ClaudePolicyLimitsOptions);
    /** The timer source this owner's cadence uses. */
    private get scheduler();
    /**
     * The status of one account; a pure read that starts no request.
     *
     * `loading` is derived from the read in flight rather than stored, and only for an account
     * with no settled observation yet. Once a read or a restore has settled, that observation is
     * what the account is judged by: a refresh in flight never hides it, and never hides a
     * recorded failure behind a loading state.
     */
    status(account: string): PolicyLimitsStatus | undefined;
    /** Every account this owner knows, for the status projection. */
    accounts(): readonly string[];
    /** What this owner's durable store resolved to; a pure read. */
    storageStatus(): PolicyLimitsStorageStatus;
    /**
     * Install the stored snapshots. Safe to call once; later calls return the same promise.
     *
     * A stored record is installed unverified: it keeps the refusals it stated, contributes no
     * conditional-request validator, and answers the reader as a `stale` prior so a missing
     * route can no longer fail open. A store that cannot be trusted installs no record and
     * blocks every account until a confirmed read replaces the missing evidence.
     * @returns a promise that settles once the stored records are installed.
     */
    hydrate(): Promise<void>;
    /**
     * Start this account's own refresh cadence, once a live binding exists for it.
     *
     * The cadence is armed only here: an account with no bound session is never polled. It is
     * idempotent for one operation, and it reschedules only after a read settles, so a slow
     * read cannot stack requests.
     * @param account - the canonical account key.
     */
    arm(account: string): void;
    /** The keys and reasons this build cannot enforce exactly, for one account. */
    unsupported(account: string): readonly {
        key: string;
        reason: string;
    }[];
    /**
     * The operation-permission keys this account's live document states, including keys outside
     * the pinned registry.
     *
     * It is the one key-level fact an operation consumer needs, and the only part of an adopted
     * document this owner hands out: the stated values, the `defaults` map, the monitoring-notice
     * text and the core skill names stay inside the owner, and the persisted projection never
     * keeps an unregistered key's name at all.
     *
     * The document's known control obligations are classified out here: they name an obligation
     * rather than an operation this provider performs, `status` reports them through its own
     * `controlRequirements`, and handing them to a consumer's operation mapping would refuse
     * operations the control does not reach. Every other stated key — an unknown one included — is
     * still reported.
     * @param account - the canonical account key.
     * @returns the stated operation-permission keys, or none when no document answers this account.
     */
    restrictionKeys(account: string): readonly string[];
    /**
     * The monitoring notice this account's accepted document states, when this process has read
     * it.
     *
     * The text is the core's own normalized, bounded projection of the server's notice, and the
     * url is only ever a usable https value; the caller renders them and never follows the url
     * itself. A snapshot restored from the store kept the notice's existence without its text,
     * so this answers `undefined` there while the status reports `notice: true` and a
     * `policy-notice` scope states that the notice is shown after the next confirmed read. The
     * pending text refuses no operation: a notice restricts no key.
     * @param account - the canonical account key.
     * @returns the notice, or `undefined` when none is in force or its text is not known here.
     */
    monitoringNotice(account: string): PolicyLimitsNotice | undefined;
    /**
     * Answer one policy question for one account.
     *
     * While a blocker is in force nothing is answered from the document: an incomplete or
     * untrusted snapshot could have restricted the key, so the operation is refused. Otherwise
     * an account with no adopted document is answered by the no-live-policy order using this
     * build's injected inputs; the caller decides whether that answer blocks an operation.
     * @param account - the canonical account key.
     * @param key - the policy key.
     * @returns the core's answer.
     */
    verdict(account: string, key: string): PolicyAnswer;
    /**
     * Read one account's document, joining a read already running for it.
     * @param account - the canonical account key.
     * @param options - the explicit force, the binding session and the caller's cancellation.
     * @returns what the account's state is after the attempt.
     */
    ensure(account: string, options?: {
        force?: boolean;
        sessionId?: string;
        signal?: AbortSignal;
    }): Promise<PolicyLimitsReadResult>;
    /** Clear a finished read's ownership of the state. */
    private settleRead;
    /** Register one live binding, replacing a state that belongs to another identity. */
    bind(account: string, sessionId: string, identity: PolicyLimitsIdentity): boolean;
    /** Suspend one account whose last binding ended; its document is kept, only polling stops. */
    suspend(account: string): Promise<void>;
    /**
     * Stop one account's background polling without waiting for anything.
     *
     * It cancels the armed refresh and invalidates the generation, so a read already in flight
     * adopts nothing and settles as superseded; the document already adopted is kept. It is
     * synchronous by contract: a caller inside {@link ClaudePolicyLimitsOptions.readFailure}
     * fences its own accounts here, and the read it is called from cannot be awaited from that
     * handler.
     * @param account - the canonical account key.
     */
    stopCadence(account: string): void;
    /** Release one session's binding, suspending the account when it was the last one. */
    releaseSession(account: string, sessionId: string): Promise<void>;
    /**
     * End one account's identity: everything this identity established is dropped.
     *
     * The stored record is removed only while it still carries this state's own identity and
     * adoption counter, so a release that races a later login or a later adoption leaves the
     * newer record exactly as it is.
     * @param account - the canonical account key.
     */
    releaseAccount(account: string): Promise<void>;
    /** Stop the owner: every cadence is cancelled, every read aborted, every owned step awaited. */
    dispose(): Promise<void>;
    /**
     * Arm one cadence for one generation, containing its own failures.
     *
     * The slot is identified by the token this call creates. A fire, a cancellation or a
     * replacement that no longer finds its own token does nothing, so a stopped operation can
     * never re-arm a timer behind a newer one.
     */
    private scheduleCadence;
    /** Whether this state is still the one installed, under this generation. */
    private owns;
    /** Invalidate one state: its cadence dies with its generation. */
    private invalidate;
    /** Stop this state's I/O; a waiter's own cancellation is unaffected. */
    private abortInFlight;
    /** Wait for this state's own work to settle: its read and everything the read started. */
    private quiesce;
    /** Wait for a pending identity handover for this account, when one is running. */
    private handoverFor;
    /** Track one started operation so disposal can wait for it. */
    private track;
    /**
     * Own one operation for a state, containing its failure and waiting for it on release.
     *
     * The warning names a fixed stage code: when the failure is the store's own typed failure its
     * closed code is reported, and every other rejection reports `owned_work_failed`. A thrown
     * error's own text is never logged.
     */
    private own;
    /** Await every operation this owner still has in flight. */
    private settleOwned;
    /** Await one shared read for one waiter: its cancellation ends only its own wait. */
    private waitFor;
    /**
     * Install a state for one identity, waiting out whatever the previous state still owned.
     *
     * A different identity never reuses the earlier state's document, cadence or validator, and
     * the replacement's own reads wait for the earlier identity's I/O to settle rather than
     * running beside it.
     */
    private replaceState;
    /** The blockers a newly created state starts with. */
    private blockersForNewState;
    /** Contain one operation's failure: a fixed reason, never an unhandled rejection. */
    private guard;
    /** One logical read, with adoption and stale retention. */
    private read;
    /**
     * Record one failed read: keep what was adopted, keep a known restriction, and let the
     * caller's own failure handler run before the result is observed.
     *
     * The handler is awaited, so a caller that sees this result knows the durable record it
     * asked for already exists; and it is only called while the identity still owns the state,
     * so a failure read for an account that has since moved on records nothing.
     *
     * A failure the pinned retry policy forbids stops this account's own background polling:
     * another read of the same identity cannot produce a different answer, so the cadence is
     * cancelled while the document already adopted stays exactly as it is. A transient failure
     * leaves the cadence running.
     */
    private failRead;
    /**
     * Run the caller's own failure handler, fenced to the identity that produced the failure.
     *
     * The handler is called synchronously from the read it belongs to, so it must not await
     * work that waits for that read: a caller that would needs to schedule it after returning.
     */
    private reportFailure;
    /** The adopted document, or `undefined` when nothing was adopted. */
    private liveDocument;
    /** The registered keys this build cannot enforce exactly, with their reasons. */
    private mappingGaps;
    /** Read and install the durable store, failing closed when it cannot be trusted. */
    private loadStore;
    /**
     * Install one stored record as an unverified snapshot.
     *
     * A state this process already read, or one that belongs to another identity, is never
     * replaced by the file: live evidence is newer than a stored projection.
     */
    private restoreRecord;
    /** Add the store blocker to one already-installed state. */
    private blockState;
    /**
     * Store the document one adoption confirmed, as this state's own persisted projection.
     *
     * Nothing is written before hydration has run: this owner has not yet read what the file
     * already holds, and a write that never compared against it could replace newer evidence.
     */
    private persist;
    /** Remove the stored record, only while it is still this state's own identity and revision. */
    private removeStored;
    /** Report a state change to the status projection's owner. */
    private notify;
}
/** What one organization check resolved to. */
export type OrgCheckOutcome = 
/** No pin is in force, so nothing was sent. */
{
    readonly kind: 'no-pin';
}
/** The account is inside the pinned set. */
 | {
    readonly kind: 'allowed';
}
/** The account must not serve: unusable pin, mismatch, or no usable result. */
 | {
    readonly kind: 'denied';
    readonly code: string;
};
/** The facts one organization check is keyed and judged by. */
export interface OrgCheckRequest {
    /** Canonical account key. */
    readonly account: string;
    /**
     * The pin the maintenance owner projected for this account, with the policy revision it
     * belongs to. No raw settings document crosses this seam.
     */
    readonly projected: {
        readonly kind: 'stated';
        readonly pin: OrgPinParse;
        readonly revision: string;
    } | {
        readonly kind: 'unknown';
        readonly revision: string;
        readonly reason: string;
    } | undefined;
    /** Access token the validation request carries. */
    readonly accessToken: () => Promise<string>;
    /**
     * The identity the remembered result belongs to. A judgment made for one account,
     * organization, lease or protocol profile is never reused for another: at minimum the
     * account, its organization, the credential lease epoch, the origin and the protocol
     * profile separate one check from the next, and the pin revision is added by this checker.
     */
    readonly identity?: {
        readonly accountUuid?: string | undefined;
        readonly organization?: string | undefined;
        readonly leaseEpoch?: string | undefined;
        readonly origin?: string | undefined;
        readonly profileFingerprint?: string | undefined;
    } | undefined;
    /** Caller cancellation. */
    readonly signal?: AbortSignal | undefined;
}
/**
 * The organization-pin checker.
 *
 * The check is event-driven, not periodic: it runs when a bound account first becomes ready
 * and when a login completes, and it is remembered by the pin's own policy revision. A
 * routine token rotation does not invalidate the record, because a refreshed credential is
 * not a new login; a pin that changes does, and takes effect at the next actual check.
 * A denied outcome is never resolved by trying another account.
 */
export declare class ClaudeOrgPinChecker {
    private readonly options;
    private readonly results;
    constructor(options: {
        /** The validation endpoint. */
        readonly url: string;
        /** User agent for this role. */
        readonly userAgent: string;
        /** The transport the validation uses. */
        readonly transport: CoreTransport;
        /** Warning sink for a contained failure. */
        readonly onWarn?: (message: string) => void;
    });
    /**
     * Validate one account against the pin its accepted policy stated.
     * @param request - the account, its projected pin, identity and the credential to validate.
     * @returns the outcome; only `allowed` and `no-pin` permit the operation.
     */
    check(request: OrgCheckRequest): Promise<OrgCheckOutcome>;
    /** Drop every remembered result for one account, for a logout or an identity replacement. */
    forget(account: string): void;
    /** The exact identity one remembered judgment belongs to. */
    private cacheKey;
}
/**
 * Adapt this plugin's fetch to the core's transport.
 *
 * The core owns the body bound, the parse and every status decision; this adapter performs
 * only the transfer and hands the response back, with the request's own deadline combined
 * with the caller's cancellation. No credential or account choice happens here.
 * @param input - the request the core wants performed.
 * @param fetchFn - the plugin's fetch implementation.
 * @returns the response the core reads.
 */
export declare function policyLimitsTransport(input: CoreHttpRequest, fetchFn: typeof fetch): Promise<CoreHttpResponse>;
