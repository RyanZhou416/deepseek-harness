/**
 * The managed-settings read: one conditional `GET` of the first-party settings endpoint,
 * the fixed envelope and cache-state semantics the pinned client uses, and the projection
 * of accepted remote policy into restrictions a consumer can enforce.
 *
 * The endpoint, its authentication and its header role belong to the Claude protocol
 * configuration; this module receives them as an injected fetch. What it owns is the
 * response contract — envelope validation, the 200/204/304/404 branches, the server's own
 * revalidation checksum, and the rule that a remote restriction is never silently dropped.
 *
 * Remote JSON never reaches Cordis config, environment variables, the tool catalog or a
 * download: this module produces a validated projection, and an operation the projection
 * cannot decide is refused rather than allowed.
 */
import type { ClaudeMaintenanceFailure } from './claude-account-state.js';
/**
 * What one conditional settings read needs from the Claude protocol configuration.
 * @param request - the account, its access token and the cache validator.
 * @returns the endpoint's response; the caller owns redirect and status handling.
 */
export type ClaudePolicyFetchFn = (request: ClaudePolicyFetchRequest) => Promise<Response>;
/** One conditional managed-settings request. */
export interface ClaudePolicyFetchRequest {
    /** Canonical account key the credential belongs to. */
    account: string;
    /** Access token to authenticate with; the caller refreshes it before a retry. */
    accessToken: string;
    /**
     * The server's own checksum from the last accepted snapshot. Present only when a
     * snapshot is cached, and sent as `If-None-Match`, which is what makes a 304 valid.
     */
    ifNoneMatch?: string;
    /** Caller cancellation. */
    signal?: AbortSignal;
}
/** What one operation a remote restriction could affect is about. */
export interface ClaudePolicyCheckRequest {
    /** Kind of operation being decided, for the common single-scope case. */
    scope?: ClaudePolicyScope;
    /**
     * Every capability scope the operation actually exercises.
     *
     * A tool run that can execute a shell command reaches the sandbox and environment
     * restrictions too, and an MCP tool call reaches the MCP ones. A caller that knows only
     * that "some tool" runs must pass {@link claudeScopesFor} with the unknown kind, which
     * reaches every scope: a restriction that cannot be shown to be unaffected stops the
     * operation instead of slipping past a narrow single scope.
     */
    capabilities?: readonly ClaudePolicyScope[];
    /** DSH tool name, for a tool operation. */
    tool?: string;
    /** Model id, for a model operation. */
    model?: string;
    /** MCP server name, for an MCP operation. */
    server?: string;
    /** Whether the operation asks for bypass-permissions mode. */
    bypassPermissions?: boolean;
}
/** The operation kinds a remote restriction can reach. */
export type ClaudePolicyScope = 
/** Tool execution. */
'tool'
/** Model selection and requests. */
 | 'model'
/** MCP servers and their tools. */
 | 'mcp'
/** Shell, hook and sandbox execution surfaces. */
 | 'execution'
/** Network destinations. */
 | 'network'
/** A restriction whose reach is unknown, so it reaches everything. */
 | 'unknown';
/** The operation kinds a caller can name when it knows what it is about to do. */
export type ClaudeOperationKind = 
/** A model request. */
'model'
/** A tool whose own effects are known not to include execution, MCP or network. */
 | 'tool'
/** A tool that can run a shell command. */
 | 'shell'
/** An MCP server call. */
 | 'mcp'
/** A network request. */
 | 'network'
/** A file read or write. */
 | 'file'
/** An operation whose reach is unknown; it reaches every scope. */
 | 'unknown';
/**
 * The capability scopes one operation of a known kind exercises.
 *
 * A caller that cannot classify its operation passes `'unknown'`, which reaches every
 * scope: an unenforceable restriction must stop the operation rather than be skipped
 * because the caller described the operation too narrowly.
 * @param kind - what the caller is about to do.
 * @returns the scopes the operation reaches.
 */
export declare function claudeScopesFor(kind: ClaudeOperationKind): readonly ClaudePolicyScope[];
/** One validated restriction a consumer can enforce. */
export interface ClaudePolicyRestriction {
    /** Remote settings key the restriction came from. */
    readonly key: string;
    /** Operation scope the restriction reaches. */
    readonly scope: ClaudePolicyScope;
    /** Consumer-specific restriction kind. */
    readonly kind: string;
    /** Consumer-specific restriction value. */
    readonly value: unknown;
}
/** A reason an accepted remote policy cannot be applied to an operation. */
export interface ClaudePolicyBlocker {
    /** Remote settings key, or `(envelope)` for a document-level problem. */
    readonly key: string;
    /** Operation scope the blocker reaches. */
    readonly scope: ClaudePolicyScope;
    /** Stable machine code the status view and the refusal carry. */
    readonly code: 'POLICY_UNSUPPORTED' | 'POLICY_INVALID_VALUE' | 'POLICY_CONSENT_REQUIRED';
    /** Short explanation naming what could not be applied. */
    readonly detail: string;
}
/** The outcome of deciding one operation. */
export type ClaudePolicyDecision = {
    readonly decision: 'allow';
    readonly reason?: string;
} | {
    readonly decision: 'deny';
    readonly code: string;
    readonly blocker: ClaudePolicyBlocker;
};
/** What one consumer's parse produced. */
export interface ClaudePolicyParseResult {
    /** Restrictions the consumer can enforce exactly. */
    readonly restrictions: readonly ClaudePolicyRestriction[];
    /** Parts of the value the consumer cannot apply exactly, which block their scope. */
    readonly unsupported: readonly ClaudePolicyBlocker[];
}
/**
 * One registered enforcement for a remote settings key.
 *
 * A consumer exists only where the fixed protocol schema's meaning is known: it parses the
 * remote value into restrictions it can enforce exactly, and it decides each affected
 * operation. A key with no consumer is never treated as applied.
 */
export interface ClaudePolicyConsumer {
    /** Remote settings key the consumer owns, for example `permissions`. */
    readonly key: string;
    /** The scope this consumer decides. */
    readonly scope: ClaudePolicyScope;
    /**
     * Parse the remote value.
     * @param value - the JSON value the accepted envelope carried for this key.
     * @returns the restrictions and the parts that cannot be applied, or `undefined` when
     *   the value is outside this consumer's contract entirely.
     */
    parse(value: unknown): ClaudePolicyParseResult | undefined;
    /**
     * Decide one operation.
     * @param request - the operation being decided.
     * @param restrictions - this consumer's restrictions that reach the request.
     * @returns the decision; a consumer never returns an allow it cannot justify.
     */
    decide(request: ClaudePolicyCheckRequest, restrictions: readonly ClaudePolicyRestriction[]): ClaudePolicyDecision;
}
/** The scope and treatment one accepted key's value receives. */
export interface ClaudePolicyKeyState {
    key: string;
    scope: ClaudePolicyScope;
    /** What happened to the value: enforced, reported, or blocking. */
    disposition: 'enforced' | 'not-applicable' | 'preference' | 'blocked';
    /** The key's fixed detail text, or the reason it blocked. */
    detail: string;
}
/** An accepted remote policy snapshot, isolated by account, organization, origin and protocol fingerprint. */
export interface ClaudePolicySnapshot {
    /** Identity the snapshot was accepted for. */
    identity: {
        account: string;
        origin: string;
        protocolFingerprint: string;
        organization?: string;
    };
    /** The server's own checksum, sent back as `If-None-Match` on the next conditional read. */
    checksum: string;
    /** The envelope's own revision identifier. */
    revision: string;
    /** When the snapshot was accepted, in epoch milliseconds. */
    acceptedAt: number;
    /**
     * The validated settings document the envelope carried, kept so the projection can be
     * re-derived against the consumers in force — after a restart in particular. It is a
     * cache of the server's own answer: it is never merged into Cordis config, the
     * environment, the tool catalog or a download.
     */
    settings: Record<string, unknown>;
    /** What happened to each key the envelope carried. */
    keys: readonly ClaudePolicyKeyState[];
    /** Restrictions an operation check can enforce. */
    restrictions: readonly ClaudePolicyRestriction[];
    /** Parts of the accepted policy that could not be applied. */
    blockers: readonly ClaudePolicyBlocker[];
}
/** What one settings read produced. */
export type ClaudePolicyReadOutcome = 
/** A 200 envelope was accepted. */
{
    readonly outcome: 'accepted';
    readonly snapshot: ClaudePolicySnapshot;
}
/** The endpoint's fixed empty-success statuses, accepted as an empty remote snapshot. */
 | {
    readonly outcome: 'empty';
    readonly snapshot: ClaudePolicySnapshot;
}
/** A 304 that revalidated the cached snapshot for the same identity. */
 | {
    readonly outcome: 'unchanged';
    readonly snapshot: ClaudePolicySnapshot;
}
/** The provider refused this account; no retry and no switch to another account. */
 | {
    readonly outcome: 'refused';
    readonly failure: ClaudeMaintenanceFailure;
}
/** The credential was rejected; the caller may refresh and retry exactly once. */
 | {
    readonly outcome: 'unauthorized';
    readonly failure: ClaudeMaintenanceFailure;
}
/** A transport or server failure; a cached snapshot stays valid. */
 | {
    readonly outcome: 'transient';
    readonly failure: ClaudeMaintenanceFailure;
}
/** A malformed envelope or an invalid 304; a cached snapshot stays valid and the blocker, when present, denies its scope. */
 | {
    readonly outcome: 'invalid';
    readonly failure: ClaudeMaintenanceFailure;
    readonly blocker?: ClaudePolicyBlocker;
}
/** The caller cancelled. */
 | {
    readonly outcome: 'cancelled';
};
/** The outer bound on a settings response body this module will read. */
export declare const CLAUDE_POLICY_BODY_LIMIT = 1048576;
/**
 * Classify one non-success settings response.
 *
 * Implemented by the reliability module's single HTTP classifier, so a client-version
 * refusal or a permission refusal discovered here carries the same decision — including
 * the hard-stop disposition — that the Messages path produces. This module never keeps a
 * second mapping of provider codes.
 * @param response - the response to classify, with its body still unread.
 * @param context - the read the response answered.
 * @returns the structured decision, or `undefined` when the classifier does not own it.
 */
export type ClaudePolicyHttpClassifier = (response: Response, context: {
    account: string;
    origin: string;
    protocolFingerprint: string;
}) => Promise<ClaudeMaintenanceFailure | undefined>;
/** Everything one settings read needs. */
export interface ClaudePolicyReadInput {
    /** The identity the snapshot is isolated by. */
    identity: ClaudePolicySnapshot['identity'];
    /** Canonical account key. */
    account: string;
    /** Access token to authenticate the read. */
    accessToken: string;
    /** Previously accepted snapshot for this identity, when there is one. */
    cached?: ClaudePolicySnapshot;
    /** Current epoch milliseconds. */
    now: number;
    /** Registered consumers, by key. */
    consumers: ReadonlyMap<string, ClaudePolicyConsumer>;
    /** The injected conditional fetch. */
    fetchSettings: ClaudePolicyFetchFn;
    /** The unified failure classifier; absent maps every non-success status generically. */
    classifyHttpFailure?: ClaudePolicyHttpClassifier;
    /** Caller cancellation. */
    signal?: AbortSignal;
}
/**
 * Format one server checksum as an `If-None-Match` entity tag.
 *
 * The pinned client sends the cached checksum quoted; a value that already carries quotes
 * is sent as it arrived rather than double-quoted.
 * @param checksum - the server's checksum.
 * @returns the entity tag to send.
 */
export declare function claudeIfNoneMatch(checksum: string): string;
/**
 * Read the managed settings once.
 *
 * The statuses follow the pinned client: 200 validates the `{uuid, checksum, settings}`
 * envelope, 204/404 are the endpoint's own empty-success semantics, a 304 is valid only
 * against a cached checksum for the same identity, and a transport failure keeps the
 * accepted snapshot. A redirected response is never read as the pinned endpoint. Every
 * other status goes to the injected unified classifier, so a version or permission refusal
 * keeps its own decision — a hard stop included — instead of becoming a generic retry.
 * @param input - the identity, credential, cache, classifier and injected fetch for this read.
 * @returns what the read produced, with the snapshot that the caller should keep.
 */
export declare function readClaudeManagedSettings(input: ClaudePolicyReadInput): Promise<ClaudePolicyReadOutcome>;
/**
 * Project one accepted settings document into restrictions, key states and blockers.
 *
 * Every key the document carries is accounted for: a key with a registered consumer is
 * parsed by that consumer, a key whose verified meaning needs no enforcement here is
 * recorded as such, and anything else blocks its scope. No value is silently dropped.
 * @param settings - the accepted envelope's settings object.
 * @param consumers - registered consumers, by key.
 * @returns the projection and the key states describing it.
 */
export declare function projectClaudePolicy(settings: Record<string, unknown>, consumers: ReadonlyMap<string, ClaudePolicyConsumer>): {
    restrictions: ClaudePolicyRestriction[];
    blockers: ClaudePolicyBlocker[];
    keys: ClaudePolicyKeyState[];
};
/** The validated envelope of a 200 response. */
export interface ClaudePolicyEnvelope {
    uuid: string;
    checksum: string;
    settings: Record<string, unknown>;
}
/**
 * Validate the fixed response envelope `{uuid, checksum, settings}`.
 *
 * The envelope schema accepts exactly these keys: `uuid` and `checksum` are response-level
 * identifiers and `settings` is the policy object. A response that does not satisfy all
 * three is a parse error, never an empty policy.
 * @param text - the response body text.
 * @returns the envelope, or `undefined` when the body is not a valid envelope.
 */
export declare function parseClaudePolicyEnvelope(text: string): ClaudePolicyEnvelope | undefined;
/**
 * Decide one operation against an accepted snapshot.
 *
 * A blocker whose scope reaches the operation refuses it; so does a restriction whose key
 * has no registered consumer at decision time, because a restriction that cannot be
 * enforced exactly must not be dropped. Everything else is delegated to the consumer.
 * @param request - the operation being decided.
 * @param snapshot - the accepted snapshot, when one exists.
 * @param consumers - registered consumers, by key.
 * @returns whether the operation may run.
 */
export declare function decideClaudePolicy(request: ClaudePolicyCheckRequest, snapshot: ClaudePolicySnapshot | undefined, consumers: ReadonlyMap<string, ClaudePolicyConsumer>): ClaudePolicyDecision;
/** One parsed permission rule: a wire tool name and whether it carried a specifier. */
interface ClaudePermissionRule {
    tool: string;
    specifier?: string;
}
/**
 * Parse one `Tool` or `Tool(specifier)` permission rule.
 * @param rule - the rule string from the remote value.
 * @returns the parsed rule, or `undefined` when the string is not a rule at all.
 */
export declare function parseClaudePermissionRule(rule: string): ClaudePermissionRule | undefined;
/** Options for {@link claudePermissionConsumer}. */
export interface ClaudePermissionConsumerOptions {
    /**
     * Exact wire tool name to DSH tool name map. A rule naming a tool outside this map is
     * unsupported, so the operation it would restrict is refused rather than ignored.
     */
    toolAliases: Readonly<Record<string, string>>;
    /**
     * Whether a rule specifier — for example `Bash(npm test:*)` — has an exact,
     * already-verified translation for one wire tool name. Absent means every specifier is
     * unsupported, which blocks the tool scope instead of guessing at a pattern language.
     */
    specifierMatchers?: Readonly<Record<string, (specifier: string, tool: string) => boolean>>;
}
/**
 * Build the `permissions` consumer.
 *
 * Only the meanings the fixed schema states are enforced: `deny` rules refuse a tool,
 * `ask` rules require a consent surface this plugin does not own (reported as
 * consent-required, which blocks the tool scope), and `disableBypassPermissionsMode`
 * refuses bypass mode. A rule whose specifier has no verified translation blocks the tool
 * scope with `POLICY_UNSUPPORTED`; it is never interpreted as a pattern language.
 * @param options - the exact tool alias map and any verified specifier matchers.
 * @returns the consumer to register for the `permissions` key.
 */
export declare function claudePermissionConsumer(options: ClaudePermissionConsumerOptions): ClaudePolicyConsumer;
/**
 * Build the consumer registry the maintenance owner and its operation checks share.
 *
 * The registry is passed by reference to every decision, so the projection and the
 * enforcement always read one set of consumers.
 * @param consumers - the consumers to register, in order; a later duplicate key wins.
 * @returns the registry keyed by remote settings key.
 */
export declare function claudePolicyConsumers(consumers: readonly ClaudePolicyConsumer[]): Map<string, ClaudePolicyConsumer>;
export {};
