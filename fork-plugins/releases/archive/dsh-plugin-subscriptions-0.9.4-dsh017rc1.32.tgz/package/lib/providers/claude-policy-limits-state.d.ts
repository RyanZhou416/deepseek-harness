/**
 * Durable `policy_limits` state: the safe projection of one account's accepted document, so a
 * normal restart keeps what the account already confirmed instead of reading it again.
 *
 * The file is the `policy_limits` owner's own store, separate from the settings namespace and
 * from the maintenance state: two writers of different documents never merge into one file.
 *
 * It holds no credential and no raw remote value. A restriction is stored as the bool the
 * document stated, for the keys the pinned registry knows; a monitoring notice, a non-empty
 * `defaults` map, core skill names and any restriction key outside the registry are stored as
 * existence facts only — never as the value that carried them — and each one is a blocker the
 * restored account keeps until a fresh verified read replaces the record. A file that exists
 * but cannot be trusted is never read as an empty one: the caller learns the state is
 * unavailable and fails closed instead of silently losing a restriction an earlier run read.
 */
import type { LockTiming } from '../auth/store-lock.js';
/** The outer bound on the state file this module will read or write, in characters. */
export declare const CLAUDE_POLICY_LIMITS_STATE_LIMIT = 1048576;
/** The store version this module writes and accepts. */
export declare const CLAUDE_POLICY_LIMITS_STATE_VERSION = 1;
/** The fixed codes every failure of this store reports. */
export type ClaudePolicyLimitsStateCode = 
/** A file exists but could not be read at all. */
'state_unreadable'
/** A file exists but is not the document this module wrote, in shape or in values. */
 | 'state_corrupt'
/** The stored version is not one this build accepts. */
 | 'state_version_unsupported'
/** The stored file is larger than the accepted bound. */
 | 'state_oversized'
/** A write was refused because the document it would replace cannot be trusted. */
 | 'state_untrusted_write'
/** Another process holds the store lock and could not be waited out. */
 | 'state_locked'
/** The write itself failed. */
 | 'state_write_failed';
/** One store failure, as a fixed code plus this plugin's own detail text. */
export interface ClaudePolicyLimitsStateError {
    /** The stable machine code. */
    readonly code: ClaudePolicyLimitsStateCode;
    /** This module's own description of the failure; never a remote value. */
    readonly detail: string;
}
/** A store failure reported by throwing, so one write cannot fail silently. */
export declare class ClaudePolicyLimitsStateFailure extends Error {
    readonly code: ClaudePolicyLimitsStateCode;
    readonly detail: string;
    /**
     * @param code - the stable machine code.
     * @param detail - this module's own description of the failure.
     */
    constructor(code: ClaudePolicyLimitsStateCode, detail: string);
}
/**
 * The identity one stored record belongs to.
 *
 * It is the same fence the in-memory owner keys a state by: the account key alone is never
 * enough, because a new login keeps the account key and changes the identity.
 */
export interface ClaudePersistedPolicyLimitsIdentity {
    /** Canonical account key. */
    readonly account: string;
    /** Organization UUID the credential stated, when it stated one. */
    readonly accountUuid?: string | undefined;
    /** Confirmed organization, when one is known. */
    readonly organization?: string | undefined;
    /** Endpoint origin the record was read from. */
    readonly origin: string;
    /** Protocol-profile fingerprint the record was read under. */
    readonly profileFingerprint: string;
    /** Credential lease epoch, when the caller has one. */
    readonly epoch?: string | undefined;
}
/** One registered key's stored verdict. */
export interface ClaudePersistedPolicyLimitsRestriction {
    /** A key the pinned registry knows. */
    readonly key: string;
    /** The verdict the accepted document stated for it. */
    readonly allowed: boolean;
}
/** One stored capability default. */
export interface ClaudePersistedPolicyLimitsDefault {
    /** A defaults key whose value type this module knows. */
    readonly key: string;
    /** The bool the accepted document stated for it. */
    readonly value: boolean;
}
/**
 * The `defaults` keys this store may keep by name.
 *
 * The pinned typed reader resolves a defaults entry as a per-key boolean, and the only bound
 * consumer in the analyzed build is the startup remote-control capability, which this plugin
 * does not provide either. A key outside this set, or a value that is not a boolean, is stored
 * as a count only: a remote string is never written to disk here.
 */
export declare const CLAUDE_POLICY_KNOWN_DEFAULT_KEYS: ReadonlySet<string>;
/** One account's stored projection of an accepted document. */
export interface ClaudePersistedPolicyLimitsRecord {
    /** The identity the record belongs to. */
    readonly identity: ClaudePersistedPolicyLimitsIdentity;
    /**
     * Monotonic adoption counter of that identity, starting at one. It is the strict
     * compare-and-swap token a removal must state, so a removal can never delete a record a
     * later adoption wrote.
     */
    readonly revision: number;
    /** The validator of the raw body, or `''` when none was derived. */
    readonly validator: string;
    /** When this process adopted the document, in epoch milliseconds. */
    readonly receivedAt: number;
    /** The registered keys the document stated, with the bool it stated. */
    readonly restrictions: readonly ClaudePersistedPolicyLimitsRestriction[];
    /** The normalized compliance taints in force; already bounded by the pinned pattern. */
    readonly taints: readonly string[];
    /** Whether normalization dropped at least one taint entry. */
    readonly lossyTaints: boolean;
    /** Whether a monitoring notice was in force; its text is never stored. */
    readonly noticePresent: boolean;
    /** The capability defaults this build can re-state, with the bool the document gave them. */
    readonly defaults: readonly ClaudePersistedPolicyLimitsDefault[];
    /** How many defaults entries this build cannot type or does not know; their values are not stored. */
    readonly unknownDefaults: number;
    /** Whether the document named core skills; the names are never stored. */
    readonly coreSkillsPresent: boolean;
    /** How many stated restriction keys are outside the pinned registry; their names are not stored. */
    readonly unknownKeys: number;
}
/** What a load produced. */
export type ClaudePolicyLimitsLoadResult = 
/** Nothing was ever stored at this path. */
{
    readonly status: 'cold';
}
/** The stored records, validated. */
 | {
    readonly status: 'loaded';
    readonly records: readonly ClaudePersistedPolicyLimitsRecord[];
}
/** A file exists but cannot be trusted; the caller must fail closed. */
 | {
    readonly status: 'unavailable';
    readonly error: ClaudePolicyLimitsStateError;
};
/** What a compare-and-swap removal produced. */
export type ClaudePolicyLimitsRemoval = 
/** The record matched the stated identity and revision and is gone. */
{
    readonly status: 'removed';
}
/** No record was stored for the account. */
 | {
    readonly status: 'absent';
}
/** The stored record is not the one the caller stated; it was left in place. */
 | {
    readonly status: 'superseded';
}
/** The removal could not be attempted; the record is left in place. */
 | {
    readonly status: 'retained';
    readonly error: ClaudePolicyLimitsStateError;
};
/** The account whose record one removal names, with the exact token it must still carry. */
export interface ClaudePolicyLimitsRemovalRequest {
    /** Canonical account key. */
    readonly account: string;
    /** The identity the caller's in-memory state belongs to. */
    readonly identity: ClaudePersistedPolicyLimitsIdentity;
    /** The adoption counter the caller's in-memory state holds. */
    readonly revision: number;
}
/** The durable store the owner injects. */
export interface ClaudePolicyLimitsStateStore {
    /**
     * Read the stored records.
     * @returns the validated records, or why they cannot be trusted.
     */
    load(): Promise<ClaudePolicyLimitsLoadResult>;
    /**
     * Store these records, merging them into whatever the file already holds for accounts this
     * call does not name, so two processes writing different accounts keep both.
     * @param records - the accounts to write.
     */
    save(records: readonly ClaudePersistedPolicyLimitsRecord[]): Promise<void>;
    /**
     * Drop one account's record, only while it is still the exact record the caller states.
     * @param request - the account, its identity and the adoption counter to compare.
     * @returns what the removal did.
     */
    remove(request: ClaudePolicyLimitsRemovalRequest): Promise<ClaudePolicyLimitsRemoval>;
}
/** Whether two stored identities are the same fence. */
export declare function samePolicyLimitsIdentity(left: ClaudePersistedPolicyLimitsIdentity, right: ClaudePersistedPolicyLimitsIdentity): boolean;
/**
 * The plugin's own `policy_limits` state file.
 *
 * Writes are serialized inside a cross-process lock, merged per account key, and swapped into
 * place atomically from an exclusively created temporary file, so one process cannot drop
 * another's record and a reader never observes a half-written document.
 */
export declare class FileClaudePolicyLimitsState implements ClaudePolicyLimitsStateStore {
    private readonly options;
    private writeTail;
    /**
     * @param options - the file to use, the lock timing, and a diagnostic sink.
     */
    constructor(options?: {
        /**
         * The absolute file path. The caller injects it from the harness home it already
         * configures; a test injects a private path so no real home is touched.
         */
        path?: string;
        timing?: LockTiming;
        onWarn?: (message: string) => void;
    });
    /** Absolute path of the state file. */
    private path;
    /**
     * Read the stored records.
     * @returns the validated records, or why they cannot be trusted.
     */
    load(): Promise<ClaudePolicyLimitsLoadResult>;
    /**
     * Merge these records into the stored ones and write the result under the store lock.
     * @param records - the accounts to write.
     */
    save(records: readonly ClaudePersistedPolicyLimitsRecord[]): Promise<void>;
    /**
     * Drop one account's record while it still matches the caller's identity and revision.
     * @param request - the account, its identity and the adoption counter to compare.
     * @returns what the removal did.
     */
    remove(request: ClaudePolicyLimitsRemovalRequest): Promise<ClaudePolicyLimitsRemoval>;
    /**
     * Remove one record while this process owns the lock, comparing identity and revision first.
     *
     * The comparison is the whole point: a release that arrives after a later login or a later
     * adoption must not delete the state those wrote. A document that cannot be trusted is left
     * exactly as it is.
     * @param request - the account, its identity and the adoption counter to compare.
     * @returns what the removal did.
     */
    private removeUnderOwnedLock;
    /**
     * Merge these records into the stored document while this process owns the lock.
     *
     * Ownership is a precondition, not a preference: a write that cannot take the lock fails so
     * the caller learns it did not happen. A document this process cannot trust is never
     * replaced by a partial write either — an account's accepted restriction must not be erased
     * by an unrelated write — so the write is refused and the caller keeps failing closed until
     * an operator repairs or removes the file.
     * @param records - the accounts to write.
     */
    private mergeUnderOwnedLock;
    /** Serialize this instance's own writes. */
    private enqueue;
    /** Read and validate the file, distinguishing "never written" from "not trustworthy". */
    private readDocument;
    /** Write the complete document atomically, from an exclusively created temporary file. */
    private writeDocument;
}
