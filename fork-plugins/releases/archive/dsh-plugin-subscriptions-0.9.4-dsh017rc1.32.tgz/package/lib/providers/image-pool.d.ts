import type { ProviderId } from '../auth/store.js';
import type { AccountTokenManager } from './accounts.js';
import type { RateLimitResetReader } from './rate-limit.js';
type ImageProvider = 'codex' | 'grok';
interface ImageSession {
    accessToken: string;
    refreshToken: string;
    expiresAt: number;
}
interface ImageAccountRequest<S extends ImageSession> {
    provider: ImageProvider;
    tokens: AccountTokenManager<S>;
    signal: AbortSignal;
    /** Session object identity provides bounded-lifetime affinity, also across generate/edit. */
    owner?: object | undefined;
    rateLimitReset: RateLimitResetReader;
    send: (session: S) => Promise<Response>;
}
export declare class ImageAccountPool {
    private readonly options;
    private readonly health;
    private sticky;
    constructor(options?: {
        enabled?: boolean;
        onWarn?: (message: string) => void;
    });
    /** Login/logout clears cooling image members and stale session affinity. */
    clear(provider: ImageProvider, account?: string): void;
    /**
     * Move one account's image cooldowns to the canonical key the token store
     * renamed it to. A rename is not a re-login: an account parked on an image
     * failure stays parked instead of being tried again under the new key. A
     * provider this pool does not serve has no image records to move.
     * @param provider - the provider route (only the image providers key records).
     * @param from - the key the account's image records were held under.
     * @param to - the canonical key the account now resolves to.
     */
    renameAccount(provider: ProviderId, from: string, to: string): void;
    request<S extends ImageSession>(request: ImageAccountRequest<S>): Promise<Response>;
}
export {};
