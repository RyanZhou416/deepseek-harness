/**
 * The catalog plumbing the subscription adapters share. One
 * {@link ProviderCatalog} owns a provider's account-indexed model caches and
 * runs the listing skeleton: union every logged-in account, map a catalogue onto
 * the static rows when nothing is known, and keep every read free of provider
 * I/O. An adapter supplies only what is genuinely its own — the discovery fetch,
 * the static rows, the row mapping and the fallback wording.
 *
 * The split that matters: {@link ProviderCatalog.list}, {@link resolve} and
 * {@link read} only ever answer from the local cache or the built-in rows, while
 * {@link refresh} is the single path that asks the provider. Callers decide when
 * that is warranted — login, opening Manage, an explicit refresh, or the account
 * a request is about to use.
 */
import type { LlmModelInfo } from '@deepseek-ai/dsh-llm';
import type { ProviderId } from '../auth/store.js';
import type { CatalogRefreshReport, CatalogStoreFactory, DiscoveredModel } from './common.js';
/** The account-store surface catalog listing reads. */
interface CatalogAccounts {
    /** The provider's accounts, default first. */
    list(): Promise<readonly {
        key: string;
    }[]>;
    /** Resolve a usable session for one account, refreshing on demand. */
    session(account?: string, forceRefresh?: boolean): Promise<unknown>;
    /** Whether a session is stored for one account (cheap; never refreshes). */
    hasSession(account?: string): Promise<boolean>;
    /** The default account's key, or undefined when logged out. */
    defaultAccount(): Promise<string | undefined>;
}
/** The pool seam that contributes picker rows beyond the discovered catalog. */
interface CatalogTierSource {
    /** The provider's configured tier rows. */
    modelsForProvider(provider: ProviderId): Promise<LlmModelInfo[]>;
}
/** The catalog-relevant slice of every subscription adapter's options. */
interface CatalogHost {
    /** The provider's account store. */
    tokens: CatalogAccounts;
    /** Durable per-account store factory; every account keeps its own catalogue. */
    catalogStore?: CatalogStoreFactory;
    /** Whether to discover the live catalogue; false serves the static rows. */
    discovery: boolean;
    /** Freshness window before an explicit event may refresh an entry. */
    catalogMaxAgeMs?: number;
    /** Failure cooldown when a request failed without disclosing a retry-after. */
    cacheRetryDelayMs?: number;
    /** Called once after a refresh stored a catalogue different from the previous one. */
    onCatalogChanged?: (provider: string) => void;
    /** Warn sink for a cache problem or a failed refresh that kept the last-known rows. */
    onWarn?: (message: string) => void;
}
/** The provider-specific pieces of one adapter's catalog listing. */
interface CatalogHooks {
    /** The provider's configured rows, served when discovery is off or nothing is known. */
    staticRows: (provider: string) => LlmModelInfo[];
    /** Fetches one account's catalog from the provider. Only refresh calls this. */
    fetchCatalog: (account: string, signal: AbortSignal) => Promise<DiscoveredModel[]>;
    /** One discovered entry as a picker row, filling the provider's capability fields. */
    row: (provider: string, model: DiscoveredModel) => LlmModelInfo;
    /** Per-account bound for one catalogue request; defaults to {@link DISCOVERY_TIMEOUT_MS}. */
    timeoutMs?: number;
}
/**
 * One provider's account-indexed catalogue caches and listing behaviour. Every
 * logged-in account has its own cache and its own persisted entry, so switching
 * accounts never serves another account's plan and a restart keeps each account's
 * capability metadata.
 */
export declare class ProviderCatalog {
    private readonly host;
    private readonly provider;
    private readonly label;
    private readonly hooks;
    /** One cache per account key, created on first use. */
    private readonly caches;
    /** The durable half of each cache, with the key it currently persists under. */
    private readonly durable;
    /** Durable drops still running, so {@link drain} can wait for them. */
    private readonly pending;
    /**
     * @param host - the adapter's token store and catalog configuration.
     * @param provider - the route this instance serves, named in change announcements.
     * @param label - provider name in diagnostics, e.g. `codex`.
     * @param hooks - the provider-specific listing pieces.
     */
    constructor(host: CatalogHost, provider: string, label: string, hooks: CatalogHooks);
    /**
     * Drop one account's cached catalogue, or every account's when omitted.
     *
     * The durable record is the point: an account can be logged out before any
     * read ever built its cache, so the store is cleared directly for an account
     * this instance holds no cache for, and the whole provider entry is dropped
     * when no account is named. A cache that does hold the account has its
     * generation bumped in the same breath, so an in-flight request cannot write
     * the dropped catalogue back. Callers use this for logout, removal, or a
     * changed catalogue identity — never for a routine default-account switch.
     * @param account - the account to forget; every persisted account when undefined.
     */
    clearAccountCatalog(account?: string): void;
    /** Drop every persisted account entry when the store cannot do it in one call. */
    private clearPersisted;
    /** Track one durable drop so {@link drain} waits for it; a failure is reported, not thrown. */
    private trackClear;
    /**
     * Await every refresh and cache clear still running, without starting new
     * work, so a route can be dropped without leaving a write behind.
     */
    drain(): Promise<void>;
    /**
     * Move one account's cached catalogue to its renamed canonical key.
     *
     * The SAME cache object moves, so its seeded snapshot, its freshness instant
     * and its failure cooldown all survive; nothing here waits on an in-flight
     * request, because this runs inside the save the account's own token refresh
     * triggered and awaiting the cache would deadlock against the request waiting
     * for that save to return. The retired key keeps resolving to the moved cache,
     * so a read or a clear that still names it reaches the same account and no
     * later write can recreate a record under the old key. A cache already built
     * for the new key is superseded by the moved one.
     * @param from - the key the account's catalogue was stored under.
     * @param to - the canonical key the account now resolves to.
     */
    renameAccount(from: string, to: string): Promise<void>;
    /** Move one account's durable record, merging what the target already holds. */
    private movePersisted;
    /** The cache for one account, created with its own durable entry on first use. */
    private cache;
    /**
     * The durable half for one cache, over a target a rename can re-point: the
     * cache keeps one persistence object for its lifetime, so a moved account
     * keeps its in-memory state and simply persists under the new key afterwards.
     */
    private durableFor;
    /**
     * One account's last-known catalogue. Pure: it may load the local cache file
     * on the first call and never starts a provider request.
     * @param account - the account key.
     * @returns the models, `undefined` when nothing is known yet, or an empty
     *   list for an account whose provider answered with no models.
     */
    read(account: string): Promise<readonly DiscoveredModel[] | undefined>;
    /**
     * The last-known catalogue for one account, the default account when omitted.
     * @param account - the account key, or undefined for the default account.
     * @returns the models, or undefined when nothing is known.
     */
    lastKnown(account?: string): Promise<readonly DiscoveredModel[] | undefined>;
    /**
     * One account's own rows for an advisory read: the last-known catalogue, or
     * the static rows while nothing is known. Pure — a cold or stale catalogue
     * answers from disk and static rows rather than paying a provider request, so
     * no picker, pool or capability read can start one. `undefined` is caller
     * cancellation alone, which the caller reads as "this account sits out".
     * @param provider - the provider route the rows belong to.
     * @param account - the account to read.
     * @param signal - caller cancellation, observed after the local read.
     * @returns that account's rows, or `undefined` when the caller cancelled.
     */
    resolve(provider: string, account: string, signal?: AbortSignal): Promise<readonly LlmModelInfo[] | undefined>;
    /**
     * The provider's own catalog: the union over every logged-in account, or one
     * account when named. Reads never start a provider request; an account with no
     * catalogue yet contributes its static rows, and one that is logged out or
     * failing contributes nothing.
     * @param provider - the provider route the rows belong to.
     * @param account - the account to list; every logged-in account when undefined.
     * @param signal - caller cancellation; aborting drops the whole union.
     * @returns the provider's own model rows.
     */
    list(provider: string, account?: string, signal?: AbortSignal): Promise<readonly LlmModelInfo[]>;
    /**
     * The first account whose last-known catalogue lists one model. Pure: it reads
     * each account's local snapshot in turn and never starts a provider request, so
     * capability resolution cannot turn into discovery.
     *
     * A named account is checked against the store first: a credential removed
     * outside this process leaves its cached catalogue on disk, and those rows say
     * nothing about an account that can no longer serve a request.
     * @param model - the wire model id to look for.
     * @param account - the account to ask; every logged-in account (default first) when omitted.
     * @returns the advertised entry, or undefined when no consulted account lists it.
     */
    findModel(model: string, account?: string): Promise<DiscoveredModel | undefined>;
    /**
     * Every known model id whose catalogue advertises the fast tier, unioned over
     * the logged-in accounts. Pure: an account with nothing known contributes
     * nothing, so the Speed control follows what the caches already hold.
     * @returns the fast-capable model ids, in account then catalogue order.
     */
    fastTierIds(): Promise<string[]>;
    /**
     * Request the provider's catalogue for one account and store it. The only
     * path in this class that starts a provider request; it is called for login,
     * opening Manage, an explicit refresh, and the account a request is about to use.
     * @param provider - the provider route the rows belong to.
     * @param account - the account to refresh; the default account when undefined.
     * @param options - `force` re-requests a fresh success snapshot (an explicit
     *   user refresh) but never bypasses a live failure cooldown; `signal` detaches
     *   this caller alone from a request other waiters still share.
     * @returns which account was requested, skipped, cancelled or failed.
     */
    refresh(provider: string, account?: string, options?: {
        force?: boolean;
        signal?: AbortSignal;
    }): Promise<CatalogRefreshReport>;
    /**
     * One account's explicit refresh. The stored result announces itself (see
     * {@link cache}), so a caller that waits, a caller that detached, and a caller
     * that joined someone else's request all produce at most that one report.
     */
    private refreshAccount;
    /**
     * One bounded request for an account's catalogue. The bound is this call's
     * own, never the caller's signal: a caller that stops waiting must not abort a
     * request other callers still share.
     */
    private fetchOnce;
}
/**
 * Picker-row fields only some providers discover: the catalog description, the
 * Codex sort priority, the provider's own context size, and an entry the account
 * cannot select.
 */
interface CatalogRowExtras {
    description?: string;
    priority?: number;
    contextWindow?: number;
    disabledReason?: string;
}
/**
 * The provider's own disabled marker on one picker row, when the route published one.
 *
 * The harness model-info contract has no field for it, so a route that receives a
 * `disabled_reason` from its catalogue carries the marker as an extension of its own row.
 * The owning adapters and the settings RPC both read it through here, so the extension
 * has one spelling.
 * @param model - one row as a subscription route published it.
 * @returns the provider's reason for refusing the model, or undefined when it may serve.
 */
export declare function modelDisabledReason(model: LlmModelInfo): string | undefined;
/**
 * One picker row for a discovered catalog entry: the advertised id, name and
 * modalities, plus the provider's own extra fields. A provider that does not
 * surface a catalog description passes no `description` extra.
 * @param provider - the provider route the row belongs to.
 * @param model - the discovered entry.
 * @param inputModalities - modalities to advertise; undefined leaves the field off.
 * @param extras - provider-specific row fields.
 * @returns the picker row.
 */
export declare function catalogRow(provider: string, model: DiscoveredModel, inputModalities: readonly ('text' | 'image')[] | undefined, extras?: CatalogRowExtras): LlmModelInfo;
/**
 * One provider's picker rows: its own catalog plus any configured pool tiers
 * the catalog does not already list. An account pool reuses the catalog row of
 * the same wire id for its members, so only configured tiers are extra.
 * @param own - the provider's own rows.
 * @param pool - the provider's account pool, when one is configured.
 * @param provider - the provider route the pool is keyed by.
 * @returns the own rows followed by the unseen pool rows.
 */
export declare function withPoolTiers(own: readonly LlmModelInfo[], pool: CatalogTierSource | undefined, provider: string): Promise<readonly LlmModelInfo[]>;
export {};
