/**
 * Plumbing shared by the subscription adapters: HTTP error mapping, a
 * stream idle watchdog, fetch failure classification, OAuth endpoint errors,
 * and the per-provider {@link TokenManager} that owns session freshness.
 * Concurrent refreshes for one provider coalesce behind a single in-flight
 * promise (`inflight`), so a rotating refresh token is never spent twice.
 */
import { LlmError, ReasoningEffortId } from '@deepseek-ai/dsh-llm';
import type { RateLimitResetReader } from './rate-limit.js';
import type { UnifiedRateLimitState } from './unified-rate-limit.js';
/** One configured model catalog entry. */
export interface ModelEntry {
    /** Wire model id; must be non-empty. */
    id: string;
    /** Selector label; defaults to the id. */
    name?: string;
    /** Known combined request/response context capacity. */
    contextWindow?: number;
    /** Per-request output cap for this model. */
    maxTokens?: number;
    /** Accepted request modalities; when set, wins over the provider default. */
    inputModalities?: ('text' | 'image')[] | undefined;
    /**
     * Force this model's upstream protocol. Only the copilot adapter consumes
     * the semantics; the union is inlined here to avoid a circular import of
     * the copilot module's `CopilotWire`.
     */
    wire?: 'chat-completions' | 'responses';
}
/**
 * Validate a configured model catalog (mirrors llm-deepseek's resolveModels).
 * @param models - raw configured entries.
 * @param label - diagnostic prefix naming the provider.
 * @returns the validated entries.
 */
export declare function validateModels(models: readonly ModelEntry[], label: string): ModelEntry[];
/**
 * Failure code for a refusal the provider stated it will not accept a retry
 * for. No subscription route lists it among its retryable codes, so the turn
 * ends on it, and the pool parks the refusing account rather than asking
 * another one the same question.
 */
export declare const ENFORCEMENT_CODE = "ENFORCEMENT";
/**
 * Whether provider error text names a billing or credit refusal.
 *
 * The same wording decides a response's classification here and an in-band
 * error event's classification in the stream translators, so a refusal is read
 * by one rule whichever half of the exchange carries it.
 * @param text - the provider's error type and message, as the provider wrote them.
 * @returns true when the text names a billing or credit refusal.
 */
export declare function namesBillingRefusal(text: string): boolean;
/**
 * Whether a failed response is a refusal the provider stated is final, as
 * opposed to a rate limit whose window simply reopens.
 *
 * The signals are the provider's own, and the genuine client stops retrying on
 * every one of them: `x-should-retry: false`, a unified status of `rejected`,
 * a disabled organisation/seat/member reason, billing or credit wording, and a
 * 429 that disclosed no reset at all — a refusal with no window to wait out
 * can only be retried blind, straight back into the block.
 * @param response - the failed response, for its headers.
 * @param body - the complete response body.
 * @param reset - the reset instant the caller resolved, when one was disclosed.
 * @param now - the current epoch milliseconds.
 * @returns true when the refusal must not be retried or answered from another account.
 */
export declare function isEnforcementRefusal(response: Response, body: string, reset: number | undefined, now: number): boolean;
/** Optional per-call hooks {@link httpLlmError} uses to read a rate-limit window. */
interface HttpLlmErrorOptions {
    /**
     * The calling provider's reader for the instant its rate-limit window
     * reopens. Consulted on a 429 only, and there ahead of the generic
     * `retry-after` header, because a provider's own field names the window while
     * `retry-after` often names a short backoff.
     */
    rateLimitReset?: RateLimitResetReader;
    /** Provider-specific retry headers; absent preserves the shared retry-after reader. */
    retryHeaderReset?: (response: Response, now: number) => number | undefined;
    /** Diagnostic sink for a 429 that disclosed no reset instant this code recognizes. */
    onWarn?: (message: string) => void;
}
/** Inputs the shared, provider-neutral HTTP failure classification reads. */
export interface SharedHttpFailureInput {
    /** The failed response, for its status and headers. */
    readonly response: Response;
    /** The complete response body. */
    readonly body: string;
    /** The reset instant the caller resolved, when one was disclosed. */
    readonly reset: number | undefined;
    /** Current epoch milliseconds. */
    readonly now: number;
    /** Whether the status was 429. */
    readonly rateLimited: boolean;
}
/**
 * The ordered status and refusal classification every subscription route shares.
 *
 * A route with its own ordering composes around this rather than restating it: it decides
 * the cases its provider adds first, then delegates here, so a shared rule changes in one
 * place. Returns undefined for a status this table does not name, which the caller reports
 * as its own `HTTP_<status>` code.
 * @param input - the failed response and the instant facts the table reads.
 * @returns the stable failure code, or undefined for an unnamed status.
 */
export declare function sharedHttpFailureCode(input: SharedHttpFailureInput): string | undefined;
/**
 * The message one failed response reports: the diagnostic label, the status, and the
 * provider's own structured error fields — never the raw body.
 * @param label - diagnostic prefix naming the provider API.
 * @param response - the failed response.
 * @param body - the complete response body.
 * @returns the message to report.
 */
export declare function httpFailureMessage(label: string, response: Response, body: string): string;
/**
 * Build an LlmError from a non-2xx provider response, mapping the status to a
 * stable code and, for a rate-limited request, the disclosed reset instant to
 * the `providerRetryAfterMs` the retry plugin waits out.
 *
 * A 429 classifies as `RATE_LIMIT` on the strength of the status alone, ahead
 * of the quota-wording check. On these routes there is no terminal quota to
 * distinguish: a subscription has no balance to top up, only a window that
 * reopens, and providers announce an exhausted window with wording
 * (`usage_limit_reached`) the shared classifier reads as permanent.
 *
 * {@link isEnforcementRefusal} takes precedence over that: a refusal the
 * provider stated is final — its own stop-retry header, a `rejected` unified
 * status, a disabled account reason, billing or credit wording, or a 429 that
 * disclosed no window — classifies as {@link ENFORCEMENT_CODE}, which no route
 * retries and no pool answers from another account.
 * @param response - the failed response.
 * @param label - diagnostic prefix naming the provider API.
 * @param options - the calling provider's rate-limit reader and warning sink.
 * @returns the classified error.
 */
export declare function httpLlmError(response: Response, label: string, options?: HttpLlmErrorOptions): Promise<LlmError>;
/** An idle watchdog: aborts its signal when no SSE activity arrives within the timeout. */
interface IdleWatchdog {
    /** Signal to pass to fetch and body reads; aborts on caller cancel or idle expiry. */
    readonly signal: AbortSignal;
    /** Reset the idle timer (call on every received SSE event). */
    pulse(): void;
    /** Stop the timer and detach from the caller signal. */
    stop(): void;
    /** Whether the last abort came from idle expiry rather than caller cancellation. */
    timedOut(): boolean;
}
/**
 * Create an idle watchdog chained to the caller's signal.
 * @param caller - the request's own abort signal, when present.
 * @param timeoutMs - maximum idle interval while a stream read is outstanding.
 * @returns the watchdog; always {@link IdleWatchdog.stop} it when the stream ends.
 */
export declare function idleWatchdog(caller: AbortSignal | undefined, timeoutMs: number): IdleWatchdog;
/**
 * Classify a thrown fetch failure. Caller cancellation maps to ABORTED, idle
 * expiry to TIMEOUT, and everything else (DNS, TLS, refused connection) to
 * TRANSPORT with the cause chained.
 * @param label - diagnostic prefix naming the provider API.
 * @param error - the thrown value.
 * @param watchdog - the request's idle watchdog.
 * @param caller - the request's own abort signal, when present.
 * @returns the classified error.
 */
export declare function mapFetchFailure(label: string, error: unknown, watchdog: IdleWatchdog, caller: AbortSignal | undefined): LlmError;
/** OAuth token-endpoint failure carrying the provider's `error` code when it sent one. */
export declare class OAuthEndpointError extends Error {
    /** HTTP status of the token endpoint response. */
    readonly status: number;
    /** The provider's OAuth `error` code (e.g. `invalid_grant`), when present. */
    readonly oauthCode: string | undefined;
    /**
     * The endpoint's `retry-after`, in ms, when it sent one. Usage/models
     * endpoints reuse this error type and can rate-limit progressively (each
     * hit within the window extends the next one), so a caller retrying on a
     * fixed schedule instead of honoring this can keep an account locked out
     * indefinitely.
     */
    readonly retryAfterMs: number | undefined;
    constructor(message: string, status: number, oauthCode?: string, retryAfterMs?: number);
}
/**
 * Read an OAuth JSON error body into an {@link OAuthEndpointError}.
 * @param response - the failed token-endpoint response.
 * @param label - diagnostic prefix naming the provider.
 * @returns the error to throw.
 */
export declare function oauthEndpointError(response: Response, label: string): Promise<OAuthEndpointError>;
/** A session fresh enough to serve a request without a refresh. */
interface TimedSession {
    accessToken: string;
    refreshToken: string;
    expiresAt: number;
}
/** Provider hooks the token manager needs. */
export interface TokenManagerOptions<S extends TimedSession> {
    /** Human-readable provider name for error messages. */
    displayName: string;
    /** Refresh this long before `expiresAt`. */
    preemptMs: number;
    load(): Promise<S | undefined>;
    /**
     * Read the stored session together with the revision it is stored under, in ONE read.
     *
     * This is the read a refresh spends its grant from, and it is deliberately not two calls:
     * reading the session and then the revision separately lets a logout and a same-token
     * re-login land between them, pairing the old session with the new revision so the
     * conditional write succeeds and overwrites the login. Absent falls back to
     * {@link load}, with the token comparison as the whole guard.
     * @returns the stored session and its revision; `session` is `undefined` when logged out.
     */
    loadCredential?(): Promise<{
        session: S | undefined;
        revision: number | undefined;
    }>;
    /**
     * Persist a refresh result under the manager's own scope key. The store is
     * the authority, and the manager re-reads after every save, so an
     * implementation need not report a conditional write it refused.
     * @param session - the refreshed session to store.
     * @param expectedPrior - the session the refresh spent.
     * @param expectedRevision - the revision that session was read under.
     */
    save(session: S, expectedPrior?: S, expectedRevision?: number): Promise<void>;
    /**
     * Delete the stored session. With `expectedPrior`, the store deletes it only
     * while it is still that session, so a removal cannot destroy a login or a
     * rotation that landed after the caller read it.
     * @param expectedPrior - the session this refresh spent, when one was attempted.
     * @param expectedRevision - the revision that session was read under.
     * @returns true when the session was removed, false when the removal was
     *   refused because the store held something else. An implementation may
     *   return nothing, which reads as removed.
     */
    remove(expectedPrior?: S, expectedRevision?: number): Promise<void | boolean>;
    /** Perform the provider's refresh-token grant. */
    refresh(session: S): Promise<S>;
    /** Whether a refresh failure is permanent (re-login required). */
    isPermanent(error: unknown): boolean;
    /** Called when a permanent refresh failure actually deleted the stored session. */
    onRemoved?(): void;
    /**
     * Run one account's whole refresh cycle — re-read the store, spend the grant, save —
     * under cross-process ownership, so two cooperating processes sharing one credential
     * store cannot both spend the same refresh grant. Absent keeps the in-process
     * single-flight and the store's conditional write alone.
     *
     * Ownership is a precondition, not a hint: a cycle that cannot own the scope must not
     * run, because rotating without it is exactly the double-spend this prevents. The
     * manager answers a refusal with {@link REFRESH_BUSY_CODE} so a caller with a still-valid
     * credential keeps it instead of sending an expired one.
     * @param cycle - the read-refresh-save sequence to run while owned.
     * @returns the cycle's outcome, or `{ acquired: false }` when another owner held it.
     */
    withRefreshOwnership?<T>(cycle: () => Promise<T>): Promise<RefreshOwnershipOutcome<T>>;
}
/**
 * The failure a refresh reports when another owner holds cross-process refresh ownership
 * for the account and the wait was exhausted.
 *
 * Deliberately neither `AUTH` nor `INVALID_CREDENTIAL`: no grant was spent and nothing was
 * refused by the provider, so the credential is untouched and the caller may retry. It is
 * not retryable by the pool either — the pool's classifier fails the turn on an unknown
 * code without parking the account.
 */
export declare const REFRESH_BUSY_CODE = "REFRESH_BUSY";
/**
 * What a {@link TokenManagerOptions.withRefreshOwnership} implementation reports.
 * @typeParam T - the value the owned cycle produces.
 */
export type RefreshOwnershipOutcome<T> = {
    readonly acquired: true;
    readonly value: T;
} | {
    readonly acquired: false;
};
/**
 * Per-provider session freshness: loads the stored session, refreshes
 * proactively inside the preempt window or on demand after a 401, and
 * coalesces concurrent refreshes behind one in-flight promise. Permanent
 * refresh failures delete the stored session and surface INVALID_CREDENTIAL
 * with a re-login hint; transient failures fall back to a still-valid token.
 *
 * The stored session is the authority. A refresh answers with what the store
 * holds after the write, so a save the store refused — a logout, a re-login or
 * a concurrent rotation that won the compare-and-set — is never returned, and a
 * scope whose session disappeared while the refresh ran fails
 * MISSING_CREDENTIAL instead of reviving the credential the caller still holds.
 * A permanent failure likewise deletes the session it spent only while the
 * store still holds it, serves a login that landed in the meantime, and reports
 * the removal once.
 */
export declare class TokenManager<S extends TimedSession> {
    private readonly options;
    private inflight;
    /** The session whose refresh token the in-flight refresh is spending. */
    private attempted;
    /** The revision that session was read under, when the backend keeps one. */
    private attemptedRevision;
    constructor(options: TokenManagerOptions<S>);
    /**
     * Read the stored session without any refresh side effect. Catalog queries
     * (`listModels`) use this to decide whether the provider is logged in.
     * @returns the stored session, or `undefined` when logged out.
     */
    peek(): Promise<S | undefined>;
    /**
     * Whether a session is currently stored (cheap; never refreshes).
     * @returns true when logged in.
     */
    hasSession(): Promise<boolean>;
    /**
     * Resolve a usable session, refreshing proactively or on demand.
     * @param forceRefresh - refresh regardless of expiry (used after a 401).
     * @returns the persisted session to send.
     * @throws LlmError MISSING_CREDENTIAL when logged out — including a scope
     *   whose session was removed while its refresh was in flight, which is never
     *   revived and never answered with the pre-logout credential;
     *   INVALID_CREDENTIAL when the refresh grant is permanently rejected.
     */
    session(forceRefresh?: boolean): Promise<S>;
    /** The logged-out result for this manager's own scope. */
    private missingCredential;
    private doRefresh;
    private refreshCycle;
    /**
     * Persist a caller-updated session without touching refresh state. Identity
     * backfill (minted device id, discovered account uuid) uses this; the next
     * {@link session} read loads the updated copy from the store.
     * @param session - the updated session to store.
     * @param expectedPrior - the stored session this update was derived from. The
     *   store refuses the write once another writer has replaced it, so a backfill
     *   cannot roll a rotation back.
     * @param expectedRevision - the revision that stored session was read under. A
     *   caller that read the session and its revision together passes it so a
     *   write derived from that read is refused once the record has moved on —
     *   including by a write that left the credential fields identical, such as an
     *   ownership-mode change, a logout or a same-token re-login. Absent keeps the
     *   session comparison as the whole guard.
     */
    replace(session: S, expectedPrior?: S, expectedRevision?: number): Promise<void>;
}
/** Fetch signature adapters accept for discovery calls (injectable for tests). */
export type FetchFn = typeof fetch;
/** Bound on one account catalog fetch or usage poll — a hang must not block the picker. */
export declare const DISCOVERY_TIMEOUT_MS = 10000;
/**
 * Run `work` with an aborting signal. Resolves undefined when the timeout
 * fires (the fetch is aborted); other failures propagate.
 */
export declare function withTimeout<T>(work: (signal: AbortSignal) => Promise<T>, timeoutMs: number): Promise<T | undefined>;
/** One rate-limit window reported by a provider's usage endpoint. */
export interface UsageWindow {
    /** Window kind: `session` for the short rolling window, `weekly` for the 7-day one. */
    kind: 'session' | 'weekly' | 'other';
    /** Model scope for model-specific windows (e.g. `Opus`), when the provider names one. */
    scope?: string;
    /** Percent of the window already consumed (0–100). */
    usedPercent: number;
    /** Epoch milliseconds at which the window resets, when the provider discloses it. */
    resetsAt?: number;
}
/** One banked ChatGPT rate-limit reset credit, as listed by the credits endpoint. */
export interface ResetCredit {
    /** Provider credit id. Sent back unchanged on consume. */
    id: string;
    /** `available` credits can be spent; anything else is display-only. */
    status: 'available' | 'redeemed' | 'expired' | 'other';
    title?: string;
    description?: string;
    /** ISO timestamp from the provider, when present. */
    grantedAt?: string;
    /** ISO timestamp from the provider, when present. */
    expiresAt?: string;
    /** Provider reset type, such as `codex_rate_limits`. */
    resetType?: string;
}
/** `resetCredits` endpoint value. `supported: false` when the provider has no credits. */
export interface ResetCreditList {
    supported: boolean;
    /** Credits that can still be spent, when the provider disclosed a count. */
    availableCount?: number;
    credits?: ResetCredit[];
}
/**
 * `consumeResetCredit` endpoint value. A resolved result means the provider
 * accepted the spend (HTTP 200); callers refetch usage for the new windows.
 */
export interface ResetCreditConsumeResult {
    code?: string;
    windowsReset?: number;
}
/**
 * How fresh a usage payload is, from the reader's point of view. A payload read
 * from cache without an upstream round trip is `missing`, `stale` or `error`
 * rather than absent, so a display surface can say what it knows instead of
 * presenting a never-observed account as an empty one.
 */
export type UsageCacheState = 'fresh' | 'stale' | 'missing' | 'error' | 'refreshing';
/**
 * Safe classification of a failed usage read. It carries no provider message,
 * token or response body, so it is safe to persist and to show.
 */
export type UsageFailureReason = 'rate_limited' | 'unauthorized' | 'unreachable' | 'invalid_response' | 'unknown';
/** Freshness of one usage payload, alongside the windows it describes. */
export interface UsageCacheMeta {
    /** Freshness of the payload this metadata accompanies. */
    state: UsageCacheState;
    /** Epoch milliseconds of the newest observation behind the payload, when one exists. */
    observedAt?: number;
    /** Epoch milliseconds a recorded failure stops suppressing upstream reads. */
    retryAt?: number;
    /** Why the last upstream read failed, when one did. */
    error?: UsageFailureReason;
}
/** Subscription usage of one provider, as served by the `usage` RPC endpoint. */
export interface ProviderUsage {
    /** False when the provider has no usage endpoint (grok); windows are absent then. */
    supported: boolean;
    /** Usage windows in display order. */
    windows?: UsageWindow[];
    /** Plan name the usage endpoint reported, when present. */
    plan?: string;
    /**
     * Banked rate-limit reset credits, when this usage payload disclosed a count.
     * Absent means the provider did not report the field — not "zero credits".
     */
    resetCredits?: {
        availableCount: number;
        /** Earliest expiry among available credits, epoch ms. Pool selection only. */
        soonestExpiresAt?: number;
    };
    /**
     * The unified rate-limit report of this account's last answered request, when
     * one was captured. It states the account's standing more precisely than the
     * usage windows do — a `rejected` status is the provider refusing requests —
     * and is absent for accounts that have not issued a request since startup.
     */
    rateLimit?: UnifiedRateLimitState;
    /**
     * The account pool's view of this account, present only while the pool is
     * enabled. It is what separates a pool condition (another account is serving
     * instead) from a fact about this account alone.
     */
    pool?: UsagePoolState;
    /**
     * Freshness of this payload. Present for reads served from the plugin's own
     * usage cache — which is every read that did not just perform an upstream
     * round trip — and absent when the payload came straight from a provider
     * fetcher with no cache in front of it.
     */
    cache?: UsageCacheMeta;
}
/** The account pool's view of one account, as the `usage` endpoint reports it. */
export interface UsagePoolState {
    /**
     * Why the pool parked this account: `auth` when the stored login stopped
     * working (only a re-login clears it), `quota` for a spent allowance or a
     * rate limit. Read only together with `coolingUntil`.
     */
    coolingReason?: 'auth' | 'quota';
    /** Epoch ms the pool parks this account until; absent when it is not parked. */
    coolingUntil?: number;
    /**
     * Whether another account that may serve this provider's pool is clear right
     * now. False when the pool is disabled, the account is the only member, or
     * every other member is parked or past a usage floor the pool reserves.
     */
    peerAvailable: boolean;
}
/** One model discovered from a provider's live model-list endpoint. */
export interface DiscoveredModel {
    /** Account-specific server-advertised ceiling for local context overrides. */
    maxContextWindow?: number;
    /** Wire model id. */
    id: string;
    /** Human-readable display name. */
    name: string;
    description?: string;
    /**
     * The reason the provider's catalogue marks this entry unavailable to the account,
     * or absent when it is selectable. The row stays listed so the picker can show a
     * model the account cannot use instead of dropping it silently.
     */
    disabledReason?: string;
    /** Advertised combined context capacity in tokens. */
    contextWindow?: number;
    /** Server-advertised per-request output token ceiling, when disclosed. */
    maxOutputTokens?: number;
    /** Provider sort hint; lower sorts earlier. */
    priority?: number;
    /** Advertised reasoning efforts, when the provider discloses them. */
    reasoning?: {
        efforts: {
            id: ReasoningEffortId;
            name: string;
            description?: string;
        }[];
        defaultEffort?: ReasoningEffortId;
    };
    /** Accepted request modalities the endpoint advertised (e.g. Copilot's vision support flag). */
    inputModalities?: ('text' | 'image')[];
    /** The catalog advertises a fast tier (Codex priority service, Cursor's `fast` parameter, or Claude's `fast_mode` capability). */
    fastTier?: boolean;
    /**
     * Cursor `models.list` parameters. Sent back as `model.params`.
     * Other providers leave this unset.
     */
    cursorParameters?: {
        id: string;
        values: {
            value: string;
            name?: string;
        }[];
    }[];
    /** Cursor default variant parameter values. */
    cursorDefaults?: {
        id: string;
        value: string;
    }[];
    /** Copilot-specific: which upstream protocol the model's endpoints speak. */
    copilotWire?: 'chat-completions' | 'responses';
    /**
     * Copilot-specific: the catalog also lists `/responses` for this model
     * (dual-protocol entries, e.g. gpt-5.4), so a chat-wire request may reroute
     * there when it combines function tools with a reasoning effort.
     */
    copilotResponses?: boolean;
}
/** Display name for a wire reasoning-effort identifier. */
export declare function effortDisplayName(effort: string): string;
/** The reasoning-block shape every caller passes to {@link mergeReasoning}. */
interface ReasoningBlock {
    efforts: readonly {
        id: ReasoningEffortId;
        name: string;
        description?: string;
    }[];
    defaultEffort?: ReasoningEffortId;
}
/**
 * Fold a configured per-model default effort into a reasoning block, keeping
 * the DSH runtime invariant `defaultEffort ∈ efforts` (the runtime rejects an
 * unknown default with `INVALID_MODEL_REASONING`).
 *
 * A configured level the base set does not advertise is *dropped*, not
 * appended: for claude/grok/copilot the base is the provider's live catalog,
 * i.e. the truth about what the model accepts, so honouring a stale override
 * would put an unsupported effort on every single request instead of letting
 * the harness reject it before provider I/O. The override then simply falls
 * back to the provider's own default until the user picks a level the catalog
 * still lists.
 *
 * `extendable` opts into the opposite rule for a base that is a *built-in
 * fallback* rather than discovered truth (codex, whose static effort list is
 * known to trail the backend): there, appending the configured level is how a
 * newly shipped tier becomes selectable at all.
 * @param configuredDefault - the user-configured default effort id, or undefined.
 * @param base - the discovered/built-in reasoning block, or undefined.
 * @param options - `extendable` marks the base as a fallback that may be extended.
 * @returns the merged block, or undefined when neither side contributes one.
 */
export declare function mergeReasoning(configuredDefault: string | undefined, base: ReasoningBlock | undefined, options?: {
    extendable?: boolean;
}): DiscoveredModel['reasoning'] | undefined;
/**
 * First account catalog that lists `model` (callers pass default-first).
 *
 * One failing lookup sits that account out so a sibling's metadata still
 * resolves — the same isolation as the picker catalog union.
 *
 * Deliberately unfiltered by the pool health registry. This answers "what does
 * this model support", not "who serves the next turn": the account list is every
 * logged-in account, a catalogue read carries no completion request, and the
 * route that actually serves is chosen by the pool's own selection, which applies
 * health and the usage floors. Filtering parked accounts here would instead drop
 * the capability metadata an in-flight session depends on for exactly as long as
 * its account is cooling. A parked account whose credential no longer resolves
 * still sits out through the lookup's own failure.
 * @param accounts - the accounts to ask, default first.
 * @param lookup - one account's catalog reader.
 * @returns the first entry found, or undefined when no account lists the model.
 */
export declare function discoverAcrossAccounts(accounts: readonly string[], lookup: (account: string) => Promise<DiscoveredModel | undefined>): Promise<DiscoveredModel | undefined>;
/**
 * How long a discovered catalogue is trusted before an explicit event may
 * refresh it. Freshness is only ever read at those events: no timer and no read
 * path consults it. A route overrides it with `catalogMaxAgeMs`.
 */
export declare const DEFAULT_CATALOG_MAX_AGE_MS: number;
/**
 * Failure cooldown applied when a catalogue request failed without disclosing a
 * `retry-after`, so one outage is not re-queried at every explicit event. A route
 * overrides it with `cacheRetryDelayMs`.
 */
export declare const DEFAULT_CACHE_RETRY_DELAY_MS = 60000;
/** A durable snapshot of one provider account's discovered catalogue. */
export interface CatalogSnapshot {
    /** Epoch milliseconds of the successful fetch that produced it. */
    at: number;
    /**
     * The models the provider advertised. An empty array is an authoritative
     * "this account lists nothing", distinct from having no snapshot at all.
     */
    models: DiscoveredModel[];
}
/**
 * One failed catalogue request's cooldown, persisted beside the last good
 * snapshot so a RESTART still honours a `retry-after` the provider disclosed.
 * It carries no models and no fetch time: it is a hint about when the next
 * request may run, never a catalogue, and never a fabricated `at`.
 */
export interface CatalogFailure {
    /** Epoch milliseconds before which no catalogue request may run again. */
    notBefore: number;
}
/**
 * The durable state of one provider account's catalogue: the last good snapshot
 * and the last failure's cooldown, either of which may be absent on its own. A
 * cold account that failed holds a failure alone — nothing is invented to make
 * it look like a catalogue that was ever fetched.
 */
export interface CatalogRecord {
    /** The last successfully stored catalogue, when one exists. */
    snapshot?: CatalogSnapshot;
    /** The last failed request's cooldown, while it is still meaningful. */
    failure?: CatalogFailure;
}
/** The durable half of a {@link ModelCatalogCache} for ONE provider account. */
export interface CatalogPersistence {
    /** The persisted record, or undefined when the account has none. */
    load(): Promise<CatalogRecord | undefined>;
    /**
     * Persist a fresh snapshot (write-through after every successful fetch). A
     * stored failure is dropped: its cooldown belongs to the request that failed,
     * and this one answered.
     */
    save(snapshot: CatalogSnapshot): Promise<void>;
    /**
     * Persist a failure's cooldown, keeping the last good snapshot if there is
     * one. Optional on a double that keeps no durable state.
     */
    saveFailure?(failure: CatalogFailure): Promise<void>;
    /** Drop the persisted record (the login or the catalogue identity changed). */
    clear(): Promise<void>;
}
/**
 * Durable store factory a route supplies so EVERY logged-in account keeps its
 * own catalogue, not only the default one. The key is the account key.
 *
 * The two provider-wide operations exist for a logout that must drop records no
 * in-memory cache holds: an account removed before its cache was ever built.
 * Both are optional so a test double may implement only the per-account half.
 */
export interface CatalogStoreFactory {
    /** The persistence hooks for one account key (usable without building a cache). */
    (account: string): CatalogPersistence;
    /** Account keys this provider has a persisted entry for, without loading any. */
    accounts?(): Promise<readonly string[]>;
    /** Drop every persisted entry of this provider, cache or no cache. */
    clearAll?(): Promise<void>;
}
/** One account's explicit catalogue-refresh outcome. */
export type CatalogRefreshOutcome = {
    status: 'fetched';
    models: readonly DiscoveredModel[];
}
/** Nothing was requested: the entry is fresh, or a failure is still cooling down. */
 | {
    status: 'skipped';
    reason: 'fresh' | 'cooldown';
}
/** The caller stopped waiting; the shared request continues for other waiters. */
 | {
    status: 'cancelled';
};
/** What one provider-wide explicit refresh requested, skipped, cancelled or failed. */
export interface CatalogRefreshReport {
    /** Accounts whose catalogue this call requested from the provider. */
    fetched: readonly string[];
    /** Accounts answered from cache: nothing was missing/stale, or a failure is cooling down. */
    skipped: readonly string[];
    /** Accounts whose request ran and failed; each keeps its last-known catalogue. */
    failed: readonly string[];
    /** Accounts whose caller stopped waiting before the shared request settled. */
    cancelled: readonly string[];
}
/** Durability, freshness bounds and warning sink of one {@link ModelCatalogCache}. */
export interface ModelCatalogCacheOptions {
    /** Durable half for this account; absent keeps the cache in memory only. */
    persistence?: CatalogPersistence;
    /** Freshness window; stale makes the entry eligible for an explicit refresh. */
    maxAgeMs?: number;
    /** Failure cooldown when the failure disclosed no `retry-after`. */
    retryDelayMs?: number;
    /** Warning sink for an unreadable cache file or a failed save. */
    onWarn?: (message: string) => void;
    /** Provider name in warnings, e.g. `codex`. */
    label?: string;
    /**
     * Called once when a refresh STORES a catalogue that differs from what was
     * stored before. It belongs to the accepted result rather than to any waiting
     * caller: several callers share one request, a caller that detached still
     * leaves that request running, and one stored catalogue is one notification.
     */
    onStored?: () => void;
}
/**
 * ONE provider account's discovered-model catalogue.
 *
 * Reads ({@link read}, {@link lastKnown}) are pure: they may load the local
 * cache file, they never start a provider request, and a stale entry is served
 * as-is. Capability metadata (reasoning efforts) must stay stable for a session
 * that selected an effort, so losing it to a lapsed window would fail
 * mid-conversation calls with UNSUPPORTED_REASONING_EFFORT before provider I/O.
 *
 * {@link refresh} is the only path that starts a request, and it runs only when
 * an explicit event asks for it. It coalesces concurrent callers into one
 * request, keeps the last good snapshot when the request fails, and records a
 * failure cooldown so repeated events do not re-query a failing provider.
 * {@link invalidate} drops memory and disk and bumps the generation, so an
 * in-flight request that lost that race cannot write its result back.
 */
export declare class ModelCatalogCache {
    private readonly options;
    private entry;
    private inflight;
    /** Settles once the persisted snapshot (when any) has been considered. */
    private seeded;
    /** Set by {@link invalidate} so an in-flight disk read cannot resurrect dropped state. */
    private seedDisabled;
    /** Bumped by {@link invalidate} so a loser in-flight request cannot write back. */
    private generation;
    /** Epoch ms before which a refresh is skipped after a failure. */
    private retryNotBefore;
    /** Every request and cache clear still running, so a route can drain them. */
    private readonly work;
    private readonly maxAgeMs;
    private readonly retryDelayMs;
    constructor(options?: ModelCatalogCacheOptions);
    /**
     * The last-known catalogue for this account, from memory or the local cache
     * file. Pure: it starts no provider request, however cold or stale it is.
     * @returns the models, or `undefined` when nothing is known. `[]` is a known
     *   catalogue that lists nothing, not an absent one.
     */
    read(): Promise<readonly DiscoveredModel[] | undefined>;
    /**
     * The last-known catalogue already in memory, ignoring freshness.
     * @returns the models, or `undefined` before anything has been seeded or fetched.
     */
    lastKnown(): readonly DiscoveredModel[] | undefined;
    /** Whether the entry is missing or older than the freshness window. */
    stale(): boolean;
    /**
     * Load the persisted record once; a request or invalidate that landed first
     * wins. Both halves are seeded: the last good catalogue and, when it has not
     * lapsed, the cooldown a failed request left behind — so a restart does not
     * re-ask a provider that named its own retry instant.
     */
    private ensureSeeded;
    /** Track work a route must be able to drain before it is dropped. */
    private track;
    /** Write the snapshot through, reporting a save failure without losing memory state. */
    private persist;
    /**
     * Persist a failure's cooldown, so the wait the provider disclosed survives a
     * restart. Reported rather than thrown: failing to remember it costs one
     * extra request, which is what the memory-only behaviour cost anyway.
     */
    private persistFailure;
    /** Run (or join) the single in-flight request, updating memory and disk on success. */
    private run;
    /**
     * Request this account's catalogue from the provider: the only path that
     * starts a provider request. Concurrent callers share one request, and a
     * failure keeps the last good snapshot in place.
     * @param fetcher - performs the provider's model-list request.
     * @param options - `force` re-requests a fresh SUCCESS snapshot (an explicit
     *   user refresh); it never bypasses a live failure cooldown, which is the
     *   retry storm that cooldown exists to prevent. `signal` detaches THIS waiter
     *   alone; the shared request continues for the others.
     * @returns what this call did. A failed request rejects. A request that was
     *   invalidated mid-flight (a logout dropped the account) still reports
     *   `fetched`, because it ran, but its result is not stored.
     */
    refresh(fetcher: () => Promise<readonly DiscoveredModel[]>, options?: {
        force?: boolean;
        signal?: AbortSignal;
    }): Promise<CatalogRefreshOutcome>;
    /**
     * Drop the cached catalogue: memory, the persisted entry, and the generation
     * an in-flight request would need to write back. The next refresh re-reads it.
     */
    invalidate(): void;
    /**
     * Forget a failure cooldown so ONE immediate retry may run, for a caller that
     * has just renewed the credential the failed attempt used. The cooldown is
     * meant for a provider that keeps refusing, not for the same request retried
     * with a fresh token; a retry that also fails re-arms it, and one that answers
     * clears the persisted hint with the snapshot it stores.
     */
    clearFailureCooldown(): void;
    /**
     * Await every request and cache clear still running, without starting new
     * work, so a route being dropped leaves no write behind.
     */
    drain(): Promise<void>;
    /** The provider name warnings are prefixed with. */
    private label;
}
/** Whether discovery failed because the stored login is gone. */
export declare function isMissingOrInvalidCredential(error: unknown): boolean;
/** Whether discovery stopped because the caller cancelled or the timeout fired. */
export declare function isDiscoveryAborted(error: unknown, signal?: AbortSignal): boolean;
/**
 * Run a catalog fetch, retrying once after a forced token refresh when the
 * first attempt is a 401/AUTH. The retry clears the failure cooldown the first
 * attempt armed — the credential it needed has just been renewed, so this one
 * retry is warranted — and only {@link ModelCatalogCache.invalidate}s when the
 * retry is also an auth failure, so a refresh race cannot erase last-known
 * capability metadata.
 */
export declare function discoverOrRetryAuth<T>(session: (forceRefresh?: boolean) => Promise<unknown>, catalog: ModelCatalogCache, run: () => Promise<T>): Promise<T>;
/**
 * Keep Codex's session header stable for a supplied, non-empty session ID.
 * Existing UUIDs are preserved; other IDs use a SHA-256-derived UUIDv8 (a
 * custom deterministic layout). UUID formatting is a client convention,
 * not a claim about gateway validation or guaranteed prompt-cache hits.
 * Missing and empty IDs have no session identity and receive a fresh UUIDv4.
 */
export declare function deterministicSessionId(sessionId?: string): string;
export {};
