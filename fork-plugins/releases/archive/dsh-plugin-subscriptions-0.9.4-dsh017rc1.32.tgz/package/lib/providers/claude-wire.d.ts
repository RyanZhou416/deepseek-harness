import type { ContextManagementConfig } from '@tormentalabs/claude-code-wire-compat';
import type { BuiltClaudeCodeRequest, ClaudeCodeRequestInput } from '@tormentalabs/claude-code-wire-compat';
import { LlmError } from '@deepseek-ai/dsh-llm';
import type { GenerateOptions } from '@deepseek-ai/dsh-llm';
import type { ClaudeSession } from '../auth/store.js';
import type { TranslatableMessage } from '../translate/resolved.js';
import type { ClaudeEnginePolicy } from '../claude-engine/request-policy.js';
/**
 * Pinned CLI identity this route presents on every subscription endpoint.
 *
 * The compatibility profile owns the claim; this is the name the request-building path
 * already used for it.
 */
export declare const CLAUDE_USER_AGENT: string;
/**
 * The user agent the client uses on endpoints that are not the transport.
 *
 * The client has two: the transport one carries the entrypoint clause (what
 * {@link CLAUDE_USER_AGENT} is), and the plain one is `claude-code/<version>` with no
 * qualifier. Bootstrap, the OAuth profile read and the Files API use the plain form, so a
 * client process emits both and this plugin has to as well.
 */
export declare const CLAUDE_PLAIN_USER_AGENT: string;
/** The `thinking` object this module maps onto the wire (display is fixed here). */
export interface ClaudeWireThinking {
    type: 'enabled' | 'adaptive';
    budgetTokens?: number;
}
/** A two-level string-keyed table whose total leaf count is bounded. */
interface BoundedTwoLevelMap<V> {
    /**
     * @param outer - first-level key.
     * @param inner - second-level key.
     * @returns the value stored under both keys, or undefined.
     */
    get(outer: string, inner: string): V | undefined;
    /**
     * @param outer - first-level key.
     * @returns whether that entry holds any leaf.
     */
    isEmpty(outer: string): boolean;
    /**
     * Store a value under both keys; a leaf that already exists is replaced in
     * place. A new leaf inserted at the limit evicts the table's oldest leaf.
     * @param outer - first-level key.
     * @param inner - second-level key.
     * @param value - value to store.
     */
    set(outer: string, inner: string, value: V): void;
    /**
     * @param outer - first-level key whose leaves are all dropped.
     */
    deleteOuter(outer: string): void;
    /** Drop every leaf. */
    clear(): void;
}
/**
 * Build a bounded two-level table.
 *
 * Leaf order is insertion order across the whole table: at the limit the
 * oldest leaf — the first leaf of the first non-empty first-level entry — is
 * evicted, and a first-level entry disappears with its last leaf. What the two
 * key levels mean and what the limit is belong to the caller.
 * @param limit - maximum number of leaves kept.
 * @returns a table bounded to that many leaves.
 */
export declare function boundedTwoLevelMap<V>(limit: number): BoundedTwoLevelMap<V>;
/**
 * The per-request facts the continuation owner prepared before this request is built.
 *
 * Every member is an explicit input. The wire session identity is the one the span store committed
 * for this request's span, the pin is the one that span froze (or nothing when it sends none), and
 * the previous request id is the one the log-derived selector chose — none of them is minted,
 * looked up or defaulted here, because a second source for any of them would disagree with the
 * durable one after a restart.
 */
export interface ClaudeWireContinuation {
    /** The wire session identity this request declares. */
    readonly sessionId: string;
    /** The `x-cc-atis` token the span froze, or undefined when it sends none. */
    readonly atisPin: string | undefined;
    /** The earlier turn's `request-id` this request chains, or undefined when it chains none. */
    readonly previousRequestId: string | undefined;
}
/**
 * The `cc_prompt_id` segment of the billing block: the request id for this turn.
 *
 * The genuine client mints a fresh UUIDv4 per user prompt turn and reuses it across
 * that turn's tool continuations. A random id there would be model-visible text that
 * no session event records, so this route derives it from the session identity and
 * the turn instead: the same session and turn always render the same bytes, and two
 * sessions never render the same id.
 *
 * @param sessionId - the wire session identity the request declares.
 * @param turn - the prompt turn ordinal within that session.
 * @returns a UUID-shaped id, the only form in which the block emits the segment; the
 *   digest carries a UUIDv4's version and variant nibbles.
 */
export declare function claudePromptId(sessionId: string, turn: number): string;
/**
 * Map a wire-builder rejection onto a harness error. `INPUT_TOO_LARGE` goes
 * through the logged image-offload path; every other code names a request
 * this assembly layer must reject, so it surfaces as INVALID_REQUEST with
 * the wire code instead of a generic transport failure.
 * @param error - the thrown builder error.
 * @param messages - resolved images in wire order, for the offload mapping.
 * @returns the mapped LlmError, or undefined for a non-wire error.
 */
export declare function mapClaudeWireError(error: unknown, messages: readonly TranslatableMessage[]): LlmError | undefined;
/**
 * The `speed` field a request carries for one session's tier.
 *
 * The client sends the field only on the fast tier, and it is also what the pinned builder
 * reads to push `fast-mode-2026-02-01`, so the body value and the beta identifier are decided
 * from this one input. Standard routing is the field's absence: a `"standard"` literal would be
 * a request no client sends.
 *
 * @param fast - whether the session serving this request selected the fast tier.
 * @returns the field to spread into the builder input, or nothing on standard routing.
 */
export declare function claudeSpeedField(fast: boolean): Pick<ClaudeCodeRequestInput, 'speed'>;
/**
 * The platform the anchored identity claims, and the architecture with it.
 *
 * The pinned profile is the Windows desktop, so these are constants rather than this
 * host's values: a client reporting `claude-desktop` for Windows while sending another
 * platform, or an architecture that application is not built for, contradicts itself, and
 * a host-specific value would also identify the operator.
 *
 * The runtime version is deliberately NOT pinned with them. The client reports the
 * version of the runtime that performs the fetch, so a constant names a runtime that
 * issued nothing: this route reports `process.version` of whichever runtime sends the
 * request, and the Bun transport reports its own.
 */
export declare const CLAUDE_CLIENT_OS = "Windows";
/** Architecture the Windows desktop application is built for. */
export declare const CLAUDE_CLIENT_ARCH = "x64";
/**
 * The request class the client reports for the call kind this route is issuing.
 *
 * The client derives the header from the query source that spawned the request: a compact query
 * reports `compaction`, and its own session-title generator runs under the
 * `generate_session_title` source, which reports `auxiliary`. Every other request this route
 * issues is the conversation's own Messages call, which reports `main`.
 *
 * The client sends the header unconditionally on an ordinary first-party session: its emission
 * predicate short-circuits true at the host check, so the feature flag that would otherwise
 * decide emission is reached only for a base URL that is not Anthropic's own — a case this route
 * never produces. The header therefore carries the request class as its value on every request
 * here. `subagent` and `workflow` name agent and workflow-run query sources that no call reaching
 * this adapter has, so neither class is reachable here.
 *
 * @param purpose - the provider-neutral classification the caller set on the request.
 * @returns the class the genuine client would report for that call kind.
 */
export declare function claudeRequestClass(purpose: GenerateOptions['purpose']): NonNullable<ClaudeCodeRequestInput['requestClass']>;
/**
 * Refuse a request whose body states `context_management` without the beta that declares it.
 *
 * The client emits the field only from the same composed beta list that carries
 * `context-management-2025-06-27`, so the two never travel apart. The builder decides the beta
 * from the model's capability while this route decides the field from its planned edits, so the
 * relationship is asserted here rather than left to two independent gates agreeing.
 *
 * @param built - the request the builder returned.
 * @param statesContextManagement - whether this route asked for the body field.
 */
export declare function assertContextManagementBeta(built: BuiltClaudeCodeRequest, statesContextManagement: boolean): void;
/**
 * Refuse a conversation shape that a withholding policy cannot express.
 *
 * The mid-conversation betas are what carry a system role inside the conversation. When a policy
 * withholds them, such a message has no wire form this route may send, and rewriting it as a
 * top-level prompt would send a request the caller never asked for. A leading system message is a
 * different thing: it opens the conversation and states the same instruction the top-level system
 * prompt carries, so it stays legal.
 * @param messages - the translated conversation.
 * @param model - the model the request is for.
 * @throws LlmError naming the unsupported shape, with a forbidding retry disposition.
 */
export declare function assertPolicyRequestShape(messages: readonly TranslatableMessage[], model: string): void;
/**
 * Build the pinned Claude Code request for one attempt.
 * @param options - the caller's generate options.
 * @param session - the account session the request is made under.
 * @param messages - the translated conversation.
 * @param maxTokens - the output cap for this request.
 * @param thinking - the thinking parameter, when the model takes one.
 * @param effort - the requested effort level, when the model takes one.
 * @param continuation - the wire session identity, sent pin and chained request id the durable
 *   owner prepared for this request; each is used exactly as given.
 * @param account - the account the request is billed to.
 * @param identityLine - the deployment's own identity line, when it configured one.
 * @param contextManagement - the planned context edits, when the model accepts them.
 * @param fast - whether this session selected the fast tier.
 * @param policy - the caller's resolved policy, when it stated one.
 * @returns the built request: pinned URL, header plan, and serialized body.
 */
export declare function buildClaudeWireRequest(options: GenerateOptions, session: ClaudeSession, messages: readonly TranslatableMessage[], maxTokens: number, thinking: ClaudeWireThinking | undefined, effort: string | undefined, continuation: ClaudeWireContinuation, account: string, identityLine?: string, contextManagement?: ContextManagementConfig, fast?: boolean, policy?: ClaudeEnginePolicy): Promise<BuiltClaudeCodeRequest>;
export {};
