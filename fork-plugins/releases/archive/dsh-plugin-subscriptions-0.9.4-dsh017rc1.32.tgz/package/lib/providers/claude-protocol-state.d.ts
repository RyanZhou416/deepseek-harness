/**
 * Durable record of a compatibility profile the service refused.
 *
 * A client-version refusal is evidence about the protocol, not about the account: the same
 * target origin refuses the same profile whoever is signed in. So the record is keyed by
 * provider, normalized origin and profile fingerprint alone, and it deliberately has no
 * clear path — re-login, an account rename, a quota reset and a restart must not release a
 * profile the service already refused. Only a profile whose fingerprint no longer matches
 * (a trusted replacement of the pinned combination) stops matching.
 *
 * The store is fail-closed on its own state. Only a missing file means "never refused"; a
 * record that cannot be read, cannot be parsed, or does not carry the identity it is filed
 * under is reported as unreadable and treated as a block, because releasing a refused
 * profile on a damaged record would send exactly the request the service refused. Writes go
 * to an exclusively created temporary file and are renamed into place, so two processes
 * cannot truncate each other's record and a crash leaves either the old record or the new
 * one.
 *
 * The store keeps the minimum such a record needs and nothing derived from a credential: no
 * token, no header, no response body, no account key. Files are written under the plugin's
 * own home directory with owner-only permissions.
 *
 * @module dsh-plugin-subscriptions/providers/claude-protocol-state
 */
/** The provider/origin/profile identity one block is keyed by. */
export interface ClaudeProtocolKey {
    /** Provider route the refusal was reported on. */
    readonly provider: string;
    /** Normalized origin the request targeted. */
    readonly origin: string;
    /** Compatibility-profile fingerprint the request was built from. */
    readonly fingerprint: string;
}
/** One persisted protocol block, as stored on disk. */
export interface ClaudeProtocolBlock extends ClaudeProtocolKey {
    /** Record version, so a future schema can migrate rather than guess. */
    readonly version: 1;
    /** Stable reason code the refusal produced. */
    readonly reason: string;
    /** The provider's own code, when it sent one. */
    readonly serverCode?: string;
    /** ISO instant this identity was first refused. */
    readonly firstSeenAt: string;
    /** ISO instant this identity was most recently refused. */
    readonly lastSeenAt: string;
}
/** Constructor options for {@link ClaudeProtocolBlockStore}. */
export interface ClaudeProtocolBlockStoreOptions {
    /** Directory holding the records; absent uses the plugin's own home directory. */
    readonly directory?: string;
    /** Sink for a diagnostic about the store itself; never used for a credential. */
    readonly onWarn?: (message: string) => void;
}
/** The record one refusal contributes, before its instants are filled in. */
export type ClaudeProtocolBlockRecord = ClaudeProtocolKey & {
    /** Stable reason code the refusal produced. */
    readonly reason: string;
    /** The provider's own code, when it sent one. */
    readonly serverCode?: string;
};
/**
 * What the store found for one requested identity.
 *
 * `unreadable` is a safe error rather than an absence: the route must treat it as a block,
 * because a record it cannot verify is a record it cannot rule out.
 */
export type ClaudeProtocolBlockState = 
/** No record exists for this identity. */
'absent'
/** A readable record for exactly this identity exists. */
 | 'blocked'
/** The store holds something for this identity that it cannot verify. */
 | 'unreadable';
/** Whether a block reached durable storage. */
export interface ClaudeProtocolBlockWrite {
    /** Whether the record was persisted; false means the block is only in memory. */
    readonly persisted: boolean;
    /** Why persistence failed, when it did. */
    readonly error?: unknown;
}
/** Every record the store can read, and the ones it cannot. */
export interface ClaudeProtocolBlockListing {
    /** The records that parsed and carried their own identity. */
    readonly blocks: readonly ClaudeProtocolBlock[];
    /** File names whose contents could not be trusted, for diagnostics. */
    readonly unreadable: readonly string[];
}
/**
 * The bounded, credential-free record store for refused compatibility profiles.
 *
 * The hot path reads one deterministic file for the requested identity and never walks the
 * directory, so an unrelated damaged record cannot stall or fail an unaffected profile. A
 * store failure is reported once and still yields a safe answer: an unverifiable record
 * blocks, and a write that did not reach disk keeps its in-memory block and reports itself
 * as unpersisted.
 */
export declare class ClaudeProtocolBlockStore {
    private readonly options;
    private readonly directory;
    private readonly blocks;
    private readonly unreadable;
    private warned;
    /**
     * @param options - directory override and diagnostic sink.
     */
    constructor(options?: ClaudeProtocolBlockStoreOptions);
    /**
     * Whether this provider, origin and profile fingerprint may not be asked again.
     * @param key - the identity to test.
     * @returns the state the store can prove: blocked, absent, or unverifiable.
     */
    state(key: ClaudeProtocolKey): Promise<ClaudeProtocolBlockState>;
    /**
     * Whether this identity is blocked, counting an unverifiable record as blocked.
     * @param key - the identity to test.
     * @returns true when the route must not send a request for this identity.
     */
    isBlocked(key: ClaudeProtocolKey): Promise<boolean>;
    /**
     * Record one refusal, keeping the first instant it was seen.
     *
     * The block is published in memory before the write is attempted, so a failed write still
     * stops this process from asking again; the returned result says whether it would survive
     * a restart, and the caller reports that rather than claiming success.
     * @param record - the identity and the reason it was refused.
     * @returns whether the record reached durable storage.
     */
    block(record: ClaudeProtocolBlockRecord): Promise<ClaudeProtocolBlockWrite>;
    /**
     * Every record the store can read, with the ones it cannot. Diagnostics only: the hot path
     * never walks the directory, and an unreadable file is reported rather than thrown.
     * @returns the readable records and the file names that could not be trusted.
     */
    list(): Promise<ClaudeProtocolBlockListing>;
    private warnOnce;
}
