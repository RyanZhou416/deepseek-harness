/**
 * Durable account-maintenance state: the profile freshness record and the accepted remote
 * policy, so a normal restart reuses what the account already confirmed instead of
 * re-reading it.
 *
 * Two rules shape the file. It holds no credential and no remote value: the policy side
 * keeps only this plugin's own validated vocabulary — the accepted checksum, the key
 * dispositions and the blocker codes — never the server's document, which may carry
 * environment or hook values. And a file that exists but cannot be trusted is not read as
 * an empty one: a caller learns the state is unavailable and refuses the operations that
 * depended on it, rather than silently losing a restriction an earlier run enforced.
 */
import type { LockTiming } from '../auth/store-lock.js';
/** The outer bound on the state file this module will read or write. */
export declare const CLAUDE_MAINTENANCE_STATE_LIMIT = 1048576;
/** One key's recorded disposition, in this plugin's own vocabulary. */
export interface ClaudePersistedKey {
    key: string;
    scope: string;
    disposition: string;
    detail: string;
}
/** One recorded blocker, in this plugin's own vocabulary. */
export interface ClaudePersistedBlocker {
    key: string;
    scope: string;
    code: string;
    detail: string;
}
/** One account's durable maintenance record. */
export interface ClaudePersistedAccount {
    /** Canonical account key. */
    account: string;
    /** Provider origin the record was made under. */
    origin: string;
    /** Protocol-configuration fingerprint the record was made under. */
    protocolFingerprint: string;
    /** Confirmed organization, when one is known. */
    organization?: string;
    /** The accepted profile fields, when a read succeeded. */
    profile?: {
        accountUuid?: string;
        emailAddress?: string;
        subscriptionType?: string | null;
        capturedAt: number;
        complete: boolean;
        /**
         * The completeness contract `complete` was computed under. Absent marks a record
         * written before the evidence-based check: its fields are kept, but it reads as
         * incomplete, so one bounded read replaces it.
         */
        completenessVersion?: number;
        credentialRevision: number;
    };
    /**
     * The accepted remote policy as this plugin projected it.
     *
     * `restrictions` are not stored: a restriction's value belongs to its consumer and may
     * quote a remote document. A policy whose keys were enforced is therefore restored as
     * needing re-verification, which is a blocker until a fresh read confirms it again.
     */
    policy?: {
        checksum: string;
        revision: string;
        acceptedAt: number;
        keys: ClaudePersistedKey[];
        blockers: ClaudePersistedBlocker[];
        /** Whether any accepted key was enforced, so the projection cannot be restored as-is. */
        enforced: boolean;
    };
}
/** What a load produced. */
export type ClaudeMaintenanceLoadResult = 
/** Nothing was ever stored for this home. */
{
    readonly status: 'cold';
}
/** The stored records, validated. */
 | {
    readonly status: 'loaded';
    readonly records: readonly ClaudePersistedAccount[];
}
/** A file exists but cannot be trusted; the caller must fail closed, not read it as empty. */
 | {
    readonly status: 'unavailable';
    readonly reason: string;
};
/** Where the controller keeps its durable state. */
export interface ClaudeMaintenancePersistence {
    /**
     * Read the stored records.
     * @returns the validated records, or why they cannot be trusted.
     */
    load(): Promise<ClaudeMaintenanceLoadResult>;
    /**
     * Store these records, merging them into whatever the file already holds for accounts
     * this call does not name, so two processes writing different accounts keep both.
     * @param records - the accounts to write.
     */
    save(records: readonly ClaudePersistedAccount[]): Promise<void>;
    /**
     * Drop one account's record, for a logout or an account removal.
     * @param account - the canonical account key.
     */
    remove?(account: string): Promise<void>;
}
/**
 * The plugin's own maintenance state file.
 *
 * Writes are serialized inside a cross-process lock, merged per account key, and swapped
 * into place atomically from an exclusively created temporary file, so one process cannot
 * drop another's account record.
 */
export declare class FileClaudeMaintenancePersistence implements ClaudeMaintenancePersistence {
    private readonly options;
    private writeTail;
    /**
     * @param options - the file to use, the lock timing, and a diagnostic sink.
     */
    constructor(options?: {
        path?: string;
        timing?: LockTiming;
        onWarn?: (message: string) => void;
    });
    /** Absolute path of the state file. */
    private path;
    /**
     * Read the stored records.
     * @returns the validated records, or why they cannot be trusted.
     */
    load(): Promise<ClaudeMaintenanceLoadResult>;
    /**
     * Merge these records into the stored ones and write the result under the store lock.
     * @param records - the accounts to write.
     */
    save(records: readonly ClaudePersistedAccount[]): Promise<void>;
    /**
     * Drop one account's record.
     * @param account - the canonical account key.
     */
    remove(account: string): Promise<void>;
    /**
     * Merge these records into the stored document while this process owns the lock.
     *
     * Ownership is a precondition, not a preference: a write that cannot take the lock fails
     * so the caller learns it did not happen, rather than replacing a document another
     * process may be extending. A document this process cannot trust is never replaced by a
     * partial write either — an unrelated account's profile must not erase a restriction an
     * earlier run enforced — so the caller is told the state is unavailable and keeps
     * refusing until an operator repairs or removes the file.
     * @param records - the accounts to write.
     * @param removeAccount - one account to drop, when this is a removal.
     */
    private mergeUnderOwnedLock;
    /** Serialize this instance's own writes. */
    private enqueue;
    /** Read and validate the file, distinguishing "never written" from "not trustworthy". */
    private readDocument;
    /** Write the complete document atomically. */
    private writeDocument;
}
