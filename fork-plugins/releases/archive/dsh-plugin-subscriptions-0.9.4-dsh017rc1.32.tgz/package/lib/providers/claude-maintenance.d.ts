/**
 * The Claude account maintenance owner.
 *
 * It owns three pieces of work, all bound to accounts that real sessions have actually
 * routed through: proactive credential renewal before expiry, profile freshness, and the
 * managed-settings policy read. Nothing here runs because a status page, a model list or a
 * usage badge was read — a binding exists only after {@link ClaudeMaintenanceController.ensureReady}
 * served an actual request for that session and account.
 *
 * The controller never treats a stream ending as a session ending: only an explicit release
 * (session disposed, user stop, logout, account removal, plugin disposal) drops a binding.
 */
import { LlmError } from '@deepseek-ai/dsh-llm';
import type { AccountCredential, AccountEntry, ClaudeSession } from '../auth/store.js';
import type { ClaudeClock, ClaudeCredentialStatus, ClaudeMaintenanceConfig, ClaudeMaintenanceFailure, ClaudePolicyEligibility, ClaudePolicyStatus, ClaudeScheduler, ClaudePolicyEligibilityInput } from './claude-account-state.js';
import type { ClaudeProfileReadReason, ClaudeProfileReader } from './claude-profile.js';
import type { OrgPinParse } from '../claude-core/org-pin.js';
import type { ClaudeMaintenancePersistence } from './claude-maintenance-state.js';
import type { ClaudePolicyBlocker, ClaudePolicyCheckRequest, ClaudePolicyConsumer, ClaudePolicyDecision, ClaudePolicyFetchFn, ClaudePolicyHttpClassifier, ClaudePolicyKeyState } from './claude-managed-settings.js';
/** The pinned first-party Messages origin, used when the deployment states no other. */
export declare const CLAUDE_DEFAULT_ORIGIN = "https://api.anthropic.com";
/**
 * The credential plumbing the controller drives.
 *
 * `AccountTokenManager<ClaudeSession>` satisfies this shape; the interface exists so a
 * test can drive the controller over a real manager with a temporary store.
 */
export interface ClaudeMaintenanceTokens {
    list(): Promise<AccountEntry<ClaudeSession>[]>;
    session(account?: string, forceRefresh?: boolean): Promise<ClaudeSession>;
    peek(account?: string): Promise<ClaudeSession | undefined>;
    resolveAccount(account: string): Promise<string>;
    snapshot(account?: string): Promise<AccountCredential<ClaudeSession> | undefined>;
}
/**
 * The protocol-block authority the reliability module owns.
 *
 * The controller asks this one authority and keeps no block store of its own, so a
 * configuration refused once cannot be re-probed by a second copy of the same state.
 */
export interface ClaudeProtocolBlockAuthority {
    /**
     * Whether a protocol configuration is blocked for one origin.
     * @param request - the provider, origin and protocol-configuration fingerprint.
     * @returns true when requests under that configuration must not be sent.
     */
    isBlocked(request: {
        provider: string;
        origin: string;
        fingerprint: string;
    }): boolean | Promise<boolean>;
    /**
     * Record one refusal in the same store {@link isBlocked} reads, so a protocol refusal
     * discovered on the profile path stops the route everywhere instead of being re-probed.
     * @param record - the refusal to record.
     */
    block?(record: {
        provider: string;
        origin: string;
        fingerprint: string;
        reason: string;
        serverCode?: string;
    }): void | Promise<unknown>;
}
/** The controller's injected dependencies. */
export interface ClaudeMaintenanceOptions {
    /** Credential plumbing for the Claude provider. */
    tokens: ClaudeMaintenanceTokens;
    /** Deployment configuration; `refreshLeadMs` is the provider's own expiry lead. */
    config: Partial<ClaudeMaintenanceConfig> & Pick<ClaudeMaintenanceConfig, 'refreshLeadMs'>;
    /** Protocol-level profile reader; absent keeps the profile unread and reported as such. */
    readProfile?: ClaudeProfileReader;
    /** Protocol-level managed-settings fetch; absent keeps policy unreported and unenforced. */
    fetchSettings?: ClaudePolicyFetchFn;
    /**
     * The unified HTTP failure classifier the reliability module owns. Every non-success
     * settings status goes through it, so a version or permission refusal keeps its own
     * decision and hard stop instead of becoming a second, local classification.
     */
    classifyHttpFailure?: ClaudePolicyHttpClassifier;
    /** Host-registered policy consumers; the projection and every check read this one set. */
    policyConsumers?: readonly ClaudePolicyConsumer[];
    /** Protocol-block authority; absent sends no block check. */
    protocolBlocks?: ClaudeProtocolBlockAuthority;
    /**
     * Where the profile and accepted-policy records survive a restart. Absent keeps the
     * maintenance state in memory alone, and the status view then reports only what this
     * process learned rather than what the account already confirmed earlier.
     */
    persistence?: ClaudeMaintenancePersistence;
    /**
     * Classify one credential failure. The unified classifier owns the real mapping; the
     * default reads the plugin's own `INVALID_CREDENTIAL` / `MISSING_CREDENTIAL` codes.
     */
    classifyCredentialFailure?: (error: unknown) => 'transient' | 'permanent' | 'missing';
    /**
     * The protocol-configuration fingerprint the account's requests run under. The Claude
     * protocol module owns the value; the default keeps the controller usable on its own.
     */
    protocolFingerprint?: () => string;
    /** The provider origin the account is served from. */
    origin?: string;
    /** Which account keys are served by the plugin's own first-party OAuth path. */
    isFirstPartyOAuth?: (account: string) => boolean;
    /** Time source; defaults to the process clock. */
    clock?: ClaudeClock;
    /** Timer source; defaults to the process timers. */
    scheduler?: ClaudeScheduler;
    /** Called after any observable maintenance state changes, so the status projection re-reads. */
    onChanged?: (account: string) => void;
    /** Warning sink for a contained background failure. */
    onWarn?: (message: string) => void;
}
/** One account's adopted organization pin, projected with the policy revision it belongs to. */
export type AdoptedOrganizationPin = 
/** The accepted policy stated a pin, or stated none at all; the parse is the core's. */
{
    readonly kind: 'stated';
    readonly pin: OrgPinParse;
    readonly revision: string;
}
/** The accepted policy was restored without its settings, so its pin is not known. */
 | {
    readonly kind: 'unknown';
    readonly revision: string;
    readonly reason: string;
};
/** One request a caller is about to send through a bound account. */
export interface ClaudeRequestReadiness {
    /** Canonical or alias account key the request targets. */
    account: string;
    /** The harness session id, when the caller has one; absent creates no binding. */
    sessionId?: string | undefined;
    /** Caller cancellation. */
    signal?: AbortSignal | undefined;
}
/** Whether a request may be sent, and with which credential. */
export type ClaudeRequestDecision = {
    readonly ok: true;
    readonly account: string;
    readonly session: ClaudeSession;
} | {
    readonly ok: false;
    readonly error: LlmError;
};
/** The status projection the Settings surface reads; computed while nothing refreshes. */
export interface ClaudeAccountMaintenanceView {
    account: string;
    organization?: string;
    origin: string;
    protocolFingerprint: string;
    /** How many live session bindings currently hold this account. */
    bindings: number;
    credential: {
        status: ClaudeCredentialStatus;
        expiresAt?: number;
        nextCheckAt?: number;
        failure?: ClaudeMaintenanceFailure;
    };
    profile: {
        status: 'fresh' | 'stale' | 'missing' | 'unavailable';
        reason: ClaudeProfileReadReason;
        capturedAt?: number;
        complete: boolean;
        missing: readonly string[];
        subscriptionType?: string | null;
        failure?: ClaudeMaintenanceFailure;
    };
    policy: {
        status: ClaudePolicyStatus;
        reason: string;
        fetchedAt?: number;
        checksum?: string;
        nextCheckAt?: number;
        blockers: readonly ClaudePolicyBlocker[];
        keys: readonly ClaudePolicyKeyState[];
        failure?: ClaudeMaintenanceFailure;
    };
}
/**
 * Owner of the three Claude account-maintenance loops.
 *
 * Every network action it starts is bound to at least one live session binding; releasing
 * the last binding cancels the account's timers and aborts its in-flight reads without
 * discarding the data they produced.
 */
export declare class ClaudeMaintenanceController {
    private readonly options;
    private readonly states;
    private readonly config;
    private readonly clock;
    private readonly scheduler;
    private readonly consumers;
    private readonly origin;
    private disposed;
    /**
     * Why the durable policy state cannot be trusted, when it cannot.
     *
     * While this is set, policy-gated requests are refused: a stored restriction an earlier
     * run enforced cannot be assumed absent just because its file could not be read. A fresh
     * accepted policy clears it.
     */
    private stateUnavailableReason;
    private readonly inFlight;
    constructor(options: ClaudeMaintenanceOptions);
    /**
     * Establish or refresh the binding for one real request and return the credential to
     * send with it.
     *
     * This is the adapter's pre-request hook: it is the only place a session becomes bound,
     * it never starts work for an account the request does not name, and it refuses the
     * request — rather than sending it — when the credential is gone, the protocol
     * configuration is blocked, or an accepted policy restriction reaches the request.
     * @param request - the account, the harness session id and the caller's cancellation.
     * @returns the credential to send, or `undefined` when nothing changed.
     * @throws LlmError when the request must not be sent.
     */
    beforeAccountRequest(request: ClaudeRequestReadiness): Promise<ClaudeSession | undefined>;
    /**
     * Decide whether one request may be sent, and with which credential.
     *
     * The binding is established here — with a real harness session id only — but a request
     * that names no session still receives the credential and policy checks; it simply
     * creates no lasting maintenance ownership.
     * @param request - the account, the harness session id and the caller's cancellation.
     * @returns the ready credential, or the refusal to send.
     */
    ensureReady(request: ClaudeRequestReadiness): Promise<ClaudeRequestDecision>;
    /**
     * A request that named no session owns nothing lasting.
     *
     * Its policy determination is recorded (a configured store keeps it), the account's
     * timers and reads are dropped, and the state leaves the map: repeated direct requests
     * cannot accumulate owners. Without a store the state is kept, because that map is then
     * the only place the knowledge lives.
     * @param state - the state the finished request used.
     */
    private releaseTransientState;
    /**
     * Resolve one request's readiness, reporting the state it used so a request that owns no
     * binding can release it afterwards.
     * @param request - the account, session id and cancellation.
     * @param adopt - receives the state this request used.
     * @returns the decision.
     */
    private resolveReadiness;
    /**
     * Bind one session as a live user of one account.
     *
     * Called from {@link ensureReady} for a real request; a caller that has only an account
     * list, a menu read or a historical session must not call this.
     * @param sessionId - the harness session id that used the account.
     * @param account - the account key the session used.
     */
    noteSessionUsed(sessionId: string, account: string): void;
    /**
     * Release one session's bindings and wait for the work it owned.
     *
     * A stream ending, an idle turn or a completed response is not a release: only session
     * disposal, a user stop, a logout or an account removal reaches this. Work another live
     * session still needs — the shared credential refresh above all — is not awaited here.
     * @param sessionId - the harness session that ended.
     * @returns a promise that resolves once no work owned by that session is still running.
     */
    releaseSession(sessionId: string): Promise<void>;
    /**
     * Release every binding of one account and drop its maintenance state: logout, account
     * removal or an identity replacement. The next real use starts from a fresh identity.
     * @param account - the account key, canonical or alias.
     * @returns a promise that resolves once the account's work has settled.
     */
    releaseAccount(account: string): Promise<void>;
    /**
     * Re-arm the credential timer after the credential changed outside a maintenance cycle
     * — a request reached a 401 and refreshed it, for example.
     * @param account - the account whose credential changed.
     */
    noteCredentialChanged(account: string): void;
    /**
     * Decide one operation against the accepted remote policy.
     *
     * The same projection the fetch produced is the one enforced here, and a restriction
     * whose consumer is missing refuses the operation instead of being ignored.
     * @param request - the operation, optionally scoped to one account.
     * @returns whether the operation may run.
     */
    assertAllowed(request: ClaudePolicyCheckRequest & {
        account?: string;
    }): ClaudePolicyDecision;
    /**
     * The current status projection.
     *
     * A pure read of in-memory state: it starts no request, arms no timer, extends no
     * cooldown and never refreshes a credential.
     * @returns one view per account the controller knows.
     */
    view(): readonly ClaudeAccountMaintenanceView[];
    /**
     * The organization pin one account's accepted policy carries, projected for its consumer.
     *
     * The raw settings document is deliberately not exposed: only the pin and the revision it
     * belongs to leave this owner, so a consumer cannot read or persist a remote value the
     * minimal projection does not keep. An accepted policy is only as good as the document it
     * was read from: a snapshot restored from disk carries no settings, so its pin reads as
     * unknown and the pin checker keeps refusing until a fresh full read states it again —
     * never as the absence of a pin. The endpoint's empty-success record is the exception: its
     * own record states the whole empty body, so the absence of a pin is stated, not assumed.
     * @param account - the canonical account key.
     * @returns the projected pin state, or `undefined` when this account holds no policy.
     */
    adoptedOrganizationPin(account: string): AdoptedOrganizationPin | undefined;
    /**
     * Load the profile and accepted-policy records a previous run stored.
     *
     * Hydration installs data only: it creates no binding, arms no timer and starts no
     * request, so a restart never resumes work for a session that no longer exists. A
     * persisted policy snapshot is re-projected against the consumers in force now, so a
     * restriction this build still cannot enforce blocks again instead of disappearing.
     * @returns a promise that resolves once the stored records are installed.
     */
    hydrate(): Promise<void>;
    /**
     * Stop every timer, abort every read in flight and wait for the aborted work to settle.
     *
     * @returns a promise that resolves once no maintenance work is still running.
     */
    dispose(): Promise<void>;
    /** Origin and fingerprint for one account, from the injected protocol configuration. */
    private identityFor;
    /** The protocol-configuration fingerprint the injected supplier reports. */
    private protocolFingerprint;
    /** The single account state when exactly one exists, for an unscoped check. */
    private onlyState;
    /** The state bound to one account key, canonical or alias. */
    private stateByAccount;
    /**
     * The state for one account key, rebuilt when the stored credential now names another
     * account UUID. A re-login that lands on the same key is a different identity, so the
     * caches read under the earlier one must not be carried over.
     * @param account - the canonical account key.
     * @param session - the credential currently stored for it.
     * @param revision - the credential revision that credential is stored under.
     * @returns the state to maintain this identity with.
     */
    private stateForAccount;
    /** The state for one identity, replacing a state whose identity changed. */
    private stateFor;
    /** Build and register a fresh state for one identity. */
    private createState;
    /**
     * Establish one binding, releasing the session from any other account it was bound to.
     *
     * A harness session that switches accounts keeps one identity at a time: the earlier
     * account's binding is released and its own work awaited before the new one starts, while
     * every other session's binding stays exactly as it was. Work is not started here;
     * {@link resolveReadiness} starts it after the policy determination it will be judged by.
     * @param state - the account the session now uses.
     * @param sessionId - the harness session id.
     */
    private bind;
    /** Cancel an account's timers and abort its reads, keeping its data. */
    private suspend;
    /** Wait for exactly the work these states started, not for other sessions' shared work. */
    private quiesce;
    /** Cancel every timer of one state. */
    private cancelTimers;
    /** Abort the reads one state has in flight. */
    private abortInFlight;
    /** Stop scheduling further work for one account until it is used again. */
    private stopScheduling;
    /**
     * Start the best-effort maintenance of a bound account.
     * @param state - the bound account.
     * @param policyDetermined - whether this request already waited for the bounded policy
     *   determination, in which case the poller owns the next check instead of a second read.
     */
    private startBoundWork;
    /**
     * Wait for this identity's policy determination, or take part in the one already running.
     *
     * Every caller shares a single bounded read: a second session of the same account waits
     * for the read the first one started instead of being judged before it lands. A caller's
     * own cancellation withdraws only that caller's wait — the shared read continues for the
     * others and is cancelled when the last waiter leaves. The read is bounded by the
     * configured timeout, which aborts it: nothing keeps running in the background, and a
     * read that was cancelled this way leaves the identity undetermined so a later request
     * retries it rather than being judged by a refusal that never arrived. The retry is the
     * next real request's, never a loop here, and a failed read keeps its own backoff: a
     * restored or failed policy is read again only once that backoff has passed.
     * @param state - the account state being judged.
     * @param signal - the caller's own cancellation.
     */
    private ensurePolicyDetermined;
    /**
     * The one determination read for this identity, started if none is running.
     * @param state - the account state.
     * @returns the shared read, or `undefined` when this deployment has no settings fetch.
     */
    private startPolicyDetermination;
    /**
     * Run one bounded determination and settle the identity's state from its outcome.
     *
     * The settlement is fenced on the operation itself: if the binding was released or a
     * newer read replaced this one while it was in flight, this read no longer owns the
     * account state — it must not mark the identity determined, clear the newer read's
     * promise, or arm a timer for a binding that is gone. A release therefore leaves the
     * identity undetermined, so the next binding reads again instead of trusting a result
     * that arrived after the fact.
     * @param state - the account state.
     * @param operation - this read's identity and cancellation.
     */
    private runPolicyDetermination;
    /** Register one waiter for the shared determination read. */
    private joinPolicyWait;
    /**
     * Drop one waiter.
     *
     * The read stops only when nobody is waiting for it AND no binding remains: a bound
     * account owns its background determination (the poller's read, or a sibling session's),
     * and that read is bounded by its own timeout instead. Releasing the last binding is what
     * cancels it, through {@link suspend}.
     */
    private leavePolicyWait;
    /**
     * The access token one maintenance read sends for an account.
     *
     * A `read-only-import` credential's source is owned outside this plugin, so the stored record
     * is a reference rather than a token: the read resolves the credential through the use path a
     * request uses, which re-reads that source and refuses rather than falling back to whatever
     * the store happens to hold. Every other mode sends the stored credential exactly as before,
     * so no grant is spent where none was spent before.
     * @param account - the account whose credential the read uses.
     * @param stored - the stored credential the read was decided from.
     * @returns the token to send, or the failure the use path produced.
     */
    private readAccessToken;
    /**
     * Arm the next credential check from the stored expiry.
     *
     * An unknown expiry is reported as unknown and schedules nothing: a fabricated deadline
     * would become an immediate retry loop. A credential already inside the lead window is
     * checked at once, and a failed check backs off within the configured budget.
     */
    private armCredentialTimer;
    /** One credential maintenance cycle: read, refresh when due, re-arm from the winner. */
    private runCredentialCycle;
    /**
     * Move one state onto the organization a profile response just confirmed.
     *
     * The state keeps its bindings and its work, and changes its identity key. Everything
     * accepted while the organization was unidentified was cached under a different key, so
     * the remote policy is re-determined instead of being carried across.
     * @param state - the account state being re-keyed.
     * @param organization - the confirmed organization.
     */
    private adoptOrganization;
    /** Start a profile check unless one is already running for this account. */
    private startProfileWork;
    /** One profile check: decide, read once, adopt only what this identity confirms. */
    private runProfileCycle;
    /**
     * Start a policy check unless one is already running for this account.
     *
     * The poller and the bounded initialization share this one entry, so a check the poller
     * starts is also the read a concurrent request waits for, and no identity ever has two
     * determinations in flight.
     */
    private startPolicyWork;
    /**
     * Read one policy snapshot and fold it into the account state.
     *
     * Shared by the bounded initialization and the poller, so both follow the same
     * eligibility, refusal and backoff rules.
     * @param state - the account being maintained.
     * @param generation - the binding generation the read belongs to.
     * @param signal - cancellation for this read.
     */
    private readPolicySnapshot;
    /** Arm the poller after a completed cycle, honouring a failure backoff. */
    private armPolicyTimer;
    /** Cancel the policy poller alone. */
    private cancelPolicyTimer;
    /**
     * The subscription type maintenance may act on.
     *
     * A record captured for the same identity is the most recent validated statement; a
     * credential-derived type stands in while no record states one. An explicit null from a
     * validated response makes the type unknown, and nothing else does.
     */
    private confirmedSubscription;
    /**
     * Apply a protocol-configuration refusal to every account served by that configuration.
     *
     * The refusal is recorded in the shared block store first, so any account under the same
     * provider, origin and protocol fingerprint is refused at {@link ensureReady}; then every
     * matching account in this process stops its credential, profile and policy work, because
     * a configuration the service refused must not keep sending Messages or rotating
     * credentials from a sibling account. An account-scoped refusal (a permission denial, for
     * instance) never reaches this method: it stops its own policy alone.
     * @param state - the account whose read was refused.
     * @param failure - the refusal, which names the protocol configuration.
     */
    private applyProtocolRefusal;
    /** Whether the injected block authority refuses this identity's configuration. */
    private protocolBlocked;
    /**
     * Record a protocol-level profile refusal in the shared block store.
     *
     * The store is the reliability module's; this only adds the record, so the same refusal
     * stops the route from anywhere it is observed.
     * @param state - the account whose configuration was refused.
     * @param failure - the refusal to record, when it names a protocol refusal.
     */
    private recordProtocolBlock;
    /** The refusal one denied policy decision becomes. */
    private policyRefusal;
    /** Classify one credential failure, through the injected classifier when there is one. */
    private classify;
    /** Structured failure facts for one caught error, without a body, a token or a message. */
    private failureFrom;
    /** The next failure backoff, doubling to the configured ceiling. */
    private nextBackoff;
    /**
     * Track one promise against its account state and against disposal.
     *
     * A release waits for exactly the states it released; disposal waits for everything.
     * A contained background failure is reported rather than rejecting the caller that
     * started the work.
     * @param state - the account the work belongs to.
     * @param pending - the work to track.
     */
    private trackWork;
    /**
     * Record the current durable facts.
     *
     * Only validated, non-secret state is written: the profile fields a consumer needs, the
     * policy document the server accepted, and the instants that decide freshness. A write
     * failure is contained — the in-memory state stays authoritative for this run.
     */
    private schedulePersist;
    /** Report a state change to the status projection's owner. */
    private notify;
    /** Project one state into the status view. */
    private viewOf;
}
/**
 * The eligibility verdict one account's confirmed metadata produces.
 *
 * Exposed so a caller that only wants the status (a settings card or a diagnostic dump)
 * can compute it without a controller or a network read.
 * @param input - confirmed subscription type, credential and path facts.
 * @returns the eligibility verdict.
 */
export declare function claudeMaintenanceEligibility(input: ClaudePolicyEligibilityInput): ClaudePolicyEligibility;
