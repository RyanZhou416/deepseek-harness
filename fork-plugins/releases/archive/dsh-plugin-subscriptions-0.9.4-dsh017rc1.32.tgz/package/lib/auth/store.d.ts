/**
 * On-disk OAuth session store at `~/.dsh/plugins/subscriptions/auth.json`.
 *
 * The file is a JSON object keyed by provider id, each entry holding that
 * provider's ACCOUNTS: a map of account key → session plus the default
 * account's key. Writes are atomic (tmp file + rename) with mode 0600
 * because they carry bearer tokens. Mode 0600 is the owner-only guarantee on
 * POSIX platforms only: Windows ignores it, so there the file keeps the ACL of
 * the directory holding it, and every principal that ACL admits can read the
 * tokens. Session shapes live here (not in the provider modules) because this
 * file owns the durable format.
 *
 * Backward compatibility: entries written by single-account versions hold
 * the session fields directly (no `accounts` wrapper); reads migrate them
 * in memory, and the next write persists the new shape — existing logins
 * survive the upgrade untouched.
 *
 * A Claude entry may state its credential ownership mode. An absent field reads as the mode its
 * own facts imply; a value this build does not implement fails the whole read rather than being
 * inferred from or dropped, because it decides who may spend a shared refresh grant.
 */
import type { ClaudeCredentialMode } from './claude-credential-ownership.js';
/** Provider routes this plugin can serve. */
export type ProviderId = 'codex' | 'claude' | 'grok' | 'copilot' | 'antigravity' | 'cursor';
/** Every provider route, in display order. */
export declare const PROVIDER_IDS: readonly ProviderId[];
/**
 * A session whose provider can report no display identity. Such a session carries the
 * random id it is keyed by, so the account key served to the browser derives from no
 * credential.
 */
interface AccountKeyedSession {
    /** Random per-login account id, written with the session; absent until one is assigned. */
    accountKeyId?: string;
}
/** Stored ChatGPT/Codex subscription session. */
export interface CodexSession {
    accessToken: string;
    refreshToken: string;
    /** Epoch milliseconds at which the access token expires. */
    expiresAt: number;
    /** `chatgpt_account_id` claim from the id token; sent as the `chatgpt-account-id` header. */
    accountId: string;
    idToken?: string;
    /** User email from the id token, when the token carried it. */
    emailAddress?: string;
    /** `chatgpt_plan_type` claim from the id token (e.g. `plus`, `pro`), when present. */
    planType?: string;
}
/** Stored Claude Pro/Max subscription session. */
export interface ClaudeSession extends AccountKeyedSession {
    accessToken: string;
    refreshToken: string;
    /** Epoch milliseconds at which the access token expires. */
    expiresAt: number;
    /** Scope string the tokens were issued with; echoed on refresh. */
    scopes: string;
    emailAddress?: string;
    subscriptionType?: string;
    /**
     * Account UUID from the OAuth profile; fills the `metadata.user_id`
     * correlation triple the Claude Code wire contract requires. Sessions
     * stored before the wire upgrade lack it and are backfilled on first use.
     */
    accountUuid?: string;
    /**
     * Deterministic account-and-local-OS device id used in the correlation triple.
     * The Claude adapter rechecks it before Messages and conditionally replaces
     * legacy account-only ids or values copied from another OS installation.
     */
    deviceId?: string;
    /**
     * True when this account was imported from Claude Code's own credential
     * store (Keychain/file): only bound accounts sync refreshes back to it.
     */
    keychainBound?: boolean;
    /**
     * How this account's credential is owned, and therefore who may rotate it.
     * Absent on records written before the field existed, where the mode is
     * inferred from {@link keychainBound}; a stated value outranks that inference
     * and survives a restart. See `claude-credential-ownership.ts` for the modes
     * and the conversions allowed between them.
     */
    credentialOwnershipMode?: ClaudeCredentialMode;
}
/** Stored Grok (X Premium / xAI) subscription session. */
export interface GrokSession extends AccountKeyedSession {
    accessToken: string;
    refreshToken: string;
    /** Epoch milliseconds at which the access token expires. */
    expiresAt: number;
    /** Token endpoint from OIDC discovery; retained for refreshes. */
    tokenEndpoint: string;
    scopes?: string;
    /** Display account: email, username, or subject claim from the id token. */
    account?: string;
}
/**
 * Stored GitHub Copilot subscription session. Two token generations are at
 * play: the long-lived GitHub OAuth token from the device flow is kept in
 * `refreshToken`, and `accessToken` carries the short-lived (~30 minutes)
 * Copilot API token exchanged from it. A "refresh" is therefore a fresh
 * exchange against `copilot_internal/v2/token`, not an OAuth grant.
 */
export interface CopilotSession extends AccountKeyedSession {
    /** Copilot API token; sent as the bearer on api.githubcopilot.com. */
    accessToken: string;
    /** Long-lived GitHub OAuth token from the device flow. */
    refreshToken: string;
    /** Epoch milliseconds at which the Copilot API token expires. */
    expiresAt: number;
    /** GitHub login name, for the status display. */
    account?: string;
}
/**
 * Stored Cursor account. `accessToken` is the user API key used for chat.
 * `refreshToken` repeats that key so the shared session shape stays valid.
 * Dashboard usage uses the separate session tokens captured at login; accounts
 * stored before that capture have neither and must log in again.
 */
export interface CursorSession extends AccountKeyedSession {
    /** User API key for agent requests. */
    accessToken: string;
    /** Copy of the API key. Cursor chat has no refresh grant. */
    refreshToken: string;
    /** Epoch milliseconds at which the user API key expires. */
    expiresAt: number;
    /** Account email, when login reported one. */
    email?: string;
    /** Short-lived dashboard access token for usage queries. */
    dashboardAccessToken?: string;
    /** Dashboard refresh token. Renewed only when a usage query needs it. */
    dashboardRefreshToken?: string;
}
/** Stored Google OAuth session for the Antigravity v1internal API. */
export interface AntigravitySession extends AccountKeyedSession {
    accessToken: string;
    refreshToken: string;
    /** Epoch milliseconds at which the Google access token expires. */
    expiresAt: number;
    /** Cloud AI Companion project required by Antigravity request envelopes. */
    projectId: string;
    /** Google account email, for the status display. */
    account?: string;
    /** Subscription tier observed during project discovery. */
    plan?: string;
    /** Granted Google OAuth scopes, when the token endpoint returned them. */
    scopes?: string;
}
/** One provider's accounts: account key → session, plus the default account. */
interface ProviderAccounts<S> {
    /** Key of the account direct (non-pool) routes serve; the first login wins. */
    default?: string;
    accounts: Record<string, S>;
    /** Old keys remain bound to their migrated account, never a workspace sibling. */
    aliases?: Record<string, string>;
    /**
     * Per-account credential revision, bumped by every accepted write of that account
     * (save, removal) and never decremented. A reader that decided on a revision can
     * therefore tell whether the credential it reasoned about is still the current one.
     * Absent on stores written before revisions existed, which read as revision 0.
     */
    revisions?: Record<string, number>;
}
/** The durable store shape: per provider, its accounts. */
interface SessionMap {
    codex?: ProviderAccounts<CodexSession>;
    claude?: ProviderAccounts<ClaudeSession>;
    grok?: ProviderAccounts<GrokSession>;
    copilot?: ProviderAccounts<CopilotSession>;
    antigravity?: ProviderAccounts<AntigravitySession>;
    cursor?: ProviderAccounts<CursorSession>;
    /**
     * Per-provider, per-account revision high-water marks. They outlive the account they
     * name: removing the last account of a provider takes the account map away, and this
     * map is what keeps the next login of that account on a higher revision than the
     * credential the removal retired — in this process and in every other one.
     */
    revisions?: Record<string, Record<string, number>>;
}
/** Any stored session, for provider-agnostic plumbing. */
export type StoredSession = CodexSession | ClaudeSession | GrokSession | CopilotSession | AntigravitySession | CursorSession;
/** The session type one provider stores. */
type SessionOf<K extends ProviderId> = NonNullable<SessionMap[K]>['accounts'][string];
/** One account entry as returned by {@link listAccounts} (default first). */
export interface AccountEntry<S> {
    key: string;
    session: S;
}
/**
 * The stable identity of one session's account: Codex keys on workspace AND
 * user (email fallback, workspace-only for unidentified legacy sessions),
 * the others on their display identity, and on the random id carried by a
 * session that has none. Logging the same account in again lands on the same
 * key, so a re-login updates in place instead of duplicating. (An identity-less
 * account re-logged in mints a new id, which reads as a second account on the
 * Settings page; the earlier entry can simply be logged out.)
 *
 * A session without a display identity is assigned its id here, and the caller
 * that stores the session persists that id with it.
 * @param provider - the provider route.
 * @param session - the session to key.
 * @returns the account map key.
 */
export declare function accountKeyOf(provider: ProviderId, session: StoredSession): string;
/**
 * Resolve a persisted legacy account key to its canonical account identity.
 * For Codex, a reference that matches no key or alias also resolves through
 * a unique login email or workspace ID (see {@link resolveCodexReference}).
 */
export declare function resolveAccountKey(provider: ProviderId, account: string, path?: string): Promise<string>;
/**
 * Absolute path of the auth store file.
 * @returns `dshHomePath('plugins', 'subscriptions', 'auth.json')`.
 */
export declare function authFilePath(): string;
/**
 * Read the whole store. A missing file is an empty store; malformed JSON or a
 * malformed entry throws, because silently discarding tokens would strand the
 * user without a diagnosis. Single-account entries are migrated in memory;
 * the next write persists the new shape. An account key that names the session's
 * refresh token is replaced here and written back immediately, so the account
 * keeps one key across restarts.
 * @param path - store file path; defaults to {@link authFilePath}.
 * @returns the parsed session map.
 */
export declare function loadStore(path?: string): Promise<SessionMap>;
/**
 * List one provider's accounts, default first.
 * @param provider - the provider route.
 * @param path - store file path; defaults to {@link authFilePath}.
 * @returns the account entries in stable order (empty when logged out).
 */
export declare function listAccounts<K extends ProviderId>(provider: K, path?: string): Promise<AccountEntry<SessionOf<K>>[]>;
/**
 * Read one account's session.
 * @param provider - the provider route.
 * @param account - the account key; defaults to the provider's default account.
 * @param path - store file path; defaults to {@link authFilePath}.
 * @returns the stored session, or `undefined` when absent.
 */
export declare function getAccountSession<K extends ProviderId>(provider: K, account?: string, path?: string): Promise<SessionOf<K> | undefined>;
/**
 * A store-minted, monotonic revision of one account's credential.
 *
 * It changes whenever the credential does — a rotation, a re-login, a removal — and never
 * returns to an earlier value, so a caller that recorded a revision can tell whether the
 * credential it reasoned about is still the one stored.
 */
export type CredentialRevision = number;
/**
 * One account's stored credential together with the revision it is stored under.
 * @typeParam S - the provider's session type.
 */
export interface AccountCredential<S> {
    /** Canonical account key the credential is stored under. */
    key: string;
    session: S;
    revision: CredentialRevision;
}
/**
 * Read one account's credential and the revision it is stored under, without any side
 * effect and without refreshing. A caller that will act on the session keeps the revision
 * and re-reads before committing an effect that must not land on a newer credential.
 * @param provider - the provider route.
 * @param account - the account key; defaults to the provider's default account.
 * @param path - store file path; defaults to {@link authFilePath}.
 * @returns the credential snapshot, or `undefined` when the account is not logged in.
 */
export declare function getAccountCredential<K extends ProviderId>(provider: K, account?: string, path?: string): Promise<AccountCredential<SessionOf<K>> | undefined>;
/**
 * Write one account's session, preserving the others. The first account of a
 * provider becomes its default.
 *
 * The session is validated before it lands: a corrupt entry written here
 * would fail every later read of the whole store (one bad entry breaks all
 * providers' status), so the write path must be as strict as the read path.
 * Every accepted write also bumps that account's {@link CredentialRevision}.
 * @param provider - the provider route.
 * @param account - the account key (see {@link accountKeyOf}).
 * @param session - the fresh session from a login or refresh.
 * @param path - store file path; defaults to {@link authFilePath}.
 * @param options - `expectedPrior` compares the stored session's tokens, and
 *   `expectedRevision` compares the stored revision, so a decision taken on either can be
 *   refused once a newer credential landed. Both are optional; a caller that reads a
 *   revision before deciding passes it.
 * @throws when the session is missing accessToken/refreshToken/expiresAt.
 */
export declare function saveAccountSession<K extends ProviderId>(provider: K, account: string, session: SessionOf<K>, path?: string, options?: {
    expectedPrior?: SessionOf<K>;
    expectedRevision?: CredentialRevision;
}): Promise<boolean>;
/**
 * Delete one account's session (logout). Deleting the default moves the badge
 * to the next remaining account.
 *
 * The removal runs inside the store's own serialization, so a caller that names
 * the session it read cannot delete one another writer stored in the meantime:
 * a login or a rotation that landed first is kept, and the caller answers false.
 * @param provider - the provider route.
 * @param account - the account key.
 * @param path - store file path; defaults to {@link authFilePath}.
 * @param options - `expectedPrior` makes the removal conditional on the stored
 *   session still being that one, and `expectedRevision` on the stored revision still
 *   being the one the caller read, exactly as {@link saveAccountSession} does.
 * @returns true when the session was actually removed; false when the account
 *   was already absent or another writer had replaced the named session.
 */
export declare function deleteAccountSession<K extends ProviderId>(provider: K, account: string, path?: string, options?: {
    expectedPrior?: SessionOf<K>;
    expectedRevision?: CredentialRevision;
}): Promise<boolean>;
/**
 * Pin the account direct (non-pool) routes serve.
 * @param provider - the provider route.
 * @param account - the account key; must exist.
 * @param path - store file path; defaults to {@link authFilePath}.
 */
export declare function setDefaultAccount(provider: ProviderId, account: string, path?: string): Promise<void>;
export {};
