import type { ClaudeSession } from './store.js';
/**
 * One credential as Claude Code's own store states it.
 *
 * `session` is the shape this plugin records; `declaredScopes` is what the source itself
 * granted, which a read-only use must judge for itself because the recorded shape may carry the
 * pinned default set the source never stated.
 */
export interface ClaudeSourceCredential {
    /** The session shape this plugin records for this source. */
    readonly session: ClaudeSession;
    /**
     * The scopes the credential document itself declared, or `undefined` when it declared none.
     * A read-only use refuses a source that declares none: an inferred scope set must never
     * authorize serving an externally owned credential.
     */
    readonly declaredScopes?: string;
}
/**
 * Read the current Claude Code credential from its source of truth: macOS Keychain, falling
 * back to the credentials file.
 * @returns the source credential, or `undefined` when the source holds none.
 */
export declare function readClaudeCodeCredentialSource(): ClaudeSourceCredential | undefined;
/** Read the current Claude Code session from its source of truth: macOS Keychain, falling back to the credentials file. */
export declare function readClaudeCodeCredentials(): ClaudeSession | undefined;
/**
 * Refresh a Claude session, first checking whether Claude Code's own store
 * already holds a fresher token (rotated by the `claude` CLI or another
 * consumer) before hitting the OAuth endpoint ourselves — and writing our own
 * refresh back to that store so every consumer of the account stays synced.
 *
 * A rotation read from that store is adopted only under {@link sameSourceAccount}'s local
 * contract; otherwise this fails closed with {@link claudeCredentialSourceChangedError},
 * spending no grant and writing nothing. The lock taken here serialises this plugin's own
 * cooperating processes; whether the `claude` CLI locks this path the same way is not
 * established, so no coordination with it is claimed.
 * @param session - the session TokenManager wants refreshed.
 * @param doRefresh - the actual OAuth refresh-token grant (network call).
 * @returns the freshest available session.
 * @throws LlmError `CLAUDE_CREDENTIAL_SOURCE_CHANGED` when the store's credential changed and
 *   this account cannot be confirmed against it, unknown identity included.
 */
export declare function refreshClaudeSynced(session: ClaudeSession, doRefresh: (session: ClaudeSession) => Promise<ClaudeSession>): Promise<ClaudeSession>;
/**
 * Resolve the credential one read-only use serves.
 *
 * The external store is read again on every use and its current winner is adopted, so a
 * rotation the `claude` CLI performed is served without this plugin ever spending the shared
 * grant or writing back. The stored record is a reference, never a fallback: a source that is
 * absent, expired, under-scoped or unconfirmable for this account stops the use, and no token
 * is read from the local record.
 *
 * The scope gate reads what the SOURCE declared, not the recorded shape: the local record
 * carries the pinned default set when the blob stated none, so judging it there would let a
 * credential that declares nothing be served as if it granted inference.
 *
 * The served session keeps the reference fields the stored record owns (see
 * {@link withClaudeCredentialReference}): a consumer that persists an identity backfill must
 * not lose the mode, and dropping the device binding would re-run that backfill every request.
 * @param session - the stored read-only record this account is served under.
 * @param source - the external credential as the source states it, or `undefined` when it holds
 *   none for this account.
 * @returns the winner to serve, carrying the record's own reference fields.
 * @throws LlmError `CLAUDE_CREDENTIAL_SOURCE_CHANGED` when the source cannot be confirmed as
 *   this account's, and `INVALID_CREDENTIAL` when it cannot serve a request at all.
 */
export declare function resolveClaudeReadOnlyCredential(session: ClaudeSession, source: ClaudeSourceCredential | undefined): ClaudeSession;
/**
 * Resolve the credential one refresh WINDOW serves for a read-only record.
 *
 * The use path normally answers a read-only account before the token manager loads a credential,
 * so reaching a refresh means the record's ownership moved inside the manager's own window. This
 * runs there, under the manager's durable lock, so it judges the reference the manager is already
 * holding and never reads the plugin's store again.
 *
 * The manager answers a non-permanent refresh failure with the credential it loaded — the stored
 * reference, which is exactly the local cached token the read-only mode forbids — so a source that
 * cannot serve is reported as a missing credential, the one failure the manager propagates without
 * falling back to that copy and without deleting the record. Its message is the source's own.
 * @param session - the read-only reference the manager holds.
 * @param readSource - reads Claude Code's own credential source.
 * @returns the external winner to serve.
 * @throws LlmError `MISSING_CREDENTIAL` when the source cannot serve this account: it holds
 *   nothing, holds a credential that cannot serve it, or cannot be read at all.
 */
export declare function resolveClaudeReadOnlyRefresh(session: ClaudeSession, readSource: () => ClaudeSourceCredential | undefined): ClaudeSession;
/**
 * The use-path preparation for one Claude account.
 *
 * Answers `undefined` for every mode that does not read an external store, so the caller keeps
 * the manager's own load-and-refresh path unchanged. A read-only account answers the winner
 * re-read from the source, which is what makes the check reachable from every credential use —
 * a Messages request, a forced refresh after a 401, usage, model discovery and the maintenance
 * reads — while a list, snapshot or status read never touches that source.
 * @param account - the canonical account key.
 * @param readSource - reads Claude Code's own credential source.
 * @returns the credential to serve, or `undefined` when the account is not read-only.
 * @throws LlmError as {@link resolveClaudeReadOnlyCredential} does.
 */
export declare function claudeReadOnlyUse(account: string, readSource: () => ClaudeSourceCredential | undefined): Promise<ClaudeSession | undefined>;
