/**
 * The `subscriptions-auth` host RPC endpoints the web Settings page drives.
 * They are mounted as exact POST Fetch routes on the shared `/api` channel
 * (`/api/subscriptions-auth.<endpoint>`) and registered only when a host
 * `connection` service exists (the web profile); headless compositions load
 * the plugin without it. All business outcomes are returned as RpcResult
 * values; handlers never throw.
 */
import type { Context } from '@deepseek-ai/cordis';
import type { ImageAttachmentRef } from '@deepseek-ai/dsh-attachment';
import { type ProviderId } from './store.js';
import type { ClaudeCredentialMode } from './claude-credential-ownership.js';
import type { SpeedTier } from '../model-defaults.js';
import type { ProviderUsage, ResetCreditConsumeResult, ResetCreditList } from '../providers/common.js';
import type { ProxyConfigView, ProxyDraft, ProxyInput, ProxyTestResult } from '../http.js';
import type { ControlRequirements } from '../claude-core/control-requirements.js';
/**
 * Endpoint-name prefix under the shared `/api` channel: endpoint `status`
 * is served at `/api/subscriptions-auth.status`. The browser half calls
 * `rpc.call('/api', 'subscriptions-auth.status', payload)`.
 */
export declare const SUBSCRIPTIONS_AUTH_PREFIX = "subscriptions-auth.";
/** Decoded image bytes returned by the `image` endpoint. */
export interface ImageBytesResult {
    mediaType: string;
    dataBase64: string;
}
/** Decoded video bytes returned by the `video` endpoint. */
export interface VideoBytesResult {
    mediaType: string;
    dataBase64: string;
}
/** One model's speed choice: standard routing or the fast (priority) tier. */
export type { SpeedTier };
/** `speed` endpoint value: one model's stored tier plus the visibility list. */
export interface SpeedState {
    /** The stored tier for the requested model (default `standard`). */
    tier: SpeedTier;
    /** Fast-capable ids for the requested provider; Codex includes its independent account rows. */
    fastModels: string[];
}
/** Speed state the RPC handler delegates to (the durable per-model store). */
export interface SpeedController {
    /** Current speed state for one provider's model: its stored tier and the fast-capable models. */
    speed(provider: ProviderId, model: string): Promise<SpeedState>;
    /** Store one provider's model tier; `standard` clears the stored entry. */
    setSpeed(provider: ProviderId, model: string, tier: SpeedTier): Promise<void>;
}
/**
 * Fixed reason codes a credential dimension may carry. A closed set, so no
 * provider or transport text can reach the client through this field.
 */
export type CredentialCode = 'REAUTH_REQUIRED';
/**
 * Credential dimension of one account: whether the stored authorization can
 * serve a request at all. Independent of quota and protocol state. The states
 * mirror the account-maintenance owner's own closed set, so the projection
 * reports exactly what that owner decided.
 */
export interface CredentialStatus {
    state: 
    /** A stored credential exists and nothing is wrong with it. */
    'ready'
    /** A refresh cycle is running for this account. */
     | 'refreshing'
    /** The provider permanently refused the credential; a user login is required. */
     | 'reauth_required'
    /** No credential is stored. */
     | 'missing'
    /** Expiry is unknown, so no deadline can be scheduled. */
     | 'unknown-expiry'
    /** The credential's source is externally owned, so this plugin does not renew it on a timer. */
     | 'maintenance-unsupported'
    /**
     * The credential's source is externally owned and this plugin may still refresh it and
     * write the rotation back through the pre-existing path; coordination with that external
     * holder is not proven, so the same grant may be spent twice.
     */
     | 'external-coordination-unproven';
    /** Fixed reason code; absent for a usable credential. */
    code?: CredentialCode;
    /** Epoch ms the parking record expires, when the source stated one; absent means unknown. */
    until?: number;
    /** Epoch ms the owner may next run its credential check. */
    nextCheckAt?: number;
}
/** Fixed reason codes an availability dimension may carry. */
export type AvailabilityCode = 'QUOTA_EXHAUSTED' | 'RATE_LIMITED' | 'ENFORCEMENT_REFUSAL' | 'PROVIDER_UNAVAILABLE' | 'REQUEST_TIMEOUT' | 'MODEL_UNAVAILABLE' | 'PROVIDER_ERROR';
/**
 * Availability dimension of one account: a quota window, a transient provider
 * failure, or a refusal the provider aimed at this identity. Never merged with
 * the credential dimension, so "sign-in expired" cannot render as a cooldown.
 */
export interface AvailabilityStatus {
    /** `refused` is a stated refusal, which is not a waitable cooldown. */
    state: 'available' | 'cooling' | 'transient' | 'refused';
    /** Fixed reason code; absent for `available`. */
    code?: AvailabilityCode;
    /** Epoch ms the parking record expires; absent means the recovery time is unknown. */
    until?: number;
}
/** Fixed reason codes a protocol dimension may carry. */
export type ProtocolCode = 'CLIENT_VERSION_UNSUPPORTED' | 'UNSUPPORTED_RESPONSE';
/**
 * Protocol-compatibility dimension of the account's frozen wire profile. A
 * version refusal is not cleared by a re-login or a quota reset.
 */
export interface ProtocolStatus {
    state: 'current' | 'upgrade_required' | 'unsupported_response';
    /** Fixed reason code; absent for `current`. */
    code?: ProtocolCode;
    /** Protocol-configuration id/fingerprint the state belongs to. */
    profileId?: string;
    /** Epoch ms the state was first observed. */
    since?: number;
}
/**
 * Account-profile freshness dimension. `stale`/`unavailable` describe the
 * cached profile only and never claim the credential became invalid.
 */
export interface ProfileStatus {
    state: 'fresh' | 'stale' | 'missing' | 'unavailable';
    /** Epoch ms the retained profile was captured. */
    capturedAt?: number;
    /** Whether the retained profile carries every field the current protocol requires. */
    complete?: boolean;
}
/** Fixed reason codes a managed-policy dimension may carry, from its own blockers. */
export type PolicyCode = 'POLICY_UNSUPPORTED' | 'POLICY_INVALID_VALUE' | 'POLICY_CONSENT_REQUIRED';
/** The operation scope a managed-policy restriction or blocker reaches. */
export type PolicyScope = 'tool' | 'model' | 'mcp' | 'execution' | 'network' | 'unknown';
/**
 * Managed-policy dimension of one account. `blocked` is the state an
 * unsupported or unapplied restriction leaves: the operations it affects stay
 * suspended rather than silently continuing.
 */
export interface PolicyStatus {
    state: 'ineligible' | 'loading' | 'current' | 'stale' | 'unavailable' | 'consent-required' | 'blocked';
    /** Fixed code of the first blocker; absent while no restriction blocks an operation. */
    code?: PolicyCode;
    /** The operations or models the state applies to; absent means the whole account. */
    scope?: PolicyScope;
    /** Epoch ms the retained policy snapshot was fetched. */
    fetchedAt?: number;
}
/** Fixed reason codes a Claude policy-limits dimension may carry. */
export type PolicyLimitsCode = 
/** The read could not use the stored credential. Whether that credential is still valid is the credential dimension's fact, not this one. */
'CREDENTIAL_UNAVAILABLE'
/** The provider refused the credential for this read. */
 | 'AUTH_REJECTED'
/** The read failed at the transport or status level. */
 | 'REQUEST_FAILED'
/** The response did not satisfy the pinned `policy_limits` envelope. */
 | 'PARSE_FAILED'
/** This plugin's own response-size bound stopped the read; the provider stated no restriction. */
 | 'RESPONSE_OVER_LIMIT';
/**
 * Fixed blocker codes a policy-limits dimension may carry, the owner's own
 * closed set. While any is in force every verdict is refused, so a restriction
 * this build could not re-state never leaves an operation silently allowed.
 */
export type PolicyLimitsBlocker = 
/** The durable store exists but cannot be trusted; a restriction may have been lost. */
'policy_limits_state_unavailable'
/** The stored document stated restriction keys this build cannot re-state. */
 | 'policy_limits_unknown_keys'
/** The stored document named core skills, whose names are not retained. */
 | 'policy_limits_core_skills_unstored'
/** The stored document's taints did not all normalize, so its taint set is incomplete. */
 | 'policy_limits_lossy_taints';
/** The monitoring notice the owner holds, already normalized and bounded by the core's parse. */
export interface PolicyLimitsOwnerNotice {
    readonly text: string;
    /** The url the server stated, or `null` for none. */
    readonly url: string | null;
}
/**
 * The monitoring notice the client renders. Its text is displayed as text, and
 * its url is a destination the user opens deliberately: the client links it and
 * never fetches it.
 */
export interface PolicyLimitsNotice {
    /** The notice text, normalized and bounded by the core's parse. */
    text: string;
    /** The notice's https url, when the server stated a usable one. */
    url?: string;
}
/**
 * Claude `policy_limits` dimension of one account: whether this build holds a
 * limits document and what that document refuses. Independent of the
 * managed-settings {@link PolicyStatus} — separate documents, separate owners,
 * neither replacing the other.
 *
 * Only fixed codes, counts, booleans and the normalized notice cross to the
 * client: the adopted document, its `defaults`, its core-skill names and its
 * taint values stay on the host, counts replace the key lists, the control
 * obligations arrive as this build's own fixed tri-state, and the notice arrives
 * as its own text rather than as a document member.
 */
export interface PolicyLimitsStatus {
    /**
     * `ineligible` is an eligibility refusal, never a document that came back
     * empty; `blocked` is a restriction in force, never a quota state.
     */
    state: 'ineligible' | 'loading' | 'current' | 'stale' | 'unavailable' | 'blocked';
    /** Fixed reason code; absent when the state alone states the outcome. */
    code?: PolicyLimitsCode;
    /** Fixed blockers in force; absent while the document is enforced as stated. */
    blockers?: readonly PolicyLimitsBlocker[];
    /** Epoch ms the retained document was fetched; absent when none was ever adopted. */
    fetchedAt?: number;
    /** How many registered keys this build cannot enforce exactly; absent when there are none. */
    unknownCount?: number;
    /** How many keys the retained document refuses; the key names themselves are not sent. */
    deniedCount?: number;
    /** How many compliance taints are in force; the taint values themselves are not sent. */
    taintCount?: number;
    /** How many configured capabilities this build does not provide; absent when there are none. */
    unsupportedScopeCount?: number;
    /**
     * The control obligations the document in force states, when it states any. The owner's own
     * tri-state answers whether each is in force, and `unsupportedActiveControls` names the ones
     * in force that this build provides no capability for. Nothing here refuses an operation.
     */
    controlRequirements?: ControlRequirements;
    /**
     * Whether a monitoring notice is in force. A notice restricts no key, so this
     * is a display fact: {@link PolicyLimitsStatus.noticeContent} carries its text
     * once this process has read it.
     */
    notice?: boolean;
    /**
     * The notice's text and url, when this process read them. Absent while only
     * the notice's existence is retained, which the client states as text it has
     * not read rather than as no notice.
     */
    noticeContent?: PolicyLimitsNotice;
    /**
     * What the verdicts are answered from: a document this process confirmed
     * (`live`), one kept through a failed read or restored from the durable store
     * (`stale`), or nothing at all (`none`, where the no-live-policy order
     * answers).
     */
    fallback: 'live' | 'stale' | 'none';
}
/**
 * The policy-limits owner's own status, as {@link projectPolicyLimits} reads
 * it. Only these members are consulted, so no adopted document, default value,
 * core-skill name, taint value or notice text can reach the client through this
 * path.
 */
export interface PolicyLimitsOwnerStatus {
    readonly state: PolicyLimitsStatus['state'];
    /** The owner's own reason text; it never reaches the client verbatim. */
    readonly reason: string;
    readonly fallback: PolicyLimitsStatus['fallback'];
    readonly fetchedAt?: number;
    /** Keys the live document refused; the client receives their count only. */
    readonly deniedKeys?: readonly string[];
    /** The fixed failure the last read produced, when it failed. Only its fixed sub-reason is read. */
    readonly failure?: {
        readonly reason?: string;
    };
    /** The owner's blockers in force, as its own fixed codes. */
    readonly blockers?: readonly string[];
    /** Whether a monitoring notice is in force; its text arrives through the notice argument. */
    readonly notice?: boolean;
    /** The compliance taints in force; the client receives their count only. */
    readonly taints?: readonly string[];
    /** Capabilities the document configures that this build does not provide; only their count is read. */
    readonly unsupportedScopes?: readonly {
        readonly scope: string;
        readonly reason: string;
    }[];
    /** The control obligations the document in force states, when it states any. */
    readonly controlRequirements?: ControlRequirements;
}
/**
 * Project the policy-limits owner's status onto the client's dimension.
 *
 * The owner's reason is free-form text, its denied keys and taints carry remote
 * values, and a notice carries remote prose and a destination, so each is
 * mapped: a reason reaches the client only as a fixed code, a key list and a
 * taint list only as counts, and a notice only through {@link policyLimitsNotice}.
 * The control obligations cross as their own closed triple of this build's own
 * fixed values, never as the server's key names.
 * @param status - the owner's status for one account, or undefined when it holds none.
 * @param unsupported - the owner's unmapped-key gaps for that account, when it reports any.
 * @param notice - the owner's notice for that account, when its text was read.
 * @returns the projected dimension, or undefined so the client omits it instead
 *   of reporting it healthy.
 */
export declare function projectPolicyLimits(status: PolicyLimitsOwnerStatus | undefined, unsupported?: readonly {
    readonly key: string;
    readonly reason: string;
}[], notice?: PolicyLimitsOwnerNotice | undefined): PolicyLimitsStatus | undefined;
/**
 * How one Claude account's credential is owned, as the Settings surface reports it.
 *
 * This is provenance and write authority only: `firstPartyOAuth` is a separate fact, and the
 * mode never decides whether an organization policy applies.
 */
export interface CredentialOwnershipStatus {
    /** The stored or inferred ownership mode. */
    mode: 'legacy-writeback' | 'read-only-import' | 'independent-oauth';
    /** Whether a store outside this plugin holds the credential. */
    external: boolean;
    /**
     * Present only for `legacy-writeback`: this plugin may spend the same refresh grant the
     * external holder spends, and coordination with that holder is not proven.
     */
    coordinationUnproven?: true;
}
/**
 * Every independent state one account is reported in. Each dimension is
 * computed by its own owner; a dimension whose owner has nothing to report is
 * omitted rather than defaulted to a healthy value.
 */
export interface AccountStatus {
    /** Stable account key (store identity). */
    key: string;
    /** Display identity (email / login), when known. */
    account?: string;
    /** Epoch milliseconds at which the stored access token expires. */
    expiresAt?: number;
    /** Plan name the session carries (codex planType / claude subscriptionType), when known. */
    plan?: string;
    /** Whether direct (non-pool) routes serve this account. */
    isDefault: boolean;
    /** Credential dimension. Always reported: it is what the account roster itself proves. */
    credential: CredentialStatus;
    /**
     * Credential ownership, reported for routes that have the concept (Claude only). Absent
     * everywhere else, where there is no mode to state.
     */
    credentialOwnership?: CredentialOwnershipStatus;
    /** Quota / temporary availability; absent while nothing has parked this account. */
    availability?: AvailabilityStatus;
    /** Protocol compatibility of the frozen profile; absent for routes without one. */
    protocol?: ProtocolStatus;
    /** Account-profile freshness; absent for routes without profile maintenance. */
    profile?: ProfileStatus;
    /** Managed policy; absent until eligibility for this account was evaluated. */
    policy?: PolicyStatus;
    /** Claude policy limits; absent while no owner reports this account. */
    policyLimits?: PolicyLimitsStatus;
}
/** The provider operation a recorded failure belongs to. */
export type ProviderOperation = 'login' | 'import' | 'logout' | 'status';
/**
 * Fixed code describing one recorded provider-operation failure. Closed set:
 * the client renders its own localized copy per code, so no server text is
 * stored or shown.
 */
export type ProviderFailureCode = 'CANCELLED' | 'CREDENTIALS_UNAVAILABLE' | 'CREDENTIALS_REJECTED' | 'PROVIDER_REJECTED' | 'NETWORK' | 'TIMEOUT' | 'INVALID_RESPONSE' | 'UNKNOWN';
/** One recorded provider-operation failure, in allowlisted fields only. */
export interface ProviderOperationFailure {
    /** Fixed failure code. */
    code: ProviderFailureCode;
    /** Operation the failure belongs to. */
    operation: ProviderOperation;
    /** Epoch ms the failure was recorded. */
    at: number;
    /** HTTP status the provider answered with, when it sent one. */
    status?: number;
    /** The provider's own error code (e.g. OAuth `invalid_grant`), never a message. */
    providerCode?: string;
    /** Earliest instant a retry is accepted, when the provider stated one. */
    retryAt?: number;
}
/** Fixed code naming why this plugin refused to register one provider route. */
export type ProviderUnavailableCode = 
/** The Host build does not declare the failure-recovery contract the route requires. */
'CLAUDE_HOST_INCOMPATIBLE';
/** Login state of one provider, as rendered by the Settings page. */
export interface ProviderStatus {
    /** Whether a login attempt is currently waiting for its code. */
    busy: boolean;
    /** Logged-in accounts, default first. */
    accounts: AccountStatus[];
    /**
     * The last failed operation, shown until the next success on that provider.
     * Replaces a free-text detail line: the client localizes it from {@link ProviderFailureCode}.
     */
    lastError?: ProviderOperationFailure;
    /**
     * Present when this plugin refused to register the route for this Host, so
     * the card can state why instead of showing an unexplained logged-out route.
     */
    unavailable?: ProviderUnavailableCode;
}
/** How a Claude login should acquire credentials (other providers ignore it). */
export type LoginMethod = 'oauth' | 'keychain' | 'manual';
/** Proxy config operations behind the `proxyGet/proxySet/proxyTest` endpoints. */
interface ProxyConfigController {
    /** Current proxy configuration (secrets omitted). */
    get(): Promise<ProxyConfigView>;
    /** Validate, persist, and apply one config. */
    set(input: ProxyInput): Promise<ProxyConfigView>;
    /** Probe one destination through the draft (unsaved) or stored proxy. */
    test(payload: {
        url?: string;
        proxy?: ProxyDraft;
    }): Promise<ProxyTestResult>;
}
/** Provider and account preference operations behind providerSettings/setProviderSettings. */
interface ProviderSettingsController {
    get(provider: ProviderId, force: boolean, refresh?: boolean): Promise<unknown>;
    set(provider: ProviderId, settings: unknown): Promise<void>;
}
export interface ModelDefaultsController {
    /** Set one model's configured default effort; undefined clears the override. */
    set(provider: ProviderId, model: string, effort: string | undefined): Promise<void>;
}
/** Provider-agnostic auth operations the RPC handler delegates to. */
export interface AuthController {
    /** Current status of one provider. */
    status(provider: ProviderId): Promise<ProviderStatus>;
    /**
     * Start a background login attempt.
     * @param provider - the provider route.
     * @param method - Claude only: force the OAuth browser flow or the Claude
     *   Code credential import; omitted keeps the auto behavior (import when
     *   available, else OAuth).
     * @returns the authorize URL for the user's browser; device-flow providers
     *   (copilot) also return the `userCode` the user types at that URL.
     * @throws when an attempt is already running for this provider.
     */
    login(provider: ProviderId, method?: LoginMethod): Promise<{
        authorizeUrl: string;
        userCode?: string;
    }>;
    /**
     * Feed a pasted callback URL or bare code into the pending attempt.
     * @throws when no attempt is pending or the input is unusable.
     */
    manual(provider: ProviderId, input: string): Promise<void>;
    /** Abort the pending attempt; a no-op when none is pending. */
    cancel(provider: ProviderId): Promise<void>;
    /** Delete one account's stored session. */
    logout(provider: ProviderId, account: string): Promise<void>;
    /** Pin the account direct (non-pool) routes serve. */
    setDefault(provider: ProviderId, account: string): Promise<void>;
    /**
     * Persist one Claude account's credential-ownership mode.
     *
     * The mode decides who may rotate the credential: only `legacy-writeback` may spend the
     * shared refresh grant and write back, and only `independent-oauth` runs this plugin's own
     * renewal timer. Moving between the two external modes is a setting this call may persist;
     * `independent-oauth` is not, because it means this plugin holds its own authorization, which
     * only the browser sign-in flow can produce.
     * @param riskAcknowledged - the caller's explicit statement that it showed the
     *   legacy-writeback risk and the user accepted it. Enforced by this server rather than
     *   trusted from a client, so no caller of the channel can move an account onto the
     *   grant-spending mode without stating it.
     * @throws BadRequest when the account is unknown, the requested conversion is refused, or a
     *   real conversion onto legacy-writeback arrives without the risk acknowledgement.
     */
    setCredentialOwnership(provider: ProviderId, account: string, mode: ClaudeCredentialMode, riskAcknowledged: boolean): Promise<void>;
    /**
     * Local subscription usage snapshot for one account. Plain reads never query
     * the provider; missing data is reported through cache metadata, not as zero usage.
     * @param signal - caller cancellation from the RPC transport.
     * @param force - explicitly refresh even a fresh success; failure cooldown still applies.
     * @param refresh - allow a scoped refresh only if the cached data needs one.
     * @returns the retained usage and freshness metadata, or `{ supported: false }`.
     * @throws on caller cancellation or a credential failure during an explicit refresh.
     */
    usage(provider: ProviderId, account: string, signal: AbortSignal, force?: boolean, refresh?: boolean): Promise<ProviderUsage>;
    /**
     * Banked ChatGPT reset credits for one account. Other providers answer
     * `{ supported: false }` and make no network call.
     * @param force - bypass a fresh cached list. A live failure cooldown still applies.
     */
    listResetCredits(provider: ProviderId, account: string, signal: AbortSignal, force?: boolean): Promise<ResetCreditList>;
    /**
     * Spend one ChatGPT reset credit. The request id is the caller's idempotency
     * key and is forwarded unchanged.
     */
    consumeResetCredit(provider: ProviderId, account: string, creditId: string, redeemRequestId: string, signal: AbortSignal): Promise<ResetCreditConsumeResult>;
    /**
     * Read one image attachment's bytes for inline display.
     * @param ref - the full durable reference (`readImage` verifies against it).
     * @param signal - caller cancellation from the RPC transport.
     * @returns the media type and base64-encoded bytes.
     * @throws when no attachment service is mounted or the read fails.
     */
    readImage(ref: ImageAttachmentRef, signal: AbortSignal): Promise<ImageBytesResult>;
    /**
     * Read one generated video's bytes for inline playback.
     * @param name - bare MP4 file name inside the plugin's videos directory
     *   (validated against {@link VIDEO_NAME_PATTERN}; never a path).
     * @param signal - caller cancellation from the RPC transport.
     * @returns the media type and base64-encoded bytes.
     * @throws when the file does not exist or cannot be read.
     */
    readVideo(name: string, signal: AbortSignal): Promise<VideoBytesResult>;
}
/** Payload carried no usable provider id — an RPC client bug, not a server failure. */
export declare class BadRequest extends Error {
}
/**
 * Register the `/subscriptions-auth` RPC channel when a host connection exists.
 * @param ctx - the plugin context (headless profiles have no `connection`).
 * @param controller - the auth operations backing the endpoints.
 * @param speed - the durable per-model speed-tier state backing the Speed toggle.
 * @param proxy - optional proxy-config controller backing `proxyGet`/`proxySet`/`proxyTest`.
 * @param modelDefaults - optional per-model effort writer; catalogue reads belong to `providerSettings`.
 */
export declare function registerAuthRpc(ctx: Context, controller: AuthController, speed: SpeedController, proxy?: ProxyConfigController | undefined, modelDefaults?: ModelDefaultsController | undefined, providerSettings?: ProviderSettingsController | undefined): void;
