/**
 * Translate between the harness message vocabulary and the Anthropic Messages
 * API wire format used by the claude provider: request message assembly, tool
 * schema mapping, and a push-model SSE-event → StreamChunk state machine
 * ({@link AnthropicStreamTranslator}) so tests need no streams.
 */
import type { ClaudeSseErrorObject } from '../providers/claude-failure.js';
import type { ClaudeProtocolProfile } from '../providers/claude-protocol.js';
import type { ClaudeRefusalProbe } from '../providers/claude-failure.js';
import type { ClaudeAccountRef } from '../claude-core/account-ref.js';
export type { ClaudeRefusalProbe as AnthropicRefusalProbe } from '../providers/claude-failure.js';
/**
 * The identity facts one accepted Claude response records beside its blocks.
 *
 * The adapter's own state is the only source of these: the account reference the salt derives, the
 * identity generation in force, and the span's harness session and committed wire session. The
 * request id belongs to the response itself, so the translator adds it.
 */
export interface ClaudeContinuationMetadata {
    /** The account the turn was served for, as the store's verifiable reference. */
    readonly accountRef: ClaudeAccountRef;
    /** The identity generation in force when the turn was served. */
    readonly spanEpoch: number;
    /** The harness session the turn belongs to. */
    readonly harnessSessionId: string;
    /** The wire session the turn was served under. */
    readonly wireSessionId: string;
}
declare module '@deepseek-ai/dsh-llm' {
    interface FinishReasonMap {
        'refusal': {
            kind: 'refusal';
        };
    }
}
import type { StreamChunk, ToolSchema } from '@deepseek-ai/dsh-llm';
import type { MessageContent, TextBlock, ToolDefinition as ClaudeToolDefinition } from '@tormentalabs/claude-code-wire-compat';
/**
 * Block types the public package surface derives but does not name directly.
 * Each alias extracts from an exported union so the shapes cannot drift.
 */
type WireBlock = Exclude<MessageContent, string>[number];
import type { TranslatableMessage } from './resolved.js';
/**
 * Tags wrapping a mid-conversation system message where it sits in the history.
 */
export declare const NO_CONTENT_TEXT = "(no content)";
/**
 * The genuine client's own text for the `tool_result` it synthesizes when a
 * `tool_use` in the request has no result to answer it.
 */
export declare const MISSING_TOOL_RESULT_TEXT = "[Tool result missing due to internal error]";
/**
 * Failure code for a response the harness cannot complete a turn from: a stop
 * reason this adapter has no way to continue, or server-tool content with
 * nothing the harness can present or answer. Deliberately outside every
 * subscription route's retryable set, so the request is not repeated
 * automatically and the turn fails instead of passing as a completed one.
 */
export declare const UNSUPPORTED_RESPONSE_CODE = "UNSUPPORTED_RESPONSE";
/**
 * One Anthropic request message. The Claude Code identity and billing blocks
 * are emitted by the wire builder, never here.
 */
interface AnthropicMessage {
    role: 'user' | 'assistant' | 'system';
    /**
     * A mid-conversation system message carries its text as a plain string, which is what
     * the genuine client sends; every other message carries blocks.
     */
    content: WireBlock[] | string;
    /** Clears a mid-conversation system message once the next user message arrives. */
    clear_at?: 'next_user_message';
}
/**
 * Convert harness messages into Anthropic messages. Consecutive same-role
 * messages merge into one message with multiple content blocks; tool results
 * arrive as user messages with `tool_result` blocks, which a merged user
 * message keeps in one leading run ({@link leadWithToolResults}); system-role
 * messages before the conversation starts are handled by
 * {@link toAnthropicSystem} and skipped here, while a later one rides in
 * place as a user-role `<system-reminder>` block (the wire contract models no
 * system-role message).
 * Signed thinking blocks are replayed for the same Claude model; unsigned
 * reasoning is omitted because the API rejects a thinking block with no
 * signature. Images must arrive pre-resolved ({@link TranslatableMessage});
 * an unresolved ImageBlock is skipped because its bytes are unreachable here.
 * A tool result whose `tool_use` was narrated away (a settled subagent's
 * closing message) is narrated the same way, because the wire validator
 * rejects any `tool_result` whose call id is not in the request; conversely a
 * `tool_use` with no result is answered by the synthesized error result the
 * genuine client adds ({@link MISSING_TOOL_RESULT_TEXT}). Both repairs touch
 * only the assembled request, never the history.
 * @param messages - ordered conversation messages with resolved images.
 * @param model - the model this request targets. Thinking signatures are
 *   model-bound, so a signature from another model is not replayed.
 * @param midConversationSystem - whether this model accepts a mid-conversation system
 *   message. The caller answers with the same predicate that decides the beta header, so
 *   the message and the header cannot disagree.
 * @returns Anthropic messages in conversation order.
 */
export declare function toAnthropicMessages(messages: readonly TranslatableMessage[], model?: string, midConversationSystem?: boolean): AnthropicMessage[];
/**
 * Build the Anthropic `system` array: the explicit system prompt, then any
 * system-role messages preceding the conversation. The wire builder places
 * the Claude Code billing and identity blocks ahead of these and owns cache
 * breakpoint placement.
 * @param system - explicit system prompt, when set.
 * @param messages - conversation messages; the system-role text preceding the
 *   conversation is appended, and a later one is left to {@link toAnthropicMessages}.
 * @returns the caller system content blocks.
 */
export declare function toAnthropicSystem(system?: string, messages?: readonly TranslatableMessage[]): TextBlock[];
export declare function toAnthropicTools(tools: readonly ToolSchema[]): ClaudeToolDefinition[];
/**
 * Usage fields this translator reads. `thinking_tokens` requires beta
 * `thinking-token-count-2026-05-13`. Missing and null counts preserve earlier values.
 */
interface AnthropicUsage {
    input_tokens?: number | null;
    output_tokens?: number | null;
    cache_read_input_tokens?: number | null;
    cache_creation_input_tokens?: number | null;
    output_tokens_details?: {
        thinking_tokens?: number | null;
    } | null;
}
/** The subset of Anthropic SSE event shapes this translator reads. */
/**
 * The server's own account of the context edits it applied to this response.
 *
 * Present only while the context-management beta is active and only when an edit ran, so an
 * absent field means the server applied nothing.
 */
interface AnthropicContextManagement {
    readonly applied_edits?: readonly {
        readonly type?: string;
        readonly cleared_tool_uses?: number;
        readonly cleared_input_tokens?: number;
    }[];
}
export interface AnthropicStreamEvent {
    type: string;
    index?: number;
    message?: {
        usage?: AnthropicUsage;
    };
    content_block?: {
        type?: string;
        id?: string;
        name?: string;
        /** Opaque payload of a `redacted_thinking` block. Must be replayed verbatim. */
        data?: string;
        /** `server_tool_use` input: the start object's value, or what `input_json_delta` builds. */
        input?: unknown;
        /** `tool_search_tool_result` payload. Opaque; replayed verbatim. */
        content?: unknown;
        /** The `server_tool_use` call a `tool_search_tool_result` answers. */
        tool_use_id?: string;
    };
    delta?: {
        type?: string;
        text?: string;
        thinking?: string;
        /** Cryptographic signature the next request must send back unchanged. */
        signature?: string;
        partial_json?: string;
        stop_reason?: string;
    };
    usage?: AnthropicUsage;
    /**
     * The provider's error object, read whole: a refusal can be named by the event's type, by a
     * flat code, or by a code nested under `details`, and the classifier reads all three.
     */
    error?: ClaudeSseErrorObject;
    /** The edits the server applied to this response, when it applied any. */
    context_management?: AnthropicContextManagement;
}
/**
 * Push-model Anthropic SSE translator: feed each parsed event object to
 * {@link push} and collect the emitted harness StreamChunks. Block indexes
 * are allocated in first-seen order; `usage` is emitted before the terminal
 * `finish`, and nothing is emitted after it. `error` events throw
 * {@link LlmError}. A stop reason this adapter cannot continue — a paused turn,
 * a server-side compaction, or one it does not model — and a response whose only
 * content was server-tool blocks both end as an error finish carrying
 * {@link UNSUPPORTED_RESPONSE_CODE} rather than an ordinary stop.
 */
export declare class AnthropicStreamTranslator {
    private readonly requestId?;
    private readonly isRefusal?;
    private readonly profile;
    private readonly continuation?;
    private blocks;
    /** Replay entries aligned with harness block indexes. */
    private replay;
    /** Server-tool blocks captured for the next request, in arrival order. */
    private serverBlocks;
    /** Harness block kind per harness index, so a pruned response can rebase captures. */
    private blockKinds;
    /** Open server-tool blocks under assembly, by wire index. */
    private openServerBlocks;
    private nextIndex;
    private sawAnyBlock;
    /** Token totals every usage object so far has stated, in harness terms. */
    private reportedUsage;
    private stopReason;
    /** The stop reason that left the turn uncontinuable, for the failure it reports. */
    private unsupportedStopReason;
    private usageEmitted;
    /** Set once `message_stop` produced the terminal finish chunk. */
    terminated: boolean;
    /**
     * Whether any chunk other than the terminal finish has gone out for this response.
     *
     * The first chunk the Host receives commits the attempt, so this is the delivery
     * boundary a later failure reports: a failure after it may not be replayed.
     */
    private delivered;
    /** Set when a tool block closed with arguments that do not parse as JSON. */
    private incompleteToolSeen;
    /**
     * @param requestId - the `request-id` response header this stream answers, recorded on
     *   the finish envelope so the request the model saw and the response it produced stay
     *   checkable from the session log. Omitted when the response carried no such header.
     * @param isRefusal - classifies an in-band `error` event against the response it
     *   arrived on. Omitted when the caller has no response to classify against.
     * @param profile - the frozen compatibility profile this stream was opened under.
     * @param continuation - the identity facts this attempt was prepared under, when the
     *   adapter has them; they are recorded with every accepted response.
     */
    constructor(requestId?: string | undefined, isRefusal?: ClaudeRefusalProbe | undefined, profile?: ClaudeProtocolProfile, continuation?: ClaudeContinuationMetadata | undefined);
    private open;
    /** Remember the signature or redacted payload for one closed block. */
    private remember;
    /** Start capturing a server-tool block, which occupies no harness block index. */
    private openServer;
    /** Finalize one captured server-tool block and keep it for the next request. */
    private closeServer;
    /** The edits the server reported applying to this response, when it reported any. */
    private appliedEdits;
    /**
     * The captured server-tool blocks with positions in the assembled message.
     *
     * A capture records how many harness blocks preceded it in the response, which
     * is also where it goes back while the message keeps every block. Assembly
     * drops the tool calls of a response that ended at a generation limit, so that
     * recorded position would name a block the message no longer carries and the
     * next request would emit the captured pair after text it originally led.
     * Rebasing past the dropped blocks ahead of each capture leaves every index a
     * position in the message's own blocks, pruned or not.
     * @returns the captures, in arrival order, at message positions.
     */
    private rebasedServerBlocks;
    /**
     * Replay envelope for a successful response that carried something the adapter
     * must remember: thinking the next turn has to echo, the context edits the
     * server reported applying, a server-tool block the request has to carry back,
     * or the response's own request id. Omitted when the response carried none of
     * them, so a plain text response with no request id stays free of adapter
     * metadata.
     */
    private replayEnvelope;
    /**
     * The continuation member this attempt's prepared identity facts state.
     *
     * The identifier the next request chains is the response's own `request-id`, which the caller
     * reads from the answered response; a response that carried none records the identity without it,
     * and the reader then skips that turn rather than chaining a value it never saw.
     * @returns the accepted-core continuation, or undefined when the caller prepared no facts.
     */
    private continuationEnvelope;
    /**
     * Fold one event's usage into the stream's totals.
     *
     * Counts are totals, not increments. A later number, including zero, replaces
     * that field; absent/null fields retain their earlier values. Input and cache
     * counters stay disjoint, as required by the harness usage contract.
     * @param usage - the usage object the event carried.
     */
    private mergeUsage;
    private emitUsage;
    /**
     * Process one parsed Anthropic SSE event.
     *
     * Everything except the terminal finish counts as delivered output: a usage report, a
     * reasoning fragment and a tool-argument fragment all reach the Host, so they commit the
     * attempt exactly as visible text does.
     * @param event - the parsed event object.
     * @returns the StreamChunks this event produced (possibly none).
     */
    push(event: AnthropicStreamEvent): StreamChunk[];
    /**
     * Apply one parsed event to this stream's state.
     * @param event - the parsed event object.
     * @returns the StreamChunks this event produced (possibly none).
     */
    private handle;
}
/**
 * Consume an Anthropic SSE byte stream and yield harness StreamChunks.
 * @param stream - raw response body.
 * @param onActivity - transport-activity callback for the idle watchdog.
 * @param requestId - the response's `request-id` header, when it carried one.
 * @param isRefusal - classifies an in-band `error` event against the response it
 *   arrived on, so a refusal stated inside a 200 is not retried as a rate limit.
 * @param profile - the frozen compatibility profile this request was built under.
 * @param continuation - the identity facts this attempt was prepared under, when the adapter has
 *   them; they are recorded with every accepted response.
 * @returns the chunk stream; throws when the stream ends before `message_stop`, with the
 *   delivery boundary the caller needs to decide whether a replay is still permitted.
 */
export declare function streamAnthropic(stream: ReadableStream<Uint8Array>, onActivity?: () => void, requestId?: string, isRefusal?: ClaudeRefusalProbe, profile?: ClaudeProtocolProfile, continuation?: ClaudeContinuationMetadata): AsyncGenerator<StreamChunk>;
