/** Demand-driven freshness and failure cooldowns for subscription metadata caches. */
import z from '@deepseek-ai/schemastery';
/** Freshness permits an explicit refresh; it never schedules background polling. */
export interface SubscriptionCachePolicy {
    /** Maximum age of an account's model catalogue before its next use may refresh it. */
    modelMaxAgeMs: number;
    /** Maximum age of usage facts before an actual candidate needs confirmation. */
    usageMaxAgeMs: number;
    /** Minimum delay after a failed metadata query; a longer server retry delay wins. */
    retryDelayMs: number;
}
/** Configuration defaults for account-scoped metadata, not timer intervals. */
export declare const SubscriptionCacheSchema: z<Schemastery.ObjectS<NoInfer<{
    modelMaxAgeMs: z<number, number, "defined">;
    usageMaxAgeMs: z<number, number, "defined">;
    retryDelayMs: z<number, number, "defined">;
}>>, Schemastery.ObjectT<NoInfer<{
    modelMaxAgeMs: z<number, number, "defined">;
    usageMaxAgeMs: z<number, number, "defined">;
    retryDelayMs: z<number, number, "defined">;
}>>, "plain">;
/**
 * Resolve cache policy before adapters or stores start work.
 * @param input - deployment overrides for the three demand checks.
 * @returns a complete policy with positive safe-integer durations.
 * @throws when a configured duration is invalid.
 */
export declare function resolveSubscriptionCachePolicy(input?: Partial<SubscriptionCachePolicy>): SubscriptionCachePolicy;
