/**
 * The Claude rejection vocabulary, standalone.
 *
 * This module is the single home of the client-version refusal markers, the known Anthropic
 * error-event types and their classification. It imports nothing from the harness or from the
 * plugin's provider modules, so a caller outside the harness (the Mac worker today) can depend on
 * it without pulling in a desktop-shaped compatibility profile or a platform assumption.
 *
 * The plugin's `providers/claude-protocol.ts` re-exports these names for its own consumers, and
 * its profile machinery stays there; only the vocabulary lives here.
 *
 * @module dsh-plugin-subscriptions/claude-engine/failure-rules
 */
/** What a rejection is evidence about. */
export type ClaudeRuleScope = 'operation' | 'account' | 'provider-profile' | 'model' | 'unknown';
/** Whether automatic recovery may still run for a decided rejection. */
export type ClaudeRuleDisposition = 'forbid' | 'allow';
/**
 * Error codes and wording the service uses when it refuses a client version.
 *
 * Matched against a bounded, parsed error envelope and against bounded body text, so an echoed
 * request field cannot claim a version rejection the service never sent.
 */
export declare const CLAUDE_VERSION_REJECTION_MARKERS: readonly string[];
/**
 * Whether a bounded text contains a marker naming a client-version refusal.
 * @param text - bounded error text (structured fields and a capped body slice).
 * @returns true when the text names a known version-refusal code.
 */
export declare function matchesClaudeVersionRejection(text: string): boolean;
/** The classification one Anthropic error event's own fields name. */
export interface ClaudeErrorEventRule {
    /** Stable reason code. */
    readonly code: string;
    /** Whether automatic recovery may still run for this event's own fields. */
    readonly retryDisposition: ClaudeRuleDisposition;
    /** What the event, read alone, is evidence about. */
    readonly scope: ClaudeRuleScope;
    /** Whether the provider itself describes this event as a passing condition. */
    readonly transient: boolean;
}
/**
 * Classify one Anthropic `error` event from its own fields.
 *
 * The response an event arrived on can still make a classified-as-retryable event final; that
 * decision belongs to the caller that holds the response. This function answers only what the
 * event's own type, code and message support, and answers `undefined` for a type it has no
 * mapping for.
 * @param type - the event's `error.type` (or its code), when present.
 * @param message - the event's `error.message`, when present.
 * @returns the rule the event's own fields name, or undefined for an unknown type.
 */
export declare function anthropicErrorEventRule(type: string | undefined, message: string | undefined): ClaudeErrorEventRule | undefined;
/**
 * Whether a code is a provider error type this vocabulary already maps.
 * @param code - the code or type a response named.
 * @returns true when this module recognizes it.
 */
export declare function isKnownAnthropicErrorCode(code: string): boolean;
