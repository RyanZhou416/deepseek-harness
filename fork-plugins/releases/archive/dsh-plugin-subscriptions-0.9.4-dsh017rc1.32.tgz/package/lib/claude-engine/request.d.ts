/**
 * Raw Anthropic Messages DTO → one wire request, for a single account.
 *
 * The caller supplies the request body it already holds and the identity it wants attributed;
 * this module validates both and hands them to the maintained
 * `@tormentalabs/claude-code-wire-compat` builder, which owns the protocol identity, billing
 * header and beta composition. Nothing here re-implements or copies that package, and nothing
 * here invents a platform: an identity that is absent or internally inconsistent is refused
 * rather than filled in.
 *
 * Validation is strict by design, at every level. A field or nested member this engine does not
 * model is reported, never dropped: silently discarding it would send a request the caller did
 * not ask for.
 *
 * @module dsh-plugin-subscriptions/claude-engine/request
 */
import type { ClaudeCodeRequestInput, Message, SystemInput, ToolDefinition } from '@tormentalabs/claude-code-wire-compat';
/** The tool-choice directive, taken from the builder's own input contract. */
type ToolChoice = NonNullable<ClaudeCodeRequestInput['toolChoice']>;
import type { ClaudeEnginePolicy } from './request-policy.js';
import type { ClaudeEngineChain, ClaudeEngineFailure, ClaudeEngineIdentity, ClaudeEngineRequest } from './types.js';
/** The result of validating one caller-supplied body. */
export type ClaudeEngineValidation = {
    readonly ok: true;
    readonly body: ClaudeEngineValidatedBody;
} | {
    readonly ok: false;
    readonly failure: ClaudeEngineFailure;
};
/** A body that passed validation, with its wire-shaped members narrowed. */
export interface ClaudeEngineValidatedBody {
    /** Model id the body declares. */
    readonly model: string;
    /** Output cap the body declares. */
    readonly maxTokens: number;
    /** Conversation messages, validated at every level. */
    readonly messages: readonly Message[];
    /** System blocks, as the builder accepts them. */
    readonly system?: readonly SystemInput[];
    /** Tool definitions, validated. */
    readonly tools?: readonly ToolDefinition[];
    /** Tool-choice directive, forwarded verbatim once validated. */
    readonly toolChoice?: ToolChoice;
    /** Thinking configuration, when the caller requested one. */
    readonly thinking?: {
        readonly type: 'enabled' | 'adaptive' | 'disabled';
        readonly budgetTokens?: number;
    };
    /** Sampling controls the caller set. */
    readonly temperature?: number;
    /** Nucleus sampling the caller set. */
    readonly topP?: number;
    /** Top-k sampling the caller set. */
    readonly topK?: number;
    /** Stop sequences the caller set. */
    readonly stopSequences?: readonly string[];
    /** Validated metadata values the caller attached. */
    readonly metadata?: Readonly<Record<string, string | number | boolean>>;
}
/**
 * What the caller can prove about the files a request refers to.
 *
 * V1 accepts inline content and files this pool uploaded itself. A file id the caller cannot
 * prove it owns is not a request this engine will build: a foreign id would attribute another
 * account's upload to this one, so an absent proof refuses rather than assumes.
 */
export interface ClaudeEngineFileOwnership {
    /**
     * Whether this pool uploaded the given file id.
     * @param fileId - the id the request names.
     * @returns true only when the caller can prove this pool owns that upload.
     */
    readonly ownsFile: (fileId: string) => boolean;
}
/**
 * Validate one caller-supplied Anthropic Messages body.
 *
 * The supported set is exactly the V1 conversation vocabulary: text, inline-image and file
 * content, system blocks, tool definitions and tool results, tool choice, thinking with a token
 * budget, and the sampling controls. A body asking for `stream: false` is refused — this engine
 * exists to stream — and a member the engine does not model is reported by name rather than
 * dropped, at every nesting level.
 * @param body - the caller's raw body (parsed JSON or an equivalent object).
 * @param ownership - the caller's proof of which files this pool uploaded, when the body names
 * any; without it a file reference is refused rather than attributed to this account.
 * @returns the validated body, or the typed failure that refuses it.
 */
export declare function validateAnthropicBody(body: unknown, ownership?: ClaudeEngineFileOwnership): ClaudeEngineValidation;
/** Everything one build needs from the caller. */
export interface ClaudeEngineBuildInput {
    /** The caller's raw Anthropic Messages body. */
    readonly body: unknown;
    /** Access token the Mac vault holds; never logged and never stored here. */
    readonly accessToken: string;
    /** Identity the request is attributed to. */
    readonly identity: ClaudeEngineIdentity;
    /** Opaque per-request id the caller generates. */
    readonly clientRequestId: string;
    /** The caller's continuation chain, when it keeps one. */
    readonly chain?: ClaudeEngineChain;
    /**
     * Trusted policy the caller states out of band, from its own policy adapter.
     *
     * Not a request-body field: the DTO has no such member, so a caller cannot suppress a beta by
     * sending one.
     */
    readonly policy?: ClaudeEnginePolicy;
    /**
     * The caller's proof of which files this pool uploaded.
     *
     * Required for any request that names a file: the engine cannot tell a pool-owned upload from a
     * foreign id, so an absent proof refuses the reference instead of attributing it here.
     */
    readonly files?: ClaudeEngineFileOwnership;
}
/** The outcome of one build. */
export type ClaudeEngineBuildResult = {
    readonly ok: true;
    readonly request: ClaudeEngineRequest;
} | {
    readonly ok: false;
    readonly failure: ClaudeEngineFailure;
};
/**
 * Build one Messages request from a caller-supplied DTO.
 *
 * The pinned 2.1.288 profile is passed to the builder explicitly — the package's own default is a
 * different release — so the request a Mac caller sends is the profile this engine reports. The
 * profile is verified for internal coherence first, and the caller's identity must name all three
 * identifiers: a profile or identity the caller cannot state consistently is refused instead of
 * being completed with a platform guess.
 * @param input - the body, credential, identity and correlation the caller supplies.
 * @returns the request to hand to a transport, or the typed failure that refuses it.
 */
export declare function buildClaudeEngineRequest(input: ClaudeEngineBuildInput): Promise<ClaudeEngineBuildResult>;
export {};
