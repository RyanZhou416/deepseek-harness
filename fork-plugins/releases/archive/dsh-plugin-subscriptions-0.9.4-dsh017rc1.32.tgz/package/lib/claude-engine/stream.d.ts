/**
 * One single-account Messages turn: build nothing, decide everything.
 *
 * The caller supplies an already-built request and a transport; this engine issues it once,
 * frames the raw SSE bytes, tracks the three lifecycle facts separately, and reports a typed
 * terminal. It never retries across accounts or machines: the only recovery it can perform is
 * the one the caller's own hook promises, and the caller's own hook is the only thing that may
 * refuse a request before it is issued.
 *
 * The rejection vocabulary is the plugin's, imported rather than restated
 * (`claude-protocol.ts` owns the recognized Anthropic error types and the version-refusal
 * markers). The ordering below is this engine's, and is the Claude route's subset: the
 * harness-side enforcement wording table stays owned by the plugin's `common.ts` and is
 * deliberately not copied here.
 *
 * @module dsh-plugin-subscriptions/claude-engine/stream
 */
import type { ClaudeEngineEvent, ClaudeEngineRequest, ClaudeEngineTransport, ClaudeEngineUsage } from './types.js';
/** What the caller must provide for one turn. */
export interface ClaudeEngineTurnHooks {
    /**
     * Decide whether this request may be issued, and with which credential.
     *
     * Required: the engine has no default that would let a request out unchecked. Returning
     * `{ ok: false }` refuses the request before any POST, and the turn ends with that refusal.
     * @param request - the request about to be issued.
     * @returns the verdict, with a replacement access token when the caller rotates one.
     */
    readonly beforeRequest: (request: ClaudeEngineRequest) => Promise<ClaudeEngineVerdict> | ClaudeEngineVerdict;
    /**
     * Answer a 401 with at most one replacement credential.
     *
     * Absent means no recovery is attempted, which is the default: the engine never crosses
     * accounts, machines or vaults on its own.
     * @param context - the rejected status and the attempt ordinal.
     * @returns whether to replay once with a new token, or to stop.
     */
    readonly recoverUnauthorized?: (context: {
        readonly status: number;
        readonly attempt: number;
    }) => Promise<ClaudeEngineRecovery> | ClaudeEngineRecovery;
    /**
     * Observe bounded usage once per turn.
     * @param usage - the totals the stream reported.
     */
    readonly onUsage?: (usage: ClaudeEngineUsage) => void;
}
/** The pre-request verdict. */
export type ClaudeEngineVerdict = {
    readonly ok: true;
    readonly accessToken?: string;
} | {
    readonly ok: false;
    readonly reason: string;
};
/** The answer to a rejected credential. */
export type ClaudeEngineRecovery = {
    readonly retry: 'once';
    readonly accessToken: string;
} | {
    readonly retry: 'stop';
    readonly reason?: string;
};
/** One turn's inputs. */
export interface ClaudeEngineTurnInput {
    /** The request to issue, exactly as built. */
    readonly request: ClaudeEngineRequest;
    /** The injected transport; there is no default. */
    readonly transport: ClaudeEngineTransport;
    /** The caller's hooks; `beforeRequest` is mandatory. */
    readonly hooks: ClaudeEngineTurnHooks;
    /** Caller cancellation. */
    readonly signal?: AbortSignal;
}
/**
 * Run one Messages turn.
 *
 * The returned stream yields raw bytes as they arrive and ends with exactly one `terminal`
 * event. A failure is a value in that terminal, never a thrown harness error, so a caller
 * outside the harness can route on it.
 * @param input - the request, transport, hooks and cancellation.
 * @returns the turn's events.
 */
export declare function runClaudeEngineTurn(input: ClaudeEngineTurnInput): AsyncGenerator<ClaudeEngineEvent>;
