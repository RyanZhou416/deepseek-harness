/**
 * Server-sent-event framing over raw bytes.
 *
 * The framing is the spec's own: `data:` lines are joined, comments and other fields are
 * skipped, an event is dispatched on its blank-line terminator, and an unterminated tail at EOF
 * is truncation rather than an event. This module is DSH-free so a caller outside the harness can
 * use it; the plugin's translator delegates here instead of keeping a second parser.
 *
 * Every buffer is bounded. A provider cannot make this framer hold unbounded memory: the
 * unterminated tail and a single frame's data are both capped, and a stream that exceeds a cap is
 * reported as overflow rather than growing without limit.
 *
 * @module dsh-plugin-subscriptions/claude-engine/sse
 */
/** The largest unterminated tail the framer will buffer. */
export declare const SSE_TAIL_LIMIT_BYTES = 1048576;
/** The largest single frame's joined data the framer will dispatch. */
export declare const SSE_FRAME_LIMIT_BYTES = 8388608;
/** One parsed SSE event. */
export interface ClaudeEngineSseEvent {
    /** Joined `data:` payload lines. */
    readonly data: string;
    /** The `event:` field, when the frame carried one. */
    readonly event?: string;
}
/** The outcome of feeding one chunk. */
export interface ClaudeEngineSsePushResult {
    /** The events this chunk completed, in order. */
    readonly events: readonly ClaudeEngineSseEvent[];
    /**
     * Set when a cap was exceeded: the framer stops dispatching from this point, and the caller must
     * treat the response as malformed rather than as a normal stream.
     */
    readonly overflowed?: true;
}
/** Incremental SSE framer: feed decoded text, take the events each chunk completed. */
export interface ClaudeEngineSseFramer {
    /**
     * Feed one decoded chunk.
     * @param text - the text decoded so far; a partial frame stays buffered.
     * @param onActivity - called for a comment line, which is traffic without an event.
     * @returns the events this chunk completed, and whether a cap was exceeded.
     */
    push(text: string, onActivity?: () => void): ClaudeEngineSsePushResult;
}
/**
 * Create one incremental framer.
 * @returns a framer that keeps the unterminated tail buffered until it is completed, under caps.
 */
export declare function createSseFramer(): ClaudeEngineSseFramer;
/**
 * Decode a byte stream into SSE events.
 *
 * Reads may split anywhere, including mid-UTF-8 sequence, so the decoder is kept in streaming
 * mode. An event without a terminating blank line is never dispatched: at EOF it is dropped, which
 * is what makes a truncated tail distinguishable from a complete one. The generator ends early
 * when a cap is exceeded, without dispatching a partial frame.
 * @param stream - raw response bytes.
 * @param onActivity - called for every received chunk and comment line, for a caller's idle bound.
 * @returns events in arrival order.
 */
export declare function parseSseBytes(stream: AsyncIterable<Uint8Array>, onActivity?: () => void): AsyncGenerator<ClaudeEngineSseEvent>;
