/**
 * The continuation selector: the only authority for which earlier Claude turn a request may
 * chain to.
 *
 * The authority is the final retained message history the request was built from, and nothing
 * else. A reply's `request-id` is remembered by the response envelope the adapter already
 * writes into `assistant/message`, so the earlier turn's own durable record is the fact a
 * later request reads. No process-local scalar, no second store and no cache stands beside
 * this rule: two authorities would disagree after a restart, and the disagreement would be
 * invisible in the model-visible bytes.
 *
 * This module is pure. It reads the messages it is handed and derives nothing from a store, a
 * clock, an environment or a credential, so the same trusted span and the same retained
 * messages always produce the same selection. The account reference it compares comes from the
 * zero-dependency `claude-core/account-ref` module, which is the single definition of the type,
 * its shape check and its comparison: this module has no second copy of any of them.
 *
 * The walk is backward and each row is gated before it can be selected. A row that names
 * another provider, another response version, another account, another identity generation or
 * another wire session is skipped rather than trusted, and a row whose recorded `request-id` is
 * not truthy — absent or empty — is skipped so the walk continues to an earlier turn. A truthy
 * `request-id` that is not the shape the client emits is omitted outright: backtracking to an
 * older id after rejecting a newer one would chain a turn the client itself refused.
 *
 * @module dsh-plugin-subscriptions/claude-engine/continuation
 */
import type { ClaudeAccountRef } from '../claude-core/account-ref.js';
/** The response-envelope version this module reads; the envelope contract is unchanged. */
export declare const CLAUDE_CONTINUATION_RESPONSE_VERSION = 1;
/** The continuation member's own version, fixed for the lifetime of this reader. */
export declare const CLAUDE_CONTINUATION_VERSION = 1;
/**
 * The account reference one recorded continuation carries.
 *
 * The reference is a digest, not an account key: the `ref` is what distinguishes one account
 * from another, so comparing two references without it would pass every account. The type and
 * its shape check come from the pure `claude-core/account-ref` module, which this selector may
 * import because that module has no store, no Node and no harness dependency.
 */
export type ClaudeContinuationAccountRef = ClaudeAccountRef;
/** The durable continuation facts one Claude response records beside its blocks. */
export interface ClaudeContinuationV1 {
    /** The continuation member's own version. */
    readonly v: typeof CLAUDE_CONTINUATION_VERSION;
    /** The account this turn was served for, as a verifiable reference. */
    readonly accountRef: ClaudeContinuationAccountRef;
    /** The identity generation in force when the turn was served. */
    readonly spanEpoch: number;
    /** The harness session the turn belongs to. */
    readonly harnessSessionId: string;
    /** The wire session the turn was served under. */
    readonly wireSessionId: string;
    /** The response's own `request-id`, when the response carried one. */
    readonly requestId?: string;
}
/**
 * The span a request belongs to, with the facts every candidate row must match.
 *
 * Every field is derived from this installation's own state: `accountRef` is a reference the
 * salt derives, and the session and wire identities are the span's prepared ones. A candidate
 * row is eligible only when all of them match, so a row from another account, another
 * generation or another wire session cannot be selected by coincidence.
 */
export interface ContinuationGate {
    /** The account the request is served for. */
    readonly accountRef: ClaudeContinuationAccountRef;
    /** The identity generation in force for the request. */
    readonly spanEpoch: number;
    /** The harness session the request belongs to. */
    readonly harnessSessionId: string;
    /** The wire session the request will declare. */
    readonly wireSessionId: string;
}
/**
 * One message the selector reads.
 *
 * Only the members this rule consults are declared, so a caller passes the retained history it
 * already has. `content` is read because the response envelope's `blocks` must line up with the
 * assembled blocks the row actually carries.
 */
export interface ContinuationMessage {
    readonly role?: string;
    readonly content?: readonly unknown[];
    readonly source?: {
        readonly kind?: string;
        readonly provider?: string;
        readonly model?: string;
        readonly replayState?: unknown;
    };
}
/** What the backward walk selected. */
export type ContinuationSelection = 
/** A usable earlier `request-id`; the request chains to it. */
{
    readonly kind: 'selected';
    readonly requestId: string;
    readonly index: number;
}
/** An eligible row carried an unusable id; the request sends no chain. */
 | {
    readonly kind: 'omitted';
    readonly reason: 'invalid-request-id';
}
/** No eligible row carried an id; the request sends no chain. */
 | {
    readonly kind: 'none';
};
/** Whether a value is the `request-id` shape the client emits. */
export declare function isClaudeRequestId(value: unknown): value is string;
/**
 * Whether a value carries an account reference this build can compare.
 *
 * The check is the shared pure one; this module owns no second implementation of it.
 * @param value - the candidate reference.
 * @returns true when the reference states a derivation this build implements.
 */
export declare function isContinuationAccountRef(value: unknown): value is ClaudeAccountRef;
/**
 * Read the continuation member out of a response envelope, if it is one this build wrote.
 * @param envelope - the `source.replayState` value.
 * @returns the continuation, or undefined when the envelope is absent, foreign or older.
 */
export declare function readClaudeContinuation(envelope: unknown): ClaudeContinuationV1 | undefined;
/**
 * Select the turn this request may chain to.
 *
 * The walk is backward over the retained history. A row is eligible only when it is an
 * assistant Claude model message whose envelope is this build's response version, whose
 * recorded blocks line up with the blocks the row actually carries, and whose continuation
 * matches every gate field. An eligible row whose recorded id is not truthy is skipped so an
 * earlier turn may still answer; an eligible row whose id is truthy but not the shape the client
 * emits ends the walk with `omitted`, because the newest eligible turn is the one the client
 * would have chained to and backtracking to an older id would chain a turn the client refused.
 * @param messages - the retained history the request was built from, in order.
 * @param gate - the span the request belongs to.
 * @returns the selection, and the index it was read from.
 */
export declare function selectClaudeContinuation(messages: readonly ContinuationMessage[], gate: ContinuationGate): ContinuationSelection;
