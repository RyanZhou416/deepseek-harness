/**
 * Client side of the Bun stdio transport.
 *
 * Owns one long-lived Bun child, multiplexes requests over it by `streamId`, and
 * presents each response as a web `Response` whose body streams from the frames.
 *
 * The child holds an upstream request open until the bridge tells it otherwise, so a
 * body its caller stops reading is released with one cancel frame per stream, exactly
 * as an abort is.
 *
 * The duplex is injectable so the framing and failure paths are testable without
 * spawning a process; the default duplex spawns the built child under the Bun
 * runtime.
 *
 * Failure policy is fail-closed: a dead child rejects every in-flight request and
 * every later one with a diagnosable error. It never falls back to the Node
 * transport, because the Node path is the configuration this transport exists to
 * replace.
 */
/** Bytes-level duplex to the child. */
export interface BridgeDuplex {
    /** Sends bytes to the child. */
    write(bytes: Uint8Array): void;
    /** Registers the data handler; called once. */
    onData(handler: (bytes: Uint8Array) => void): void;
    /** Registers the exit handler; called once. */
    onExit(handler: (reason: string) => void): void;
    /** Terminates the child. */
    kill(): void;
}
/** Failure raised when the transport cannot carry a request. */
export declare class BridgeError extends Error {
    /** Machine-readable reason. */
    readonly reason: 'child-exited' | 'child-error' | 'remote-error' | 'cancelled' | 'unsupported-body' | 'invalid-status' | 'backpressure';
    /**
     * @param reason - Why the request could not complete.
     * @param detail - Extra context for logs.
     */
    constructor(reason: BridgeError['reason'], detail?: string);
}
/**
 * Default cap on one response body's unread bytes.
 *
 * A consumer that stops reading would otherwise grow that body's queue for the life of
 * a long-lived child, so the cap converts it into a diagnosable per-stream failure. It
 * measures the queue itself, so bytes a pending read already claimed and bytes the
 * consumer took are not backlog. Deployments override it through
 * {@link BridgeOptions.maxQueuedBytes}.
 */
export declare const DEFAULT_MAX_QUEUED_BYTES: number;
/** Deployment-varying limits for one bridge. */
export interface BridgeOptions {
    /**
     * Largest unread backlog, in bytes, one response body may accumulate before that
     * stream fails with `backpressure`. Must be a positive safe integer; defaults to
     * {@link DEFAULT_MAX_QUEUED_BYTES}.
     */
    readonly maxQueuedBytes?: number;
}
/** A started bridge. */
export declare class BunBridge {
    #private;
    /**
     * @param duplex - Bytes-level channel to the child.
     * @param options - Deployment limits; an unset member keeps its default.
     * @throws RangeError when `options.maxQueuedBytes` is not a positive safe integer.
     */
    constructor(duplex: BridgeDuplex, options?: BridgeOptions);
    /** True once the child is gone. */
    get dead(): boolean;
    /** The failure that ended the bridge, when it has ended. */
    get failure(): BridgeError | undefined;
    /**
     * Issues one request through the child.
     *
     * @param url - Absolute request URL.
     * @param init - Method, headers, body and optional abort signal.
     * @returns The one outcome of the request: the response, whose body streams from the
     *   child, or the rejection below. A write failure is reported through this same
     *   promise, after any frame the child already delivered for the request.
     * @throws BridgeError for a dead child, a signal that is already aborted, an
     *   unsupported body form, or a write that failed before the child answered; the
     *   caller decides whether to retry.
     */
    request(url: string, init: RequestInit): Promise<Response>;
    /** Terminates the child and rejects everything in flight. */
    dispose(): void;
}
/**
 * Spawns the built child under the Bun runtime and returns a duplex to it.
 *
 * @param options - Command and arguments for the child.
 * @returns A duplex whose exit handler fires on `exit` or `error`.
 */
/**
 * The environment the transport child runs with.
 *
 * The child issues the Messages request itself, so it needs the path, the proxy and the
 * trust-anchor variables the host was launched with — and nothing else. Inheriting the
 * whole environment would hand a pinned foreign runtime every unrelated secret the host
 * happens to hold.
 *
 * @param env - the host environment.
 * @returns the variables to pass, omitting the ones that are unset.
 */
export declare function childEnvironment(env: NodeJS.ProcessEnv): NodeJS.ProcessEnv;
export declare function spawnBunChild(options: {
    readonly command: string;
    readonly args: readonly string[];
    readonly cwd?: string;
}): BridgeDuplex;
