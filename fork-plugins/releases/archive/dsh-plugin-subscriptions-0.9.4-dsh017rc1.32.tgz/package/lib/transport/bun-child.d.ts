/**
 * Bun-side transport child.
 *
 * Runs under Bun and issues each framed request with the global `fetch`, so the
 * request leaves the machine through the same runtime the target client uses:
 * the same TLS stack, header serialization, connection handling and runtime
 * self-report. It never listens on a socket.
 *
 * Only Node-compatible APIs are used for stdio; the masquerade comes from the
 * runtime that performs the fetch, not from Bun-specific calls.
 *
 *   client → child   { streamId, index, type: "request", url, method, headers, body }
 *                    then, when `body` is true, body frames, then { streamId, type: "body-end" }
 *                    or { streamId, type: "cancel" } to abandon the request
 *   child  → client  { streamId, type: "response", status, headers }
 *                    then body frames, then { streamId, type: "end" }
 *                    or { streamId, type: "error", message } at any point
 *
 * Control ingestion never waits for a stream: each request is dispatched onto a
 * tracked task, so a cancel or a later request is answered while an earlier
 * response body is still being read. One `run` owns its own streams, codec and
 * tasks, so two instances never share state.
 */
import type { Readable } from 'node:stream';
/**
 * Issues one request.
 *
 * Production uses the runtime's global `fetch`; a test or an in-process harness
 * substitutes a double so the lifecycle is exercisable without network egress.
 */
export type TransportFetch = (url: string, init: RequestInit) => Promise<Response>;
/**
 * Writes one whole encoded frame.
 *
 * Every call carries exactly one `encodeControl`/`encodeBody` result: a frame's
 * bytes are never split, a stream's response head is awaited before its body
 * frames, and each stream's frames reach the client in the order it awaited them.
 * Different streams may interleave between frames.
 */
export type FrameWriter = (bytes: Uint8Array) => Promise<void>;
/** A condition the child cannot report through a stream. */
export interface TransportDiagnostic {
    /** Human-readable detail. */
    readonly detail: string;
    /** Whether the frame stream is unusable, which fails the child once it stops. */
    readonly fatal: boolean;
}
/** Runtime edges a caller may replace; production defaults use the process the child runs on. */
export interface TransportChildOptions {
    /** Issues each request. Defaults to the global `fetch`. */
    readonly fetch?: TransportFetch;
    /** Writes one encoded frame. Defaults to a backpressure-aware write to stdout. */
    readonly write?: FrameWriter;
    /** Receives diagnostics. Defaults to stderr, plus a failing exit code when fatal. */
    readonly report?: (diagnostic: TransportDiagnostic) => void;
}
/**
 * Runs the frame loop until the input ends, then stops every stream it started.
 *
 * Control frames are ingested as they arrive and the work they start is tracked
 * per stream instead of awaited here, so a cancel or a later request is answered
 * while an earlier response body is still being read.
 *
 * @param input - Frame bytes from the client. Defaults to the child's stdin.
 * @param options - Runtime edges to replace. The defaults fetch with the global
 *   `fetch` and write to the child's stdout.
 * @returns A promise that settles once the input ended or failed and every
 *   stream this run started has stopped.
 */
export declare function run(input?: Readable, options?: TransportChildOptions): Promise<void>;
/**
 * Reports whether a module is the file this process was started with.
 *
 * `import.meta.url` is a URL and `process.argv[1]` is the path the operating system
 * handed the runtime, so the two spellings differ wherever the install path holds a
 * byte a URL must escape: a space, `#`, `%` or a non-ASCII character stays literal in
 * argv and arrives percent-encoded in the URL. Only the converted filesystem paths are
 * comparable, and the comparison must be exact — a suffix test would also accept a
 * different file whose path merely ends with the entry path.
 *
 * Both sides are canonical: symlinks are resolved, because the loader and the parent
 * can reach one file through different links, and Windows paths are folded to one case,
 * because that filesystem is case-insensitive. A path that no longer resolves is
 * compared as spelled, so a child whose entry was removed still decides this once.
 *
 * @param moduleUrl - The candidate module's `import.meta.url`.
 * @param argvPath - The entry path the parent passed as `process.argv[1]`.
 * @returns Whether the candidate module is this process's entry point.
 */
export declare function isMainEntry(moduleUrl: string, argvPath: string | undefined): boolean;
