import { type ProviderId } from './auth/store.js';
/** One stored speed choice: standard routing or the provider's fast tier. */
export type SpeedTier = 'standard' | 'fast';
/** One model id → its configured default reasoning effort id. */
type ModelDefaultMap = Readonly<Record<string, string>>;
/** Provider route → model defaults. */
type ModelDefaults = Readonly<Partial<Record<ProviderId, ModelDefaultMap>>>;
/** Absolute path of the defaults file. */
export declare function modelDefaultsFilePath(): string;
/**
 * The last load failure, or a warning about entries that were skipped while
 * loading; consumers only use it for diagnostics.
 */
export declare function modelDefaultsLoadError(): unknown;
/** A detached snapshot of the effort sections for the RPC surface (render + diffing). */
export declare function modelDefaultsSnapshot(): ModelDefaults;
/**
 * Set or clear one model's configured default effort, then persist.
 * @param provider - the subscription provider route.
 * @param model - the wire model id.
 * @param effort - the effort id, or undefined to clear the override.
 */
export declare function setDefaultEffort(provider: ProviderId, model: string, effort: string | undefined): Promise<void>;
/**
 * Store one model's speed tier, then persist. `standard` clears the entry:
 * standard routing is the absence of a stored tier, the way an absent effort
 * follows the provider.
 * @param provider - the subscription provider route.
 * @param model - the wire model id (never an account-qualified picker id).
 * @param tier - the chosen tier.
 */
export declare function setDefaultSpeed(provider: ProviderId, model: string, tier: SpeedTier): Promise<void>;
export {};
