/**
 * One plugin application's shared subscription cache.
 *
 * The node half keeps the only authoritative cache; this module is the
 * browser-side holder in front of it, so the composer badge and the Settings
 * page render the same entries instead of running one identical read loop
 * each. Three facts live here: the last roster answer, one entry per
 * `${provider}:${accountKey}`, and which keys have a read in flight.
 *
 * Nothing in this module runs on a timer. A read happens only when a UI event
 * asks for one, every read is single-flight per key, and a request that
 * arrives while that key is already reading folds into the running read with
 * the strongest requested mode. A failed read keeps the entry's last known
 * payload, so an error line never blanks the quotas the user was reading; an
 * entry is dropped only when the roster stops listing its account.
 *
 * Every read carries the cache epoch it started in. `reset` (a new connection
 * generation, whose Host knows nothing the previous one answered) and
 * `dispose` (the owning plugin's teardown) advance the epoch, so a result that
 * arrives afterwards is discarded instead of repopulating state the owner no
 * longer has. A roster read additionally carries its own attempt number: when
 * a fresh read overtakes one still in flight, only the newest answer is
 * published.
 *
 * The cache publishes a bare snapshot source. Components never receive it:
 * the slot `hooks` compartment binds it to a `useUsage` selector hook, and
 * the read callbacks below are the only way to ask for a read.
 */
import type { ConnectionHandle } from '@deepseek-ai/dsh-api-remotes/client';
import type { ObservableSnapshot } from '@deepseek-ai/dsh-client-store';
import type { ProviderStatus, ProviderUsage, SubscriptionProvider } from './SubscriptionsSection.js';
/**
 * The framework's own snapshot-source and selector-hook seats, re-exported so
 * this package's client modules name the types the render machinery binds
 * (`ui-slots` derives its hooks compartment from exactly these).
 */
export type { ObservableSnapshot, SnapshotSelectorHook } from '@deepseek-ai/dsh-client-store';
/** How strong a usage read is: a plain local snapshot, an if-needed refresh, or a forced one. */
export type UsageReadMode = 'local' | 'if-needed' | 'force';
/** The `status` endpoint's provider roster, keyed by provider. */
export type StatusRoster = Partial<Record<SubscriptionProvider, ProviderStatus>>;
/** Outcome of one roster read; a failure carries the message its caller renders. */
export type StatusRead = {
    readonly ok: true;
    readonly providers: StatusRoster;
} | {
    readonly ok: false;
    readonly message: string;
};
/** One account's cached usage, retained across a later failed read. */
export interface CachedUsage {
    /** Last usage payload the node half answered with. */
    usage?: ProviderUsage;
    /** Last transport failure, cleared by the next successful read. */
    error?: string;
}
/** The cache snapshot every reader selects from. */
export interface SubscriptionsCacheState {
    /** Last roster answer, or undefined before the first one. */
    status: StatusRoster | undefined;
    /** Entries keyed `${provider}:${accountKey}`. */
    usage: Readonly<Record<string, CachedUsage>>;
    /** Keys with a read in flight. */
    loading: Readonly<Record<string, boolean>>;
}
/** The shared cache face: a bare source plus the read callbacks the inject face hands out. */
export interface SubscriptionsCache {
    /** Snapshot source bound to the components' `useUsage` hook. */
    readonly source: ObservableSnapshot<SubscriptionsCacheState>;
    /**
     * Read the roster and publish it. Success seeds a local read for every
     * listed account that has no entry yet, so a first mount fills the cache
     * without asking the node half for a refresh.
     * @param options - `fresh` starts an independent read instead of folding into one already running.
     * @returns the roster, or the failure message.
     */
    readStatus(options?: {
        fresh?: boolean;
    }): Promise<StatusRead>;
    /**
     * Read one account's usage.
     * @param provider - the account's provider.
     * @param account - the account key.
     * @param mode - local snapshot (default), if-needed refresh, or forced refresh.
     * @returns nothing once the read (and any folded follow-up) has started.
     */
    readUsage(provider: SubscriptionProvider, account: string, mode?: UsageReadMode): Promise<void>;
    /**
     * Read every listed account of one provider.
     * @param provider - the provider whose accounts are read.
     * @param mode - read strength.
     * @returns nothing once every read has started.
     */
    readProvider(provider: SubscriptionProvider, mode?: UsageReadMode): Promise<void>;
    /**
     * Read every listed account of the current roster.
     * @param mode - read strength.
     * @returns nothing once every read has started.
     */
    readAll(mode?: UsageReadMode): Promise<void>;
    /**
     * Account keys the current roster lists for one provider.
     * @param provider - the provider to list.
     * @returns the account keys, empty while the roster is unknown.
     */
    accountsOf(provider: SubscriptionProvider): readonly string[];
    /**
     * Forget everything and discard the results of reads still in flight: a new
     * connection generation's Host knows nothing this one answered.
     */
    reset(): void;
    /** Owner teardown: later results are discarded and no listener survives. */
    dispose(): void;
}
/**
 * Build the application-scoped cache.
 * @param rpc - Connection RPC caller reaching the `subscriptions-auth` endpoints.
 * @returns the shared cache face.
 */
export declare function createSubscriptionsCache(rpc: ConnectionHandle['rpc']): SubscriptionsCache;
