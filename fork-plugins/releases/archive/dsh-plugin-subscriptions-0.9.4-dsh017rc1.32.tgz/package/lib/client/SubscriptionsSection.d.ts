import type { ConnectionHandle } from '@deepseek-ai/dsh-api-remotes/client';
import type { InjectFace } from '@deepseek-ai/dsh-client-ui-slots';
import type { SubscriptionsKey } from './locales.js';
export { callSubscriptionsAuth } from './subscriptions-rpc.js';
import type { CachedUsage, ObservableSnapshot, StatusRead, SubscriptionsCacheState, UsageReadMode } from './subscriptions-cache.js';
/** Subscription provider ids, fixed by the node half's OAuth adapters. */
export type SubscriptionProvider = 'codex' | 'claude' | 'grok' | 'copilot' | 'antigravity' | 'cursor';
/**
 * Credential dimension of one account, mirrored from the node half's `CredentialStatus`.
 * `until` is the instant the owner's own record expires; `nextCheckAt` its next check.
 */
export interface CredentialStatus {
    state: 'ready' | 'refreshing' | 'reauth_required' | 'missing' | 'unknown-expiry' | 'maintenance-unsupported' | 'external-coordination-unproven';
    code?: 'REAUTH_REQUIRED';
    until?: number;
    nextCheckAt?: number;
}
/**
 * Credential ownership of one Claude account, mirrored from the node half's
 * `CredentialOwnershipStatus`. It states provenance and write authority only, never which
 * OAuth client issued the credential.
 */
export interface CredentialOwnershipStatus {
    mode: 'legacy-writeback' | 'read-only-import' | 'independent-oauth';
    /** Whether a store outside this plugin holds the credential. */
    external: boolean;
    /** Present only for `legacy-writeback`: coordination with the external holder is unproven. */
    coordinationUnproven?: true;
}
/** Quota / temporary-availability dimension of one account. */
export interface AvailabilityStatus {
    state: 'available' | 'cooling' | 'transient' | 'refused';
    code?: 'QUOTA_EXHAUSTED' | 'RATE_LIMITED' | 'ENFORCEMENT_REFUSAL' | 'PROVIDER_UNAVAILABLE' | 'REQUEST_TIMEOUT' | 'MODEL_UNAVAILABLE' | 'PROVIDER_ERROR';
    until?: number;
}
/** Protocol-compatibility dimension of one account's frozen wire profile. */
export interface ProtocolStatus {
    state: 'current' | 'upgrade_required' | 'unsupported_response';
    code?: 'CLIENT_VERSION_UNSUPPORTED' | 'UNSUPPORTED_RESPONSE';
    profileId?: string;
    since?: number;
}
/** Account-profile freshness dimension. */
export interface ProfileStatus {
    state: 'fresh' | 'stale' | 'missing' | 'unavailable';
    capturedAt?: number;
    /** Whether the retained profile carries every field the current protocol requires. */
    complete?: boolean;
}
/** Managed-policy dimension of one account. */
export interface PolicyStatus {
    state: 'ineligible' | 'loading' | 'current' | 'stale' | 'unavailable' | 'consent-required' | 'blocked';
    code?: 'POLICY_UNSUPPORTED' | 'POLICY_INVALID_VALUE' | 'POLICY_CONSENT_REQUIRED';
    scope?: 'tool' | 'model' | 'mcp' | 'execution' | 'network' | 'unknown';
    fetchedAt?: number;
}
/** Fixed reason codes the Claude policy-limits dimension may carry. */
export type PolicyLimitsCode = 'CREDENTIAL_UNAVAILABLE' | 'AUTH_REJECTED' | 'REQUEST_FAILED' | 'PARSE_FAILED' | 'RESPONSE_OVER_LIMIT';
/** Fixed blocker codes the Claude policy-limits dimension may carry. */
export type PolicyLimitsBlocker = 'policy_limits_state_unavailable' | 'policy_limits_unknown_keys' | 'policy_limits_core_skills_unstored' | 'policy_limits_lossy_taints';
/**
 * The monitoring notice the node half read from the accepted document. Its text
 * is rendered as text, and its url is a destination the user opens deliberately.
 */
export interface PolicyLimitsNotice {
    text: string;
    /** The notice's https url, when the server stated a usable one. */
    url?: string;
}
/**
 * Whether one control obligation is in force for the account's limits document:
 * `active` means the document requires it, `not-enforced` means it does not, and
 * `unknown` means the document answered nothing — never a refusal.
 */
export type ControlRequirement = 'active' | 'not-enforced' | 'unknown';
/** One observed control, in the plugin's own vocabulary rather than the server's key. */
export type UnsupportedActiveControl = 'trusted-devices' | 'web-search-mcp-isolation';
/** The control obligations the account's limits document states. */
export interface ControlRequirements {
    /** `require_trusted_devices`. */
    trustedDevices: ControlRequirement;
    /** `enforce_web_search_mcp_isolation`. */
    webSearchMcpIsolation: ControlRequirement;
    /** The controls in force that this client provides no capability for; it refuses nothing. */
    unsupportedActiveControls: readonly UnsupportedActiveControl[];
}
/**
 * Claude `policy_limits` dimension of one account, mirrored from the node
 * half's `PolicyLimitsStatus`. Independent of the managed {@link PolicyStatus}:
 * the two documents have separate caches and neither replaces the other. Only
 * fixed codes, counts, booleans and the normalized notice arrive; the document,
 * its defaults, its taints and its key names stay on the node half.
 */
export interface PolicyLimitsStatus {
    state: 'ineligible' | 'loading' | 'current' | 'stale' | 'unavailable' | 'blocked';
    code?: PolicyLimitsCode;
    /** Blockers in force; while any is present every verdict is refused. */
    blockers?: readonly PolicyLimitsBlocker[];
    fetchedAt?: number;
    /** Registered keys the node half cannot enforce exactly. */
    unknownCount?: number;
    /** Keys the retained document refuses; the key names themselves are not sent. */
    deniedCount?: number;
    /** Compliance taints in force; the taint values themselves are not sent. */
    taintCount?: number;
    /** Configured capabilities the node half does not provide. */
    unsupportedScopeCount?: number;
    /** Control obligations the retained document states, when it states any; absent otherwise. */
    controlRequirements?: ControlRequirements;
    /** Whether a monitoring notice is in force; a notice restricts no key. */
    notice?: boolean;
    /** The notice's text and url, once the node half has read them; absent while only its presence is known. */
    noticeContent?: PolicyLimitsNotice;
    /** What the verdicts are answered from: a confirmed document, a retained one, or nothing. */
    fallback: 'live' | 'stale' | 'none';
}
/** One logged-in account as answered by the `status` endpoint. */
export interface AccountStatus {
    key: string;
    account?: string;
    expiresAt?: number;
    plan?: string;
    isDefault: boolean;
    /** Credential dimension; always reported. */
    credential: CredentialStatus;
    /** Credential ownership; absent for routes without the concept (reported for Claude only). */
    credentialOwnership?: CredentialOwnershipStatus;
    /** Quota / temporary availability; absent while nothing has parked this account. */
    availability?: AvailabilityStatus;
    /** Protocol compatibility; absent for routes without a recorded protocol state. */
    protocol?: ProtocolStatus;
    /** Account-profile freshness; absent for routes without profile maintenance. */
    profile?: ProfileStatus;
    /** Managed policy; absent until eligibility for this account was evaluated. */
    policy?: PolicyStatus;
    /** Claude policy limits; absent while no owner reports this account. */
    policyLimits?: PolicyLimitsStatus;
}
/** Fixed code describing one recorded provider-operation failure. */
export type ProviderFailureCode = 'CANCELLED' | 'CREDENTIALS_UNAVAILABLE' | 'CREDENTIALS_REJECTED' | 'PROVIDER_REJECTED' | 'NETWORK' | 'TIMEOUT' | 'INVALID_RESPONSE' | 'UNKNOWN';
/** One recorded provider-operation failure, in allowlisted fields only. */
export interface ProviderOperationFailure {
    code: ProviderFailureCode;
    operation: 'login' | 'import' | 'logout' | 'status';
    at: number;
    status?: number;
    providerCode?: string;
    retryAt?: number;
}
/** One provider's login state as answered by the `status` endpoint. */
export interface ProviderStatus {
    busy: boolean;
    accounts: AccountStatus[];
    /** The last failed operation; the card localizes it from its fixed code. */
    lastError?: ProviderOperationFailure;
    /** Present when the node half refused to register this route in this Host. */
    unavailable?: 'CLAUDE_HOST_INCOMPATIBLE';
}
/** One rate-limit window as answered by the `usage` endpoint. */
export interface UsageWindow {
    kind: 'session' | 'weekly' | 'other';
    scope?: string;
    usedPercent: number;
    resetsAt?: number;
}
/** One unified rate-limit window as reported by the `usage` endpoint. */
interface RateLimitWindow {
    window: string;
    utilization?: number;
    resetsAt?: number;
    surpassedThreshold?: number;
}
/** The account's captured `anthropic-ratelimit-unified-*` report. */
export interface RateLimitReport {
    status: 'allowed' | 'allowed_warning' | 'rejected' | 'other';
    resetsAt?: number;
    claim?: string;
    fallbackAvailable?: boolean;
    overageStatus?: 'allowed' | 'allowed_warning' | 'rejected' | 'other';
    overageResetsAt?: number;
    overageDisabledReason?: string;
    overageInUse?: boolean;
    overageScope?: string;
    windows: RateLimitWindow[];
    observedAt: number;
}
/** The account pool's view of one account, present only while the pool is enabled. */
export interface PoolReport {
    coolingReason?: 'auth' | 'quota';
    coolingUntil?: number;
    peerAvailable: boolean;
}
/**
 * Cache state the node half reports beside a usage snapshot.
 *
 * `missing` is not zero percent and not "unsupported": nothing has been read
 * for this account yet. `stale` and `error` carry the last known windows, and
 * `retryAt` is the instant the node half's cooldown lets a forced read run.
 */
export interface UsageCacheMetadata {
    state: 'fresh' | 'stale' | 'missing' | 'error' | 'refreshing';
    /** Instant the reported values were observed, on the node half's clock. */
    observedAt?: number;
    /** Earliest instant a forced read is accepted again. */
    retryAt?: number;
    /** Coded reason of an `error` state (never raw provider text). */
    error?: string;
}
/** `usage` endpoint value: the node half owns this shape. */
export interface ProviderUsage {
    supported: boolean;
    windows?: UsageWindow[];
    plan?: string;
    /** Present only when the usage payload disclosed a reset-credit count. */
    resetCredits?: {
        availableCount: number;
    };
    /** The account's last answered request's unified rate-limit report, when captured. */
    rateLimit?: RateLimitReport;
    /** The account pool's view of this account, when the pool is enabled. */
    pool?: PoolReport;
    /** Freshness of this snapshot, when the node half reports one. */
    cache?: UsageCacheMetadata;
}
/** `proxyGet` endpoint value: the node half owns this shape (no secrets). */
export interface ProxyConfigView {
    enabled: boolean;
    url: string;
    username?: string;
    passwordSet: boolean;
    bypass: string[];
    error?: string;
}
/** `proxyTest` endpoint value. */
export interface ProxyTestResult {
    ok: boolean;
    viaProxy: boolean;
    status?: number;
    latencyMs?: number;
    error?: string;
}
/** Injected dependencies of {@link SubscriptionsSection} (slot `inject`). */
export interface SubscriptionsSectionInjected {
    /** Generic logical-RPC caller over the Connection transport. */
    rpc: ConnectionHandle['rpc'];
    /** Section copy: translate a 'settings.subscriptions' key with `{name}` template params. */
    t: (key: SubscriptionsKey, params?: Record<string, unknown>) => string;
    /**
     * Read the shared cache's roster.
     * @param options - `fresh` starts an independent read instead of folding into one already running.
     * @returns the roster, or the message the caller renders.
     */
    readStatus: (options?: {
        fresh?: boolean;
    }) => Promise<StatusRead>;
    /**
     * Read one account's usage from the shared cache.
     * @param provider - the account's provider.
     * @param account - the account key.
     * @param mode - local snapshot (default), if-needed refresh, or forced refresh.
     * @returns nothing once the read has started.
     */
    readUsage: (provider: SubscriptionProvider, account: string, mode?: UsageReadMode) => Promise<void>;
    /** Registrant hooks compartment: the shared cache source, bound to `useUsage`. */
    hooks: {
        usage: ObservableSnapshot<SubscriptionsCacheState>;
    };
}
/**
 * Props delivered by the slot outlet: the inject face with its hooks
 * compartment bound (`useUsage` is the framework's own seat and is always
 * present), and the optional members standalone renders may omit.
 */
export type SubscriptionsSectionProps = Partial<Pick<SubscriptionsSectionInjected, 'rpc' | 't'>> & Required<Pick<SubscriptionsSectionInjected, 'readStatus' | 'readUsage'>> & Pick<InjectFace<SubscriptionsSectionInjected>, 'useUsage'>;
/**
 * One line an account's reported dimensions contribute to its card.
 *
 * `warn` marks a state that stops the account serving as it is (a re-login, a
 * refusal, an unsupported protocol); `info` marks a fact about cached state
 * (a cooling window, a stale profile), which must not read as a failure.
 */
export interface AccountStateLine {
    text: string;
    tone: 'warn' | 'info';
    /**
     * Destination a line states. The card links it only when it is an `https`
     * one, and opening it is the user's own click.
     */
    url?: string;
}
/**
 * Localized lines for one account's reported dimensions, in a fixed order:
 * credential, availability, protocol, profile, policy, policy limits, observed
 * control requirement, notice.
 *
 * Every dimension is rendered from its own state, so a re-login requirement is
 * never shown as a quota cooldown and a stale profile is never shown as an
 * invalid credential. A dimension the node half did not report contributes
 * nothing rather than a healthy-looking line.
 * @param account - the account as answered by the `status` endpoint.
 * @param t - section translate.
 * @returns the lines to render beside the account, empty when every dimension is nominal.
 */
export declare function accountStateLines(account: AccountStatus, t: SubscriptionsSectionInjected['t']): AccountStateLine[];
/**
 * One account's reported dimension lines.
 *
 * Every line is rendered as text, so provider prose cannot become markup. A
 * line's destination becomes a link only when it is an `https` one, and the
 * card only offers it: opening it is the user's own click and the card never
 * requests it.
 * @param props - the lines and the section translate.
 * @returns the lines as rendered beside one account.
 */
export declare function AccountStateLines({ lines, t }: {
    lines: readonly AccountStateLine[];
    t: SubscriptionsSectionInjected['t'];
}): import("react").JSX.Element;
/**
 * Localized line for one recorded provider-operation failure.
 * @param failure - the failure the `status` endpoint reported.
 * @param t - section translate.
 * @returns the line, with the provider's stated retry instant when it sent one.
 */
export declare function providerFailureLine(failure: ProviderOperationFailure, t: SubscriptionsSectionInjected['t']): string;
/** Bar fill color: success normally, warn from 80%, error from 95%. Shared with the composer badge. */
export declare function usageBarColor(usedPercent: number): string;
/**
 * Localized freshness line of one cached usage entry: when the values were
 * observed, whether the node half kept a stale value, has none yet, failed its
 * last revalidation, or is refreshing now, plus the instant a forced read may
 * be tried again.
 *
 * The line states the cache's own state, so a `missing` account never reads as
 * "zero percent" and a failed revalidation never hides the quotas that are
 * still on screen.
 * @param entry - the account's cache entry, or undefined before any read.
 * @param t - section translate.
 * @returns the line, or undefined when the entry carries nothing to state.
 */
export declare function usageCacheNote(entry: CachedUsage | undefined, t: SubscriptionsSectionInjected['t']): string | undefined;
/**
 * The fact one account's red usage line states.
 *
 * `limit` and `near` come from the reported window percentages, `rejected` and
 * `warning` from the provider's unified rate-limit status, `relogin` from a
 * stored login the pool found dead, and `cooldown` and `overage` from the
 * account pool working around this account.
 */
type UsageAlertKind = 'limit' | 'near' | 'rejected' | 'warning' | 'relogin' | 'cooldown' | 'overage';
/** What one account's card states about its usage. */
interface UsageAlert {
    /** The fact the line states. */
    kind: UsageAlertKind;
    /**
     * `account` when the fact is about this account alone; `pool` when this
     * account is out and another pool member is serving in its place. The
     * distinction is the difference between "you are blocked" and "we routed
     * around a cooling account".
     */
    attribution: 'account' | 'pool';
    /** Latest disclosed instant still ahead of the clock at which the state clears. */
    resetsAt?: number;
}
/**
 * Whether an account's reported usage puts it out of service.
 *
 * Contract: the header state outranks the percentage state, because the
 * provider's own `rejected` verdict is more specific than a window percentage
 * that may have been read minutes earlier. A dead login is always attributed
 * to the account: no routing decision clears it. A near-limit `allowed_warning`
 * status is an account fact too — it proves only that this account is close to
 * its limit, which routing around it does not change. Overage is always
 * attributed to the pool and only reported when a peer can serve, because the
 * account itself is still answering.
 *
 * The percentage rule is unchanged from the reported windows: a window counts
 * as full at `usedPercent >= 100` for Codex and Claude, which spend a window
 * all the way down, and at `usedPercent >= 95` for every other provider — the
 * per-provider rule the pool's availability check applies
 * (`CONSUMABLE_QUOTA_FULL_PERCENT` / `QUOTA_FULL_PERCENT`). Absent or empty
 * windows, and every window below its threshold, report no alert.
 * @param provider - the provider that reported the windows.
 * @param windows - the account's reported windows, or undefined while unknown.
 * @param rateLimit - the account's captured unified rate-limit report, when any.
 * @param pool - the pool's view of this account, when the pool is enabled.
 * @returns the out-of-service state, or undefined while the account can serve.
 */
export declare function usageAlert(provider: SubscriptionProvider, windows: readonly UsageWindow[] | undefined, rateLimit?: RateLimitReport, pool?: PoolReport): UsageAlert | undefined;
/**
 * The locale key stating one alert. Account-level facts name what is wrong with
 * this account; pool-level facts name that another account is serving instead.
 * @param alert - the alert derived by {@link usageAlert}.
 * @returns the key of the line to render.
 */
export declare function usageAlertKey(alert: UsageAlert): SubscriptionsKey;
/**
 * The Subscriptions settings page component.
 * @param props - the slot inject face ({@link SubscriptionsSectionInjected}).
 * @returns the section body, or a notice while the RPC face is absent.
 */
export declare function SubscriptionsSection(props: SubscriptionsSectionProps): import("react").JSX.Element;
