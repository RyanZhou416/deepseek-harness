import type { ConnectionHandle } from '@deepseek-ai/dsh-api-remotes/client';
import type { ProviderPreferences } from '../provider-settings.js';
import type { SubscriptionProvider } from './SubscriptionsSection.js';
import type { ModelPoolAccount } from './account-preferences.js';
import type { SpeedTier } from './SpeedSelect.js';
import type { SubscriptionsKey } from './locales.js';
/** One row of the model list: a catalog model, or a saved id the catalog no longer lists. */
export interface ModelRow {
    id: string;
    name: string;
    /** The provider's own reason for refusing the model, or absent when it may serve. */
    disabledReason?: string;
    contextWindow?: number;
    defaultContextWindow?: number;
    efforts?: {
        id: string;
        name: string;
    }[];
    configured?: string;
    maxContextWindow?: number;
    /** Whether this route advertises the model's fast tier; the picker appears only then. */
    fastTier?: boolean;
    /** The stored speed tier, when one is set. */
    configuredSpeed?: SpeedTier;
}
/**
 * The pool membership the model rows carry. One account's membership is edited on the
 * model's own row, so the dialog lists every model exactly once.
 */
export interface ModelPoolEditing {
    /** Accounts offering a checkbox, in dialog order. */
    accounts: readonly ModelPoolAccount[];
    /** One account's current pool selection. */
    selectionOf: (key: string) => ReadonlySet<string>;
    /** Toggle one model's membership in one account's pool. */
    toggle: (key: string, model: string) => void;
    /** Ids a saved allowlist names that no catalog lists any more; each keeps its row. */
    unlisted: readonly string[];
}
/**
 * The rows the model list renders, each model exactly once: the provider's catalog in its own
 * order, then the saved ids the catalog no longer lists (hidden models and saved pool
 * memberships), filtered by the search box.
 * @param catalog - the provider's catalog rows.
 * @param saved - saved ids the catalog no longer lists.
 * @param query - the raw search box value.
 * @returns the render rows.
 */
export declare function composeModelRows(catalog: readonly ModelRow[], saved: readonly string[], query: string): ModelRow[];
interface Props {
    provider: SubscriptionProvider;
    rpc: ConnectionHandle['rpc'];
    t: (key: SubscriptionsKey, params?: Record<string, unknown>) => string;
    /** Freeze the editor while the owning dialog submits. */
    disabled?: boolean;
    /** Reports whether the draft differs from the loaded catalog. */
    onDirtyChange?: (dirty: boolean) => void;
    /** Per-account pool membership rendered on each model row; absent while the catalog loads. */
    pool?: ModelPoolEditing | undefined;
}
/** The editor's unsaved edits, collected by the owning dialog's single Save. */
interface ModelDraft {
    /** Provider settings minus `accounts`; absent when the draft has no edits. */
    settings?: ProviderPreferences;
    /** Reasoning-effort overrides that differ from the catalog; '' clears one. */
    efforts: {
        model: string;
        effort: string;
    }[];
    /** Speed-tier overrides that differ from the catalog. */
    speeds: {
        model: string;
        tier: SpeedTier;
    }[];
}
export interface ProviderModelEditorHandle {
    /**
     * Validate and collect the draft without mutating it, so a failed submit
     * keeps every edit. Returns undefined when a value is invalid; the editor
     * shows the reason itself.
     */
    collect(): ModelDraft | undefined;
}
/**
 * Embedded section of the account manager dialog. It owns the model draft
 * (visibility, effort, speed, context, tools) but not its submission: the dialog
 * collects the draft through the handle and saves it with the account edits
 * in one go, so there is a single Save/Cancel pair.
 */
export declare const ProviderModelEditor: import("react").ForwardRefExoticComponent<Props & import("react").RefAttributes<ProviderModelEditorHandle>>;
export {};
