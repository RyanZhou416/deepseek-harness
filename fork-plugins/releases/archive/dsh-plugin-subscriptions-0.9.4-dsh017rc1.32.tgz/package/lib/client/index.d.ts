import type { Context as ClientContext } from '@deepseek-ai/cordis';
import type { ModelMenuRowOwnerProps } from './SpeedSelect.js';
import type { SubscriptionsKey } from './locales.js';
export type { SubscriptionsSectionInjected, SubscriptionsSectionProps } from './SubscriptionsSection.js';
export type { ImageGenerateToolviewInjected, ImageGenerateToolviewProps } from './ImageGenerateToolview.js';
export type { VideoGenerateToolviewInjected, VideoGenerateToolviewProps } from './VideoGenerateToolview.js';
export type { ModelMenuRowOwnerProps, SpeedSelectInjected, SpeedSelectProps, SpeedState, SpeedTier, } from './SpeedSelect.js';
export type { SubscriptionUsageBadgeInjected, SubscriptionUsageBadgeProps } from './SubscriptionUsageBadge.js';
export type { SubscriptionsKey } from './locales.js';
declare module '@deepseek-ai/dsh-client-ui-slots' {
    interface LocaleNamespaceMap {
        /** The Subscriptions settings page copy. */
        'settings.subscriptions': SubscriptionsKey;
    }
}
declare module '@deepseek-ai/dsh-client-ui-slots' {
    interface SlotMap {
        /**
         * Mirror of ui-conversation's additive model-menu row child
         * (`packages/client/ui-conversation/src/client/contract/slots.ts`), which the
         * installed `0.1.7-rc.1` contract does not declare: neither the key nor the
         * `ModelMenuRowOwnerProps` face declared in `SpeedSelect.tsx`, repeated there
         * verbatim because this package compiles standalone against that contract. A
         * later contract carrying the same shape merges with this entry, and
         * `scripts/fork-profile-setup.spec.ts` holds both in step.
         */
        'conversation.input.model.row': {
            kind: 'list';
            scope: 'session';
            owner: ModelMenuRowOwnerProps;
        };
    }
}
/**
 * Required services (cordis fiber inject): `slots` carries the registration
 * seat, `connection` the `/subscriptions-auth` RPC caller, and `locale` the copy
 * dictionaries.
 */
export declare const inject: string[];
/**
 * Register the Subscriptions section once the `settings.section` declaration
 * is on the ledger (the shell's apply order relative to this one is NOT
 * constrained; registration depends on the slot through `slots.inject()`).
 * @param ctx - client root context.
 */
export declare function apply(ctx: ClientContext): void;
