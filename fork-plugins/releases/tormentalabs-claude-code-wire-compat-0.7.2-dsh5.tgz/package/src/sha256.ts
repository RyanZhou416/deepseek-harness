// SPDX-License-Identifier: GPL-3.0-or-later

const SHA256_INITIAL = new Uint32Array([
  0x6a09e667, 0xbb67ae85, 0x3c6ef372, 0xa54ff53a, 0x510e527f, 0x9b05688c,
  0x1f83d9ab, 0x5be0cd19,
]);
const SHA256_ROUNDS = new Uint32Array([
  0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b, 0x59f111f1,
  0x923f82a4, 0xab1c5ed5, 0xd807aa98, 0x12835b01, 0x243185be, 0x550c7dc3,
  0x72be5d74, 0x80deb1fe, 0x9bdc06a7, 0xc19bf174, 0xe49b69c1, 0xefbe4786,
  0x0fc19dc6, 0x240ca1cc, 0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da,
  0x983e5152, 0xa831c66d, 0xb00327c8, 0xbf597fc7, 0xc6e00bf3, 0xd5a79147,
  0x06ca6351, 0x14292967, 0x27b70a85, 0x2e1b2138, 0x4d2c6dfc, 0x53380d13,
  0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85, 0xa2bfe8a1, 0xa81a664b,
  0xc24b8b70, 0xc76c51a3, 0xd192e819, 0xd6990624, 0xf40e3585, 0x106aa070,
  0x19a4c116, 0x1e376c08, 0x2748774c, 0x34b0bcb5, 0x391c0cb3, 0x4ed8aa4a,
  0x5b9cca4f, 0x682e6ff3, 0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208,
  0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2,
]);

function rotateRight(value: number, count: number): number {
  return (value >>> count) | (value << (32 - count));
}

function wordAt(words: Uint32Array, index: number): number {
  // The fallback is unreachable at runtime because every call site indexes
  // within the allocated array. It exists solely to satisfy
  // noUncheckedIndexedAccess and is therefore this file's sole uncovered
  // branch, intentionally not covered by a test.
  return words[index] ?? 0;
}

/**
 * Computes a digest only so the synchronous parser can verify the integrity of
 * evidence produced by this package. The asynchronous builder path uses the
 * injected Web Crypto implementations in `src/fingerprint.ts` and
 * `src/redaction.ts` and MUST continue to do so. This checks non-secret,
 * self-produced data; it is not a MAC and must not inform security decisions.
 */
export function sha256Hex(value: string): string {
  const source = new TextEncoder().encode(value);
  const paddedLength = Math.ceil((source.length + 9) / 64) * 64;
  const padded = new Uint8Array(paddedLength);
  padded.set(source);
  padded[source.length] = 0x80;
  const bitLength = source.length * 8;
  const view = new DataView(padded.buffer);
  view.setUint32(paddedLength - 8, Math.floor(bitLength / 0x1_0000_0000));
  view.setUint32(paddedLength - 4, bitLength >>> 0);
  const state = new Uint32Array(SHA256_INITIAL);
  const words = new Uint32Array(64);

  for (let offset = 0; offset < paddedLength; offset += 64) {
    for (let index = 0; index < 16; index += 1) {
      words[index] = view.getUint32(offset + index * 4);
    }
    for (let index = 16; index < 64; index += 1) {
      const previous15 = wordAt(words, index - 15);
      const previous2 = wordAt(words, index - 2);
      const sigma0 =
        rotateRight(previous15, 7) ^
        rotateRight(previous15, 18) ^
        (previous15 >>> 3);
      const sigma1 =
        rotateRight(previous2, 17) ^
        rotateRight(previous2, 19) ^
        (previous2 >>> 10);
      words[index] =
        wordAt(words, index - 16) + sigma0 + wordAt(words, index - 7) + sigma1;
    }

    let a = wordAt(state, 0);
    let b = wordAt(state, 1);
    let c = wordAt(state, 2);
    let d = wordAt(state, 3);
    let e = wordAt(state, 4);
    let f = wordAt(state, 5);
    let g = wordAt(state, 6);
    let h = wordAt(state, 7);
    for (let index = 0; index < 64; index += 1) {
      const sum1 = rotateRight(e, 6) ^ rotateRight(e, 11) ^ rotateRight(e, 25);
      const choice = (e & f) ^ (~e & g);
      const temporary1 =
        (h +
          sum1 +
          choice +
          wordAt(SHA256_ROUNDS, index) +
          wordAt(words, index)) >>>
        0;
      const sum0 = rotateRight(a, 2) ^ rotateRight(a, 13) ^ rotateRight(a, 22);
      const majority = (a & b) ^ (a & c) ^ (b & c);
      const temporary2 = (sum0 + majority) >>> 0;
      h = g;
      g = f;
      f = e;
      e = (d + temporary1) >>> 0;
      d = c;
      c = b;
      b = a;
      a = (temporary1 + temporary2) >>> 0;
    }
    state[0] = wordAt(state, 0) + a;
    state[1] = wordAt(state, 1) + b;
    state[2] = wordAt(state, 2) + c;
    state[3] = wordAt(state, 3) + d;
    state[4] = wordAt(state, 4) + e;
    state[5] = wordAt(state, 5) + f;
    state[6] = wordAt(state, 6) + g;
    state[7] = wordAt(state, 7) + h;
  }
  return Array.from(state, (word) => word.toString(16).padStart(8, "0")).join(
    "",
  );
}
