/** The proxy config as served to the client: secrets replaced by a flag. */
export interface ProxyConfigView {
    enabled: boolean;
    url: string;
    username?: string;
    /** Whether a password is stored (the password itself never leaves the host). */
    passwordSet: boolean;
    bypass: string[];
    /** Last load/apply failure, when the stored config is unusable. */
    error?: string;
}
/** One `proxySet` payload. */
export interface ProxyInput {
    enabled: boolean;
    url: string;
    username?: string;
    /** `undefined` keeps the stored password, `null`/`''` clears it. */
    password?: string | null;
    bypass?: string[];
}
/** One `proxyTest` result. */
export interface ProxyTestResult {
    /** Whether the destination answered with an HTTP status. */
    ok: boolean;
    /** Whether the plugin proxy was used; false means host routing, not necessarily direct. */
    viaProxy: boolean;
    /** Status of the answered request, when one was received. */
    status?: number;
    /** Round-trip latency in milliseconds. */
    latencyMs?: number;
    /** Failure message, when no response was received. */
    error?: string;
}
/** A draft proxy for one test probe (never persisted). */
export interface ProxyDraft {
    url: string;
    username?: string;
    password?: string;
}
/**
 * Minimum per-address connect attempt budget for Node's Happy Eyeballs
 * (`net.autoSelectFamilyAttemptTimeout`). Node's default is 250ms, which is
 * shorter than one TCP handshake to Cloudflare-fronted hosts (registry.npmjs.org,
 * chatgpt.com) on a high-latency link: every address then fails with
 * ETIMEDOUT and the whole fetch dies even though curl succeeds.
 */
export declare const MIN_CONNECT_ATTEMPT_TIMEOUT_MS = 1500;
/**
 * Current proxy config as served to the client (secrets omitted).
 * @returns the view; {@link ProxyConfigView.error} carries the last
 *   load/apply failure when the stored config is unusable.
 */
export declare function proxyGetConfig(): Promise<ProxyConfigView>;
/**
 * Validate, persist, and apply one proxy config. A `password` of `undefined`
 * keeps the stored value; `null` or `''` clears it.
 * @param input - the client's payload.
 * @returns the resulting view (secrets omitted).
 */
export declare function proxySetConfig(input: ProxyInput): Promise<ProxyConfigView>;
/**
 * The fetch caller all subscription code uses: routes through the configured
 * proxy unless the host bypasses it. Identity-passthrough otherwise: the host
 * may itself route global fetch through an environment-configured proxy.
 *
 * A host-mandated Claude route outranks both: for a Claude destination the
 * plugin attaches no dispatcher at all, leaving the process dispatcher the host
 * installed to apply its own route to this request and every other Claude call —
 * Messages, token refresh, usage and profile alike.
 *
 * A published host route for the request's scheme is the same rule for every other
 * destination: this module's own direct agent would send the request around the
 * proxy the host routes that scheme through, so the installed dispatcher decides.
 *
 * Proxied requests run on undici's own fetch (not the global one) so the
 * ProxyAgent dispatcher always comes from the same undici build the request
 * is issued with — a mismatched dispatcher can be silently ignored by the
 * host's global fetch.
 */
export declare function proxiedFetch(input: RequestInfo | URL, init?: RequestInit): Promise<Response>;
/**
 * Reports whether the configured proxy applies to a host.
 *
 * A transport that issues its own requests outside this module cannot apply the
 * `ProxyAgent`, so it must ask first and refuse rather than send the request
 * around a proxy the operator configured deliberately.
 *
 * @param hostname - Destination host.
 * @returns true when a request to that host would go through the proxy.
 */
export declare function proxyAppliesTo(hostname: string): Promise<boolean>;
/**
 * Probe a destination through a proxy, answering with the HTTP status or a
 * flattened transport error. The probe uses `draft` when given (the dialog's
 * current inputs, without saving) and the stored config otherwise.
 *
 * Only a destination this plugin's providers use is accepted, and a target a
 * host-published route covers is refused rather than fetched around that route.
 * @param target - `http(s)` URL to fetch; defaults to {@link DEFAULT_PROXY_TEST_URL}.
 * @param draft - unsaved proxy inputs to test; absent means the stored config.
 * @returns the result; any HTTP status counts as a successful connection,
 *   only a transport failure is an error.
 */
export declare function proxyTestConnection(target?: string, draft?: ProxyDraft): Promise<ProxyTestResult>;
