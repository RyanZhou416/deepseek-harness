/**
 * dsh-plugin-subscriptions: register OAuth-subscription LLM providers
 * (ChatGPT/Codex, Claude, Grok, GitHub Copilot, Google Antigravity, Cursor) on `ctx.llm`, and expose the `/subscriptions-auth`
 * RPC channel the web Settings page uses to run the logins. The token store
 * lives at `~/.dsh/plugins/subscriptions/auth.json`; the channel registers only when
 * a host `connection` service exists, so headless compositions load fine.
 * @module dsh-plugin-subscriptions
 */
import type { Context } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
import type { ProviderId } from './auth/store.js';
import type { ModelEntry } from './providers/common.js';
import type { RateLimitConfig } from './providers/rate-limit.js';
import type { PoolSchedulingPolicy } from './providers/pool-scheduling.js';
export type { AccountPreferences, ProviderPreferences } from './provider-settings.js';
import type { PoolMemberRef } from './providers/pool-family.js';
import type { AntigravityRuntimeConfig } from './providers/antigravity.js';
export type { ModelEntry, ProviderUsage, UsageWindow } from './providers/common.js';
export type { RateLimitConfig, RateLimitWait } from './providers/rate-limit.js';
export type { ProviderStatus } from './auth/rpc.js';
export type { AntigravitySession, ClaudeSession, CodexSession, CopilotSession, CursorSession, GrokSession, ProviderId } from './auth/store.js';
export declare const name = "dsh-plugin-subscriptions";
export declare const inject: string[];
export { withTimeout } from './providers/common.js';
/** Plugin config, validated by the same-named schemastery schema. */
export interface Config {
    /** Codex /models client_version override; does not change account entitlements. */
    codexClientVersion?: string;
    /** Provider routes to register; defaults to every supported provider. */
    providers?: ProviderId[];
    /** Maximum provider idle time while one stream read is outstanding (default five minutes). */
    streamIdleTimeoutMs?: number;
    /**
     * What a Claude request tells the model about its own environment, in place of the harness
     * identity section. Clamped to this route: the harness identity stays in force everywhere
     * else. Empty omits the identity entirely.
     */
    claudeIdentityLine?: string;
    /**
     * Whether a refresh of a keychain-imported Claude account is written back into Claude
     * Code's own credential store. Off by default: that store belongs to another application,
     * and a browser-authorized account never touches it. Turning it on keeps an installed
     * `claude` CLI in sync with a rotation this plugin performs.
     */
    syncClaudeCodeCredentials?: boolean;
    /** Whether and how long a route waits out a closed rate-limit window. */
    rateLimit?: RateLimitConfig;
    /** Advisory model catalogs overriding the built-in defaults, per provider. */
    models?: {
        codex?: ModelEntry[];
        claude?: ModelEntry[];
        grok?: ModelEntry[];
        copilot?: ModelEntry[];
        antigravity?: ModelEntry[];
        cursor?: ModelEntry[];
    };
    /** Antigravity-specific OAuth and endpoint configuration. */
    antigravity?: AntigravityRuntimeConfig & {
        /** Google OAuth client id. May instead be supplied as ANTIGRAVITY_CLIENT_ID. */
        clientId?: string;
        /** Google OAuth client secret, when required by the client registration. */
        clientSecret?: string;
    };
    /** Same-subscription account pools (and optional extra tier models). */
    pool?: {
        /** Enable account pooling (default true; needs ≥2 accounts of one provider). */
        enabled?: boolean;
        /** Member selection: plain priority failover, or quota-aware urgency scheduling. */
        strategy?: 'priority' | 'quota_aware';
        /** A challenger must out-score the sticky member by this factor to take over (default 2). */
        switchMargin?: number;
        /** Bounded reset/finishing preferences and per-account concurrency penalty. */
        scheduling?: Partial<PoolSchedulingPolicy>;
        /** Auto-pool every catalog model across a provider's logged-in accounts (default true). */
        autoAccounts?: boolean;
        /** Explicit account lists for one catalog model (same provider); replaces the auto pool. */
        families?: Record<string, PoolMemberRef[]>;
        /** Extra picker entries with heterogeneous fallbacks, listed under the first member's provider. */
        tiers?: Record<string, PoolMemberRef[]>;
    };
}
export declare const Config: z<Config>;
export declare function apply(ctx: Context, config: Config): void;
