/**
 * The Claude fetch used by the subscription provider.
 *
 * Only the Messages request is issued by the Bun transport, because that is the
 * request whose reproduction the transport exists for. Every other destination —
 * token refresh, usage, profile, file upload, model listing, the other providers —
 * keeps the existing client, so a call whose identity this module does not pin can
 * never be sent under the bridge's anonymous defaults.
 *
 * The bridge is on by default. `DSH_SUBSCRIPTIONS_BRIDGE=off` restores the previous
 * path explicitly. A bridge that cannot start, a child that has exited, a proxy
 * the bridge cannot honour, or a host that requires a Claude route this child cannot
 * reach is a hard error naming that switch, never a silent fallback: falling back
 * would restore exactly the transport this exists to replace, and a host-mandated
 * route bypassed in silence is the failure this refusal exists to prevent.
 */
/** Failure raised when the bridge cannot serve a request. */
export declare class BridgeUnavailableError extends Error {
    /**
     * @param detail - What failed and which switch restores the previous path.
     */
    constructor(detail: string);
}
/** Reports whether the bridge is currently enabled by configuration. */
export declare function bridgeEnabled(env?: NodeJS.ProcessEnv): boolean;
/**
 * Fetches a request through the configured transport.
 *
 * @param input - Request URL.
 * @param init - Method, headers, body and optional abort signal.
 * @returns The response, streamed.
 */
export declare function claudeApiFetch(input: RequestInfo | URL, init?: RequestInit): Promise<Response>;
/** Stops the bridge child; called by profile teardown and by tests. */
export declare function stopBridge(): Promise<void>;
