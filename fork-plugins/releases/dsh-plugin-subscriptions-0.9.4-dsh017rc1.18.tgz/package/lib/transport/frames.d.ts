/**
 * Framing for the Bun stdio transport.
 *
 * One child process serves concurrent requests, so every frame is addressable.
 * A control frame carries UTF-8 JSON, whose `streamId` names the request it
 * belongs to. A body frame carries raw bytes — neither base64-inflated nor split
 * on newlines — preceded by the numeric index the control frames assigned to that
 * stream, because a UUID repeated on every chunk of a streamed response would cost
 * more than the payload it labels.
 *
 * Wire shape:
 *
 *   frame := uint32be length | uint8 tag | payload
 *   tag 0x01: payload is UTF-8 JSON, including `streamId`
 *   tag 0x02: payload is uint32be streamIndex followed by raw body bytes
 *
 * `length` counts the tag and the payload, never itself.
 */
/** Byte width of a frame's length prefix. */
export declare const FRAME_LENGTH_BYTES = 4;
/** Tag byte introducing a JSON control frame. */
export declare const TAG_CONTROL = 1;
/** Tag byte introducing a raw body frame. */
export declare const TAG_BODY = 2;
/**
 * Largest frame this codec will accept, in bytes.
 *
 * The child never sends a frame larger than one buffer of response bytes, and the
 * client never sends a frame larger than one request body chunk. The ceiling exists
 * so a corrupt or hostile length prefix fails loudly instead of allocating.
 */
export declare const MAX_FRAME_BYTES: number;
/** A decoded control frame. */
interface ControlFrame {
    readonly tag: typeof TAG_CONTROL;
    /** Parsed JSON payload. The `streamId` member is required by the protocol. */
    readonly message: Record<string, unknown>;
}
/** A decoded body frame. */
interface BodyFrame {
    readonly tag: typeof TAG_BODY;
    /** Stream index assigned by the control frame that opened the stream. */
    readonly streamIndex: number;
    /** Raw bytes, exactly as the peer sent them. */
    readonly bytes: Uint8Array;
}
/** Either frame shape. */
export type Frame = ControlFrame | BodyFrame;
/** Failure raised for a payload the protocol cannot represent. */
export declare class FrameError extends Error {
    /** Machine-readable reason, stable enough for tests to assert. */
    readonly reason: 'length-limit' | 'unknown-tag' | 'invalid-json' | 'missing-stream-id' | 'invalid-stream-index' | 'truncated';
    /**
     * @param reason - Which invariant the payload violated.
     * @param detail - Extra context for logs; never contains payload bytes.
     */
    constructor(reason: FrameError['reason'], detail?: string);
}
/**
 * Encodes a control frame.
 *
 * @param message - JSON payload; must carry a non-empty string `streamId`.
 * @returns The framed bytes.
 */
export declare function encodeControl(message: Record<string, unknown>): Uint8Array;
/**
 * Encodes a body frame.
 *
 * @param streamIndex - Numeric index the peer assigned to this stream.
 * @param bytes - Raw body bytes.
 * @returns The framed bytes.
 */
export declare function encodeBody(streamIndex: number, bytes: Uint8Array): Uint8Array;
/**
 * Incremental decoder.
 *
 * Bytes arrive in whatever chunks the pipe delivers, so a frame may be split
 * across reads and one read may hold several frames. `push` returns every frame
 * the buffer now completes and keeps the remainder.
 */
export declare class FrameDecoder {
    #private;
    /**
     * Feeds bytes and returns the frames they complete.
     *
     * Decoding never throws. A malformed frame stops the stream — the peer is out of
     * step and every later boundary would be guesswork — but frames already completed
     * in the same read are still returned, and the failure is reported through
     * {@link FrameDecoder.error}. This method runs inside a pipe data handler, where a
     * throw becomes an uncaught exception in the host process.
     *
     * @param chunk - Bytes read from the pipe.
     * @returns Complete frames decoded before any failure, in arrival order.
     */
    push(chunk: Uint8Array): readonly Frame[];
    /** The first decoding failure, once the stream is out of step. */
    get error(): FrameError | undefined;
    /** Bytes held for an incomplete frame. */
    get pending(): number;
}
export {};
