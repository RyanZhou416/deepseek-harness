import type { ToolDefinition } from '@deepseek-ai/dsh-tools';
/** Tool names owned by this plugin and their collision fallbacks. */
export declare const TOOL_ALIASES: {
    readonly x_search: "dsh_subscriptions_x_search";
    readonly video_generate: "dsh_subscriptions_video_generate";
    readonly image_generate: "dsh_subscriptions_image_generate";
};
interface ToolRegistry {
    register(definition: ToolDefinition): () => void;
}
/**
 * Register a tool under its canonical name, then a plugin-scoped alias.
 * @param registry - tool registry that owns disposal of the registration.
 * @param definition - tool to register under its own `name` when that name is free.
 * @param warn - sink for the collision diagnostic when neither name is free.
 * @returns the name the tool registered under, or undefined when both names are taken.
 */
export declare function registerWithAlias(registry: ToolRegistry, definition: ToolDefinition, warn?: (message: string) => void): string | undefined;
export {};
