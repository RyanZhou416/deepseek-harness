/**
 * Grok (X Premium / xAI) subscription provider: OIDC-discovered OAuth against
 * auth.x.ai with the Grok CLI client id, and streaming against the xAI
 * Responses-style endpoint.
 */
import type { GenerateOptions, LlmProviderInfo, LlmResolvedModelInfo, StreamChunk } from '@deepseek-ai/dsh-llm';
import type { FlowSpec } from '../auth/oauth-flow.js';
import type { GrokSession } from '../auth/store.js';
import type { PoolAdapter } from './pool.js';
import type { AttachmentStore } from '@deepseek-ai/dsh-attachment';
import type { ResponsesRequestInput } from '../translate/responses.js';
import { AccountTokenManager } from './accounts.js';
import type { CatalogPersistence, FetchFn, ModelEntry, ProviderUsage } from './common.js';
import { ProviderCatalog } from './provider-catalog.js';
import { PoolBackedAdapter } from './pool-delegation.js';
import type { RateLimitResetReader, RateLimitWait } from './rate-limit.js';
export declare const GROK_API_URL = "https://api.x.ai/v1/responses";
/** Refresh when the access token has less than this much life left. */
export declare const GROK_PREEMPT_MS: number;
/**
 * Reads the reset instant of the xAI window that rejected a request.
 *
 * Body only. xAI serves the OpenAI-compatible `x-ratelimit-reset-*` family,
 * whose values are rollover durations (`6m0s`) present on every response, one
 * per bucket — on a 429 the earliest of them is usually a bucket with room
 * (`0s` for the request bucket while the token bucket is the one exhausted),
 * which would burn the whole retry budget in seconds. They reach the operator
 * through `rateLimitDiagnostics` instead.
 */
export declare const grokRateLimitReset: RateLimitResetReader;
/**
 * Build the grok flow facts for the OAuth flow engine (async because the
 * authorize URL comes from OIDC discovery).
 * @returns the flow spec for one attempt.
 */
export declare function grokFlow(): Promise<FlowSpec>;
/**
 * The subscription tier encoded in a grok access token's `tier` claim (no
 * verification — same trust posture as the other claim reads).
 * @param accessToken - the stored access token.
 * @returns the display tier name, or undefined when the claim is absent.
 */
export declare function grokTierName(accessToken: string): string | undefined;
/**
 * Exchange an authorization code for a grok session (form-encoded grant that
 * echoes the PKCE challenge as well as the verifier, per the xAI flow).
 * A 403 here means the X plan lacks the API OAuth entitlement.
 * @param code - the authorization code from the callback.
 * @param verifier - the PKCE verifier minted for the attempt.
 * @param redirectUri - the attempt's redirect URI.
 * @param challenge - the PKCE challenge sent at authorize time.
 * @returns the session to store.
 */
export declare function exchangeGrokCode(code: string, verifier: string, redirectUri: string, challenge: string): Promise<GrokSession>;
/**
 * Refresh a grok session (form-encoded grant).
 * @param session - the stored session.
 * @returns the fresh session to store.
 */
export declare function refreshGrok(session: GrokSession): Promise<GrokSession>;
/**
 * Whether a grok refresh failure means the login is permanently gone.
 * @param error - the thrown refresh error.
 * @returns true when re-login is the only fix.
 */
export declare function isGrokPermanentRefreshError(error: unknown): boolean;
/**
 * Fetch the grok subscription usage from the Grok Build CLI chat proxy. The
 * newer credits config carries a ready-made percentage plus the current
 * (typically weekly) period; the legacy shape carries cent-valued
 * `monthlyLimit`/`used`, from which the percentage is derived.
 * @param session - the stored session (used as-is; never refreshed here).
 * @param fetchFn - fetch implementation (injectable for tests).
 * @param signal - caller cancellation from the RPC transport.
 * @returns the mapped usage snapshot.
 */
export declare function fetchGrokUsage(session: GrokSession, fetchFn?: FetchFn, signal?: AbortSignal): Promise<ProviderUsage>;
/**
 * Build one xAI Responses request body (exported for tests, like
 * {@link codexRequestBody}). The tool trio renders only when tools exist:
 * A reported xAI 400 invalid-argument on tool-less calls motivated omitting
 * tool controls when no tools are supplied. Keep this endpoint-specific
 * compatibility measure separate from assumptions about other backends.
 * Tool-call pairing is repaired here, as on every Responses route: the input
 * schema rejects a `function_call` without its output and an output without
 * its call.
 */
export declare function grokRequestBody(options: GenerateOptions, resolved: ResponsesRequestInput): Record<string, unknown>;
/** Constructor dependencies for {@link GrokAdapter}. */
interface GrokAdapterOptions {
    models: readonly ModelEntry[];
    streamIdleTimeoutMs: number;
    tokens: AccountTokenManager<GrokSession>;
    /** Late-bound pool facade (wired after adapter construction); pools list under their first member's provider. */
    pool?: () => PoolAdapter | undefined;
    /** Whether to fetch the live catalog when logged in (false when config `models` overrides). */
    discovery: boolean;
    /** Warning sink for discovery failures that fall back to the static catalog. */
    onWarn?: (message: string) => void;
    /** Fetch implementation for discovery and streaming requests; defaults to the configured proxy route. */
    fetchFn?: FetchFn;
    /** Resolve the attachment service per request; absent means image requests fail loudly. */
    resolveAttachments?: () => AttachmentStore | undefined;
    /** Durable catalog store seeding capability metadata across restarts. */
    catalogStore?: CatalogPersistence;
    /**
     * Per-model default reasoning effort override (the Settings page's picker).
     * Returns the user-configured default for one model, or undefined to follow
     * the provider's own default.
     */
    defaultEffortOf?: (model: string) => string | undefined;
    /** How long this route may hold a turn open waiting for a rate-limit window; defaults to waiting on, six-hour ceiling. */
    rateLimit?: RateLimitWait;
}
/** Grok wire adapter: one instance serves the `grok` provider route. */
export declare class GrokAdapter extends PoolBackedAdapter {
    private readonly options;
    protected readonly catalogs: ProviderCatalog;
    constructor(options: GrokAdapterOptions);
    /** Discovery fetcher: resolves the session through the refresh-aware path. */
    private fetchCatalog;
    /** Drop cached catalogs after login/logout so the next list does not reuse a stale plan. */
    clearAccountCatalog(account?: string): void;
    /** One discovered entry as a picker row; modality follows the model's own input support. */
    private listed;
    providerInfo(provider: string): LlmProviderInfo;
    providerRetryPolicy(provider: string): import("@deepseek-ai/dsh-llm").ResolvedRetryPolicy;
    private staticModels;
    /**
     * The discovered entry for one model. Resolved through the cache's
     * stale-while-revalidate path: capability metadata must stay stable across
     * a long conversation — a session that selected a reasoning effort calls
     * this on EVERY step, and forgetting the efforts just because the TTL
     * lapsed mid-turn would fail the call with UNSUPPORTED_REASONING_EFFORT
     * before provider I/O.
     */
    private discovered;
    /** Capability resolution of the provider's own models (the pool resolves members here). */
    resolveOwnModel(provider: string, model: string): Promise<LlmResolvedModelInfo>;
    protected streamOwn(options: GenerateOptions, account?: string): AsyncIterable<StreamChunk>;
    private request;
}
export {};
