/**
 * The Claude catalogue the model picker lists: the client's baked-in table plus
 * whatever the bootstrap endpoint adds for one account.
 *
 * Membership is read from the pinned wire profile's own `supportedModels` table, which
 * is that baked-in catalogue, so no id is restated here and a profile bump cannot leave
 * a stale copy behind. The wire library models only the catalogue fields a request
 * reads and deliberately drops `display_name`, so the display text below is transcribed
 * from the same baked-in table as the carve holds it: `chunk-g52pkz6d.js` in
 * `cc-2.1.288-modules`, whose twenty-one entries agree with
 * `.cc-carve/model-catalogue.json` on id, family and display name. An id with no display
 * text maps to the id itself rather than inventing a name.
 */
import type { DiscoveredModel } from './common.js';
/** One entry of the bootstrap document's `additional_model_options`. */
export interface ClaudeCatalogueOption {
    model?: string;
    name?: string;
    description?: string;
    disabled_reason?: string | null;
}
/**
 * The client's built-in catalogue as catalogue rows, in the catalogue's own order.
 * No request is involved: the genuine client holds this table and lists from it.
 * @returns one row per pinned profile model id.
 */
export declare function claudeBuiltInCatalogue(): DiscoveredModel[];
/**
 * The built-in catalogue with one account's options applied.
 *
 * An option naming a model the catalogue already carries replaces that row's display
 * text and disabled state in place, so the picker keeps one row per id in catalogue
 * order; an option naming a model the catalogue lacks is appended; an option naming no
 * model is skipped. A `disabled_reason` marks the row unavailable instead of removing
 * it, which is how the service tells the client that a model exists but this account
 * cannot select it.
 *
 * @param base - the built-in catalogue rows.
 * @param options - the endpoint's options, already known to be an array.
 * @returns the merged catalogue rows.
 */
export declare function mergeClaudeCatalogue(base: readonly DiscoveredModel[], options: readonly ClaudeCatalogueOption[]): DiscoveredModel[];
