/**
 * The context and output capacity this route reports for a Claude model.
 *
 * Two different quantities describe the same model. The pinned client's catalogue carries the
 * window it compacts against — a policy window that may sit below what the API accepts — while
 * the API documentation states the model's own limit. The harness picker wants the capacity the
 * model really has, so a documented limit answers before the catalogue entry does.
 *
 * A caller applies a provider-reported limit first; this module answers when discovery disclosed
 * none, in this order: the documented per-model limit, the pinned profile's catalogue entry, and
 * a conservative pair for a model no source names.
 *
 * One documented figure is withheld. A model whose catalogue entry reaches its 1M window only
 * through the long-context beta — the 200000-window entries carrying the 1M-beta flag rather
 * than native 1M — is reported at the catalogue window instead, because this route sends a
 * plain model id and never composes that beta: the documentation states what the model accepts
 * with it, and reporting a window a request cannot use is a capacity the harness would then
 * plan against and the API would refuse. The output ceiling is not beta-gated and is reported
 * as documented.
 */
/** The context and output capacity one Claude model is reported with. */
export interface ClaudeModelLimits {
    /** Combined request/response capacity in tokens. */
    readonly contextWindow: number;
    /** Per-request output ceiling in tokens. */
    readonly maxOutputTokens: number;
}
/**
 * The documented capacity for one model, when the documentation names it.
 * @param model - the wire model id.
 * @returns the documented limits, or undefined for a model the documentation does not name.
 */
export declare function claudeDocumentedLimits(model: string): ClaudeModelLimits | undefined;
/**
 * The pinned profile's catalogue capacity for one model.
 *
 * @param model - the wire model id.
 * @returns the catalogue entry's window and default output ceiling, or undefined for an id the
 *   profile does not carry.
 */
export declare function claudeProfileLimits(model: string): ClaudeModelLimits | undefined;
/**
 * The capacity to report for one model when discovery disclosed none.
 *
 * @param model - the wire model id.
 * @returns the documented limit, the pinned catalogue's entry, or the conservative pair. A
 *   documented window that needs the long-context beta is replaced by the catalogue window.
 */
export declare function claudeModelLimits(model: string): ClaudeModelLimits;
