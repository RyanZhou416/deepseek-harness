/**
 * The account-pool delegation every subscription adapter shares. An adapter
 * contributes its own catalogue data and its own model-field assembly; this base
 * owns the four seams the pool plugs into: picker rows add the configured
 * pool's tiers, resolution hands a pool-owned id to the pool, streaming runs the
 * pool prelude before the provider's own wire path, and the account seam streams
 * one named account through that same path.
 */
import { LlmAdapter } from '@deepseek-ai/dsh-llm';
import type { GenerateOptions, LlmModelInfo, LlmResolvedModelInfo, StreamChunk } from '@deepseek-ai/dsh-llm';
import type { PoolAdapter } from './pool.js';
import type { ProviderCatalog } from './provider-catalog.js';
/** The pool binding every delegating adapter carries in its constructor options. */
interface PoolBinding {
    /** Late-bound pool facade (wired after adapter construction); absent means no pool. */
    pool?: () => PoolAdapter | undefined;
}
/**
 * Base for a subscription adapter that a configured account pool may route:
 * one instance serves one provider route, and its constructor options carry the
 * pool facade. A subclass supplies its {@link ProviderCatalog} plus the
 * provider-specific pieces: {@link resolveOwnModel}, {@link streamOwn}, the
 * static and discovered row mapping, and its own account-catalog invalidation.
 */
export declare abstract class PoolBackedAdapter extends LlmAdapter {
    private readonly poolHost;
    /** The provider's account-indexed catalog, assigned by the subclass constructor. */
    protected abstract readonly catalogs: ProviderCatalog;
    protected constructor(poolHost: PoolBinding);
    listModels(provider: string): Promise<readonly LlmModelInfo[]>;
    /** The provider's own catalog: union of every account, or one account when named. */
    listOwnModels(provider: string, account?: string, signal?: AbortSignal): Promise<readonly LlmModelInfo[]>;
    resolveModel(provider: string, model: string): Promise<LlmResolvedModelInfo>;
    /** Capability resolution of the provider's own models (the pool resolves members here). */
    abstract resolveOwnModel(provider: string, model: string, account?: string): Promise<LlmResolvedModelInfo>;
    stream(options: GenerateOptions): AsyncIterable<StreamChunk>;
    /** Stream through the provider's own wire path, one account (default when omitted) at a time. */
    protected abstract streamOwn(options: GenerateOptions, account?: string): AsyncIterable<StreamChunk>;
    /** Pool seam: stream through one specific account instead of the default. */
    streamAccount(options: GenerateOptions, account?: string): AsyncIterable<StreamChunk>;
}
export {};
