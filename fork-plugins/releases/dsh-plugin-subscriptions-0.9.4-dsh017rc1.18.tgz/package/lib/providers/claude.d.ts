/**
 * Claude Pro/Max subscription provider: OAuth against claude.ai /
 * platform.claude.com with the Claude Code client id, and streaming against
 * the Anthropic Messages API through the pinned Claude Code 2.1.280 wire
 * contract built by `@tormentalabs/claude-code-wire-compat`.
 */
import type { GenerateOptions, LlmProviderInfo, LlmResolvedModelInfo, StreamChunk } from '@deepseek-ai/dsh-llm';
import type { FlowSpec } from '../auth/oauth-flow.js';
import type { ClaudeSession } from '../auth/store.js';
import type { PoolAdapter } from './pool.js';
import type { AttachmentStore } from '@deepseek-ai/dsh-attachment';
import type { TranslatableMessage } from '../translate/resolved.js';
import type { ClaudeWireThinking } from './claude-wire.js';
import { AccountTokenManager } from './accounts.js';
import type { CatalogPersistence, DiscoveredModel, FetchFn, ModelEntry, ProviderUsage } from './common.js';
import { ProviderCatalog } from './provider-catalog.js';
import { PoolBackedAdapter } from './pool-delegation.js';
import type { RateLimitResetReader, RateLimitWait } from './rate-limit.js';
export declare const CLAUDE_CLIENT_ID = "9d1c250a-e61b-44d9-88ed-5944d1962f5e";
export declare const CLAUDE_AUTHORIZE_URL: string;
export declare const CLAUDE_TOKEN_URL: string;
/**
 * Supplies a fresh access token after the service rejects the current one.
 *
 * The genuine client issues its usage request with refresh-and-replay enabled, so a
 * token that expired between the last refresh and the request costs one retry rather
 * than the whole poll.
 */
type ClaudeReauthorize = () => Promise<string>;
/**
 * The ATIS token recorded for an account.
 *
 * @param account - the account the request belongs to.
 * @returns the token, or undefined when no read has disclosed one.
 */
export declare function clientAtisFor(account: string): string | undefined;
export declare const CLAUDE_SCOPE = "org:create_api_key user:profile user:inference user:sessions:claude_code user:mcp_servers user:file_upload user:plugins";
export declare const CLAUDE_CALLBACK_PATH = "/callback";
/** Refresh when the access token has less than this much life left. */
export declare const CLAUDE_PREEMPT_MS: number;
/**
 * Reads the reset instant of the Anthropic window that rejected a request.
 *
 * `anthropic-ratelimit-unified-*` is the subscription-plan family — the one
 * Claude Code renders as "resets 3pm" — and is the only header that names the
 * window which actually rejected this request. The per-bucket
 * `anthropic-ratelimit-{requests,tokens,input-tokens,output-tokens}-reset`
 * headers are deliberately not read: they are rollover snapshots attached to
 * every response, so on a 429 they cannot say which bucket refused, and the
 * earliest of them is typically the bucket that still had room — a wait that
 * lands straight back in the closed window. They reach the operator through
 * `rateLimitDiagnostics` instead.
 */
export declare const claudeRateLimitReset: RateLimitResetReader;
/**
 * The subscription endpoint only serves requests presenting as Claude Code,
 * so the usage and models endpoints reuse the pinned wire profile's CLI
 * user-agent; the harness attribution user-agent cannot be sent here.
 */
/**
 * Models the prompt-caching guide allows to take a later `{"role":"system"}`
 * message: Fable 5, Fable 5.1, Mythos 5, Mythos 5.1, Opus 4.8, and Opus 5.
 * Sonnet 5 and Opus 5.5 are not in that list.
 */
export declare function supportsMidConversationSystem(model: string): boolean;
/**
 * Vision: images on the Claude API may be at most 10 MB once base64-encoded.
 * Larger images go through the Files API as `{ type: "file", file_id }`.
 */
export declare const CLAUDE_MAX_BASE64_IMAGE_CHARS = 10000000;
/** Uploaded Files API entries kept before the oldest is evicted. */
export declare const CLAUDE_FILE_ID_LIMIT = 256;
/**
 * The Files API id one account already uploaded for an image content hash.
 * @param account - the canonical account key that would own the upload.
 * @param contentHash - sha256 of the image's base64 payload.
 * @returns the uploaded id, or undefined when this account has not uploaded it.
 */
export declare function uploadedClaudeFileId(account: string, contentHash: string): string | undefined;
/**
 * Remember one account's uploaded Files API id for an image content hash.
 *
 * A file id is served only under the token that uploaded it, and the Claude
 * routes are pooled, so the account key joins the content hash in the key: a
 * failover uploads its own copy instead of handing another account's request a
 * file id Anthropic would reject.
 * @param account - the canonical account key that uploaded the file.
 * @param contentHash - sha256 of the image's base64 payload.
 * @param fileId - the Files API id the upload returned.
 */
export declare function rememberClaudeFileId(account: string, contentHash: string, fileId: string): void;
/**
 * Drop the Files API ids uploaded under one account, or every account when none
 * is named. A login replaces the token those ids were minted with, so the
 * adapter drops them with the account's other cached state.
 * @param account - the canonical account key whose uploads are dropped.
 */
export declare function clearClaudeFileIds(account?: string): void;
/**
 * Replace oversized inline images with a Files API `file_id`; smaller images
 * stay base64. The upload is made with the request's own account token, and the
 * resulting id is cached under that account.
 * @param messages - resolved request messages.
 * @param account - the canonical account key serving this request.
 * @param accessToken - that account's current access token.
 * @param fetchFn - fetch implementation (injectable for tests).
 * @param signal - caller cancellation.
 * @returns the messages, with uploaded images bound to a file id.
 */
export declare function bindClaudeFileIds(messages: readonly TranslatableMessage[], account: string, accessToken: string, fetchFn?: FetchFn, signal?: AbortSignal): Promise<readonly TranslatableMessage[]>;
/**
 * Where claude.com sends a browser that cannot reach this machine.
 *
 * The page displays the authorization code for the user to copy back, which is what makes a
 * login started on one device finish on another.
 */
export declare const CLAUDE_MANUAL_REDIRECT_URL = "https://platform.claude.com/oauth/code/callback";
/** Static claude flow facts for the OAuth flow engine. */
export declare const claudeFlow: FlowSpec;
/**
 * The device id one account presents.
 *
 * Derived from the account's own key instead of being minted at random, so it survives
 * every path that recreates the stored session: signing out and in again, a re-import from
 * Claude Code's own credential store, or a fresh authorization. The genuine client keeps
 * its id outside its credentials and therefore survives all of these; an id that died with
 * the credential would silently present a different device to the service.
 *
 * @param accountKey - The account's key, which is the address it signed in with.
 * @returns A 64-character lowercase hex id, the format the client uses.
 */
export declare function deriveClaudeDeviceId(accountKey: string): string;
/**
 * Carry an account's frozen device identity onto a freshly authorized session.
 *
 * The device id is minted once per account and must survive re-authorization: every
 * machine value a request declares is derived from it, so a new id would silently change
 * the device the service sees. The genuine client behaves the same way, keeping one id for
 * the life of its installation rather than issuing one per sign-in.
 *
 * @param next - The session the authorization just produced.
 * @param previous - The stored session for the same account, when there is one.
 * @returns The session to store, with the earlier identity preserved.
 */
export declare function carryClaudeIdentity(next: ClaudeSession, previous: ClaudeSession | undefined): ClaudeSession;
export declare function exchangeClaudeCode(code: string, verifier: string, redirectUri: string, state: string): Promise<ClaudeSession>;
/**
 * Refresh a claude session (JSON grant echoing the issued scope).
 * @param session - the stored session.
 * @returns the fresh session to store.
 */
export declare function refreshClaude(session: ClaudeSession): Promise<ClaudeSession>;
/**
 * Whether a claude refresh failure means the login is permanently gone.
 * @param error - the thrown refresh error.
 * @returns true when re-login is the only fix.
 */
export declare function isClaudePermanentRefreshError(error: unknown): boolean;
/**
 * Fetch the claude subscription usage from the OAuth usage endpoint (the
 * source of Claude Code's `/usage` screen). Newer responses carry a
 * structured `limits` array; older ones the flat `five_hour`/`seven_day*`
 * buckets — both shapes are read, the array winning when it has entries.
 * @param session - the stored session (used as-is; never refreshed here).
 * @param fetchFn - fetch implementation (injectable for tests).
 * @param signal - caller cancellation from the RPC transport.
 * @returns the mapped usage snapshot.
 */
export declare function fetchClaudeUsage(session: ClaudeSession, fetchFn?: FetchFn, signal?: AbortSignal, reauthorize?: ClaudeReauthorize, timeoutMs?: number): Promise<ProviderUsage>;
/**
 * The `thinking` object for one request.
 *
 * `display: 'summarized'` is fixed by the wire module on both shapes: adaptive
 * models default to `display: 'omitted'`, which returns thinking blocks with
 * an empty `thinking` field. Without this override the Think panel stays empty.
 * @param model - the requested model id.
 * @param thinkingType - the type discovery advertised, when it advertised one.
 * @param maxTokens - the resolved output cap; the manual budget is derived from it.
 * @returns the wire `thinking` request, or undefined when the model takes none.
 */
export declare function claudeThinkingBody(model: string, thinkingType: 'enabled' | 'adaptive' | undefined, maxTokens: number): ClaudeWireThinking | undefined;
/**
 * Read the account's Claude catalogue: the client's own built-in table with the model
 * options this account adds to it.
 *
 * The endpoint carries additions, not a catalogue — its own field is named
 * `additional_model_options` beside `additional_model_costs` — so the built-in table is
 * what the rows are built from and the response is merged onto it. A response that does
 * not match the document's shape, or one the endpoint refuses, leaves the built-in table
 * standing, which is what the client does with one: the catalogue it already carries
 * stays authoritative, and this call only adds to it. An option the service marks
 * disabled is listed as a disabled row rather than dropped, so the account sees that the
 * model exists and cannot use it.
 *
 * @param session - the account whose token authenticates the read.
 * @param extraHeaders - the desktop client headers, which this request carries like every
 *   other subscription request.
 * @param fetchFn - fetch implementation (injectable for tests).
 * @param signal - caller cancellation.
 * @param model - the model the client would be asking about. The genuine caller always has
 *   one, because it asks while a session is running; a listing has none, so the profile's own
 *   first catalogue entry stands in for it rather than sending a request the client's shape
 *   has no counterpart for.
 * @returns the catalogue rows for this account.
 */
export declare function fetchClaudeCatalogue(session: ClaudeSession, extraHeaders?: readonly (readonly [string, string])[], fetchFn?: FetchFn, signal?: AbortSignal, account?: string, model?: string): Promise<DiscoveredModel[]>;
/** Constructor dependencies for {@link ClaudeAdapter}. */
interface ClaudeAdapterOptions {
    /** Identity line a Claude request carries in place of the harness identity section. */
    identityLine?: string;
    models: readonly ModelEntry[];
    streamIdleTimeoutMs: number;
    tokens: AccountTokenManager<ClaudeSession>;
    /** Late-bound pool facade (wired after adapter construction); pools list under their first member's provider. */
    pool?: () => PoolAdapter | undefined;
    /** Whether to fetch the live catalog when logged in (false when config `models` overrides). */
    discovery: boolean;
    fetchFn?: FetchFn;
    onWarn?: (message: string) => void;
    /** How long this route may hold a turn open waiting for a rate-limit window; defaults to waiting on, six-hour ceiling. */
    rateLimit?: RateLimitWait;
    /** Resolve the attachment service per request; absent means image requests fail loudly. */
    resolveAttachments?: () => AttachmentStore | undefined;
    /** Durable catalog store seeding capability metadata across restarts. */
    catalogStore?: CatalogPersistence;
    /**
     * Per-model default reasoning effort override (the Settings page's picker).
     * Returns the user-configured default for one model, or undefined to follow
     * the provider's own default.
     */
    defaultEffortOf?: (model: string) => string | undefined;
}
export declare class ClaudeAdapter extends PoolBackedAdapter {
    private readonly options;
    protected readonly catalogs: ProviderCatalog;
    constructor(options: ClaudeAdapterOptions);
    private fetchCatalog;
    /**
     * Drop cached catalogs after login/logout so the next list does not reuse a stale plan,
     * and the account's uploaded Files API ids with them: those ids belong to the token that
     * uploaded them, which a login change replaces.
     * @param account - the account whose cached state is dropped, or every account when omitted.
     */
    clearAccountCatalog(account?: string): void;
    private discovered;
    private staticModels;
    /** One discovered entry as a picker row, keeping the display text the account's options added. */
    private listed;
    providerInfo(provider: string): LlmProviderInfo;
    providerRetryPolicy(provider: string): import("@deepseek-ai/dsh-llm").ResolvedRetryPolicy;
    /** Capability resolution of the provider's own models (the pool resolves members here). */
    resolveOwnModel(provider: string, model: string): Promise<LlmResolvedModelInfo>;
    /** The canonical account key that owns this session's conversation chain. */
    private chainAccount;
    protected streamOwn(options: GenerateOptions, account?: string): AsyncIterable<StreamChunk>;
    private thinkingParam;
    /**
     * Backfill the wire-identity fields a pre-upgrade stored session lacks:
     * the device id is minted once, the account uuid comes from the OAuth
     * profile. The updated session is persisted so the next request skips the
     * lookup. A missing account uuid after the lookup fails the request loudly
     * instead of sending a bogus correlation triple.
     */
    private identitySession;
    /**
     * When each session last issued a request, and whether its latest break was acted on.
     *
     * Silence cannot be observed from the request itself: the history carries no timestamps. It
     * does not need to be, because no request is issued during silence — the gap between a
     * session's consecutive requests is the gap between its consecutive transcript messages. A
     * decision is remembered so the same break keeps being acted on, which is what the client
     * does, and the table is bounded the way the client bounds its own.
     */
    private readonly requestClock;
    /**
     * Measures the silence before this request, remembering a break that was already acted on.
     *
     * @param sessionId - the session issuing the request.
     * @returns the silence in milliseconds, or the threshold when this break was already acted on.
     */
    private idleBeforeRequest;
    private request;
}
export {};
