import { LlmAdapter } from '@deepseek-ai/dsh-llm';
import type { GenerateOptions, LlmModelInfo, LlmResolvedModelInfo, StreamChunk } from '@deepseek-ai/dsh-llm';
import type { ProviderId } from '../auth/store.js';
import type { ProviderSettingsStore, AccountPreferences } from '../provider-settings.js';
import type { AccountAwareAdapter } from './accounts.js';
import type { PoolAdapter } from './pool.js';
export declare function accountModelId(account: string, model: string): string;
export declare function parseAccountModelId(id: string): {
    account: string;
    model: string;
} | undefined;
export declare function accountAllowsPool(preferences: AccountPreferences | undefined, model: string): boolean;
interface Options {
    provider: ProviderId;
    adapter: AccountAwareAdapter;
    settings: ProviderSettingsStore;
    accounts: () => Promise<readonly {
        key: string;
        label: string;
    }[]>;
    pool: () => PoolAdapter | undefined;
    /** Where a pool that owns no entry for a requested model is reported. */
    onWarn: (message: string) => void;
}
/** Keeps the registered route separate from raw adapters and pool member seams. */
export declare class AccountPreferencesAdapter extends LlmAdapter {
    private readonly options;
    /** Models already reported as unowned — a per-request diagnostic is stated once otherwise. */
    private readonly reported;
    constructor(options: Options);
    providerRetryPolicy(provider: string): import("@deepseek-ai/dsh-llm").ResolvedRetryPolicy | undefined;
    /**
     * The wrapped adapter's own display identity.
     *
     * The harness reads this for every registered route and shows the name in the model picker for
     * a route that declares no provider directory, which is how these routes appear; without the
     * delegation each adapter's name would be replaced by the raw route id.
     */
    providerInfo(provider: string): import("@deepseek-ai/dsh-llm").LlmProviderInfo;
    private preference;
    private models;
    private requireAccount;
    /**
     * Report once, per model, that an enabled pool owns no entry for it. The
     * request still runs, but on one account chosen by the pool's availability
     * rule rather than through pool failover, and that gap is a configuration
     * state the operator can act on instead of a silent difference in routing.
     */
    private reportUnowned;
    /**
     * The account serving a model the pool does not own. The pool's availability
     * rule still applies: an account that is cooling down, or that is past a
     * Claude usage floor, is skipped for the next eligible one — the fallback can
     * never reach an account the pool would have held back.
     *
     * When no account qualifies, the error names why the pool held them back and
     * when the earliest one may serve again. That is the pool-exhausted error's own
     * cause and hint: a spent allowance or a parked account is temporary and
     * retryable, and reporting `NO_ADAPTER` for it would name an unavailable model
     * and discard the recovery instant the provider already disclosed.
     */
    private fallback;
    /** Pool-only facade: explicit families/tiers must obey the same policy as auto pools. */
    poolMember(): AccountAwareAdapter;
    listModels(provider: string): Promise<readonly LlmModelInfo[]>;
    resolveModel(provider: string, id: string): Promise<LlmResolvedModelInfo>;
    stream(options: GenerateOptions): AsyncIterable<StreamChunk>;
}
export {};
