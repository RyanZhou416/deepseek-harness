/**
 * Keyed toolview for the `image_generate` tool: renders generated images
 * inline in the conversation. The row shows the call's prompt while running
 * and after settling; a settled result with image blocks renders them through
 * this plugin's own ImageGallery (harness rc.8 stopped exporting the platform
 * one as a package value), whose bytes load through the node half's
 * `/subscriptions-auth` RPC channel (the durable ImageAttachmentRef is never
 * a fetchable URL on its own). A text-only settled result (degraded route)
 * renders its text; an error result renders the first error line.
 *
 * The 'tool.call.toolview' slot contract is owned by ui-tool
 * (packages/client/ui-tool/src/client/contract/slots.ts), which this package
 * does not resolve; the SlotMap merge here and the shared ToolCallOwnerProps
 * in format.ts mirror it structurally (same discipline as
 * platform-modules.d.ts).
 */
import type { ConnectionHandle } from '@deepseek-ai/dsh-api-remotes/client';
import type { ImageLoader } from './ImageGallery.js';
import type { SubscriptionsTranslate, ToolCallOwnerProps } from './format.js';
declare module '@deepseek-ai/dsh-client-ui-slots' {
    interface SlotMap {
        /** Mirror of ui-tool's keyed atomic Tool view declaration (see the module header). */
        'tool.call.toolview': {
            kind: 'keyed';
            scope: 'session';
            owner: ToolCallOwnerProps;
        };
    }
}
/** Injected dependencies of {@link ImageGenerateToolview} (slot `inject`). */
export interface ImageGenerateToolviewInjected {
    /** Session-authorized image URL loader riding the `/subscriptions-auth` channel. */
    load: ImageLoader;
}
/**
 * Props delivered by the toolview outlet: the owner share plus the inject
 * face and the framework locale seat, spread flat.
 */
export type ImageGenerateToolviewProps = Partial<ToolCallOwnerProps> & Partial<ImageGenerateToolviewInjected> & {
    t?: SubscriptionsTranslate | undefined;
};
/**
 * Build the ImageGallery loader over the `image` endpoint.
 * @param rpc - Connection RPC caller.
 * @returns loader resolving an attachment ref to a data URL.
 */
export declare function createImageLoader(rpc: ConnectionHandle['rpc']): ImageLoader;
/**
 * The `image_generate` keyed toolview component.
 * @param props - owner share, inject face, and locale seat (spread flat).
 * @returns the call row plus, once settled, the gallery / text / error body.
 */
export declare function ImageGenerateToolview(props: ImageGenerateToolviewProps): import("react").JSX.Element | null;
