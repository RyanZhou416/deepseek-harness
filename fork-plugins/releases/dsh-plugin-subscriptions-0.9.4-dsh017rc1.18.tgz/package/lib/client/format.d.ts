/**
 * Absolute-time formatting shared by the settings section and the reset-credit
 * row. The dictionary's `dateTime` template owns the field order and
 * separators: `Date#toLocaleString` follows the browser language instead of the
 * app locale, so a locale switch would leave mixed-language text behind.
 *
 * The tool rows' shared half lives here too: the prompt line, the settled
 * result text, the missing-locale fallback and the row styles both generated
 * tool views render with.
 */
import type { CSSProperties } from 'react';
import type { ToolCallBlock } from '@deepseek-ai/dsh-client-ui-conversation/client';
import type { SubscriptionsKey } from './locales.js';
/** Translate one key of this plugin's dictionary. */
export type SubscriptionsTranslate = (key: SubscriptionsKey, params?: Record<string, unknown>) => string;
/**
 * Format one instant as a local date and time.
 * @param t - Subscriptions dictionary translator.
 * @param at - Epoch milliseconds.
 * @returns The instant rendered through the dictionary's `dateTime` template.
 */
export declare function formatDateTime(t: SubscriptionsTranslate, at: number): string;
/**
 * English-dictionary fallback for a missing locale seat (standalone renders);
 * the framework always supplies the namespace-bound one.
 * @param key - dictionary key.
 * @param params - `{name}` template params.
 * @returns the template with params substituted.
 */
export declare function fallbackTranslate(key: SubscriptionsKey, params?: Record<string, unknown>): string;
/**
 * One model row's display text.
 *
 * A row the provider refuses, or one a saved selection names without the catalog
 * listing it any more, states that beside the name instead of reading like any other
 * row: the model list and the account allowlist both offer these rows, and choosing
 * one silently is what the markers exist to prevent. The provider's own reason is wire
 * data and travels verbatim inside the localized template.
 * @param t - Subscriptions dictionary translator.
 * @param model - the row's name plus whichever markers its source stated.
 * @returns the row text.
 */
export declare function modelRowLabel(t: SubscriptionsTranslate, model: {
    name: string;
    disabledReason?: string;
    unavailable?: boolean;
}): string;
/** Extract the prompt from the call's raw args JSON; falls back to the first string value, then the raw line. */
export declare function derivePrompt(argsRaw: string): string;
/** Flatten a settled result's text blocks (the degraded text-only route and the error line). */
export declare function resultText(block: ToolCallBlock): string;
/** Mirror of ui-tool's ToolCallOwnerProps (the slot contract this package does not resolve). */
export interface ToolCallOwnerProps {
    callId: string;
    toolName: string;
    block: ToolCallBlock;
    cwd?: string | undefined;
    openFile: (path: string) => void;
    inspect?: (() => void) | undefined;
}
/** Row styles every keyed tool view of this package renders with. */
export declare const toolviewStyles: Record<string, CSSProperties>;
