import type { ConnectionHandle } from '@deepseek-ai/dsh-api-remotes/client';
import type { SubscriptionsKey } from './locales.js';
export { callSubscriptionsAuth } from './subscriptions-rpc.js';
/** Subscription provider ids, fixed by the node half's OAuth adapters. */
export type SubscriptionProvider = 'codex' | 'claude' | 'grok' | 'copilot' | 'antigravity' | 'cursor';
/** One logged-in account as answered by the `status` endpoint. */
export interface AccountStatus {
    key: string;
    account?: string;
    expiresAt?: number;
    plan?: string;
    isDefault: boolean;
}
/** One provider's login state as answered by the `status` endpoint. */
export interface ProviderStatus {
    busy: boolean;
    accounts: AccountStatus[];
    detail?: string;
}
/** One rate-limit window as answered by the `usage` endpoint. */
export interface UsageWindow {
    kind: 'session' | 'weekly' | 'other';
    scope?: string;
    usedPercent: number;
    resetsAt?: number;
}
/** One unified rate-limit window as reported by the `usage` endpoint. */
interface RateLimitWindow {
    window: string;
    utilization?: number;
    resetsAt?: number;
    surpassedThreshold?: number;
}
/** The account's captured `anthropic-ratelimit-unified-*` report. */
export interface RateLimitReport {
    status: 'allowed' | 'allowed_warning' | 'rejected' | 'other';
    resetsAt?: number;
    claim?: string;
    fallbackAvailable?: boolean;
    overageStatus?: 'allowed' | 'allowed_warning' | 'rejected' | 'other';
    overageResetsAt?: number;
    overageDisabledReason?: string;
    overageInUse?: boolean;
    overageScope?: string;
    windows: RateLimitWindow[];
    observedAt: number;
}
/** The account pool's view of one account, present only while the pool is enabled. */
export interface PoolReport {
    coolingReason?: 'auth' | 'quota';
    coolingUntil?: number;
    peerAvailable: boolean;
}
/** `usage` endpoint value: the node half owns this shape. */
export interface ProviderUsage {
    supported: boolean;
    windows?: UsageWindow[];
    plan?: string;
    /** Present only when the usage payload disclosed a reset-credit count. */
    resetCredits?: {
        availableCount: number;
    };
    /** The account's last answered request's unified rate-limit report, when captured. */
    rateLimit?: RateLimitReport;
    /** The account pool's view of this account, when the pool is enabled. */
    pool?: PoolReport;
}
/** One model's default-effort picker state as answered by `modelDefaults`. */
export interface ModelDefaultView {
    id: string;
    name: string;
    /** The provider's own reason for refusing the model, or absent when it may serve. */
    disabledReason?: string;
    /** Advertised effort levels, in catalog order (empty when the model has no reasoning). */
    efforts: {
        id: string;
        name: string;
    }[];
    /** The user-configured default effort, when set. */
    configured?: string;
}
/** `modelDefaults` endpoint value: one provider's picker state. */
export interface ModelDefaultsCatalog {
    provider: SubscriptionProvider;
    models: ModelDefaultView[];
}
/** `proxyGet` endpoint value: the node half owns this shape (no secrets). */
export interface ProxyConfigView {
    enabled: boolean;
    url: string;
    username?: string;
    passwordSet: boolean;
    bypass: string[];
    error?: string;
}
/** `proxyTest` endpoint value. */
export interface ProxyTestResult {
    ok: boolean;
    viaProxy: boolean;
    status?: number;
    latencyMs?: number;
    error?: string;
}
/** Injected dependencies of {@link SubscriptionsSection} (slot `inject`). */
export interface SubscriptionsSectionInjected {
    /** Generic logical-RPC caller over the Connection transport. */
    rpc: ConnectionHandle['rpc'];
    /** Section copy: translate a 'settings.subscriptions' key with `{name}` template params. */
    t: (key: SubscriptionsKey, params?: Record<string, unknown>) => string;
}
/**
 * Props delivered by the slot outlet: the inject face spread flat (the
 * renderer erases the share boundary at the render call).
 */
export type SubscriptionsSectionProps = Partial<SubscriptionsSectionInjected>;
/** Bar fill color: success normally, warn from 80%, error from 95%. Shared with the composer badge. */
export declare function usageBarColor(usedPercent: number): string;
/**
 * The fact one account's red usage line states.
 *
 * `limit` and `near` come from the reported window percentages, `rejected` and
 * `warning` from the provider's unified rate-limit status, `relogin` from a
 * stored login the pool found dead, and `cooldown` and `overage` from the
 * account pool working around this account.
 */
type UsageAlertKind = 'limit' | 'near' | 'rejected' | 'warning' | 'relogin' | 'cooldown' | 'overage';
/** What one account's card states about its usage. */
interface UsageAlert {
    /** The fact the line states. */
    kind: UsageAlertKind;
    /**
     * `account` when the fact is about this account alone; `pool` when this
     * account is out and another pool member is serving in its place. The
     * distinction is the difference between "you are blocked" and "we routed
     * around a cooling account".
     */
    attribution: 'account' | 'pool';
    /** Latest disclosed instant still ahead of the clock at which the state clears. */
    resetsAt?: number;
}
/**
 * Whether an account's reported usage puts it out of service.
 *
 * Contract: the header state outranks the percentage state, because the
 * provider's own `rejected` verdict is more specific than a window percentage
 * that may have been read minutes earlier. A dead login is always attributed
 * to the account: no routing decision clears it. A near-limit `allowed_warning`
 * status is an account fact too — it proves only that this account is close to
 * its limit, which routing around it does not change. Overage is always
 * attributed to the pool and only reported when a peer can serve, because the
 * account itself is still answering.
 *
 * The percentage rule is unchanged from the reported windows: a window counts
 * as full at `usedPercent >= 100` for Codex and Claude, which spend a window
 * all the way down, and at `usedPercent >= 95` for every other provider — the
 * per-provider rule the pool's availability check applies
 * (`CONSUMABLE_QUOTA_FULL_PERCENT` / `QUOTA_FULL_PERCENT`). Absent or empty
 * windows, and every window below its threshold, report no alert.
 * @param provider - the provider that reported the windows.
 * @param windows - the account's reported windows, or undefined while unknown.
 * @param rateLimit - the account's captured unified rate-limit report, when any.
 * @param pool - the pool's view of this account, when the pool is enabled.
 * @returns the out-of-service state, or undefined while the account can serve.
 */
export declare function usageAlert(provider: SubscriptionProvider, windows: readonly UsageWindow[] | undefined, rateLimit?: RateLimitReport, pool?: PoolReport): UsageAlert | undefined;
/**
 * The locale key stating one alert. Account-level facts name what is wrong with
 * this account; pool-level facts name that another account is serving instead.
 * @param alert - the alert derived by {@link usageAlert}.
 * @returns the key of the line to render.
 */
export declare function usageAlertKey(alert: UsageAlert): SubscriptionsKey;
/** What one provider's collapsible default-effort section renders. */
interface ModelDefaultsView {
    /** Models with reasoning levels, after the name filter — one row each. */
    shown: ModelDefaultView[];
    /** Models with reasoning levels before filtering (the header total). */
    total: number;
    /** How many of those carry a user override (the header count). */
    overridden: number;
    /** Models without reasoning levels: one count line, never a row each. */
    withoutEfforts: number;
    /** Whether the list is long enough to deserve a filter box. */
    showFilter: boolean;
}
/**
 * Derive one provider's default-effort section from its catalog and filter.
 * Pure so the collapsed-header counts and the filter stay testable without a
 * DOM: rows come only from models that advertise levels, the count of the rest
 * rides as one line, and the filter matches display name or model id.
 * @param models - the provider's catalog models, or undefined while loading.
 * @param filter - the raw filter input (trimmed and lowercased here).
 * @returns the section's rows and header counts.
 */
export declare function deriveModelDefaultsView(models: readonly ModelDefaultView[] | undefined, filter: string): ModelDefaultsView;
/** Inputs of the default-effort fetch decision (see {@link shouldFetchModelDefaults}). */
export interface ModelDefaultsFetchInput {
    /** Providers that currently have at least one account. */
    loggedIn: readonly SubscriptionProvider[];
    /** Providers whose disclosure is open. */
    open: readonly SubscriptionProvider[];
    /** The account signature the last completed fetch was answered for. */
    loadedFor: string | undefined;
    /** The account signature of the current status snapshot. */
    signature: string;
    /** Whether the last attempt failed (a failure latches until Retry). */
    failed: boolean;
}
/**
 * Whether the default-effort catalog needs (re)fetching.
 *
 * Fetching is gated on an *attempt* signature rather than on the payload
 * being empty: an empty answer is a legitimate result (a narrowed
 * `config.providers`, or a catalog that is momentarily unavailable), and
 * treating it as "not loaded yet" re-ran this effect forever. The signature
 * also covers the accounts, so logging a second provider in refetches
 * instead of leaving that card on the previous answer.
 * @param input - the decision inputs.
 * @returns true when the caller should start a fetch.
 */
export declare function shouldFetchModelDefaults(input: ModelDefaultsFetchInput): boolean;
/**
 * Stable signature of the accounts a catalog answer depends on. A change
 * means a previous answer is stale (an account arrived or left), so the next
 * open disclosure refetches.
 * @param statuses - the per-provider status snapshot.
 * @returns a signature string, stable across renders with equal accounts.
 */
export declare function modelDefaultsSignature(statuses: Partial<Record<SubscriptionProvider, ProviderStatus>>): string;
/**
 * The Subscriptions settings page component.
 * @param props - the slot inject face ({@link SubscriptionsSectionInjected}).
 * @returns the section body, or a notice while the RPC face is absent.
 */
export declare function SubscriptionsSection(props: SubscriptionsSectionProps): import("react").JSX.Element;
