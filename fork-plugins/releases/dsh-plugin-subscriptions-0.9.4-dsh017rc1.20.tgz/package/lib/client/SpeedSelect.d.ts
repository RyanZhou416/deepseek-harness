import type { PropsLocale, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots';
import type { ConnectionHandle } from '@deepseek-ai/dsh-api-remotes/client';
import type { SubscriptionsKey } from './locales.js';
/** One model's speed choice: standard routing or the fast (priority) tier. */
export type SpeedTier = 'standard' | 'fast';
/** `speed` endpoint value, mirrored from the node half. */
export interface SpeedState {
    tier: SpeedTier;
    fastModels: string[];
}
/** What {@link SpeedSelect} renders from: visibility plus the current tier. */
export interface SpeedSelectState {
    visible: boolean;
    tier: SpeedTier;
}
/**
 * The speed state this control watches, and the choice generation its reads belong to.
 *
 * The poll's read and the user's choice are both asynchronous, and the read is the slower of the
 * two (it asks the node half to enumerate the fast-capable models and the host for the session's
 * current model). A read that started before a choice can therefore settle after it, and
 * publishing that result would put the tier the user just replaced back on screen.
 */
export interface SpeedView {
    /** Choices this control has settled; a read carries the value it started under. */
    generation: number;
    /** The last state this control published, or null until the first read settles. */
    state: SpeedSelectState | null;
}
/**
 * Fold one settled host read into the view, unless a choice has superseded it.
 *
 * Dropping the superseded read is what keeps a settled choice on screen: the tier in it is the
 * one the choice replaced, so publishing it would show the setting reverting on its own until the
 * next poll corrected it.
 * @param view - the view the read settles into.
 * @param read - the generation the read was started under.
 * @param state - the state the read returned.
 * @returns the updated view, or the same view when the read is stale.
 */
export declare function settleRead(view: SpeedView, read: number, state: SpeedSelectState): SpeedView;
/**
 * Fold one settled choice into the view, superseding every read started before it.
 *
 * The choice is stated directly rather than re-read: a successful write is the authoritative
 * answer, and a fresh read would take another round trip to say the same thing.
 * @param view - the view the choice settles into.
 * @param tier - the tier the write accepted.
 * @returns the updated view at the next generation.
 */
export declare function settleChoice(view: SpeedView, tier: SpeedTier): SpeedView;
/**
 * Minimal structural face of ui-model-selection's `ctx.modelDirectories`
 * service (the sanctioned cross-plugin channel: cordis services, not value
 * imports — same mirroring discipline as ToolCallOwnerProps). Both dsh lines
 * ship it with this shape; it replaces rc.2's `connection.api.sessions.models`
 * read, which the 0.1.2-alpha removed along with the whole `.api` face.
 */
export interface ModelDirectoriesLike {
    /** Resolve one session's shared model directory (throws for unknown sessions). */
    directoryFor(sessionId: string): {
        /** Load the directory; `current` is the session's effective model selection. */
        load(): Promise<{
            current: {
                provider: string;
                model: string;
            } | null;
        }>;
    };
}
/** Injected dependencies of {@link SpeedSelect} (slot `inject`, session-bound). */
export interface SpeedSelectInjected {
    /** Load the current model's speed state; `visible` false keeps the control hidden. */
    loadSpeed: () => Promise<SpeedSelectState>;
    /** Store the current model's speed tier; resolves false when the write failed. */
    setSpeed: (tier: SpeedTier) => Promise<boolean>;
}
/**
 * Props delivered by the slot outlet: the framework session kit and InputZone
 * owner share (unused — everything arrives session-bound through the inject
 * face), the injected callbacks, and the locale seat.
 */
export type SpeedSelectProps = PropsRuntime<'conversation.input.right'> & Partial<SpeedSelectInjected> & Partial<PropsLocale<'settings.subscriptions'>>;
/**
 * Whether the Speed control belongs on screen for the session's current model.
 *
 * The gate has two halves: the model's route must be one whose requests carry a fast tier, and
 * the node half must list that exact model id as fast-capable. A session with no model selection
 * has nothing to switch.
 * @param current - the session's effective model selection, or null when it has none.
 * @param fastModels - the node half's fast-capable model ids.
 * @returns true when the control should render.
 */
export declare function speedControlVisible(current: {
    provider: string;
    model: string;
} | null, fastModels: readonly string[]): boolean;
/**
 * The `loadSpeed` half of the inject face: the session's current model and the
 * tier stored for it, plus the node half's fast-capable listing (the visibility
 * gate). A model-RPC failure throws rather than answering "hidden" — the caller
 * keeps its last known state, so a transient failure never locks the toggle
 * away.
 *
 * `sessionId` is a plain string: slot and command contexts brand it through
 * different dsh-session copies, and only the service boundary needs one.
 *
 * `models` resolves lazily per call: the ui-model-selection service may
 * register after this plugin applies, and a shell without it (no model seat
 * at all) simply keeps the toggle hidden.
 */
export declare function createSpeedLoader(rpc: ConnectionHandle['rpc'], models: () => ModelDirectoriesLike | undefined, sessionId: string): SpeedSelectInjected['loadSpeed'];
/** The `setSpeed` half of the inject face: boolean outcome for the component's busy state. */
export declare function createSpeedSetter(rpc: ConnectionHandle['rpc'], models: () => ModelDirectoriesLike | undefined, sessionId: string): SpeedSelectInjected['setSpeed'];
/**
 * Settle one picked tier against the session. A false answer fails the call
 * with the dictionary's failure copy, which is how an entry point that owns no
 * notice surface of its own states the failure: the `/fast` popup renders
 * through the shell's error strip, while the composer control shows the same
 * copy in place.
 * @param setSpeed - the current model's setter.
 * @param tier - the picked tier.
 * @param t - Subscriptions dictionary translator.
 * @returns nothing once the write takes effect.
 * @throws Error carrying `speedSaveFailed` when the write fails.
 */
export declare function settleSpeedTier(setSpeed: SpeedSelectInjected['setSpeed'], tier: SpeedTier, t: (key: SubscriptionsKey) => string): Promise<void>;
/**
 * The composer Speed control: a trigger reading `速度 · 快速`/`速度 · 标准`
 * that opens a two-row menu (standard/fast with descriptions, check mark on
 * the current tier). The host pushes nothing on a model switch, so the
 * control re-reads on a slow poll with a single-flight guard; a failed read
 * keeps the last known state, so a transient RPC failure can never lock the
 * toggle away. Every read is stamped with the choice generation it started
 * under, and {@link settleRead} drops one that a later choice superseded.
 */
export declare function SpeedSelect({ loadSpeed, setSpeed, t }: SpeedSelectProps): import("react").JSX.Element | null;
