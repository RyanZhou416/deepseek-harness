/**
 * Quota tracking for pool members: polls the providers' usage endpoints
 * (the same normalized `ProviderUsage` shape the Settings page consumes) and
 * turns the windows into a scheduling score.
 *
 * The baseline is the remaining quota fraction divided by time until reset.
 * Model-scoped live windows accompany that rate so the pool can add bounded
 * reset and finishing preferences. An elapsed window supplies no score or
 * quota-full assertion until the provider reports a replacement.
 */
import type { ProviderUsage, UsageWindow } from './common.js';
import type { ProviderId } from '../auth/store.js';
/** Other providers enter the quota-full fallback band at this reported usage. */
export declare const QUOTA_FULL_PERCENT = 95;
/** Claude and ChatGPT can consume their remaining quota until a window reaches 100%. */
export declare const CONSUMABLE_QUOTA_FULL_PERCENT = 100;
/** How long a usage snapshot is trusted before a background refresh. */
export declare const USAGE_TTL_MS: number;
/** The scheduling view of one member's quota. */
export interface MemberQuota {
    /** False when a window is effectively full or the login is gone. */
    available: boolean;
    /** Required burn rate (fraction of window per ms); 0 when unknown. */
    urgency: number;
    /** Epoch ms of the snapshot this was computed from; 0 when none. */
    fetchedAt: number;
    /** Applicable windows whose recorded reset has not elapsed; absent when usage is unknown. */
    windows?: readonly UsageWindow[];
    /**
     * Windows from the last successful poll of this account, retained when the
     * current poll degraded so an availability floor still sees an allowance that
     * was already spent. Selection scores read {@link windows} instead: a window
     * the endpoint is not currently vouching for must not steer routing.
     */
    floorWindows?: readonly UsageWindow[];
    /**
     * ChatGPT: the weekly window opened within the last day and an available
     * reset credit expires within three days. Selection ranks these accounts
     * with a bounded bonus inside its availability band. The pool never
     * spends the credit.
     */
    preferFreshCredit?: boolean;
}
/**
 * One account's quota read. A named model asks for the windows that constrain it;
 * an omitted model asks for the account's own session and weekly windows — the ones
 * every model shares — which is what a model-independent availability floor reads.
 */
export interface QuotaQuery {
    provider: ProviderId;
    account: string;
    model?: string;
}
/**
 * Per-ACCOUNT usage snapshots with in-flight dedupe and
 * stale-while-revalidate refresh. Providers without a usage endpoint
 * (copilot) resolve no fetcher and score a constant zero urgency — which
 * naturally ranks them behind every measured member. Fetchers are resolved
 * lazily per (provider, account) so accounts added after startup join
 * tracking on their first score.
 */
export declare class PoolUsageTracker {
    private readonly fetcherFor;
    private readonly ttlMs;
    private readonly entries;
    private readonly inflight;
    /** Bumped by {@link invalidate} so an older in-flight response cannot restore a dropped snapshot. */
    private readonly epochs;
    /**
     * The last successful snapshot accepted per account, kept outside
     * {@link entries} so {@link invalidate} cannot erase it. Only the availability
     * floors read it: an enforcement failure drops the cached snapshot, and the
     * poll that follows can fail too, which is no evidence that the allowance the
     * earlier poll reported came back.
     */
    private readonly lastWindows;
    constructor(fetcherFor: (provider: ProviderId, account: string) => (() => Promise<ProviderUsage>) | undefined, ttlMs?: number);
    /**
     * The quota view of one member. A cold cache awaits the first fetch; a
     * stale one answers immediately while the refresh serves the NEXT call
     * (member selection must never block on the network mid-conversation). A
     * failure still cooling down degrades immediately with no network call.
     *
     * Deliberately does NOT score from `lastSnapshot` the way
     * {@link snapshotFor} displays it: ranking routing decisions off data that is
     * known to be stale-and-unrefreshable risks steering traffic by an urgency
     * number the endpoint itself is no longer vouching for, whereas
     * `snapshotFor`'s stale-display concern (the Settings page, the composer
     * badge) has no such downside — showing an old percentage beats showing
     * nothing. The stale windows still reach {@link MemberQuota.floorWindows},
     * which feeds the availability floors rather than the scores.
     * @param query - the account to read, and the model whose lanes apply when one is named.
     * @returns availability plus the urgency score.
     */
    quotaFor(query: QuotaQuery): Promise<MemberQuota>;
    /**
     * Same cache as {@link quotaFor}, for direct display (the Settings page):
     * the raw snapshot, or the original fetch error, instead of a routing
     * score.
     * @param provider - the account's provider.
     * @param account - the account key.
     * @param force - bypass a fresh cached SNAPSHOT for an honest re-check (the
     *   manual Refresh button). A live failure cooldown is never bypassed —
     *   retrying through it is exactly what turns a 429 into a permanent
     *   lockout, so even a forced call still answers from the negative cache.
     * @returns `{ supported: false }` when the provider has no usage fetcher.
     */
    snapshotFor(provider: ProviderId, account: string, force?: boolean): Promise<ProviderUsage>;
    /**
     * Drop cached snapshots: one account, or a whole provider when `account` is
     * omitted. {@link lastWindows} survives, so the availability floors still see
     * the allowance the endpoint last reported.
     */
    invalidate(provider: ProviderId, account?: string): void;
    /**
     * Run (or join) the single in-flight fetch for one account key, caching
     * either outcome. A missing/invalid credential is deliberately NOT
     * negative-cached: it costs no network round trip (the session lookup
     * fails before the request goes out) and re-checking live means the
     * member rejoins routing the instant its login is fixed, rather than
     * waiting out a stale cooldown.
     */
    private refresh;
    /**
     * The last successful snapshot this tracker holds for one account: whatever
     * the cache entry carries, or the account's {@link lastWindows} record once
     * {@link invalidate} has dropped the entry.
     * @param key - the `provider/account` cache key.
     * @returns the last successful snapshot, or undefined when none was ever read.
     */
    private lastSuccessful;
    /** Score one member against a snapshot's windows. */
    private score;
}
