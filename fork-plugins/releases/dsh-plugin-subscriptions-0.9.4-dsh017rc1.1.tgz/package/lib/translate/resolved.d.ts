/**
 * Resolved-image plumbing for the wire translators. ImageBlocks carry only an
 * attachment reference; the bytes live in the attachment service, which is
 * async I/O. Adapters resolve images BEFORE calling the (pure, synchronous)
 * translators, so the translators see {@link ResolvedImagePart}s with inline
 * base64 data.
 */
import type { ContentBlock, Message, RequestMessage, ToolResultMessage } from '@deepseek-ai/dsh-llm';
import type { AttachmentStore } from '@deepseek-ai/dsh-attachment';
/** An image block with its bytes resolved to inline base64 for the wire. */
export interface ResolvedImagePart {
    type: 'image';
    /** MIME type verified by the attachment service (e.g. `image/png`). */
    mediaType: string;
    /** Base64-encoded image bytes. */
    dataBase64: string;
    /** Files API `id`, sent as `source.file_id` when the base64 image exceeds the vision limit. */
    fileId?: string;
}
/** Translator input: a harness block, resolved image, or internal tool-result wrapper. */
export type TranslatableBlock = ContentBlock | ResolvedImagePart | ResolvedToolResultBlock;
/** Tool results may themselves carry attachment-backed images. */
export interface ResolvedToolResultBlock {
    type: 'tool-result';
    toolCallId: ToolResultMessage['toolCallId'];
    isError?: boolean;
    content: readonly TranslatableBlock[];
}
/**
 * Wires with text-only tool outputs receive images in a following user turn.
 * Defer that turn until all consecutive user messages have been processed:
 * parallel tool results can arrive in separate harness messages, and a user
 * image message must not interrupt their tool-call/output pairing.
 */
export declare function withToolResultImages(messages: readonly TranslatableMessage[]): TranslatableMessage[];
/** Translator input message: role plus resolved blocks. */
export interface TranslatableMessage {
    role: 'system' | 'user' | 'assistant';
    content: readonly TranslatableBlock[];
    /** Preserved for adapters whose provider-private replay metadata is required. */
    source?: Message['source'];
}
/**
 * Resolve every ImageBlock's attachment reference to inline base64 bytes.
 * Ordinary image-free messages keep their identity; V4 tool-role messages
 * become internal result blocks. A request carrying an image without an
 * attachment service fails; unsupported developer messages also fail rather
 * than being silently omitted.
 * @param messages - durable conversation messages and request-only user input.
 * @param attachments - the deployment's attachment service, when mounted.
 * @param signal - cancellation for the storage reads.
 * @returns ordered translator messages with tool results and images resolved.
 */
export declare function resolveImages(messages: readonly RequestMessage[], attachments: AttachmentStore | undefined, signal?: AbortSignal): Promise<readonly TranslatableMessage[]>;
