/**
 * The continuation stores' shared private-file machinery: owned work, bounded waits and
 * cross-process serialisation.
 *
 * Four properties here are correctness requirements rather than conveniences:
 *
 * 1. One logical deadline bounds the *wait*, never the work. The bound is an absolute instant, so
 *    every step a caller passes it to shares what is left instead of starting a fresh clock, and a
 *    step whose budget already ended refuses before it starts new I/O. A caller that arrives while
 *    this document's operation is still running waits for that operation inside the same absolute
 *    budget and then runs its own change: waiting never adopts the earlier operation's result, and
 *    a wait that ends first starts none of the arriving caller's own I/O. The operation a caller
 *    started stays owned by this helper: it keeps running, and a caller whose own wait ended is
 *    told only that the state is unavailable. Every later caller waits for that operation's real
 *    settlement under its own absolute budget and then reads and changes the document inside the
 *    lock, so no caller decides from a document a pending write may still replace. An ended wait
 *    neither retries nor revokes the owned operation; that operation may still commit before its
 *    lock is released. The write runs inside the lock, so a process that honours this lock cannot
 *    decide from the document either while the abandoned work is still writing.
 * 2. Every outcome of a wait — elapsed, timed out, aborted — releases that wait's own timer and
 *    abort listener, so a caller that keeps sending requests accumulates neither.
 * 3. One read-modify-write runs entirely inside the lock this plugin already owns
 *    ({@link withStoreLockOwned}); locking only the write would let two processes read the same
 *    document and each drop the other's change. A lock that cannot be owned is a refusal, not a
 *    degraded unowned run. A held lock refuses under the lock budget, independently of the
 *    logical deadline. The lock's staleness bound is that primitive's own lease semantics: a
 *    holder that does not take this lock is not serialised by it.
 * 4. A document is replaced by one exclusively created owner-only temporary file renamed into
 *    place, so a crash leaves either the old record or the new one, and a failed write removes
 *    only its own temporary file. The document's directory is created first, so the first use in
 *    a directory that does not exist yet is a creation rather than a lock that looks busy.
 *
 * The failure code lives here rather than in one store because every store here reports the same
 * refusal, and a second spelling of it would let a caller route on the wrong one.
 *
 * @module dsh-plugin-subscriptions/providers/claude-continuation-io
 */
import type { LockTiming } from '../auth/store-lock.js';
/** The fixed refusal every continuation store reports; a caller must then send nothing. */
export declare const LOCAL_CONTINUATION_STATE_UNAVAILABLE = "LOCAL_CONTINUATION_STATE_UNAVAILABLE";
/** The failure every continuation store reports. */
export type ContinuationUnavailable = {
    readonly kind: 'unavailable';
    readonly code: typeof LOCAL_CONTINUATION_STATE_UNAVAILABLE;
    readonly reason: string;
};
/**
 * Build the refusal one operation reports.
 * @param reason - the specific fact the caller must act on; never a credential.
 * @returns the fixed refusal.
 */
export declare function continuationUnavailable(reason: string): ContinuationUnavailable;
/**
 * One absolute budget a caller shares across a whole preparation chain.
 *
 * The instant, not a duration, is what makes the budget shared: a step that starts later computes
 * a smaller remaining wait from the same value, so a chain of steps cannot extend the caller's
 * bound by starting each one with a fresh duration. A step whose budget has already ended refuses
 * before it starts new I/O; work that already started stays owned until it really settles.
 */
export interface ContinuationDeadline {
    /** The instant (epoch milliseconds) this budget ends. */
    readonly expiresAt: number;
    /** The caller's own cancellation, which ends each wait and never the owned work. */
    readonly signal?: AbortSignal;
}
/**
 * Start one absolute budget from a configured duration and the caller's cancellation.
 *
 * A request preparation chain resolves this once and passes the same value to every step.
 * @param deadlineMs - how long the chain may wait, from the configured deadline.
 * @param signal - the caller's own cancellation, when it has one.
 * @returns the budget every step of that chain shares.
 */
export declare function continuationBudget(deadlineMs: number, signal?: AbortSignal): ContinuationDeadline;
/** What ended a bounded wait. */
export type ContinuationWaitOutcome = 'elapsed' | 'timed-out' | 'aborted';
/** The private file operations one continuation document needs. */
export interface ContinuationFiles {
    /**
     * Create the document's directory when it is not there yet.
     * @param directory - the directory the document lives in.
     */
    ensureDirectory(directory: string): Promise<void>;
    /**
     * Read the document.
     * @param path - the document's path.
     * @returns its text, or undefined when it does not exist.
     */
    read(path: string): Promise<string | undefined>;
    /**
     * Replace the document with `text`, at owner-only mode.
     * @param path - the document's path.
     * @param text - the complete document text.
     */
    writeAtomic(path: string, text: string): Promise<void>;
}
/** The timers, clock and abort listeners one bounded wait uses; a test injects one to control them. */
export interface ContinuationWaitHost {
    /**
     * Read the current instant.
     * @returns epoch milliseconds, from which a remaining budget is computed.
     */
    now(): number;
    /**
     * Start a timer.
     * @param delayMs - how long to wait.
     * @param fire - what the elapsed timer calls.
     * @returns the disposer that cancels the timer.
     */
    schedule(delayMs: number, fire: () => void): () => void;
    /**
     * Subscribe to a signal's abort.
     * @param signal - the caller's cancellation.
     * @param fire - what an abort calls.
     * @returns the disposer that removes the listener.
     */
    onAbort(signal: AbortSignal, fire: () => void): () => void;
}
/** The filesystem this host provides, at owner-only mode. */
export declare const nodeContinuationFiles: ContinuationFiles;
/** This process's clock, timers and abort listeners. */
export declare const systemContinuationWaits: ContinuationWaitHost;
/**
 * The filesystem code a caught failure carries.
 * @param error - the caught value.
 * @returns its code, or a fixed label when it carries none.
 */
export declare function errorCode(error: unknown): string;
/**
 * Whether a caught failure means the path simply is not there.
 * @param error - the caught value.
 * @returns true when the path was absent.
 */
export declare function isMissing(error: unknown): boolean;
/**
 * The lock policy this module's own stores use, derived from the configured lock budget.
 *
 * The staleness bound stays in the same order as the plugin's existing lock policy: a
 * continuation document is tiny and its critical sections are milliseconds, so a longer lease
 * only delays recovering a dead holder. The retry budget is what turns a live holder into a
 * refusal, and it is the configured lock bound rather than the request's deadline.
 * @param lockTimeoutMs - the resolved `continuationStateLockTimeoutMs`.
 * @returns the timing the guarded read-modify-write runs under.
 */
export declare function continuationLockTiming(lockTimeoutMs: number): LockTiming;
/** What one guarded update left standing. */
export type ContinuationOutcome = {
    readonly kind: 'applied';
    /** The text that stands after the operation, whether or not it was written. */
    readonly text: string;
    /** Whether this operation persisted the text; false means it only read. */
    readonly written: boolean;
} | ContinuationUnavailable;
/** Constructor options for {@link ContinuationIo}. */
export interface ContinuationIoOptions {
    /** The document every operation on this helper reads or replaces. */
    readonly path: string;
    /** How long one operation may wait for the owned lock. */
    readonly lockTimeoutMs: number;
    /** How long one operation may wait when its caller passes no deadline. */
    readonly deadlineMs: number;
    /** The private file operations; absent uses this host's filesystem. */
    readonly files?: ContinuationFiles;
    /** The timers and abort listeners; absent uses this process's timers. */
    readonly waits?: ContinuationWaitHost;
}
/**
 * One continuation document's owned work.
 *
 * The helper is the document's owner in this process: it starts every read-modify-write under the
 * plugin's own lock, keeps a started operation alive past the caller's wait, makes a later caller
 * wait for that operation's real settlement before reading and changing the document itself, and
 * can be closed once the plugin is disposed. One caller at a time changes the document, so two
 * requests that merely overlap are serialised rather than refused.
 */
export declare class ContinuationIo {
    private readonly path;
    private readonly lockTimeoutMs;
    private readonly deadlineMs;
    private readonly files;
    private readonly waits;
    /**
     * Owned work that has not really settled yet. A later caller waits for every entry under its own
     * budget, and settlement removes only its own entry.
     */
    private readonly settling;
    private closed;
    /**
     * @param options - the document, both configured budgets and the injectable I/O boundary.
     */
    constructor(options: ContinuationIoOptions);
    /**
     * Run one read-modify-write under the plugin's own lock, bounded by the caller's budget.
     *
     * The change runs inside the lock with the document it read, so two processes cannot each read
     * the same document and then drop the other's change. Returning `undefined` leaves the
     * document as it is, which is how a caller reads without writing. A caller whose signal is
     * already aborted, and a caller whose budget has already ended, perform no file operation at
     * all. A caller that arrives while an operation this helper owns is still running waits for that
     * operation's real settlement under its own budget and then runs its own change; a wait that
     * ends first starts none of this caller's work, and a caller that stopped waiting does not
     * revoke the operation it started.
     * @param change - the pure change, given the current text (undefined when the document is
     *   absent); returning undefined means "write nothing".
     * @param deadline - the absolute budget and cancellation the caller resolved; absent starts one
     *   from the configured deadline and carries no signal.
     * @returns the text that stands, whether it was written, or the fixed refusal.
     */
    update(change: (current: string | undefined) => string | undefined, deadline?: ContinuationDeadline): Promise<ContinuationOutcome>;
    /**
     * Wait for one owned work promise under a budget and the caller's cancellation.
     *
     * The wait's own timer and abort listener are removed on every outcome. Neither outcome
     * cancels the work: the caller learns only that it stopped waiting.
     * @param work - the owned work; it reports its own outcome to its own caller and must not
     *   reject.
     * @param deadline - the absolute budget and cancellation.
     * @returns 'elapsed' when the work settled first, otherwise what ended the wait.
     */
    awaitSettlement(work: Promise<unknown>, deadline: ContinuationDeadline): Promise<ContinuationWaitOutcome>;
    /**
     * How much of one budget is left.
     * @param deadline - the caller's absolute budget.
     * @returns the remaining milliseconds, never below zero; zero means no new I/O may start.
     */
    remainingMs(deadline: ContinuationDeadline): number;
    /**
     * Start one budget from this document's configured deadline.
     * @returns the budget one lifecycle step runs under.
     */
    budget(): ContinuationDeadline;
    /**
     * Create the document's directory, so a lock beside the document can be created.
     *
     * This is not owned work: it writes nothing a later read depends on, and repeating it is
     * harmless.
     */
    ensureDirectory(): Promise<void>;
    /**
     * Stop accepting new work and wait for the work already owned to reach real settlement.
     *
     * This is the plugin's dispose obligation: it reports settlement, not success, and each
     * operation's own outcome was already returned to its caller. It must not be awaited from
     * inside an operation this helper owns, and it never pretends a committed write was cancelled.
     * A caller that is waiting for admission when this is called wakes to the closed state and is
     * refused instead of admitted, so no work starts after disposal began. A caller that has to
     * bound its own teardown does so around this call; this never reports a settlement it did not
     * observe.
     */
    close(): Promise<void>;
    /**
     * Wait until every operation this helper owns has really settled.
     *
     * Owned work reports its outcome to its caller and never rejects, so this waits for settlement
     * rather than deciding anything about it.
     */
    drain(): Promise<void>;
    /** Start one owned read-modify-write and keep it tracked until it really settles. */
    private own;
    /** The real operation: create the directory, take the lock, read, change, write. */
    private run;
}
