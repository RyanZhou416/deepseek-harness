// SPDX-License-Identifier: GPL-3.0-or-later

import { BETA_REGISTRY } from "./beta-registry.js";
import type {
  ClaudeCodeCapabilities,
  ClaudeCodeProtocolProfile,
} from "./contracts.js";
import { ClaudeCodeWireError } from "./contracts.js";
import {
  supportsMidConversationSystem,
  supportsStructuredOutputs,
} from "./model-capabilities.js";
import { BETA_REGISTRY_2_1_233 } from "./profiles/beta-registry-2.1.233.js";
import { BETA_REGISTRY_2_1_280 } from "./profiles/beta-registry-2.1.280.js";
import { CLAUDE_CODE_2_1_195_PROFILE } from "./profiles/claude-code-2.1.195.js";
import { CLAUDE_CODE_2_1_233_PROFILE } from "./profiles/claude-code-2.1.233.js";
import { CLAUDE_CODE_2_1_280_PROFILE } from "./profiles/claude-code-2.1.280.js";

/*
 * Provenance. The emitted order is a port of the genuine client's base beta set
 * `$9r` (byte offset 227387921), followed by the gated pushes the request
 * builder performs afterwards (bytes 238153535-238155672). The identifiers
 * themselves come from registry `Udd`, ported verbatim as `BETA_REGISTRY`.
 *
 * The order is EMERGENT, not declared: upstream neither sorts the array nor
 * keeps a canonical list, so the sequence below is load-bearing and must not be
 * reordered for tidiness. `docs/source-trace.md` records the same fact under
 * "Beta registry and push order".
 *
 * The push SITES are shared across profiles; the identifiers they push are not.
 * A profile therefore selects its registry (see `resolveBetaRegistry`) and the
 * sequence of sites stays fixed, which is what keeps a registry change from
 * silently becoming an ordering change.
 */

/** Structural shape of a registry entry, shared by every registry version. */
interface BetaRegistryEntry {
  readonly featureKey: string;
  readonly header: string;
}

/**
 * The entries the push sites below require, as a structural contract rather
 * than a reference to one concrete registry.
 *
 * Registry versions have different key sets. Every REQUIRED key here is present
 * in all of them, so those push sites index directly. The optional ones are
 * optional because they exist in some registry versions and not others, and a
 * push site whose key is absent becomes inert: it evaluates its gates, finds no
 * entry, pushes nothing, and the surrounding order closes up with no gap.
 * Making the optionality part of the TYPE is what forces every future registry
 * to be checked against the push sites at compile time instead of at runtime.
 *
 * `NARRATION_SUMMARIES` is optional in the older direction -- upstream removed
 * it after 2.1.195 (see `src/profiles/beta-registry-2.1.233.ts`). The keys
 * added for 2.1.280 -- the remaining optional members declared below -- are
 * optional in the newer direction: they are absent from the 2.1.195 registry,
 * and all but `PER_MESSAGE_EFFORT` are absent from the 2.1.233 one. `PER_MESSAGE_EFFORT` IS declared by the 2.1.233 registry, so
 * registry absence does not keep its site inert there; what does is the
 * catalogue, because no 2.1.233 model declares the backing capability. The two
 * mechanisms are not interchangeable and both are load-bearing.
 */
export interface ComposableBetaRegistry {
  readonly CLAUDE_CODE: BetaRegistryEntry;
  readonly OAUTH_AUTH: BetaRegistryEntry;
  readonly LONG_CONTEXT: BetaRegistryEntry;
  readonly INTERLEAVED_THINKING: BetaRegistryEntry;
  readonly REDACT_THINKING: BetaRegistryEntry;
  readonly THINKING_TOKEN_COUNT: BetaRegistryEntry;
  readonly CONTEXT_MANAGEMENT: BetaRegistryEntry;
  readonly STRUCTURED_OUTPUTS: BetaRegistryEntry;
  readonly PROMPT_CACHING_SCOPE: BetaRegistryEntry;
  readonly MID_CONVERSATION_SYSTEM: BetaRegistryEntry;
  readonly PER_MESSAGE_EFFORT?: BetaRegistryEntry;
  readonly MID_CONV_TOOL_CHANGE?: BetaRegistryEntry;
  readonly MID_CONVERSATION_SYSTEM_CLEAR_AT?: BetaRegistryEntry;
  readonly EFFORT: BetaRegistryEntry;
  readonly THINKING_BINDING_CONTROLS?: BetaRegistryEntry;
  readonly THINKING_DISPLAY_UPDATES?: BetaRegistryEntry;
  readonly SPEED: BetaRegistryEntry;
  readonly AFK_MODE: BetaRegistryEntry;
  readonly EXTENDED_CACHE_TTL: BetaRegistryEntry;
  readonly CONTEXT_HINT: BetaRegistryEntry;
  readonly CACHE_DIAGNOSIS: BetaRegistryEntry;
  readonly NARRATION_SUMMARIES?: BetaRegistryEntry;
}

const PROFILE_BETA_REGISTRIES: ReadonlyMap<string, ComposableBetaRegistry> =
  new Map<string, ComposableBetaRegistry>([
    [CLAUDE_CODE_2_1_195_PROFILE.id, BETA_REGISTRY],
    [CLAUDE_CODE_2_1_233_PROFILE.id, BETA_REGISTRY_2_1_233],
    [CLAUDE_CODE_2_1_280_PROFILE.id, BETA_REGISTRY_2_1_280],
  ]);

/**
 * Selects the registry a profile composes against.
 *
 * An unrecognised id falls back to the 2.1.195 registry rather than throwing.
 * Rejecting unknown profiles is the request builder's job -- it validates the
 * profile before any of this runs -- and duplicating that rejection here would
 * give `composeBetas` a second, differently-worded opinion about profile
 * validity. Standalone callers keep the 2.1.195 behaviour they had before
 * profiles were a parameter.
 *
 * Exported for tests only, and deliberately NOT re-exported from
 * `src/index.ts`: the public runtime surface stays closed. That fallback is
 * precisely why a test needs to reach this function. A profile bound to the
 * wrong registry, or to none, silently composes against 2.1.195 instead of
 * failing, and every required key of `ComposableBetaRegistry` currently
 * carries an identical header in all three registries -- so a mis-binding
 * changes no emitted byte and no behavioural suite can see it. Asking this
 * function directly is the only way to observe the binding at all.
 */
export function resolveBetaRegistry(
  profile: ClaudeCodeProtocolProfile,
): ComposableBetaRegistry {
  return PROFILE_BETA_REGISTRIES.get(profile.id) ?? BETA_REGISTRY;
}

export interface ComposeBetasInput {
  readonly rawModel: string;
  readonly normalizedId: string;
  readonly capabilities: ClaudeCodeCapabilities;
  readonly thinkingDisplayActive: boolean;
  /**
   * Whether a `thinking` object of type `adaptive` or `enabled` will reach the
   * wire for this request AND the model is interleaved-thinking capable, i.e.
   * upstream `ac` minus its `Fg()` term. Compute it with `isThinkingActive`
   * from `./thinking.js`; never re-derive it at a call site.
   *
   * Required rather than optional: it is a total function of inputs every call
   * site already holds, and requiring it is what forces a new call site to
   * decide rather than silently inherit a default.
   */
  readonly thinkingActive: boolean;
  readonly cacheTtl?: "5m" | "1h" | null;
  readonly speed?: "standard" | "fast" | null;
  /**
   * Package extension, not observed upstream behaviour. Consumer-supplied beta
   * identifiers appended AFTER the derived canonical set. See
   * `docs/source-trace.md`, governance ledger L10.
   */
  readonly additionalBetas?: readonly string[];
  /**
   * Package extension, not observed upstream behaviour. Beta identifiers
   * removed from the emitted set AFTER composition and AFTER the
   * `additionalBetas` merge, so suppression beats addition. An identifier that
   * is not in the composed set is a silent no-op. See `docs/source-trace.md`,
   * governance ledger L14.
   */
  readonly suppressBetas?: readonly string[];
  /**
   * Package extension, not observed upstream behaviour. Forces (`true`) or
   * suppresses (`false`) the 1M-context beta for this request, overriding the
   * `[1m]` model marker. See `docs/source-trace.md`, governance ledger L10.
   */
  readonly use1MContextOverride?: boolean;
}

/**
 * Reports the emitted beta set together with the identifiers `suppressBetas`
 * actually removed. `suppressedBetaNames` is empty when the seam is unused or
 * matched nothing, which is what keeps the evidence key absent for every
 * request built before the seam existed.
 */
export interface ComposedBetas {
  readonly betas: readonly string[];
  readonly suppressedBetaNames: readonly string[];
  /**
   * Present only when push site 12b fired. This is the body-side half of a
   * beta/body pair: the site pushes the display-updates beta AND decides that
   * the body's `thinking` object carries `display: "updates"`. The consumer is
   * the canonical body builder (`buildCanonicalBody`), which hands it to
   * `resolveThinking`.
   *
   * `suppressBetas` cannot unset it. Suppressing the beta identifier removes
   * the HEADER only; the body keeps `display: "updates"`. That matches the
   * existing coupled pair where suppressing `effort-2025-11-24` leaves
   * `output_config.effort` in the body.
   */
  readonly thinkingDisplayOverride?: "updates";
}

/**
 * Bounds a caller-supplied beta list (`additionalBetas` and `suppressBetas`
 * share these rules verbatim). The header is a comma-joined single
 * field, so a comma, control character, or whitespace in an entry would let a
 * caller synthesize extra beta values (or, with CR/LF, an entirely separate
 * header). The allowlist below is deliberately narrower than the observed
 * upstream identifiers require, because every genuine beta name in
 * `BETA_REGISTRY` matches it.
 */
const ADDITIONAL_BETA_PATTERN = /^[A-Za-z0-9][A-Za-z0-9._-]*$/u;
const MAX_ADDITIONAL_BETA_LENGTH = 128;
const MAX_ADDITIONAL_BETAS = 32;

function validateAdditionalBetas(value: unknown): readonly string[] {
  if (!Array.isArray(value) || value.length > MAX_ADDITIONAL_BETAS) {
    throw new ClaudeCodeWireError("INVALID_INPUT");
  }
  return value.map((entry: unknown): string => {
    if (
      typeof entry !== "string" ||
      entry.length === 0 ||
      entry.length > MAX_ADDITIONAL_BETA_LENGTH ||
      !ADDITIONAL_BETA_PATTERN.test(entry)
    ) {
      throw new ClaudeCodeWireError("INVALID_INPUT");
    }
    return entry;
  });
}

const NO_SUPPRESSED_BETAS: readonly string[] = Object.freeze([]);

export function composeBetas(
  input: ComposeBetasInput,
  profile: ClaudeCodeProtocolProfile = CLAUDE_CODE_2_1_195_PROFILE,
): readonly string[] {
  return composeBetasWithAudit(input, profile).betas;
}

export function composeBetasWithAudit(
  input: ComposeBetasInput,
  profile: ClaudeCodeProtocolProfile = CLAUDE_CODE_2_1_195_PROFILE,
): ComposedBetas {
  const out: string[] = [];
  const policy = profile.betaPolicy;
  const experimental = policy.experimentalBetasEnabled;
  const registry = resolveBetaRegistry(profile);

  if (!input.normalizedId.includes("haiku"))
    out.push(registry.CLAUDE_CODE.header);
  if (policy.oauthAuthenticated) out.push(registry.OAUTH_AUTH.header);
  // Package extension: `use1MContextOverride` replaces the model-marker gate
  // for this request. The profile gate still applies, so an override cannot
  // enable a beta the pinned profile declares unavailable.
  const oneMillionRequested =
    input.use1MContextOverride ?? /\[1m\]/iu.test(input.rawModel);
  if (policy.oneMillionContextEnabled && oneMillionRequested) {
    out.push(registry.LONG_CONTEXT.header);
  }
  if (
    policy.interleavedThinkingEnabled &&
    input.capabilities.interleavedThinking
  ) {
    out.push(registry.INTERLEAVED_THINKING.header);
  }
  if (
    experimental &&
    input.capabilities.interleavedThinking &&
    policy.interactive &&
    !policy.thinkingSummariesShown &&
    !input.thinkingDisplayActive
  ) {
    out.push(registry.REDACT_THINKING.header);
  }
  if (
    policy.thinkingTokenCountEnabled &&
    experimental &&
    input.capabilities.interleavedThinking
  ) {
    out.push(registry.THINKING_TOKEN_COUNT.header);
  }
  /*
   * The narration push site keeps its position in the sequence even when the
   * resolved registry dropped the entry. Upstream removed the beta after
   * 2.1.195, so a registry without it emits nothing here and the surrounding
   * order closes up with no gap; the gates are still evaluated first so a
   * profile that enables narration against a registry that has it behaves
   * exactly as it did before.
   */
  const narrationSummaries = registry.NARRATION_SUMMARIES;
  if (
    experimental &&
    policy.narrationSummariesEnabled &&
    narrationSummaries !== undefined
  ) {
    out.push(narrationSummaries.header);
  }
  if (experimental && input.capabilities.contextManagement)
    out.push(registry.CONTEXT_MANAGEMENT.header);
  if (
    experimental &&
    supportsStructuredOutputs(input.normalizedId) &&
    policy.structuredOutputsEnabled
  ) {
    out.push(registry.STRUCTURED_OUTPUTS.header);
  }

  // No web-search beta: upstream pushes it only for vertex and foundry.
  if (experimental) out.push(registry.PROMPT_CACHING_SCOPE.header);

  /*
   * Upstream `jR`. The local boolean below records that this site PUSHED, which
   * is what sites 11b and 11c gate on -- upstream reads `Ee.includes(jR)`, the
   * composed array, not the registry. Asking the registry instead would fire
   * those two sites for a model this one skipped.
   */
  const midConversationSystemFired = supportsMidConversationSystem(
    input.normalizedId,
    profile,
  );
  if (midConversationSystemFired) {
    out.push(registry.MID_CONVERSATION_SYSTEM.header);
  }

  /*
   * Site 11a. Upstream `wRt`, which reduces to
   * `Fg() && mD(provider) && catalogue-declares-per_turn_effort`; the provider
   * term is first-party here by construction.
   */
  const perMessageEffort = registry.PER_MESSAGE_EFFORT;
  if (
    experimental &&
    input.capabilities.perTurnEffort &&
    perMessageEffort !== undefined
  ) {
    out.push(perMessageEffort.header);
  }

  /*
   * Site 11b. Upstream `oQt() && Tue(model)`. `Tue` opens with
   * `if (!Fg() || !kue(e)) return false`, so the experimental gate is upstream's
   * and not an addition. Step 3 of `Tue` -- which sends the beta for any model
   * with NO catalogue entry -- is deliberately not ported; see the analysis
   * document's divergence record.
   */
  const midConvToolChange = registry.MID_CONV_TOOL_CHANGE;
  if (
    experimental &&
    midConversationSystemFired &&
    input.capabilities.midConvToolChange &&
    midConvToolChange !== undefined
  ) {
    out.push(midConvToolChange.header);
  }

  /*
   * Site 11c. Upstream `Mo`, which is the one site whose experimental gate is
   * invisible at the statement level -- `Mo` names no `Fg()` at all. The gate is
   * reached three calls deep instead: `Mee` is `oRt(model) !== "off"`, `oRt`
   * wraps `fur`, and `fur` opens by returning `"off"` when `Fg()` is false. So
   * `experimental` is upstream's own conjunct here exactly as it is at 11a and
   * 11b, and a reader who checks only the `Mo` expression will wrongly conclude
   * it was invented. It was not.
   *
   * `Mo`'s remaining conjuncts are constants for this package. `!l7(querySource)`
   * holds because `l7` is true only for the two auto-mode query sources. `!Vr`
   * holds because `Vr` is a per-session latch, and a stateless package composes
   * every request as a first request. `Mee`'s other terms are fixed on the
   * first-party path. What is left is `Ee.includes(jR)`, which is precisely the
   * `midConversationSystemFired` outcome recorded at site 11.
   */
  const midConversationSystemClearAt =
    registry.MID_CONVERSATION_SYSTEM_CLEAR_AT;
  if (
    experimental &&
    midConversationSystemFired &&
    midConversationSystemClearAt !== undefined
  ) {
    out.push(midConversationSystemClearAt.header);
  }

  // Site 12.
  if (input.capabilities.effort) out.push(registry.EFFORT.header);

  /*
   * Site 12a. Upstream `er && Fg()` with the latch write, which on the pinned
   * first-party path collapses to thinking-active AND experimental.
   * The coupled body field `thinking.block_binding` is NOT emitted: it needs a
   * host override this package cannot observe.
   */
  const thinkingBindingControls = registry.THINKING_BINDING_CONTROLS;
  if (
    experimental &&
    input.thinkingActive &&
    thinkingBindingControls !== undefined
  ) {
    out.push(thinkingBindingControls.header);
  }

  /*
   * Site 12b. Upstream guards the push with
   * `(yc?.type === "adaptive" || yc?.type === "enabled") && ac && firstParty
   *  && !callerSuppliedDisplay && ...` plus the simulate-proxy environment
   * variable and a per-session latch. The reachable remainder of that guard is
   * modelled below: `experimental` is upstream's `Fg()` term inside `ac`,
   * `input.thinkingActive` is the thinking-type test together with the rest of
   * `ac`, and `!input.thinkingDisplayActive` is the caller-supplied-display
   * test. First-party is not modelled because this package only builds the
   * first-party path, the simulate-proxy env var is not modelled because the
   * package reads no environment, and the per-session latch is always empty in
   * a stateless package that composes every request as a first request.
   *
   * The branch is additionally reached only when the display-mode resolver
   * `Gxt` returns its connector-text result; its other results break out
   * before the push. `!policy.thinkingSummariesShown` is that resolver's
   * `sQt()` term, mapped onto the profile flag exactly as at the
   * redact-thinking site above. See the 2.1.280 analysis document, §6.4, for
   * the resolver itself.
   *
   * The resolver's other two diverting branches are already covered by
   * `!thinkingDisplayActive`. A caller display of `"summarized"` takes the
   * first branch, and `"omitted"` takes the second whenever the
   * explicit-display flag is falsy, which is the only state this package can
   * express -- it models no equivalent of that flag. Under a truthy
   * explicit-display flag upstream would fall through and overwrite an
   * explicit `"omitted"` with `"updates"`; that input is unreachable here, and
   * is recorded rather than modelled.
   *
   * The site is coupled: it pushes the beta, records `display: "updates"` for
   * the body builder, and removes the previously composed redact-thinking beta
   * (upstream `qu()`).
   *
   * The splice sits INSIDE this block and is deliberately the LAST thing it
   * does. At this point `out` holds only canonical pushes, because the caller
   * `additionalBetas` merge runs later. So a caller who explicitly supplies
   * `redact-thinking-2026-02-12` in `additionalBetas` still gets it, precisely
   * because the merge's `if (!out.includes(beta))` test now succeeds. Moving
   * the splice after the merge would silently eat that caller's entry.
   */
  const thinkingDisplayUpdates = registry.THINKING_DISPLAY_UPDATES;
  let thinkingDisplayOverride: "updates" | undefined;
  if (
    experimental &&
    input.thinkingActive &&
    !policy.thinkingSummariesShown &&
    !input.thinkingDisplayActive &&
    thinkingDisplayUpdates !== undefined
  ) {
    out.push(thinkingDisplayUpdates.header);
    thinkingDisplayOverride = "updates";
    const redactIndex = out.indexOf(registry.REDACT_THINKING.header);
    if (redactIndex !== -1) out.splice(redactIndex, 1);
  }

  if (input.speed === "fast" && !out.includes(registry.SPEED.header)) {
    out.push(registry.SPEED.header);
  }
  if (policy.afkModeEnabled && !out.includes(registry.AFK_MODE.header)) {
    out.push(registry.AFK_MODE.header);
  }
  if (
    input.cacheTtl === "1h" &&
    experimental &&
    !out.includes(registry.EXTENDED_CACHE_TTL.header)
  ) {
    out.push(registry.EXTENDED_CACHE_TTL.header);
  }
  if (profile.contextHintEnabled) out.push(registry.CONTEXT_HINT.header);
  if (
    policy.cacheDiagnosisEnabled &&
    !out.includes(registry.CACHE_DIAGNOSIS.header)
  ) {
    out.push(registry.CACHE_DIAGNOSIS.header);
  }

  // No advisor-tool beta: upstream has no observed unconditional push site.

  // Package extension. Canonical, upstream-derived identifiers always precede
  // caller-supplied ones, and a caller entry that duplicates an already-emitted
  // identifier is dropped rather than reordering the canonical prefix.
  if (input.additionalBetas !== undefined) {
    for (const beta of validateAdditionalBetas(input.additionalBetas)) {
      if (!out.includes(beta)) out.push(beta);
    }
  }

  // Package extension. The suppression filter is deliberately LAST: it runs
  // after the canonical composition and after the `additionalBetas` merge, so
  // an identifier named by both seams does not reach the wire. Removal is
  // reported in composed order, never in caller order, and an identifier that
  // was never composed is a silent no-op because a consumer cannot know which
  // betas this package derives for a given model.
  if (input.suppressBetas === undefined) {
    return Object.freeze({
      betas: Object.freeze(out),
      suppressedBetaNames: NO_SUPPRESSED_BETAS,
      ...(thinkingDisplayOverride === undefined
        ? {}
        : { thinkingDisplayOverride }),
    });
  }
  const suppressed = new Set(validateAdditionalBetas(input.suppressBetas));
  const kept: string[] = [];
  const removed: string[] = [];
  for (const beta of out) {
    if (suppressed.has(beta)) removed.push(beta);
    else kept.push(beta);
  }
  return Object.freeze({
    betas: Object.freeze(kept),
    suppressedBetaNames: Object.freeze(removed),
    // The suppression filter above touches only the header list; the body
    // half of the site-12b pair survives it by design.
    ...(thinkingDisplayOverride === undefined
      ? {}
      : { thinkingDisplayOverride }),
  });
}
