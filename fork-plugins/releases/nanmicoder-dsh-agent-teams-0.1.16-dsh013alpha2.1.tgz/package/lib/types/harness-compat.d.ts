/**
 * Version-specific subagent adapters for the exact Harness releases exercised
 * by AgentTeams. Public model messaging and host-authored Queue/Steer delivery
 * remain separate because they carry different provenance and turn semantics.
 */
import type { Context } from '@deepseek-ai/cordis';
import type { Agent } from '@deepseek-ai/dsh-agent';
import type { ContentBlock, MessageId } from '@deepseek-ai/dsh-llm';
import type { Session, SessionEvent, SessionId } from '@deepseek-ai/dsh-session';
type Setup = (childCtx: Context) => () => void;
/** Read child-owned history without a descriptor inherited from its parent. */
export declare function sessionOwnEvents(session: Session): readonly SessionEvent[];
/** Install member setup before the first request, including cold resume. */
export declare function installContinuableMemberSetup(ctx: Context, setup: Setup): void;
/** Queue a distinct host-authored turn on a supported legacy Harness. */
export declare function queueMemberPrompt(runtime: Context['subagents'], parent: Agent, childId: SessionId, content: ContentBlock[], signal: AbortSignal): Promise<MessageId>;
/**
 * Deliver a member message with Alpha.2's nearest-step policy.
 *
 * A resident member receives Steer so guidance is visible at its next model
 * step. An inactive member receives Queue, which may cold-resume it as a
 * distinct turn.
 */
export declare function deliverMemberPrompt(ctx: Context, parent: Agent, childId: SessionId, content: ContentBlock[], signal: AbortSignal): Promise<MessageId>;
/** Guard every resumable delivery path while preserving native receivers. */
export declare function guardSubagentDelivery(ctx: Context, isRetired: (sender: Agent, targetId: SessionId) => Promise<boolean>): void;
export {};
