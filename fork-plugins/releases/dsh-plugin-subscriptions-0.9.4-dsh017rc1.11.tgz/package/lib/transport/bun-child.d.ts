/**
 * Bun-side transport child.
 *
 * Runs under Bun and issues each framed request with the global `fetch`, so the
 * request leaves the machine through the same runtime the target client uses:
 * the same TLS stack, header serialization, connection handling and runtime
 * self-report. It never listens on a socket.
 *
 * Only Node-compatible APIs are used for stdio and compression; the masquerade
 * comes from the runtime that performs the fetch, not from Bun-specific calls.
 *
 *   client → child   { streamId, type: "request", url, method, headers, body: boolean }
 *                    then, when `body` is true, body frames, then { streamId, type: "body-end" }
 *   child  → client  { streamId, type: "response", status, headers }
 *                    then body frames, then { streamId, type: "end" }
 *                    or { streamId, type: "error", message } at any point
 */
import type { Readable } from 'node:stream';
/**
 * Whether request bodies may be compressed, and at what size.
 *
 * The genuine client's decision is gated by two remote flags whose default is
 * false, so ordinary traffic sends an identity body: it compresses only when the
 * runtime is Bun, the destination is the real API host, the body is a string at or
 * above a per-endpoint threshold, and the feature flag is on. This transport has no
 * equivalent of those flags, so it mirrors their default — no compression — and
 * keeps the capability behind an explicit opt-in rather than guessing a threshold.
 *
 * The size comparison is in UTF-16 code units, matching the client's own check.
 */
export declare const GZIP_THRESHOLD_CHARS: number;
/** Environment variable that opts into request-body compression. */
export declare const GZIP_SWITCH_ENV = "DSH_SUBSCRIPTIONS_GZIP";
/** Runs the frame loop until stdin closes. */
export declare function run(input?: Readable): Promise<void>;
