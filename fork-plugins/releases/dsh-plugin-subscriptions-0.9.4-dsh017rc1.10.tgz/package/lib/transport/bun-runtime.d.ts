/**
 * Locates the Bun runtime that carries the masqueraded transport.
 *
 * The runtime is a versioned artifact, not an ambient tool: the transport's whole
 * point is that the request is serialized and handshaked by a specific runtime, so
 * an unpinned `bun` on `PATH` would silently reintroduce the variance this exists
 * to remove. Resolution order is an explicit override, then the platform package
 * the plugin declares, and a missing runtime is a hard error rather than a
 * fallback.
 */
/** Environment variable naming a Bun executable to use instead of the package. */
export declare const BUN_PATH_ENV = "DSH_SUBSCRIPTIONS_BUN_PATH";
/** Failure raised when no usable Bun runtime can be located. */
export declare class BunRuntimeError extends Error {
    /**
     * @param detail - What was searched and what the caller can do about it.
     */
    constructor(detail: string);
}
/**
 * Resolves the Bun executable to run the transport child with.
 *
 * @param env - Environment to read the override from; defaults to `process.env`.
 * @param requireFrom - Module whose resolution paths locate the platform package.
 * @returns Absolute path to the executable.
 * @throws BunRuntimeError when the override is set but missing, the platform is
 *   unsupported, or the declared package is not installed.
 */
export declare function resolveBunRuntime(env?: NodeJS.ProcessEnv, requireFrom?: NodeRequire): string;
