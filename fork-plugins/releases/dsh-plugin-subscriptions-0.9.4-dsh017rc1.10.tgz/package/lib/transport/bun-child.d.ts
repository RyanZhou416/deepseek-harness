/**
 * Bun-side transport child.
 *
 * Runs under Bun and issues each framed request with the global `fetch`, so the
 * request leaves the machine through the same runtime the target client uses:
 * the same TLS stack, header serialization, connection handling and runtime
 * self-report. It never listens on a socket.
 *
 * Only Node-compatible APIs are used for stdio and compression; the masquerade
 * comes from the runtime that performs the fetch, not from Bun-specific calls.
 *
 *   client → child   { streamId, type: "request", url, method, headers, body: boolean }
 *                    then, when `body` is true, body frames, then { streamId, type: "body-end" }
 *   child  → client  { streamId, type: "response", status, headers }
 *                    then body frames, then { streamId, type: "end" }
 *                    or { streamId, type: "error", message } at any point
 */
import type { Readable } from 'node:stream';
/**
 * Request-body size at or above which the body is sent gzip-compressed.
 *
 * The genuine client compresses a string body through a helper whose decision
 * depends on storage state this transport has no equivalent of, so the threshold
 * is a single tunable that must be pinned against the genuine client before the
 * bridge is trusted for large bodies.
 */
export declare const GZIP_THRESHOLD_BYTES: number;
/** Runs the frame loop until stdin closes. */
export declare function run(input?: Readable): Promise<void>;
