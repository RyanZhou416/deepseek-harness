/**
 * The Claude API fetch used by the subscription provider.
 *
 * Requests to the Messages API host are issued by the Bun transport, so the
 * request is serialized and handshaked by the same runtime the target client uses.
 * Every other destination — token refresh, usage polling, the other providers —
 * keeps the existing client, because only the Messages path is the one being
 * reproduced.
 *
 * The bridge is on by default. `DSH_SUBSCRIPTIONS_BRIDGE=off` restores the previous
 * path explicitly; a bridge that cannot start is a hard error rather than a silent
 * fallback, because falling back would restore exactly the transport this exists to
 * replace.
 */
/** Environment variable that turns the bridge off. */
export declare const BRIDGE_SWITCH_ENV = "DSH_SUBSCRIPTIONS_BRIDGE";
/** Failure raised when the bridge cannot serve a request. */
export declare class BridgeUnavailableError extends Error {
    /**
     * @param detail - What failed and which switch restores the previous path.
     */
    constructor(detail: string);
}
/** Reports whether the bridge is currently enabled by configuration. */
export declare function bridgeEnabled(env?: NodeJS.ProcessEnv): boolean;
/**
 * Fetches a Claude API request through the configured transport.
 *
 * @param input - Request URL.
 * @param init - Method, headers and body.
 * @returns The response, streamed.
 */
export declare function claudeApiFetch(input: RequestInfo | URL, init?: RequestInit): Promise<Response>;
/** Stops the bridge child; used by tests and by profile teardown. */
export declare function stopBridge(): Promise<void>;
