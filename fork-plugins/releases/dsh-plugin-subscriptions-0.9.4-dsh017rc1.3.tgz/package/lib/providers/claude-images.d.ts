/** Anthropic Messages image limits for the current request, including historical tool images. */
import type { SubscriptionImagePolicy } from '../translate/resolved.js';
import type { TranslatableMessage } from '../translate/resolved.js';
/**
 * Resolve Claude's protocol limits without changing normalized attachments.
 * @param contextWindow - resolved model context capacity.
 * @returns request-only dimensions and the model's image occurrence ceiling.
 */
export declare function claudeImagePolicy(contextWindow: number): SubscriptionImagePolicy;
/**
 * Require a logged offload before submitting an oversized JSON body.
 * @param body - exact serialized Messages payload.
 * @param messages - resolved images in the same order used by the wire translator.
 * @returns nothing when the request fits.
 * @throws LlmError with an offload count, or INVALID_REQUEST when images cannot free enough bytes.
 */
export declare function assertClaudeRequestBytes(body: string, messages: readonly TranslatableMessage[]): void;
