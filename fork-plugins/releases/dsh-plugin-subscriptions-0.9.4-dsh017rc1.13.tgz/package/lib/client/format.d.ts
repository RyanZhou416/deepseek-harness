/**
 * Absolute-time formatting shared by the settings section and the reset-credit
 * row. The dictionary's `dateTime` template owns the field order and
 * separators: `Date#toLocaleString` follows the browser language instead of the
 * app locale, so a locale switch would leave mixed-language text behind.
 */
import type { SubscriptionsKey } from './locales.js';
/** Translate one key of this plugin's dictionary. */
export type SubscriptionsTranslate = (key: SubscriptionsKey, params?: Record<string, unknown>) => string;
/**
 * Format one instant as a local date and time.
 * @param t - Subscriptions dictionary translator.
 * @param at - Epoch milliseconds.
 * @returns The instant rendered through the dictionary's `dateTime` template.
 */
export declare function formatDateTime(t: SubscriptionsTranslate, at: number): string;
