/**
 * Client side of the Bun stdio transport.
 *
 * Owns one long-lived Bun child, multiplexes requests over it by `streamId`, and
 * presents each response as a web `Response` whose body streams from the frames.
 *
 * The duplex is injectable so the framing and failure paths are testable without
 * spawning a process; the default duplex spawns the built child under the Bun
 * runtime.
 *
 * Failure policy is fail-closed: a dead child rejects every in-flight request and
 * every later one with a diagnosable error. It never falls back to the Node
 * transport, because the Node path is the configuration this transport exists to
 * replace.
 */
/** Bytes-level duplex to the child. */
export interface BridgeDuplex {
    /** Sends bytes to the child. */
    write(bytes: Uint8Array): void;
    /** Registers the data handler; called once. */
    onData(handler: (bytes: Uint8Array) => void): void;
    /** Registers the exit handler; called once. */
    onExit(handler: (reason: string) => void): void;
    /** Terminates the child. */
    kill(): void;
}
/** Failure raised when the transport cannot carry a request. */
export declare class BridgeError extends Error {
    /** Machine-readable reason. */
    readonly reason: 'child-exited' | 'child-error' | 'remote-error' | 'cancelled' | 'unsupported-body' | 'invalid-status' | 'backpressure';
    /**
     * @param reason - Why the request could not complete.
     * @param detail - Extra context for logs.
     */
    constructor(reason: BridgeError['reason'], detail?: string);
}
/** A started bridge. */
export declare class BunBridge {
    #private;
    /**
     * @param duplex - Bytes-level channel to the child.
     */
    constructor(duplex: BridgeDuplex);
    /** True once the child is gone. */
    get dead(): boolean;
    /** The failure that ended the bridge, when it has ended. */
    get failure(): BridgeError | undefined;
    /**
     * Issues one request through the child.
     *
     * @param url - Absolute request URL.
     * @param init - Method, headers, body and optional abort signal.
     * @returns The response, with a body that streams from the child.
     * @throws BridgeError for a dead child, an unsupported body form, or a write
     *   failure; the caller decides whether to retry.
     */
    request(url: string, init: RequestInit): Promise<Response>;
    /** Terminates the child and rejects everything in flight. */
    dispose(): void;
}
/**
 * Spawns the built child under the Bun runtime and returns a duplex to it.
 *
 * @param options - Command and arguments for the child.
 * @returns A duplex whose exit handler fires on `exit` or `error`.
 */
/**
 * The environment the transport child runs with.
 *
 * The child issues the Messages request itself, so it needs the path, the proxy and the
 * trust-anchor variables the host was launched with — and nothing else. Inheriting the
 * whole environment would hand a pinned foreign runtime every unrelated secret the host
 * happens to hold.
 *
 * @param env - the host environment.
 * @returns the variables to pass, omitting the ones that are unset.
 */
export declare function childEnvironment(env: NodeJS.ProcessEnv): NodeJS.ProcessEnv;
export declare function spawnBunChild(options: {
    readonly command: string;
    readonly args: readonly string[];
    readonly cwd?: string;
}): BridgeDuplex;
