/**
 * Bun-side transport child.
 *
 * Runs under Bun and issues each framed request with the global `fetch`, so the
 * request leaves the machine through the same runtime the target client uses:
 * the same TLS stack, header serialization, connection handling and runtime
 * self-report. It never listens on a socket.
 *
 * Only Node-compatible APIs are used for stdio; the masquerade comes from the
 * runtime that performs the fetch, not from Bun-specific calls.
 *
 *   client → child   { streamId, index, type: "request", url, method, headers, body }
 *                    then, when `body` is true, body frames, then { streamId, type: "body-end" }
 *                    or { streamId, type: "cancel" } to abandon the request
 *   child  → client  { streamId, type: "response", status, headers }
 *                    then body frames, then { streamId, type: "end" }
 *                    or { streamId, type: "error", message } at any point
 */
import type { Readable } from 'node:stream';
/**
 * Header the child owns.
 *
 * Its value must come from the runtime that performs the fetch: the genuine client
 * reports the version of the runtime issuing the request, so a value computed by
 * the caller on a different runtime would name the wrong runtime on the wire.
 * The spelling is the SDK's, which is what reaches the peer.
 */
export declare const RUNTIME_VERSION_HEADER = "X-Stainless-Runtime-Version";
/** Runs the frame loop until stdin closes. */
export declare function run(input?: Readable): Promise<void>;
