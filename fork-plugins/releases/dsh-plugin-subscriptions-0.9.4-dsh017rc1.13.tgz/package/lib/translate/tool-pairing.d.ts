/**
 * Tool-call/tool-result pairing repair for the provider wires that reject an
 * unpaired call.
 *
 * Both the Responses input schema and the chat completions message schema
 * require every function call to be answered by its result and every result to
 * belong to a call: a `function_call` without its `function_call_output` (or a
 * chat `tool_calls` entry without its `tool` message) is a request error, and a
 * result whose call is absent has no meaning to the model. A harness history
 * normally pairs both sides, but a session whose durable log kept a call
 * without its result — a crash whose tail repair ran before the closed step,
 * a fork seed — can still reach a request in that state. The adapters repair
 * the assembled request locally; the durable history stays authoritative and
 * unchanged.
 */
/** Text marking a repaired tool result as an unknown outcome; the model must verify before retrying. */
export declare const UNKNOWN_TOOL_OUTCOME_TEXT = "The tool call has no recorded result. Its outcome is unknown; verify external state before retrying any operation that may have side effects.";
/**
 * Reconcile one Responses input's tool-call pairing: every `function_call`
 * gets an output and every `function_call_output` matches a call. Missing
 * outputs become error-style outputs whose text marks the outcome unknown;
 * orphan outputs are dropped. Duplicate calls of one id receive exactly one
 * repair output.
 * @param input - Responses input items.
 * @returns the same array when already balanced, otherwise a repaired array.
 */
export declare function reconcileResponsesToolCalls(input: Record<string, unknown>[]): Record<string, unknown>[];
/**
 * Reconcile one chat completions `messages` array: every assistant message's
 * `tool_calls` entry is answered by a `tool` message, and every `tool` message
 * answers a call some assistant message advertised. Missing results become
 * error-style `tool` messages appended to the run of results that follows
 * their call; orphan results are dropped. Duplicate calls of one id receive
 * exactly one repair result.
 * @param messages - chat completions wire messages.
 * @returns the same array when already balanced, otherwise a repaired array.
 */
export declare function reconcileChatToolCalls(messages: Record<string, unknown>[]): Record<string, unknown>[];
