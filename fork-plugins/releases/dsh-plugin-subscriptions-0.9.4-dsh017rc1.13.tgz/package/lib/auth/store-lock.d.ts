/**
 * A lock file guarding one account's credential store, so two processes sharing an account
 * cannot both rotate its refresh token.
 *
 * The protocol is the one the genuine client uses, taken from its own bundled copy: the
 * lock is a directory created atomically, a holder is considered dead when the directory's
 * modification time is older than the staleness bound, a live holder renews that time so
 * its own lease cannot expire while it works, and a waiter takes a dead holder's lock away
 * and retries. The client applies it to its device-key and job files, and it is what keeps
 * a rotation on one side from invalidating the token the other side just stored.
 *
 * Coordination with Claude Code's own CLI is not claimed: that process locks the paths it
 * owns, and whether it locks this credential file the same way is not established. What this
 * guarantees is that this plugin's own processes serialise, which is the case that arises
 * when several harness instances share one account.
 *
 * An expired lease is the only evidence of death a file lock has. A holder that is alive but
 * frozen for a whole staleness bound can still be taken over, so the guarded work must stay
 * safe when two holders run it at once.
 *
 * Giving up is deliberate and safe. A holder that cannot be waited out degrades to running
 * without the lock — the behaviour every consumer had before this existed — because the
 * write-back path already compares the token it expects against the one on disk and refuses
 * to overwrite a rotation it did not make.
 */
/** The waiting a holder does before it gives up and runs without the lock. */
export interface LockTiming {
    /** Attempts after the first failure. */
    readonly retries: number;
    /** First wait between attempts, doubling up to the cap. */
    readonly minTimeoutMs: number;
    /** Cap on the wait between attempts. */
    readonly maxTimeoutMs: number;
    /** How long a lock may go untouched before its holder is presumed dead. */
    readonly staleMs: number;
}
/**
 * Run one operation with the lock held for the given resource.
 *
 * @param resourcePath - the file the lock protects; the lock is `${path}.lock`, as upstream
 *   names it.
 * @param run - the work to perform while holding the lock.
 * @param timing - the waiting policy; the default is the one described above.
 * @returns whatever `run` returned.
 */
export declare function withStoreLock<T>(resourcePath: string, run: () => Promise<T>, timing?: LockTiming): Promise<T>;
