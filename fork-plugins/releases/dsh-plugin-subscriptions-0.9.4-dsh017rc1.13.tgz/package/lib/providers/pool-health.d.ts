/**
 * Health bookkeeping for pool members: which `(provider, account, model)`
 * member is cooling down after a failure, and for how long. Purely in-memory
 * — a restart re-probes members naturally, so nothing here is persisted.
 *
 * The failure classifier maps the adapters' stable `LlmError` codes (see
 * `httpLlmError`/`mapFetchFailure` in `common.ts`) to one of three actions:
 * switch to another member with a cooldown, switch without recording a
 * cooldown (transport blips say nothing about the account), or rethrow
 * (the request itself is at fault and another account would fail alike).
 *
 * An enforcement-shaped refusal — a rate-limit refusal the provider stated is
 * final, and every credential refusal — is neither: it parks the account and
 * ends the turn on that refusal, because answering it from another account
 * multiplies the traffic the refusal was aimed at.
 */
import type { ProviderId } from '../auth/store.js';
/** Registry key for one pool member. */
export declare function memberKey(provider: ProviderId, account: string, model: string): string;
/** Registry key parking EVERY member of one account (account-level failures). */
export declare function accountKey(provider: ProviderId, account: string): string;
/** Default cooldown when a quota, rate, or enforcement failure carries no `retry-after`. */
export declare const DEFAULT_QUOTA_COOLDOWN_MS: number;
/** Auth failures recheck after a day; a re-login clears the record immediately. */
export declare const AUTH_COOLDOWN_MS: number;
/** Transient server-side failures cool down briefly. */
export declare const TRANSIENT_COOLDOWN_MS = 60000;
/** Whether a failure parks one member or the account's whole quota. */
export type PoolFailureScope = 'member' | 'account';
/**
 * Whether a failure code names a refusal the provider aimed at one identity.
 * @param code - the failure code a member reported.
 * @returns true when another account of the same subscription must not be asked.
 */
export declare function isRefusalCode(code: string): boolean;
/**
 * The code naming why a pool served nothing: the refusal when its members
 * reported one, otherwise their single shared reason, otherwise the
 * cooling-down state they have in common. A refusal outranks a rate limit
 * another member reported, because naming the rate limit would hand a refused
 * account's turn back to the retry loop.
 * @param codes - every reason a selection recorded or found parked.
 * @returns the terminal error's code.
 */
export declare function exhaustionCode(codes: ReadonlySet<string>): string;
/**
 * Whether a cooldown reason records a login that stopped working rather than a
 * spent allowance. Only a re-login clears these; every other parked account
 * recovers on its own once its window reopens.
 */
export declare function isAuthCooldownReason(reason: string): boolean;
/** What the pool should do with a member that just failed. */
export type PoolFailureAction = 
/** Park the failing member or account, then try the next one. */
{
    action: 'switch';
    cooldownMs: number;
    reason: string;
    scope: PoolFailureScope;
}
/** Try the next member without recording anything about this one. */
 | {
    action: 'switch';
}
/** Fail the turn with this error; another member would fail alike. */
 | {
    action: 'throw';
}
/**
 * Park the account and fail the turn on this refusal. The provider refused
 * this identity, so another account of the same subscription only repeats the
 * refusal — which is the traffic such a refusal is meant to stop.
 */
 | {
    action: 'park';
    cooldownMs: number;
    reason: string;
    scope: PoolFailureScope;
};
/**
 * Classify a member failure. Quota and rate-limit failures cool down (using
 * the provider's own `retry-after` when sent, which is more accurate than
 * any fixed guess) — account-wide for account-metered providers, per-member
 * for model-scoped ones; server/timeout failures get a short per-member
 * cooldown; transport failures switch without a record; everything else —
 * most importantly CONTEXT_WINDOW_EXCEEDED and ABORTED — is the request's own
 * fault and is rethrown untouched.
 *
 * Enforcement-shaped refusals park the account and end the turn instead of
 * switching: a rate-limit refusal the provider stated is final
 * ({@link ENFORCEMENT_CODE}), and every credential refusal, since credentials
 * are account-level. Both record a cooldown — the disclosed reset when the
 * refusal carried one, {@link AUTH_COOLDOWN_MS} for a dead login — so the
 * account is not asked again until something may have changed.
 * @param error - the failure thrown by a member adapter's stream.
 * @param provider - the failing member's provider (decides the quota scope).
 * @returns the action the pool should take.
 */
export declare function classifyPoolFailure(error: unknown, provider: ProviderId): PoolFailureAction;
/** One parked account or member: how long it sits out, and the failure code that parked it. */
export interface HealthRecord {
    unavailableUntil: number;
    reason: string;
}
/**
 * Cooldown registry keyed by {@link memberKey}. A member whose cooldown has
 * expired is simply available again — recovery is proven by the next real
 * request, not by a background probe.
 */
export declare class PoolHealthRegistry {
    private readonly records;
    /** Whether a member may serve: neither it nor its whole account is cooling. */
    isMemberAvailable(provider: ProviderId, account: string, model: string, now?: number): boolean;
    /** Whether one registry key is clear right now. */
    isAvailable(key: string, now?: number): boolean;
    /** Park a member for `cooldownMs`; a longer existing cooldown wins. */
    markUnavailable(key: string, cooldownMs: number, reason: string, now?: number): void;
    /**
     * The cooldown parking one account right now, when any: the longest-lived
     * unexpired record among that account's account key and its member keys,
     * with the reason that record holds. Expired records are dropped on the way,
     * the same recovery {@link isAvailable} performs.
     * @param provider - the account's provider route.
     * @param account - the account key.
     * @param now - the current epoch milliseconds.
     * @returns the parking record, or undefined when the account may serve.
     */
    accountCooling(provider: ProviderId, account: string, now?: number): HealthRecord | undefined;
    /**
     * Epoch ms at which the earliest cooling record among `keys` recovers;
     * `undefined` when none of them is cooling. The registry is shared by
     * every pool, so the caller passes the keys of ITS members (member and
     * account keys alike) — an unrelated pool's cooldown must not shape this
     * pool's retry hint. Feeds the pool-exhausted error's
     * `providerRetryAfterMs`.
     */
    earliestRecovery(keys: ReadonlySet<string>, now?: number): number | undefined;
    /** Drop records of one provider, or of a single account when given (auth changes). */
    clear(provider: ProviderId, account?: string): void;
}
