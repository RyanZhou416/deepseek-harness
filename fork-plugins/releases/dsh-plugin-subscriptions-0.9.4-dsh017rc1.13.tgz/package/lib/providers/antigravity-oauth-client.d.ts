/**
 * Public Antigravity desktop OAuth client identity, also distributed by pi-antigravity.
 * These application constants are distinct from user access/refresh tokens.
 * Source: https://github.com/Rahularya01/pi-antigravity/blob/697858cafcf1faddf2ae898d2f053b2ff26c05e6/src/auth/oauth.ts
 */
export {};
