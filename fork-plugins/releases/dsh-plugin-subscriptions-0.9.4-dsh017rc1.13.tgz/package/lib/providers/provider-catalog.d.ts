/**
 * The catalog plumbing the subscription adapters share. One
 * {@link ProviderCatalog} owns a provider's account-indexed model caches and
 * runs the listing skeleton: union every logged-in account, bound each lookup,
 * map a discovery failure onto the static rows. An adapter supplies only what
 * is genuinely its own — the discovery fetch, the static rows, the row mapping
 * and the fallback wording.
 */
import type { LlmModelInfo } from '@deepseek-ai/dsh-llm';
import type { ProviderId } from '../auth/store.js';
import { ModelCatalogCache } from './common.js';
import type { CatalogPersistence, DiscoveredModel } from './common.js';
/** The account-store surface catalog listing reads. */
export interface CatalogAccounts {
    /** The provider's accounts, default first. */
    list(): Promise<readonly {
        key: string;
    }[]>;
    /** Resolve a usable session for one account, refreshing on demand. */
    session(account?: string, forceRefresh?: boolean): Promise<unknown>;
    /** Whether a session is stored for one account (cheap; never refreshes). */
    hasSession(account?: string): Promise<boolean>;
    /** The default account's key, or undefined when logged out. */
    defaultAccount(): Promise<string | undefined>;
}
/** The pool seam that contributes picker rows beyond the discovered catalog. */
export interface CatalogTierSource {
    /** The provider's configured tier rows. */
    modelsForProvider(provider: ProviderId): Promise<LlmModelInfo[]>;
}
/** The catalog-relevant slice of every subscription adapter's options. */
export interface CatalogHost {
    /** The provider's account store. */
    tokens: CatalogAccounts;
    /** Durable half of the default account's cache (the persisted cache is the default's). */
    catalogStore?: CatalogPersistence;
    /** Whether to fetch the live catalog when logged in; false serves the static rows. */
    discovery: boolean;
    /** Warn sink for a discovery failure that fell back to the static rows. */
    onWarn?: (message: string) => void;
}
/** The provider-specific pieces of one adapter's catalog listing. */
export interface CatalogHooks {
    /** The provider's configured rows, served when discovery is off, absent, or failing. */
    staticRows: (provider: string) => LlmModelInfo[];
    /** Fetches one account's catalog from the provider. */
    fetchCatalog: (account: string | undefined, signal?: AbortSignal) => Promise<DiscoveredModel[]>;
    /** One discovered entry as a picker row, filling the provider's capability fields. */
    row: (provider: string, model: DiscoveredModel) => LlmModelInfo;
    /** Per-account bound for the union listing; defaults to {@link DISCOVERY_TIMEOUT_MS}. */
    timeoutMs?: number;
}
/**
 * One provider's account-indexed catalog caches and listing behaviour. The
 * persisted cache serves the default account; every other account gets a
 * throwaway in-memory cache, so switching accounts never serves another
 * account's plan.
 */
export declare class ProviderCatalog {
    private readonly host;
    private readonly label;
    private readonly hooks;
    private readonly defaultCache;
    /** In-memory catalogs for non-default accounts (the persisted cache is the default's). */
    private readonly accountCaches;
    /** Account whose snapshot currently lives in {@link defaultCache}; cleared on default change. */
    private owner;
    /**
     * @param host - the adapter's token store and catalog configuration.
     * @param label - provider name in the fallback warning, e.g. `codex`.
     * @param hooks - the provider-specific listing pieces.
     */
    constructor(host: CatalogHost, label: string, hooks: CatalogHooks);
    /** Drop cached catalogs after login/logout so the next list does not reuse a stale plan. */
    invalidate(account?: string): void;
    /** The persisted cache for the default account; a throwaway cache for any other. */
    cache(account?: string): Promise<ModelCatalogCache>;
    /**
     * The last successfully fetched catalog for one account, ignoring TTL. Used
     * to carry capability metadata forward when a later fetch cannot re-enrich.
     * @param account - the account key; the default account when undefined.
     * @returns the last-known models, or undefined when nothing has been stored.
     */
    lastKnown(account?: string): Promise<readonly DiscoveredModel[] | undefined>;
    /**
     * The provider's own catalog: the union over every logged-in account, or one
     * account when named. Each account lookup is bounded and one failing account
     * sits out; a discovery failure warns and falls back to the static rows, a
     * cancellation propagates, and a vanished login lists nothing.
     * @param provider - the provider route the rows belong to.
     * @param account - the account to list; every logged-in account when undefined.
     * @param signal - caller cancellation; aborting drops the whole union.
     * @returns the provider's own model rows.
     */
    list(provider: string, account?: string, signal?: AbortSignal): Promise<readonly LlmModelInfo[]>;
}
/**
 * Picker-row fields only some providers discover: the catalog description, the
 * Codex sort priority, and Cursor's advertised context size.
 */
export interface CatalogRowExtras {
    description?: string;
    priority?: number;
    contextWindow?: number;
}
/**
 * One picker row for a discovered catalog entry: the advertised id, name and
 * modalities, plus the provider's own extra fields. A provider that does not
 * surface a catalog description passes no `description` extra.
 * @param provider - the provider route the row belongs to.
 * @param model - the discovered entry.
 * @param inputModalities - modalities to advertise; undefined leaves the field off.
 * @param extras - provider-specific row fields.
 * @returns the picker row.
 */
export declare function catalogRow(provider: string, model: DiscoveredModel, inputModalities: readonly ('text' | 'image')[] | undefined, extras?: CatalogRowExtras): LlmModelInfo;
/**
 * One provider's picker rows: its own catalog plus any configured pool tiers
 * the catalog does not already list. An account pool reuses the catalog row of
 * the same wire id for its members, so only configured tiers are extra.
 * @param own - the provider's own rows.
 * @param pool - the provider's account pool, when one is configured.
 * @param provider - the provider route the pool is keyed by.
 * @returns the own rows followed by the unseen pool rows.
 */
export declare function withPoolTiers(own: readonly LlmModelInfo[], pool: CatalogTierSource | undefined, provider: string): Promise<readonly LlmModelInfo[]>;
