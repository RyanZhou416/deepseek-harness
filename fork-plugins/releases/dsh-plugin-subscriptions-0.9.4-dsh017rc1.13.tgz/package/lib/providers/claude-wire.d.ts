import type { ContextManagementConfig } from '@tormentalabs/claude-code-wire-compat';
import type { BuiltClaudeCodeRequest } from '@tormentalabs/claude-code-wire-compat';
import { LlmError } from '@deepseek-ai/dsh-llm';
import type { GenerateOptions } from '@deepseek-ai/dsh-llm';
import type { ClaudeSession } from '../auth/store.js';
import type { TranslatableMessage } from '../translate/resolved.js';
/** Pinned CLI identity this route presents on every subscription endpoint. */
export declare const CLAUDE_USER_AGENT: string;
/**
 * The user agent the client uses on endpoints that are not the transport.
 *
 * The client has two: the transport one carries the entrypoint clause (what
 * {@link CLAUDE_USER_AGENT} is), and the plain one is `claude-code/<version>` with no
 * qualifier. Bootstrap, the OAuth profile read and the Files API use the plain form, so a
 * client process emits both and this plugin has to as well.
 */
export declare const CLAUDE_PLAIN_USER_AGENT: string;
/** The `thinking` object this module maps onto the wire (display is fixed here). */
export interface ClaudeWireThinking {
    type: 'enabled' | 'adaptive';
    budgetTokens?: number;
}
/** A two-level string-keyed table whose total leaf count is bounded. */
export interface BoundedTwoLevelMap<V> {
    /**
     * @param outer - first-level key.
     * @param inner - second-level key.
     * @returns the value stored under both keys, or undefined.
     */
    get(outer: string, inner: string): V | undefined;
    /**
     * @param outer - first-level key.
     * @returns whether that entry holds any leaf.
     */
    isEmpty(outer: string): boolean;
    /**
     * Store a value under both keys; a leaf that already exists is replaced in
     * place. A new leaf inserted at the limit evicts the table's oldest leaf.
     * @param outer - first-level key.
     * @param inner - second-level key.
     * @param value - value to store.
     */
    set(outer: string, inner: string, value: V): void;
    /**
     * @param outer - first-level key whose leaves are all dropped.
     */
    deleteOuter(outer: string): void;
    /** Drop every leaf. */
    clear(): void;
}
/**
 * Build a bounded two-level table.
 *
 * Leaf order is insertion order across the whole table: at the limit the
 * oldest leaf — the first leaf of the first non-empty first-level entry — is
 * evicted, and a first-level entry disappears with its last leaf. What the two
 * key levels mean and what the limit is belong to the caller.
 * @param limit - maximum number of leaves kept.
 * @returns a table bounded to that many leaves.
 */
export declare function boundedTwoLevelMap<V>(limit: number): BoundedTwoLevelMap<V>;
/**
 * The wire session id for one account span of a harness session.
 * @param account - the canonical account key serving this request.
 * @param harnessSessionId - the harness session the conversation belongs to.
 * @returns the stable `X-Claude-Code-Session-Id` for this (account, session).
 */
export declare function claudeWireSessionId(account: string, harnessSessionId: string): string;
/**
 * Record the response `request-id` the billing block of the next request in
 * this account's session chains as `cc_prev_req`. A response without the
 * header clears the chained id, matching the genuine client's continuity
 * commit.
 * @param account - the canonical account key the response belonged to.
 * @param sessionId - the harness session the response belongs to.
 * @param requestId - the `request-id` response header, or null when absent.
 */
export declare function rememberClaudeRequestId(account: string, sessionId: string, requestId: string | null): void;
/**
 * The `cc_prompt_id` segment of the billing block: the request id for this turn.
 *
 * The genuine client mints a fresh UUIDv4 per user prompt turn and reuses it across
 * that turn's tool continuations. A random id there would be model-visible text that
 * no session event records, so this route derives it from the session identity and
 * the turn instead: the same session and turn always render the same bytes, and two
 * sessions never render the same id.
 *
 * @param sessionId - the wire session identity the request declares.
 * @param turn - the prompt turn ordinal within that session.
 * @returns a UUID-shaped id, the only form in which the block emits the segment; the
 *   digest carries a UUIDv4's version and variant nibbles.
 */
export declare function claudePromptId(sessionId: string, turn: number): string;
/**
 * Map a wire-builder rejection onto a harness error. `INPUT_TOO_LARGE` goes
 * through the logged image-offload path; every other code names a request
 * this assembly layer must reject, so it surfaces as INVALID_REQUEST with
 * the wire code instead of a generic transport failure.
 * @param error - the thrown builder error.
 * @param messages - resolved images in wire order, for the offload mapping.
 * @returns the mapped LlmError, or undefined for a non-wire error.
 */
export declare function mapClaudeWireError(error: unknown, messages: readonly TranslatableMessage[]): LlmError | undefined;
/**
 * The identity a Claude request carries when the deployment sets no line.
 *
 * It describes the environment rather than naming a product: what the agent is, that its tool
 * list is authoritative, and where its commands run. A client-shaped request carries the
 * client's own identity block as well, so this line is what keeps the model from reading that
 * block as a description of its toolset.
 */
export declare const DEFAULT_CLAUDE_IDENTITY_LINE = "You are an AI coding agent running inside a local agent harness on the user's machine.\nThe tools listed in this request are the complete and authoritative set available to you: call them exactly as documented, and ignore tool names, commands, and workflows that belong to other environments. Shell commands run on the user's machine in the workspace the request context describes, and the user reads your replies in a local client.";
/**
 * The platform the anchored identity claims, and the architecture with it.
 *
 * The pinned profile is the Windows desktop, so these are constants rather than this
 * host's values: a client reporting `claude-desktop` for Windows while sending another
 * platform, or an architecture that application is not built for, contradicts itself, and
 * a host-specific value would also identify the operator. The runtime version is pinned
 * for the same reason, so a request never varies with the machine that sent it.
 */
export declare const CLAUDE_CLIENT_OS = "Windows";
/** Architecture the Windows desktop application is built for. */
export declare const CLAUDE_CLIENT_ARCH = "x64";
/** Runtime version reported in place of this host's, so it cannot drift per machine. */
export declare const CLAUDE_CLIENT_RUNTIME_VERSION = "24.13.0";
/**
 * Build the pinned Claude Code wire request for one generate call.
 *
 * The stored session must already carry `deviceId` and `accountUuid`; the
 * adapter backfills both before calling here.
 *
 * Two harness sampling options map onto this request shape differently. A
 * `temperature` is the caller's own value on every request the pinned builder
 * emits the field for, which is what the client sends: the caller's override, or
 * its compiled-in 1, on the models whose profile gives them the parameter. Stop
 * sequences have no field in this shape — the client's main-session request
 * carries none — so a caller asking for one is refused instead of being sent a
 * request that cannot halt on it.
 * @param options - the harness generate request.
 * @param session - the account session whose token the request uses.
 * @param messages - conversation messages with images resolved.
 * @param maxTokens - the resolved output cap.
 * @param thinking - the wire thinking parameter, when the model takes one.
 * @param effort - the reasoning effort, when the model advertises efforts.
 * @param sessionId - the wire session identity, a UUID minted per account span by {@link claudeWireSessionId}.
 * @param account - the canonical account key owning this conversation's chain state.
 * @returns the built request: pinned URL, header plan, and serialized body.
 */
export declare function buildClaudeWireRequest(options: GenerateOptions, session: ClaudeSession, messages: readonly TranslatableMessage[], maxTokens: number, thinking: ClaudeWireThinking | undefined, effort: string | undefined, sessionId: string, account: string, identityLine?: string, contextManagement?: ContextManagementConfig): Promise<BuiltClaudeCodeRequest>;
