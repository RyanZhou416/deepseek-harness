/**
 * The `anthropic-ratelimit-unified-*` response headers, and the bounded
 * per-account record of the last report each account answered with.
 *
 * This family is the provider's own account-level rate-limit report, attached
 * to every answered Messages response: a status (`allowed`, `allowed_warning`,
 * `rejected`), the window that claims the limit with its reset instant, and the
 * per-window utilization and threshold readings.
 *
 * The names below are the members the genuine 2.1.288 client's own rate-limit
 * state reads: the reads are in `chunk-p8vbbyj7.js`, and the names that client
 * hoists into constants are in `chunk-pzdykw0r.js`. That client's window table
 * maps `five_hour` → `5h`, `seven_day` → `7d`,
 * `seven_day_overage_included` → `7d_oi` and `overage` → `overage`, each
 * carrying a `-utilization`, `-reset` and `-surpassed-threshold` member.
 * Values are a status token, an epoch-seconds reset, a utilization fraction
 * (`0.82`, or `1` once the cap is reached), or a threshold (`0.75`, `0.95`).
 *
 * @module dsh-plugin-subscriptions/providers/unified-rate-limit
 */
import type { ProviderId } from '../auth/store.js';
/**
 * The status member's accepted values; anything else is reported as `other` so
 * an unrecognized token is visible rather than silently read as `allowed`.
 */
export type UnifiedRateLimitStatus = 'allowed' | 'allowed_warning' | 'rejected' | 'other';
/** One window's reading, from that window's three unified members. */
export interface UnifiedWindowReading {
    /** Window token: `5h`, `7d`, `7d_oi` or `overage`. */
    window: string;
    /** Fraction of the window consumed (0–1), as the provider reported it. */
    utilization?: number;
    /** Epoch milliseconds at which the window reopens. */
    resetsAt?: number;
    /** Threshold (0.75 or 0.95) the utilization passed, when the provider sent it. */
    surpassedThreshold?: number;
}
/** One account's last unified rate-limit report. */
export interface UnifiedRateLimitState {
    /** The account's standing: `rejected` is the provider refusing its requests. */
    status: UnifiedRateLimitStatus;
    /** Epoch milliseconds the claiming window reopens, from the `reset` member. */
    resetsAt?: number;
    /** The window claiming the limit (`5h`, `7d`, `overage`, ...), when named. */
    claim?: string;
    /** Whether the provider advertised a fallback route past the limit. */
    fallbackAvailable?: boolean;
    /** The overage route's own status; `allowed` means requests still flow on overage. */
    overageStatus?: UnifiedRateLimitStatus;
    /** Epoch milliseconds the overage cap reopens. */
    overageResetsAt?: number;
    /** Why overage is unavailable (`org_spend_cap_reached`, ...), when the provider said so. */
    overageDisabledReason?: string;
    /** Whether this account's requests are currently drawing on paid overage. */
    overageInUse?: boolean;
    /** Which budget the overage draws on: `service`, `channel` or `group_pool`. */
    overageScope?: string;
    /** Per-window readings, in {@link WINDOW_PREFIXES} order. */
    windows: UnifiedWindowReading[];
    /** Epoch milliseconds this report was read off the response. */
    observedAt: number;
}
/**
 * Read one response's unified rate-limit report.
 *
 * A response is a report when it carries any member this module reads; one
 * carrying none answers `undefined`, so an account with no captured report is
 * distinguishable from one whose provider reported `allowed`.
 * @param headers - the response headers to read.
 * @param now - the current epoch milliseconds, injected so parsing is testable.
 * @returns the reported state, or undefined when the response carried no such member.
 */
export declare function parseUnifiedRateLimit(headers: Headers, now: number): UnifiedRateLimitState | undefined;
/**
 * Keep one account's report, evicting the oldest entry at the bound.
 * @param provider - the account's provider route.
 * @param account - the canonical account key the response belonged to.
 * @param state - the report parsed from that response.
 */
export declare function rememberUnifiedRateLimit(provider: ProviderId, account: string, state: UnifiedRateLimitState): void;
/**
 * The last report one account answered with, when one was captured.
 * @param provider - the account's provider route.
 * @param account - the canonical account key.
 * @returns the retained report, or undefined when that account never answered.
 */
export declare function unifiedRateLimitFor(provider: ProviderId, account: string): UnifiedRateLimitState | undefined;
/**
 * Drop retained reports: one account, every account of a provider, or
 * everything. A logout or a credential death must not leave the dead account's
 * last report on its card.
 * @param provider - the provider route; omitted drops every provider.
 * @param account - the account key; omitted drops the whole provider.
 */
export declare function forgetUnifiedRateLimit(provider?: ProviderId, account?: string): void;
