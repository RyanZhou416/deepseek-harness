/**
 * The context-management edits this route sends, planned the way the genuine client plans them.
 *
 * The client clears twice over: thinking blocks whenever a request carries thinking, and old
 * tool results once the conversation shows a long break. Both are server-side edits — the
 * request states the policy and the API applies it — so this module only decides whether an
 * edit is worth stating and with which thresholds.
 *
 * A tool result counts toward the clearing decision only when it carries enough text to be
 * worth reclaiming, and the decision fires only when the count is high enough that clearing
 * leaves a useful history behind. The numbers are the client's own.
 */
import type { ContextManagementConfig } from '@tormentalabs/claude-code-wire-compat';
import type { TranslatableMessage } from '../translate/resolved.js';
/**
 * Silence before a request that makes the conversation's earlier tool results stale.
 *
 * The client looks for this gap between consecutive transcript messages. This route cannot see
 * transcript timestamps, and does not need them: no request is issued during silence, so the
 * adapter's own record of its previous request measures the same gap.
 */
export declare const STALE_TOOL_RESULT_IDLE_MS = 3900000;
/**
 * Plans the context edits for one request.
 *
 * @param input - whether the request carries thinking, the adapter's measured silence before
 *   this request, and the request's translated history.
 * @returns the edits to state, or undefined when neither applies.
 */
export declare function planContextManagement(input: {
    readonly hasThinking: boolean;
    readonly idleBeforeRequestMs: number | undefined;
    readonly messages: readonly TranslatableMessage[];
}): ContextManagementConfig | undefined;
