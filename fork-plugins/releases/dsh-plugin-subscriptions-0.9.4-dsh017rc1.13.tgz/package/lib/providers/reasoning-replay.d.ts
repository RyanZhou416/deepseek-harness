/**
 * Adapter-memory replay of a Responses model's completed reasoning.
 *
 * A reasoning model continuing past a tool call must get its reasoning back,
 * or it restarts from scratch on every tool round trip. A Responses reasoning
 * item cannot ride back in its text form: the provider expects the COMPLETED
 * item — its id, summary, and the ENCRYPTED payload — and the encrypted
 * payload only arrives when the request asked for it. dsh-llm's reasoning
 * ContentBlock is a closed shape that cannot carry those items through the
 * harness, so the codex and copilot adapters capture them off the response
 * stream and replay them on the next request of the same conversation.
 */
import type { GenerateOptions } from '@deepseek-ai/dsh-llm';
import type { ReasoningReplayItem, ResponsesStreamEvent } from '../translate/responses.js';
/**
 * The replayable form of one completed reasoning item: the COMPLETE item as
 * the gateway delivered it on `response.output_item.done` — its ORIGINAL id
 * (captured before any adapter rewrite), summary parts, status, and the
 * encrypted payload. A reasoning item's `id` and `summary` are not optional
 * in the Responses input schema, so an item missing its id or its blob is
 * not replayable and degrades to the no-replay path instead of risking an
 * invalid input item.
 * @param item - the `item` payload of one `response.output_item.done` event.
 * @returns the replayable item, or undefined when the payload cannot be replayed.
 */
export declare function completedReasoningItem(item: NonNullable<ResponsesStreamEvent['item']>): ReasoningReplayItem | undefined;
/**
 * Collects one response's function-call ids and completed reasoning items.
 * Both sides are needed to build a replay bundle: items are replayed ahead of
 * the function_call whose call id they belong to, so a response that produced
 * only one of them has nothing to replay.
 */
export declare class ReasoningCapture {
    private readonly onCaptured?;
    private callIds;
    private items;
    /**
     * @param onCaptured - fired at each `response.completed` that produced BOTH
     *   function calls and completed reasoning items, receiving the response's
     *   call ids and replayable reasoning items so the adapter can replay them
     *   on the next request.
     */
    constructor(onCaptured?: ((callIds: string[], items: ReasoningReplayItem[]) => void) | undefined);
    /**
     * Record one parsed event as it arrived off the wire, before any adapter
     * rewrite: a replay bundle must carry the gateway's own call and item ids.
     * @param event - the event as parsed off the wire.
     */
    push(event: ResponsesStreamEvent): void;
}
/**
 * The replay scope isolating one ACCOUNT × CONVERSATION × MODEL. The account
 * identity is the session's long-lived credential identity (Copilot's GitHub
 * token, Codex's ChatGPT account id — both stable across access-token
 * refreshes and different per login); the conversation is the loop-stamped
 * `sessionId`, falling back to the first message's id when a hand-built
 * request carries no session stamp; the model separates wire families. A call
 * id captured in one scope is invisible to every other scope, so reused ids
 * cannot leak reasoning across accounts, conversations, or models.
 * @param accountKey - the session's long-lived account identity.
 * @param options - the harness generate options identifying conversation and model.
 * @returns the replay scope key.
 */
export declare function reasoningReplayScope(accountKey: string, options: GenerateOptions): string;
/**
 * Per-adapter capture store for completed reasoning items, keyed by replay
 * scope and then by the call ids of the response that produced them. Entries
 * are namespaced per ACCOUNT × CONVERSATION × MODEL, idle out via a sliding
 * TTL, and the whole store is dropped on auth transitions, so replay degrades
 * to the no-replay behavior instead of leaking across contexts.
 */
export declare class ReasoningReplayStore {
    private readonly byScope;
    /** Call-id entries kept per scope. */
    private static readonly CALL_LIMIT;
    /** Conversation scopes kept at once; bounds memory when many sessions interleave. */
    private static readonly SCOPE_LIMIT;
    /** How long a captured entry stays replayable; tool round trips take minutes, not hours. */
    private static readonly TTL_MS;
    /**
     * Store one response's completed reasoning items behind every call id it
     * produced, inside one replay scope. Retention: a CONSUMED entry is kept —
     * every later round of the same conversation replays ALL its earlier
     * function_calls — until it idles out of the TTL (see {@link replayFor})
     * or the per-scope entry cap evicts it oldest-first. All calls of one
     * response share ONE entry object: `toResponsesInput` dedupes replays by
     * array reference, so parallel calls replay the items once instead of once
     * per call.
     * @param scope - the replay scope from {@link reasoningReplayScope}.
     * @param callIds - the response's function-call ids.
     * @param items - the response's completed reasoning items, in output order.
     */
    capture(scope: string, callIds: readonly string[], items: readonly ReasoningReplayItem[]): void;
    /**
     * The replay items for one call id in one scope, when still fresh. The TTL
     * bounds IDLE time, not total age: a hit refreshes the entry (and its
     * eviction recency), so an ongoing conversation keeps its chain alive
     * while a conversation that stopped asking forgets within the TTL. An
     * absent or aged-out entry answers `undefined` — the no-replay
     * degradation, never an error.
     * @param scope - the replay scope from {@link reasoningReplayScope}.
     * @param callId - the function-call id being replayed.
     * @returns the captured items, or undefined when nothing replayable is held.
     */
    replayFor(scope: string, callId: string): readonly ReasoningReplayItem[] | undefined;
    /**
     * Drop every captured replay entry. Lookup correctness never depends on
     * the call — the scope already carries the account identity — but the host
     * wiring invokes this on every auth transition (login, logout, credential
     * death) so a switched account's memory never holds the previous account's
     * encrypted reasoning at all; conversation teardown is bounded by the TTL
     * and the caps.
     */
    clear(): void;
}
