/**
 * Translate between the harness message vocabulary and the Anthropic Messages
 * API wire format used by the claude provider: request message assembly, tool
 * schema mapping, and a push-model SSE-event → StreamChunk state machine
 * ({@link AnthropicStreamTranslator}) so tests need no streams.
 */
import { LlmError } from '@deepseek-ai/dsh-llm';
declare module '@deepseek-ai/dsh-llm' {
    interface FinishReasonMap {
        'refusal': {
            kind: 'refusal';
        };
    }
}
import type { StreamChunk, ToolSchema } from '@deepseek-ai/dsh-llm';
import type { MessageContent, TextBlock, ToolDefinition as ClaudeToolDefinition } from '@tormentalabs/claude-code-wire-compat';
/**
 * Block types the public package surface derives but does not name directly.
 * Each alias extracts from an exported union so the shapes cannot drift.
 */
type WireBlock = Exclude<MessageContent, string>[number];
type WireImageBlock = Extract<WireBlock, {
    type: 'image';
}>;
import type { TranslatableMessage } from './resolved.js';
/**
 * Tags wrapping a mid-conversation system message where it sits in the history.
 */
export declare const NO_CONTENT_TEXT = "(no content)";
export declare const SYSTEM_REMINDER_CLOSE = "</system-reminder>";
/**
 * The genuine client's own text for the `tool_result` it synthesizes when a
 * `tool_use` in the request has no result to answer it.
 */
export declare const MISSING_TOOL_RESULT_TEXT = "[Tool result missing due to internal error]";
/**
 * One Anthropic request message. The Claude Code identity and billing blocks
 * are emitted by the wire builder, never here.
 */
export interface AnthropicMessage {
    role: 'user' | 'assistant' | 'system';
    /**
     * A mid-conversation system message carries its text as a plain string, which is what
     * the genuine client sends; every other message carries blocks.
     */
    content: WireBlock[] | string;
    /** Clears a mid-conversation system message once the next user message arrives. */
    clear_at?: 'next_user_message';
}
/**
 * Image source. Under the vision limit this is base64; a Files API upload
 * uses the documented `{ type: "file", file_id }` source.
 */
export declare function anthropicImageSource(part: {
    mediaType: string;
    dataBase64: string;
    fileId?: string;
}): WireImageBlock['source'];
/**
 * Convert harness messages into Anthropic messages. Consecutive same-role
 * messages merge into one message with multiple content blocks; tool results
 * arrive as user messages with `tool_result` blocks, which a merged user
 * message keeps in one leading run ({@link leadWithToolResults}); system-role
 * messages before the conversation starts are handled by
 * {@link toAnthropicSystem} and skipped here, while a later one rides in
 * place as a user-role `<system-reminder>` block (the wire contract models no
 * system-role message).
 * Signed thinking blocks are replayed for the same Claude model; unsigned
 * reasoning is omitted because the API rejects a thinking block with no
 * signature. Images must arrive pre-resolved ({@link TranslatableMessage});
 * an unresolved ImageBlock is skipped because its bytes are unreachable here.
 * A tool result whose `tool_use` was narrated away (a settled subagent's
 * closing message) is narrated the same way, because the wire validator
 * rejects any `tool_result` whose call id is not in the request; conversely a
 * `tool_use` with no result is answered by the synthesized error result the
 * genuine client adds ({@link MISSING_TOOL_RESULT_TEXT}). Both repairs touch
 * only the assembled request, never the history.
 * @param messages - ordered conversation messages with resolved images.
 * @param model - the model this request targets. Thinking signatures are
 *   model-bound, so a signature from another model is not replayed.
 * @param midConversationSystem - whether this model accepts a mid-conversation system
 *   message. The caller answers with the same predicate that decides the beta header, so
 *   the message and the header cannot disagree.
 * @returns Anthropic messages in conversation order.
 */
export declare function toAnthropicMessages(messages: readonly TranslatableMessage[], model?: string, midConversationSystem?: boolean): AnthropicMessage[];
/**
 * Build the Anthropic `system` array: the explicit system prompt, then any
 * system-role messages preceding the conversation. The wire builder places
 * the Claude Code billing and identity blocks ahead of these and owns cache
 * breakpoint placement.
 * @param system - explicit system prompt, when set.
 * @param messages - conversation messages; the system-role text preceding the
 *   conversation is appended, and a later one is left to {@link toAnthropicMessages}.
 * @returns the caller system content blocks.
 */
export declare function toAnthropicSystem(system?: string, messages?: readonly TranslatableMessage[]): TextBlock[];
/**
 * Map harness tool schemas to Anthropic tools, in name order.
 *
 * `tools` renders at position 0 of the cached prefix, so any reordering
 * invalidates every cache entry behind it — `system` and the whole
 * conversation included. Registration order belongs to the caller and plugin
 * load order can differ between processes, so the wire order is fixed here
 * instead. Anthropic selects a tool by name; the array order carries nothing.
 * @param tools - tool schemas from the request.
 * @returns Anthropic `tools` array entries, ordered by tool name.
 */
/**
 * The placeholder the client sends to keep deferred tool loading active.
 *
 * It is an ordinary custom tool carrying `defer_loading`, not a built-in tool
 * type: the request carries the same `{name, description, input_schema,
 * defer_loading}` entry a caller could declare for itself. The description is
 * the client's own text, and the empty object schema is what it declares.
 */
export declare const DEFERRED_TOOL_PLACEHOLDER: {
    readonly name: "DeferredToolPlaceholder";
    readonly description: "Reserved placeholder that keeps deferred tool loading active; never call this tool.";
    readonly input_schema: {
        readonly type: "object";
        readonly properties: {};
    };
    readonly defer_loading: true;
};
export declare function toAnthropicTools(tools: readonly ToolSchema[]): ClaudeToolDefinition[];
/** Usage fields this translator reads. `thinking_tokens` requires beta `thinking-token-count-2026-05-13`. */
interface AnthropicUsage {
    input_tokens?: number;
    output_tokens?: number;
    cache_read_input_tokens?: number;
    cache_creation_input_tokens?: number;
    output_tokens_details?: {
        thinking_tokens?: number;
    };
}
/** The subset of Anthropic SSE event shapes this translator reads. */
/**
 * The server's own account of the context edits it applied to this response.
 *
 * Present only while the context-management beta is active and only when an edit ran, so an
 * absent field means the server applied nothing.
 */
export interface AnthropicContextManagement {
    readonly applied_edits?: readonly {
        readonly type?: string;
        readonly cleared_tool_uses?: number;
        readonly cleared_input_tokens?: number;
    }[];
}
export interface AnthropicStreamEvent {
    type: string;
    index?: number;
    message?: {
        usage?: AnthropicUsage;
    };
    content_block?: {
        type?: string;
        id?: string;
        name?: string;
        /** Opaque payload of a `redacted_thinking` block. Must be replayed verbatim. */
        data?: string;
        /** `server_tool_use` input: the start object's value, or what `input_json_delta` builds. */
        input?: unknown;
        /** `tool_search_tool_result` payload. Opaque; replayed verbatim. */
        content?: unknown;
        /** The `server_tool_use` call a `tool_search_tool_result` answers. */
        tool_use_id?: string;
    };
    delta?: {
        type?: string;
        text?: string;
        thinking?: string;
        /** Cryptographic signature the next request must send back unchanged. */
        signature?: string;
        partial_json?: string;
        stop_reason?: string;
    };
    usage?: AnthropicUsage;
    error?: {
        type?: string;
        message?: string;
    };
    /** The edits the server applied to this response, when it applied any. */
    context_management?: AnthropicContextManagement;
}
/**
 * Reports whether an in-band error event is a refusal the provider stated is
 * final.
 *
 * The status and headers that make a failure terminal belong to the response,
 * and an `error` event can arrive inside a 200, so the caller that owns the
 * response answers this; the event alone cannot.
 */
export type AnthropicRefusalProbe = (error: {
    type?: string;
    message?: string;
} | undefined) => boolean;
/**
 * Classify an Anthropic `error` event into a thrown LlmError.
 *
 * The retryable event types — a rate limit, and the overload and API failures
 * the provider states are transient — are classified as retryable by default,
 * because the usual cause is a window that reopens or a moment of congestion.
 * A refusal the provider will not accept a retry for arrives on those same
 * types, or on any type whose message names a billing or credit refusal, so the
 * caller's {@link AnthropicRefusalProbe} decides which of the two this one is;
 * without a probe the default stands.
 * @param error - the wire error object.
 * @param isRefusal - the caller's classification of this event against the
 *   response it arrived on.
 * @returns the mapped error.
 */
export declare function anthropicFailure(error: {
    type?: string;
    message?: string;
} | undefined, isRefusal?: AnthropicRefusalProbe): LlmError;
/**
 * Push-model Anthropic SSE translator: feed each parsed event object to
 * {@link push} and collect the emitted harness StreamChunks. Block indexes
 * are allocated in first-seen order; `usage` is emitted before the terminal
 * `finish`, and nothing is emitted after it. `error` events throw
 * {@link LlmError}.
 */
export declare class AnthropicStreamTranslator {
    private readonly requestId?;
    private readonly isRefusal?;
    private blocks;
    /** Replay entries aligned with harness block indexes. */
    private replay;
    /** Server-tool blocks captured for the next request, in arrival order. */
    private serverBlocks;
    /** Open server-tool blocks under assembly, by wire index. */
    private openServerBlocks;
    private nextIndex;
    private sawAnyBlock;
    private pendingUsage;
    private outputTokens;
    private stopReason;
    private usageEmitted;
    /** Set once `message_stop` produced the terminal finish chunk. */
    terminated: boolean;
    /**
     * @param requestId - the `request-id` response header this stream answers, recorded on
     *   the finish envelope so the request the model saw and the response it produced stay
     *   checkable from the session log. Omitted when the response carried no such header.
     * @param isRefusal - classifies an in-band `error` event against the response it
     *   arrived on. Omitted when the caller has no response to classify against.
     */
    constructor(requestId?: string | undefined, isRefusal?: AnthropicRefusalProbe | undefined);
    private open;
    /** Remember the signature or redacted payload for one closed block. */
    private remember;
    /** Start capturing a server-tool block, which occupies no harness block index. */
    private openServer;
    /** Finalize one captured server-tool block and keep it for the next request. */
    private closeServer;
    /** The edits the server reported applying to this response, when it reported any. */
    private appliedEdits;
    /**
     * Replay envelope for a successful response that carried something the adapter
     * must remember: thinking the next turn has to echo, the context edits the
     * server reported applying, a server-tool block the request has to carry back,
     * or the response's own request id. Omitted when the response carried none of
     * them, so a plain text response with no request id stays free of adapter
     * metadata.
     */
    private replayEnvelope;
    private emitUsage;
    /**
     * Process one parsed Anthropic SSE event.
     * @param event - the parsed event object.
     * @returns the StreamChunks this event produced (possibly none).
     */
    push(event: AnthropicStreamEvent): StreamChunk[];
}
/**
 * Consume an Anthropic SSE byte stream and yield harness StreamChunks.
 * @param stream - raw response body.
 * @param onActivity - transport-activity callback for the idle watchdog.
 * @param requestId - the response's `request-id` header, when it carried one.
 * @param isRefusal - classifies an in-band `error` event against the response it
 *   arrived on, so a refusal stated inside a 200 is not retried as a rate limit.
 * @returns the chunk stream; throws when the stream ends before `message_stop`.
 */
export declare function streamAnthropic(stream: ReadableStream<Uint8Array>, onActivity?: () => void, requestId?: string, isRefusal?: AnthropicRefusalProbe): AsyncGenerator<StreamChunk>;
export {};
