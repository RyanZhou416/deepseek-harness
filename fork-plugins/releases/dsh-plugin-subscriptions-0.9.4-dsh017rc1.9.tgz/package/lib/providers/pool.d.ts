/**
 * The pool adapter: same-subscription account routing, plus optional
 * configured tier extras. The picker is the union of every account's
 * catalog. A model listed by several accounts failovers; a model listed by
 * one account is pinned to it. Tiers are extra picker rows. Member
 * selection is sticky per session (so prompt caches survive) and optionally
 * quota-aware; failures fail over to the next member as long as no stream
 * chunk has been emitted.
 */
import { LlmAdapter } from '@deepseek-ai/dsh-llm';
import type { GenerateOptions, LlmModelInfo, LlmResolvedModelInfo, StreamChunk } from '@deepseek-ai/dsh-llm';
import type { ProviderId } from '../auth/store.js';
import type { AccountAwareAdapter } from './accounts.js';
import type { ConcretePoolMember, PoolDefinition, PoolMemberRef } from './pool-family.js';
import { PoolHealthRegistry } from './pool-health.js';
import type { PoolUsageTracker } from './pool-usage.js';
import type { PoolSchedulingPolicy } from './pool-scheduling.js';
/** Member-selection strategy: plain priority failover or quota-aware scheduling. */
export type PoolStrategy = 'priority' | 'quota_aware';
export interface PoolAdapterOptions {
    /** The live subscription adapters, by provider route. */
    adapters: Partial<Record<ProviderId, AccountAwareAdapter>>;
    health: PoolHealthRegistry;
    usage: PoolUsageTracker;
    strategy: PoolStrategy;
    /** A challenger must out-urgency the sticky member by this factor to take over. */
    switchMargin: number;
    /** Complete bounded preference and account-load policy, resolved at plugin load. */
    scheduling: PoolSchedulingPolicy;
    /** The default account of one provider (for config members omitting `account`). */
    defaultAccount: (provider: ProviderId) => Promise<string | undefined>;
    /** Resolve legacy account aliases before pool deduplication and cache identity. */
    resolveAccount?: (provider: ProviderId, account: string) => Promise<string>;
    /** Account pools (auto-aggregated plus config overrides), resolved lazily. */
    families: () => Promise<Map<string, PoolDefinition>>;
    /** User-configured extra picker entries (heterogeneous fallbacks), by pool id. */
    tiers: Record<string, PoolMemberRef[]>;
    /** Optional quota recovery for a depleted sticky account before choosing a replacement. */
    recoverQuota?: (member: ConcretePoolMember, signal?: AbortSignal) => Promise<boolean>;
    onWarn: (message: string) => void;
}
export declare class PoolAdapter extends LlmAdapter {
    private readonly options;
    /** sessionId|poolId → member key of the last member that served a chunk. */
    private readonly sticky;
    /** Outstanding pool attempts, including first-byte waits, shared across models of each account. */
    private readonly active;
    /** Messages already warned about — configuration diagnostics repeat every request otherwise. */
    private readonly warned;
    /**
     * Short-lived pools snapshot. `owns()` runs on every resolveModel — the
     * model picker issues one per entry — and pool assembly touches every
     * provider's catalog and account store, so recompute at most this often.
     * Auth changes bump {@link generation} so a stale snapshot cannot land.
     */
    private poolsCache;
    private poolsInflight;
    private generation;
    constructor(options: PoolAdapterOptions);
    /** Drop the pools snapshot so the next read reflects the current accounts. */
    invalidate(): void;
    /** Warn once per distinct message (pools() runs on every request). */
    private warnOnce;
    /** Drop members whose adapter is not registered (copy — caller state is shared). */
    private usable;
    /** Account pools (auto-aggregated plus config overrides) with usable members. */
    private familyPools;
    /** All pools (account pools merged with extra tiers) with usable members. */
    private pools;
    /** Recompute the pools snapshot (account pools merged with extra tiers). */
    private assemblePools;
    /**
     * Extra picker rows one provider lists (configured tiers). Account pools
     * reuse the catalog entry of the same wire id, so they are not listed
     * again — the picker stays one row per model in ChatGPT / Claude / ….
     */
    modelsForProvider(provider: ProviderId): Promise<LlmModelInfo[]>;
    /**
     * Whether `model` on `provider`'s route is served here (several accounts
     * fail over, one account is pinned, or a configured tier).
     */
    owns(provider: ProviderId, model: string): Promise<boolean>;
    /**
     * Resolve every member's account (config members may omit it to mean "the
     * default account") and drop members with no resolvable login. Duplicates
     * collapse — an explicitly pinned account and the default may coincide.
     */
    private concrete;
    /**
     * Resolve a pool model to the conservative INTERSECTION of its members'
     * capabilities: the smallest context window and output cap, the reasoning
     * efforts every member supports, and the modalities all of them accept —
     * so a request valid for the pool stays valid after a failover. Capability
     * metadata is account-specific, so every distinct member is resolved.
     */
    resolveModel(provider: string, model: string): Promise<LlmResolvedModelInfo>;
    stream(options: GenerateOptions): AsyncIterable<StreamChunk>;
    /**
     * Order the candidates for one request. Health filters both strategies;
     * `quota_aware` combines normalized urgency, bounded preferences, and
     * account load. Quota-full members stay in a last-resort band. A healthy
     * sticky member leads unless the same adjusted score beats its margin.
     */
    private select;
    /** Hold account load through first-byte wait, streaming, and iterator teardown. */
    private reserve;
    /** Pin the serving member to the session (with bounded memory). */
    private remember;
    /**
     * A still-available member's failure keeps its own retry facts. Only a fully
     * cooling pool carries a recovery hint from this pool's health records.
     */
    private exhausted;
}
