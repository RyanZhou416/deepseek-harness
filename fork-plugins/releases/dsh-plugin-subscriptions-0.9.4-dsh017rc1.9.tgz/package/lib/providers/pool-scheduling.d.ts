/** Bounded quota preferences and concurrent-account load for automatic pools. */
import z from '@deepseek-ai/schemastery';
import type { ConcretePoolMember } from './pool-family.js';
import type { MemberQuota } from './pool-usage.js';
/** Deployment-owned weights and lookahead windows for quota-aware selection. */
export interface PoolSchedulingPolicy {
    /** Short-window reset lookahead in milliseconds. */
    sessionResetHorizonMs: number;
    /** Weekly-window reset lookahead in milliseconds. */
    weeklyResetHorizonMs: number;
    /** Other-window reset lookahead in milliseconds. */
    otherResetHorizonMs: number;
    /** Maximum additive preference for an approaching Claude or ChatGPT reset. */
    resetWeight: number;
    /** ChatGPT remaining percentage at which gradual quota finishing begins; zero disables it. */
    codexDrainBelowPercent: number;
    /** Maximum additive ChatGPT finishing preference. */
    codexDrainWeight: number;
    /** Finite bonus for the existing fresh-week and expiring-reset-credit condition. */
    freshCreditWeight: number;
    /** Per-active-request penalty in the divisor 1 + weight * account load. */
    loadPenalty: number;
}
/** Schema also used by explicit policy resolution before constructing the pool. */
export declare const PoolSchedulingSchema: z<Schemastery.ObjectS<NoInfer<{
    sessionResetHorizonMs: z<number, number, "defined">;
    weeklyResetHorizonMs: z<number, number, "defined">;
    otherResetHorizonMs: z<number, number, "defined">;
    resetWeight: z<number, number, "defined">;
    codexDrainBelowPercent: z<number, number, "defined">;
    codexDrainWeight: z<number, number, "defined">;
    freshCreditWeight: z<number, number, "defined">;
    loadPenalty: z<number, number, "defined">;
}>>, Schemastery.ObjectT<NoInfer<{
    sessionResetHorizonMs: z<number, number, "defined">;
    weeklyResetHorizonMs: z<number, number, "defined">;
    otherResetHorizonMs: z<number, number, "defined">;
    resetWeight: z<number, number, "defined">;
    codexDrainBelowPercent: z<number, number, "defined">;
    codexDrainWeight: z<number, number, "defined">;
    freshCreditWeight: z<number, number, "defined">;
    loadPenalty: z<number, number, "defined">;
}>>, "plain">;
/**
 * Resolve and validate every scheduling choice before requests can use it.
 * @param input - optional deployment overrides.
 * @returns complete finite scheduling policy.
 */
export declare function resolvePoolScheduling(input?: Partial<PoolSchedulingPolicy>): PoolSchedulingPolicy;
/**
 * Score one member with bounded preferences in the same units as normalized urgency.
 * @param member - exact account/model being considered.
 * @param quota - current model-scoped quota facts.
 * @param maxUrgency - greatest raw urgency in this availability band.
 * @param active - outstanding requests on this provider/account across its model pools.
 * @param policy - validated deployment choices.
 * @param now - selection time shared by all candidate scores.
 * @returns nonnegative score; a band without usable urgency shares a unit baseline.
 */
export declare function poolSchedulingScore(member: ConcretePoolMember, quota: MemberQuota, maxUrgency: number, active: number, policy: PoolSchedulingPolicy, now: number): number;
