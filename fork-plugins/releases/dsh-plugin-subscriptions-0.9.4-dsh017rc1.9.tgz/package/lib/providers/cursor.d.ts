/**
 * Cursor subscription provider.
 *
 * Login uses `Cursor.auth.login({ store: null })` from `@cursor/sdk` and keeps
 * the minted user API key in this plugin's account map. Each request passes
 * that key explicitly, so the process never reads `CURSOR_API_KEY` or
 * `~/.cursor/sdk/auth.json`. The key does not refresh; an expired key asks
 * the user to log in again.
 *
 * A turn is one local `Agent` run in an empty working directory. Built-in
 * tools stay off. When the harness passed tools, the allowlist is only `mcp`,
 * which is the documented group that includes `local.customTools`. The first
 * custom-tool call cancels the run and is returned as a tool-call chunk; the
 * harness executes it and sends the result back on the next request.
 */
import { LlmAdapter } from '@deepseek-ai/dsh-llm';
import type { GenerateOptions, LlmModelInfo, LlmProviderInfo, LlmResolvedModelInfo, RequestMessage, StreamChunk } from '@deepseek-ai/dsh-llm';
import type { CursorSession } from '../auth/store.js';
import type { AttachmentStore } from '@deepseek-ai/dsh-attachment';
import type { CatalogPersistence, DiscoveredModel, FetchFn, ModelEntry, ProviderUsage } from './common.js';
import { AccountTokenManager } from './accounts.js';
import type { PoolAdapter } from './pool.js';
import type { RateLimitWait } from './rate-limit.js';
/** Default lifetime when login does not report `apiKeyExpiresAtMs`. The SDK default is 90 days. */
export declare const CURSOR_DEFAULT_TTL_MS: number;
/** How long before expiry a request attempts refresh. Cursor chat has no refresh grant. */
export declare const CURSOR_PREEMPT_MS = 60000;
/** One image attached to a Cursor `agent.send` call. `data` is base64. */
interface CursorSendImage {
    data: string;
    mimeType: string;
}
/** A browser login that has not been stored yet. */
export interface CursorLoginHandle {
    authorizeUrl: Promise<string>;
    done: Promise<CursorSession>;
    cancel(): void;
}
/** Transcript handed to one stateless Cursor agent run. */
export interface CursorTurn {
    system?: string;
    prompt: string;
    images: CursorSendImage[];
}
/**
 * Build a stored session. `refreshToken` repeats the API key because every
 * provider session in this plugin must carry a non-empty refresh token; Cursor
 * does not issue one.
 */
export declare function cursorSession(apiKey: string, expiresAt: number, email?: string, dashboard?: {
    accessToken: string;
    refreshToken: string;
}): CursorSession;
/**
 * Keep a key that has not expired. An expired key cannot be renewed.
 */
export declare function refreshCursor(session: CursorSession): Promise<CursorSession>;
/** True when the stored key can no longer be used and the account should be dropped. */
export declare function isCursorPermanentRefreshError(error: unknown): boolean;
/**
 * Start a browser login. The Settings page opens `authorizeUrl`. The same
 * browser handshake the SDK uses is polled until it releases dashboard
 * session tokens; those are kept, and one of them mints the chat API key.
 * Nothing is written to `~/.cursor/sdk/auth.json` or the Cursor IDE database.
 */
export declare function beginCursorLogin(): CursorLoginHandle;
/**
 * Refresh the dashboard access token when a usage query needs it.
 * The chat API key is left unchanged. A failed refresh does not log the
 * account out.
 */
export declare function refreshCursorDashboard(session: CursorSession, fetchFn?: FetchFn, signal?: AbortSignal): Promise<CursorSession>;
/**
 * Usage snapshot for one account. Callers invoke this from the settings
 * page, the manual refresh button, and pool member selection. There is no
 * timer. Accounts without dashboard tokens must log in again.
 */
export declare function fetchCursorUsage(session: CursorSession, fetchFn?: FetchFn, signal?: AbortSignal): Promise<ProviderUsage>;
/**
 * Return a session whose dashboard access token is still usable, refreshing
 * once when it is missing an expiry or inside the preempt window.
 */
/**
 * One on-demand usage read. Refreshes the dashboard token only when this
 * call finds it near expiry or rejected, then persists that update.
 */
export declare function loadCursorAccountUsage(session: CursorSession, fetchFn: FetchFn, signal: AbortSignal | undefined, persist: (session: CursorSession) => Promise<void>): Promise<ProviderUsage>;
export declare function cursorUsageSession(session: CursorSession, fetchFn?: FetchFn, signal?: AbortSignal): Promise<CursorSession>;
/** Render one harness request as a single Cursor prompt. Developer messages fail. */
export declare function renderCursorTurn(messages: readonly RequestMessage[], system: string | undefined): CursorTurn;
/** Constructor dependencies for {@link CursorAdapter}. */
export interface CursorAdapterOptions {
    models: readonly ModelEntry[];
    streamIdleTimeoutMs: number;
    tokens: AccountTokenManager<CursorSession>;
    pool?: () => PoolAdapter | undefined;
    discovery: boolean;
    onWarn?: (message: string) => void;
    resolveAttachments?: () => AttachmentStore | undefined;
    catalogStore?: CatalogPersistence;
    rateLimit?: RateLimitWait;
    defaultEffortOf?: (model: string) => string | undefined;
    /** Local context-window override from Settings. Capped by the catalog maximum. */
    contextWindowOf?: (model: string) => number | undefined;
    /** True when this session's Speed control is set to fast. */
    speedFor?: (sessionId: string | undefined, model: string) => boolean | Promise<boolean>;
}
export declare class CursorAdapter extends LlmAdapter {
    private readonly options;
    private readonly catalog;
    private readonly accountCatalogs;
    private catalogOwner;
    /** Context parameter values the registry rejected, keyed `account|model|value`. */
    private readonly rejectedCursorContext;
    constructor(options: CursorAdapterOptions);
    providerInfo(provider: string): LlmProviderInfo;
    providerRetryPolicy(provider: string): import("@deepseek-ai/dsh-llm").ResolvedRetryPolicy;
    clearAccountCatalog(account?: string): void;
    listModels(provider: string): Promise<readonly LlmModelInfo[]>;
    listOwnModels(provider: string, account?: string, signal?: AbortSignal): Promise<readonly LlmModelInfo[]>;
    resolveModel(provider: string, model: string): Promise<LlmResolvedModelInfo>;
    resolveOwnModel(provider: string, model: string): Promise<LlmResolvedModelInfo>;
    /** Advertised default and maximum context, when the catalog lists a context size. */
    contextLimits(model: string, account?: string): Promise<{
        default: number;
        max: number;
    } | undefined>;
    /** Whether the discovered catalog advertises Cursor's `fast` parameter. */
    supportsFastTier(model: string, account?: string): Promise<boolean>;
    /** Ids of every discovered model with a `fast` parameter. */
    fastCapableModels(): Promise<string[]>;
    stream(options: GenerateOptions): AsyncIterable<StreamChunk>;
    streamAccount(options: GenerateOptions, account?: string): AsyncIterable<StreamChunk>;
    private streamWithRetry;
    /** Remember a context value the registry refused, so the retry can step down. */
    private rejectCursorContext;
    private streamCore;
    private staticModels;
    private listed;
    private fetchCatalog;
    private discovered;
    private catalogFor;
}
/** One assistant or thinking block kept open across token-sized stream events. */
interface CursorProseBlock {
    index: number;
    kind: 'text' | 'reasoning';
    text: string;
}
interface CursorProse {
    block: CursorProseBlock | undefined;
}
/** Close the open prose block. Exported for the stream loop's end of turn. */
export declare function closeCursorProse(prose: CursorProse): StreamChunk[];
/** One row from `Cursor.models.list`. Fields match the SDK's `ModelListItem`. */
export interface CursorListedModel {
    id?: string;
    displayName?: string;
    description?: string;
    parameters?: Array<{
        id?: string;
        displayName?: string;
        values?: Array<{
            value?: string;
            displayName?: string;
        }>;
    }>;
    variants?: Array<{
        isDefault?: boolean;
        params?: Array<{
            id?: string;
            value?: string;
        }>;
    }>;
}
/** Parse a Cursor context parameter such as `300k` or `1m` into tokens. */
export declare function cursorContextTokens(value: string): number | undefined;
/** Map one `Cursor.models.list` row onto the harness catalog. */
export declare function cursorDiscoveredModel(model: CursorListedModel): DiscoveredModel | undefined;
/** Smallest advertised `context` value that covers `requested` tokens. */
export declare function cursorContextChoice(model: DiscoveredModel, requested: number | undefined): string | undefined;
/**
 * Context value to send. A value the registry already rejected is skipped.
 * When every covering value was rejected, the largest remaining smaller value
 * is used; when none remain, context is omitted.
 */
export declare function cursorContextAttempt(model: DiscoveredModel, requested: number | undefined, rejected: ReadonlySet<string>): string | undefined;
export declare function cursorRequestParams(model: DiscoveredModel, effort: string | undefined, fast: boolean | undefined, context?: string): {
    id: string;
    value: string;
}[] | undefined;
export {};
