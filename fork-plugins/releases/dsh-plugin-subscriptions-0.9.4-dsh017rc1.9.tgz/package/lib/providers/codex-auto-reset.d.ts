import type { ProviderUsage, ResetCreditConsumeResult, ResetCreditList } from './common.js';
/** Live dependencies; list and usage must bypass display caches and propagate failures. */
export interface CodexAutoResetOptions {
    enabled: () => boolean;
    accounts: () => Promise<string[]>;
    usage: (account: string, signal: AbortSignal) => Promise<ProviderUsage>;
    list: (account: string, signal: AbortSignal) => Promise<ResetCreditList>;
    consume: (account: string, credit: string, requestId: string, signal: AbortSignal) => Promise<ResetCreditConsumeResult>;
    changed: (account: string) => void;
    onWarn: (message: string) => void;
    /** Bound the optional post-spend usage refresh, including manual RPC calls. */
    confirmationTimeoutMs: number;
    /** Durable claims contain no credentials and survive an uncertain POST outcome. */
    claimsDirectory?: string;
}
/** Serializes automatic and manual spends in one Host; durable claims prevent repeat automatic spends. */
export declare class CodexAutoReset {
    private readonly options;
    private tail;
    private readonly directory;
    constructor(options: CodexAutoResetOptions);
    /**
     * Try to recover a rejected or quota-full account. A failed check preserves normal failover.
     * @param account - canonical ChatGPT account key.
     * @param signal - request cancellation, including the provider's request deadline.
     * @returns whether the caller can retry once with this account.
     */
    recover(account: string, signal: AbortSignal): Promise<boolean>;
    /**
     * Preserve manual confirmation and its caller-owned idempotency key while excluding concurrent auto spends.
     * @param account - canonical account key.
     * @param credit - selected credit id.
     * @param requestId - UUID reused by the manual dialog on retry.
     * @param signal - RPC cancellation.
     * @returns the provider's consume response.
     */
    manual(account: string, credit: string, requestId: string, signal: AbortSignal): Promise<ResetCreditConsumeResult>;
    /**
     * Rearm after an independent fresh usage poll confirms recovery. Pre-spend polls cannot clear newer claims.
     * @param account - canonical ChatGPT account key.
     * @param usage - successful uncached provider response.
     * @param startedAt - epoch milliseconds before that usage request began.
     * @returns completion of the serialized observation; filesystem failures retain the claim.
     */
    observeUsage(account: string, usage: ProviderUsage, startedAt: number): Promise<void>;
    private confirmUsage;
    private serial;
    private claimPath;
    private claim;
}
