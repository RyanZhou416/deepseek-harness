/**
 * Claude Code 2.1.280 wire construction for the claude provider.
 *
 * `buildClaudeCodeRequest` from `@tormentalabs/claude-code-wire-compat` owns
 * the pinned wire contract: the billing fingerprint and identity system
 * blocks, beta composition, correlation metadata (`user_id`), and the full
 * header plan. This module maps a resolved harness request onto that builder,
 * supplies the runtime identity and the per-session previous-request-id
 * chain, and keeps the pinned profile as the single source of the CLI
 * identity impersonated on the wire.
 */
import type { BuiltClaudeCodeRequest } from '@tormentalabs/claude-code-wire-compat';
import { LlmError } from '@deepseek-ai/dsh-llm';
import type { GenerateOptions } from '@deepseek-ai/dsh-llm';
import type { ClaudeSession } from '../auth/store.js';
import type { TranslatableMessage } from '../translate/resolved.js';
/** Pinned CLI identity this route presents on every subscription endpoint. */
export declare const CLAUDE_USER_AGENT: string;
/** The `thinking` object this module maps onto the wire (display is fixed here). */
export interface ClaudeWireThinking {
    type: 'enabled' | 'adaptive';
    budgetTokens?: number;
}
/**
 * The wire session id for one account span of a harness session.
 * @param account - the canonical account key serving this request.
 * @param harnessSessionId - the harness session the conversation belongs to.
 * @returns the stable `x-claude-code-session-id` for this (account, session).
 */
export declare function claudeWireSessionId(account: string, harnessSessionId: string): string;
/**
 * Record the response `request-id` the billing block of the next request in
 * this account's session chains as `cc_prev_req`. A response without the
 * header clears the chained id, matching the genuine client's continuity
 * commit.
 * @param account - the canonical account key the response belonged to.
 * @param sessionId - the harness session the response belongs to.
 * @param requestId - the `request-id` response header, or null when absent.
 */
export declare function rememberClaudeRequestId(account: string, sessionId: string, requestId: string | null): void;
/**
 * Map a wire-builder rejection onto a harness error. `INPUT_TOO_LARGE` goes
 * through the logged image-offload path; every other code names a request
 * this assembly layer must reject, so it surfaces as INVALID_REQUEST with
 * the wire code instead of a generic transport failure.
 * @param error - the thrown builder error.
 * @param messages - resolved images in wire order, for the offload mapping.
 * @returns the mapped LlmError, or undefined for a non-wire error.
 */
export declare function mapClaudeWireError(error: unknown, messages: readonly TranslatableMessage[]): LlmError | undefined;
/**
 * Build the pinned Claude Code wire request for one generate call.
 *
 * The stored session must already carry `deviceId` and `accountUuid`; the
 * adapter backfills both before calling here.
 * @param options - the harness generate request.
 * @param session - the account session whose token the request uses.
 * @param messages - conversation messages with images resolved.
 * @param maxTokens - the resolved output cap.
 * @param thinking - the wire thinking parameter, when the model takes one.
 * @param effort - the reasoning effort, when the model advertises efforts.
 * @param sessionId - the harness session id used as the Claude Code session identity.
 * @param account - the canonical account key owning this conversation's chain state.
 * @returns the built request: pinned URL, header plan, and serialized body.
 */
export declare function buildClaudeWireRequest(options: GenerateOptions, session: ClaudeSession, messages: readonly TranslatableMessage[], maxTokens: number, thinking: ClaudeWireThinking | undefined, effort: string | undefined, sessionId: string, account: string): Promise<BuiltClaudeCodeRequest>;
