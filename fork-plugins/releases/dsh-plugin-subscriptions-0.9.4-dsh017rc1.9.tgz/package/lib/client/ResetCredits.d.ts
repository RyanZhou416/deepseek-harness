import type { ConnectionHandle } from '@deepseek-ai/dsh-api-remotes/client';
import type { SubscriptionsKey } from './locales.js';
type Translate = (key: SubscriptionsKey, params?: Record<string, unknown>) => string;
export declare function ResetCredits({ rpc, t, accountKey, accountLabel, availableCount, onChanged, onDialogChange }: {
    rpc: ConnectionHandle['rpc'];
    t: Translate;
    accountKey: string;
    accountLabel: string;
    availableCount: number;
    /** Refetch usage after a spend so the windows and the count update together. */
    onChanged: () => void;
    /** Tell a parent popover that a modal is open, so outside-click dismiss does not unmount it. */
    onDialogChange?: (open: boolean) => void;
}): import("react").JSX.Element;
export {};
